package io.github.juloass.localization.json;

import com.google.gson.Strictness;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import io.github.juloass.localization.LocaleId;
import io.github.juloass.localization.LocalizationDiagnostic;
import io.github.juloass.localization.LocalizationValidationException;
import io.github.juloass.localization.TranslationCatalog;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/** Strict Gson-backed loader for flat UTF-8 translation catalogs. */
public final class JsonTranslationLoader {
    private JsonTranslationLoader() { }

    public static Builder builder(LocaleId referenceLocale) {
        return new Builder(referenceLocale);
    }

    public static final class Builder {
        private final LocaleId referenceLocale;
        private final List<Source> sources = new ArrayList<>();

        private Builder(LocaleId referenceLocale) {
            this.referenceLocale = Objects.requireNonNull(referenceLocale, "referenceLocale");
        }

        /** Adds a directory whose direct {@code *.json} children use canonical locale filenames. */
        public Builder addDirectory(String id, Path directory) {
            sources.add(new DirectorySource(requireId(id), Objects.requireNonNull(directory, "directory")));
            return this;
        }

        /**
         * Adds declared classpath locales. Callers must declare each locale because portable JAR class loaders
         * cannot enumerate arbitrary directory contents reliably.
         */
        public Builder addClasspath(String id, ClassLoader loader, String resourceDirectory,
                                    Collection<LocaleId> locales) {
            Objects.requireNonNull(loader, "loader");
            Objects.requireNonNull(locales, "locales");
            String directory = normalizeResourceDirectory(resourceDirectory);
            List<LocaleId> declared = locales.stream().map(value -> Objects.requireNonNull(value, "locale"))
                    .distinct().sorted().toList();
            sources.add(new ClasspathSource(requireId(id), loader, directory, declared));
            return this;
        }

        /** Adds one caller-supplied translation document for an explicit locale. */
        public Builder addInput(String id, LocaleId locale, TranslationInput input) {
            sources.add(new InputSource(
                    requireId(id),
                    Objects.requireNonNull(locale, "locale"),
                    Objects.requireNonNull(input, "input")));
            return this;
        }

        public TranslationCatalog load() {
            TranslationCatalog.Builder catalog = TranslationCatalog.builder(referenceLocale);
            List<LocalizationDiagnostic> diagnostics = new ArrayList<>();
            sources.stream().sorted(Comparator.comparing(Source::id)).forEach(source ->
                    source.load(catalog, diagnostics));

            TranslationCatalog result = null;
            try {
                result = catalog.build();
            } catch (LocalizationValidationException invalid) {
                diagnostics.addAll(invalid.diagnostics());
            }
            if (!diagnostics.isEmpty()) throw new LocalizationValidationException(diagnostics);
            return result;
        }

        private static String requireId(String id) {
            Objects.requireNonNull(id, "id");
            String normalized = id.strip();
            if (normalized.isEmpty()) throw new IllegalArgumentException("Source id must not be blank");
            return normalized;
        }
    }

    private sealed interface Source permits DirectorySource, ClasspathSource, InputSource {
        String id();
        void load(TranslationCatalog.Builder catalog, List<LocalizationDiagnostic> diagnostics);
    }

    private record DirectorySource(String id, Path directory) implements Source {
        @Override
        public void load(TranslationCatalog.Builder catalog, List<LocalizationDiagnostic> diagnostics) {
            Path normalized = directory.toAbsolutePath().normalize();
            if (!Files.isDirectory(normalized)) {
                diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, normalized.toString(), null,
                        "<document>", "Translation directory does not exist."));
                return;
            }
            try (var files = Files.list(normalized)) {
                files.filter(Files::isRegularFile)
                        .filter(path -> path.getFileName().toString().endsWith(".json"))
                        .sorted(Comparator.comparing(path -> path.toAbsolutePath().normalize().toString()))
                        .forEach(path -> loadPath(path, catalog, diagnostics));
            } catch (IOException failure) {
                diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, normalized.toString(), null,
                        "<document>", "Unable to list translation directory: " + failure.getMessage()));
            }
        }

        private static void loadPath(Path path, TranslationCatalog.Builder catalog,
                                     List<LocalizationDiagnostic> diagnostics) {
            String filename = path.getFileName().toString();
            String stem = filename.substring(0, filename.length() - ".json".length());
            LocaleId locale;
            try {
                locale = LocaleId.of(stem);
                if (!locale.value().equals(stem)) {
                    diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_LOCALE, path.toString(), locale,
                            "<document>", "Locale filename must use canonical form '" + locale + ".json'."));
                    return;
                }
            } catch (IllegalArgumentException invalid) {
                diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_LOCALE, path.toString(), null,
                        "<document>", invalid.getMessage()));
                return;
            }
            catalog.addLocale(locale);
            try (InputStream input = new BufferedInputStream(Files.newInputStream(path))) {
                parse(input, path.toString(), locale, catalog, diagnostics);
            } catch (IOException failure) {
                diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, path.toString(), locale,
                        "<document>", "Unable to read translation file: " + failure.getMessage()));
            }
        }
    }

    private record ClasspathSource(String id, ClassLoader loader, String directory,
                                   List<LocaleId> locales) implements Source {
        @Override
        public void load(TranslationCatalog.Builder catalog, List<LocalizationDiagnostic> diagnostics) {
            for (LocaleId locale : locales) {
                catalog.addLocale(locale);
                String resource = directory.isEmpty() ? locale + ".json" : directory + "/" + locale + ".json";
                List<URL> urls = new ArrayList<>();
                try {
                    Enumeration<URL> resources = loader.getResources(resource);
                    while (resources.hasMoreElements()) urls.add(resources.nextElement());
                } catch (IOException failure) {
                    diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, id + ":" + resource, locale,
                            "<document>", "Unable to enumerate classpath resources: " + failure.getMessage()));
                    continue;
                }
                urls.sort(Comparator.comparing(URL::toExternalForm));
                if (urls.isEmpty()) {
                    diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, id + ":" + resource, locale,
                            "<document>", "Declared classpath translation resource is missing."));
                    continue;
                }
                for (URL url : urls) {
                    try {
                        URLConnection connection = url.openConnection();
                        connection.setUseCaches(false);
                        try (InputStream input = new BufferedInputStream(connection.getInputStream())) {
                        parse(input, url.toExternalForm(), locale, catalog, diagnostics);
                        }
                    } catch (IOException failure) {
                        diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, url.toExternalForm(), locale,
                                "<document>", "Unable to read translation resource: " + failure.getMessage()));
                    }
                }
            }
        }
    }

    private record InputSource(String id, LocaleId locale, TranslationInput input) implements Source {
        @Override
        public void load(TranslationCatalog.Builder catalog, List<LocalizationDiagnostic> diagnostics) {
            catalog.addLocale(locale);
            try {
                InputStream opened = input.open();
                if (opened == null) {
                    diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, id, locale,
                            "<document>", "Translation input returned null."));
                    return;
                }
                try (InputStream stream = new BufferedInputStream(opened)) {
                    parse(stream, id, locale, catalog, diagnostics);
                }
            } catch (IOException | RuntimeException failure) {
                diagnostics.add(error(LocalizationDiagnostic.Code.SOURCE_ERROR, id, locale,
                        "<document>", "Unable to read translation input: " + failure.getMessage()));
            }
        }
    }

    private static void parse(InputStream input, String source, LocaleId locale, TranslationCatalog.Builder catalog,
                              List<LocalizationDiagnostic> diagnostics) {
        try (PushbackReader text = bomAwareReader(input); JsonReader reader = new JsonReader(text)) {
            reader.setStrictness(Strictness.STRICT);
            if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_JSON, source, locale, "<document>",
                        "Expected a JSON object at " + reader.getPath() + "."));
                reader.skipValue();
                return;
            }
            reader.beginObject();
            Set<String> seen = new HashSet<>();
            while (reader.hasNext()) {
                String key = reader.nextName();
                boolean duplicate = !seen.add(key);
                JsonToken valueToken = reader.peek();
                String value = null;
                if (valueToken == JsonToken.STRING) {
                    value = reader.nextString();
                } else {
                    diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_VALUE, source, locale, key,
                            "Expected a string value but found " + valueToken.name().toLowerCase() + " at "
                                    + reader.getPath() + "."));
                    reader.skipValue();
                }
                if (duplicate) {
                    diagnostics.add(error(LocalizationDiagnostic.Code.DUPLICATE_KEY, source, locale, key,
                            "Duplicate JSON field."));
                } else if (value != null) {
                    catalog.add(locale, source, key, value);
                }
            }
            reader.endObject();
            if (reader.peek() != JsonToken.END_DOCUMENT) {
                diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_JSON, source, locale, "<document>",
                        "Unexpected content after the root object at " + reader.getPath() + "."));
            }
        } catch (IOException | IllegalStateException failure) {
            diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_JSON, source, locale, "<document>",
                    "Invalid JSON: " + failure.getMessage()));
        }
    }

    private static PushbackReader bomAwareReader(InputStream input) throws IOException {
        PushbackReader reader = new PushbackReader(new InputStreamReader(input, StandardCharsets.UTF_8), 1);
        int first = reader.read();
        if (first != -1 && first != '\uFEFF') reader.unread(first);
        return reader;
    }

    private static String normalizeResourceDirectory(String directory) {
        if (directory == null || directory.isBlank()) return "";
        String normalized = directory.replace('\\', '/');
        while (normalized.startsWith("/")) normalized = normalized.substring(1);
        while (normalized.endsWith("/")) normalized = normalized.substring(0, normalized.length() - 1);
        if (normalized.equals("..") || normalized.startsWith("../") || normalized.contains("/../")) {
            throw new IllegalArgumentException("Resource directory must not contain '..': " + directory);
        }
        return normalized;
    }

    private static LocalizationDiagnostic error(LocalizationDiagnostic.Code code, String source,
                                                LocaleId locale, String key, String message) {
        return new LocalizationDiagnostic(LocalizationDiagnostic.Severity.ERROR, code,
                source, locale, key, message);
    }
}

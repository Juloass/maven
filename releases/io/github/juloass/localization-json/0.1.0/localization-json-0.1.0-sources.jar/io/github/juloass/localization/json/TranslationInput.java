package io.github.juloass.localization.json;

import java.io.IOException;
import java.io.InputStream;

/** Opens one repeatable translation input without exposing its storage system. */
@FunctionalInterface
public interface TranslationInput {
    InputStream open() throws IOException;
}

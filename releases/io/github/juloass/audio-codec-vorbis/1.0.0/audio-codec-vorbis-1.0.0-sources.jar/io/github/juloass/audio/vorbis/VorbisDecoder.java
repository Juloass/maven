package io.github.juloass.audio.vorbis;

import com.jcraft.jorbis.Info;
import com.jcraft.jorbis.JOrbisException;
import com.jcraft.jorbis.VorbisFile;
import io.github.juloass.audio.AudioDecodeLimits;
import io.github.juloass.audio.AudioDecoder;
import io.github.juloass.audio.AudioFormat;
import io.github.juloass.audio.AudioStream;
import io.github.juloass.audio.ChannelLayout;
import io.github.juloass.audio.EncodedAudioSource;
import io.github.juloass.audio.PcmData;
import org.gagravarr.ogg.OggFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Objects;
import java.util.OptionalLong;

/** Pure Java decoder for single-stream mono and stereo Ogg Vorbis audio. */
public final class VorbisDecoder implements AudioDecoder {
    @Override
    public PcmData decode(InputStream input, AudioDecodeLimits limits) throws IOException {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(limits, "limits");
        byte[] encoded = readBounded(input, limits.maximumEncodedBytes());
        validateContainer(encoded);
        try (VorbisAudioStream stream = new VorbisAudioStream(encoded, limits)) {
            int channels = stream.format().channelLayout().channels();
            int capacityFrames = (int) Math.min(stream.frameCount().orElse(4096), limits.maximumFrames());
            float[] samples = new float[Math.max(channels, capacityFrames * channels)];
            int frames = 0;
            while (true) {
                if (frames == samples.length / channels) {
                    int nextFrames = Math.min(Math.toIntExact(limits.maximumFrames()), Math.max(frames + 1, frames * 2));
                    if (nextFrames == frames) throw malformed("decoded frame count exceeds the configured limit");
                    samples = Arrays.copyOf(samples, nextFrames * channels);
                }
                int read = stream.readFrames(samples, frames, samples.length / channels - frames);
                if (read == 0) break;
                frames += read;
            }
            if (frames == 0) throw malformed("audio contains no frames");
            return new PcmData(stream.format(), Arrays.copyOf(samples, frames * channels));
        }
    }

    @Override
    public AudioStream stream(EncodedAudioSource source, AudioDecodeLimits limits) throws IOException {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(limits, "limits");
        byte[] encoded;
        try (InputStream input = source.openStream()) {
            encoded = readBounded(input, limits.maximumEncodedBytes());
        }
        validateContainer(encoded);
        return new VorbisAudioStream(encoded, limits);
    }

    private static void validateContainer(byte[] encoded) throws IOException {
        try (OggFile ogg = new OggFile(new ByteArrayInputStream(encoded));
             org.gagravarr.vorbis.VorbisFile vorbis = new org.gagravarr.vorbis.VorbisFile(ogg)) {
            if (vorbis.getInfo().getNumChannels() < 1) throw malformed("invalid channel count");
            while (vorbis.getNextAudioPacket() != null) {
                // Reading every packet makes truncation and malformed page failures deterministic.
            }
        } catch (IOException | RuntimeException exception) {
            if (exception instanceof IOException io && io.getMessage() != null && io.getMessage().startsWith("Malformed Ogg Vorbis:")) throw io;
            throw malformed("invalid Ogg container", exception);
        }
    }

    private static byte[] readBounded(InputStream input, long maximum) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        long total = 0;
        for (int read; (read = input.read(buffer)) >= 0;) {
            if (read == 0) continue;
            total += read;
            if (total > maximum) throw malformed("encoded audio exceeds the configured byte limit");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private static IOException malformed(String message) { return new IOException("Malformed Ogg Vorbis: " + message); }
    private static IOException malformed(String message, Throwable cause) { return new IOException("Malformed Ogg Vorbis: " + message, cause); }

    private static final class VorbisAudioStream implements AudioStream {
        private static final Method READ = findReadMethod();
        private final byte[] encoded;
        private final AudioDecodeLimits limits;
        private VorbisFile file;
        private AudioFormat format;
        private long frameCount;
        private long position;
        private boolean closed;

        private VorbisAudioStream(byte[] encoded, AudioDecodeLimits limits) throws IOException {
            this.encoded = encoded;
            this.limits = limits;
            reopen();
        }

        @Override public AudioFormat format() { return format; }
        @Override public OptionalLong frameCount() { return frameCount >= 0 ? OptionalLong.of(frameCount) : OptionalLong.empty(); }
        @Override public long positionFrame() { return position; }

        @Override
        public int readFrames(float[] destination, int offsetFrames, int maximumFrames) throws IOException {
            ensureOpen();
            Objects.requireNonNull(destination, "destination");
            if (offsetFrames < 0 || maximumFrames < 0) throw new IndexOutOfBoundsException("frame bounds must be non-negative");
            int channels = format.channelLayout().channels();
            int offsetSamples = Math.multiplyExact(offsetFrames, channels);
            int maximumSamples = Math.multiplyExact(maximumFrames, channels);
            if (offsetSamples > destination.length || maximumSamples > destination.length - offsetSamples) {
                throw new IndexOutOfBoundsException("destination does not contain the requested frame range");
            }
            if (maximumFrames == 0) return 0;
            byte[] pcm16 = new byte[maximumFrames * channels * 2];
            int[] bitstream = new int[1];
            int bytes = invokeRead(file, pcm16, pcm16.length, bitstream);
            if (bytes < 0) throw malformed("decoder reported a damaged packet");
            if (bytes == 0) return 0;
            if (bitstream[0] != 0) throw malformed("chained logical streams are not supported");
            int frameBytes = channels * 2;
            if (bytes % frameBytes != 0) throw malformed("decoder returned a partial frame");
            int frames = bytes / frameBytes;
            if (position + frames > limits.maximumFrames()) throw malformed("decoded frame count exceeds the configured limit");
            ByteBuffer input = ByteBuffer.wrap(pcm16, 0, bytes).order(ByteOrder.LITTLE_ENDIAN);
            for (int index = 0; index < frames * channels; index++) destination[offsetSamples + index] = input.getShort() / 32768.0f;
            position += frames;
            return frames;
        }

        @Override
        public void seekFrame(long target) throws IOException {
            ensureOpen();
            if (target < 0 || target > limits.maximumFrames() || frameCount >= 0 && target > frameCount) {
                throw new IllegalArgumentException("frame is outside the stream");
            }
            if (target < position) reopen();
            int channels = format.channelLayout().channels();
            float[] discard = new float[4096 * channels];
            while (position < target) {
                int read = readFrames(discard, 0, (int) Math.min(4096, target - position));
                if (read == 0) throw new IOException("seek target is beyond the decoded stream");
            }
        }

        @Override
        public void close() throws IOException {
            if (!closed) {
                closed = true;
                file.close();
            }
        }

        private void reopen() throws IOException {
            if (file != null) file.close();
            try {
                file = new VorbisFile(new ByteArrayInputStream(encoded), null, 0);
            } catch (JOrbisException exception) {
                throw malformed("decoder rejected the stream", exception);
            }
            if (file.streams() != 1) throw malformed("chained logical streams are not supported");
            Info info = file.getInfo(0);
            if (info == null || info.channels < 1 || info.channels > 2) throw malformed("only mono and stereo streams are supported");
            if (info.rate < 1 || info.rate > limits.maximumSampleRate()) throw malformed("sample rate exceeds the configured limit");
            long total = file.pcm_total(0);
            if (total > limits.maximumFrames()) throw malformed("decoded frame count exceeds the configured limit");
            format = new AudioFormat(info.rate, ChannelLayout.forChannels(info.channels));
            frameCount = total;
            position = 0;
        }

        private void ensureOpen() throws IOException { if (closed) throw new IOException("audio stream is closed"); }

        private static Method findReadMethod() {
            try {
                Method method = VorbisFile.class.getDeclaredMethod("read", byte[].class, int.class, int.class, int.class, int.class, int[].class);
                method.setAccessible(true);
                return method;
            } catch (ReflectiveOperationException exception) {
                throw new ExceptionInInitializerError(exception);
            }
        }

        private static int invokeRead(VorbisFile file, byte[] target, int length, int[] bitstream) throws IOException {
            try {
                return (int) READ.invoke(file, target, length, 0, 2, 1, bitstream);
            } catch (IllegalAccessException exception) {
                throw new IOException("Vorbis decoder access failed", exception);
            } catch (InvocationTargetException exception) {
                Throwable cause = exception.getCause();
                if (cause instanceof IOException io) throw io;
                throw new IOException("Vorbis decoder failed", cause);
            }
        }
    }
}

/**
 * Immutable namespaced identifiers with one canonical text form.
 */
package io.github.juloass.identifier;

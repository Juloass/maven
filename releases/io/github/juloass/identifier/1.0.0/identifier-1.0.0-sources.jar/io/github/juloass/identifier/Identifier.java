package io.github.juloass.identifier;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * An immutable logical name in {@code namespace:path/segments} form.
 *
 * <p>The namespace and every path segment contain only lowercase ASCII
 * letters, digits, {@code _}, or {@code -}. The constructor and factory
 * methods validate input without changing it.</p>
 *
 * @param namespace the non-empty namespace
 * @param path the non-empty slash-separated path
 */
public record Identifier(String namespace, String path) implements Comparable<Identifier> {
    private static final Pattern NAMESPACE_PATTERN = Pattern.compile("[a-z0-9_-]+");
    private static final Pattern PATH_PATTERN = Pattern.compile("[a-z0-9_-]+(?:/[a-z0-9_-]+)*");
    private static final Pattern SEGMENT_PATTERN = Pattern.compile("[a-z0-9_-]+");
    private static final String EXPECTED_FORM = "namespace:path/segments";

    /**
     * Creates and validates an identifier.
     *
     * @throws NullPointerException if a component is {@code null}
     * @throws IllegalArgumentException if a component is not canonical
     */
    public Identifier {
        namespace = requireMatch(namespace, "namespace", NAMESPACE_PATTERN);
        path = requireMatch(path, "path", PATH_PATTERN);
    }

    /**
     * Creates an identifier from separate components.
     *
     * @param namespace the namespace
     * @param path the slash-separated path
     * @return the validated identifier
     * @throws NullPointerException if a component is {@code null}
     * @throws IllegalArgumentException if a component is not canonical
     */
    public static Identifier of(String namespace, String path) {
        return new Identifier(namespace, path);
    }

    /**
     * Parses one complete canonical identifier.
     *
     * @param value the complete identifier text
     * @return the parsed identifier
     * @throws NullPointerException if {@code value} is {@code null}
     * @throws IllegalArgumentException if {@code value} is not canonical
     */
    public static Identifier parse(String value) {
        Objects.requireNonNull(value, "value");
        int separator = value.indexOf(':');
        if (separator <= 0 || separator == value.length() - 1
                || value.indexOf(':', separator + 1) >= 0) {
            throw new IllegalArgumentException(
                    "Invalid identifier '" + value + "': expected " + EXPECTED_FORM);
        }
        return of(value.substring(0, separator), value.substring(separator + 1));
    }

    /**
     * Tries to parse one complete canonical identifier.
     *
     * @param value the candidate text, or {@code null}
     * @return the identifier, or an empty value for invalid input
     */
    public static Optional<Identifier> tryParse(String value) {
        if (value == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(parse(value));
        } catch (IllegalArgumentException exception) {
            return Optional.empty();
        }
    }

    /**
     * Tests whether text is one complete canonical identifier.
     *
     * @param value the candidate text, or {@code null}
     * @return {@code true} only for canonical identifier text
     */
    public static boolean isValid(String value) {
        return tryParse(value).isPresent();
    }

    /**
     * Returns the complete canonical text.
     *
     * @return {@code namespace:path}
     */
    public String value() {
        return namespace + ':' + path;
    }

    /**
     * Returns the immutable path segments in their source order.
     *
     * @return the path segments
     */
    public List<String> pathSegments() {
        return List.of(path.split("/"));
    }

    /**
     * Returns the final path segment.
     *
     * @return the final path segment
     */
    public String lastPathSegment() {
        int separator = path.lastIndexOf('/');
        return separator < 0 ? path : path.substring(separator + 1);
    }

    /**
     * Returns the identifier above this path.
     *
     * @return the parent, or an empty value for a single-segment path
     */
    public Optional<Identifier> parent() {
        int separator = path.lastIndexOf('/');
        return separator < 0
                ? Optional.empty()
                : Optional.of(of(namespace, path.substring(0, separator)));
    }

    /**
     * Appends exactly one path segment.
     *
     * @param segment the segment to append
     * @return the child identifier
     * @throws NullPointerException if {@code segment} is {@code null}
     * @throws IllegalArgumentException if {@code segment} is not canonical
     */
    public Identifier child(String segment) {
        requireMatch(segment, "path segment", SEGMENT_PATTERN);
        return of(namespace, path + '/' + segment);
    }

    /**
     * Compares the namespace first and the path second.
     *
     * @param other the identifier to compare
     * @return the lexical comparison result
     * @throws NullPointerException if {@code other} is {@code null}
     */
    @Override
    public int compareTo(Identifier other) {
        Objects.requireNonNull(other, "other");
        int namespaceResult = namespace.compareTo(other.namespace);
        return namespaceResult != 0 ? namespaceResult : path.compareTo(other.path);
    }

    /**
     * Returns the complete canonical text.
     *
     * @return {@code namespace:path}
     */
    @Override
    public String toString() {
        return value();
    }

    private static String requireMatch(String value, String name, Pattern pattern) {
        Objects.requireNonNull(value, name);
        if (!pattern.matcher(value).matches()) {
            throw new IllegalArgumentException(
                    "Invalid identifier " + name + " '" + value + "': expected " + EXPECTED_FORM);
        }
        return value;
    }
}

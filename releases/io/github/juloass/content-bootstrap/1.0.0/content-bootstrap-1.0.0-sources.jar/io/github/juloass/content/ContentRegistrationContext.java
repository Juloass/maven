package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.registry.RegistryBuilder;
import io.github.juloass.registry.RegistryView;
import io.github.juloass.resource.pack.ResourcePackCandidate;
import io.github.juloass.resource.ResourceType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Registration-only API exposed to content modules. */
public final class ContentRegistrationContext {
    private final RegistryLifecycleController lifecycle =
            new RegistryLifecycleController();
    private final LinkedHashMap<ContentRegistryDefinition<?>, RegistryBuilder<?>>
            registries = new LinkedHashMap<>();
    private final LinkedHashMap<ContentRegistryDefinition<?>, Set<Identifier>>
            processorOwners = new LinkedHashMap<>();
    private final LinkedHashMap<Identifier, ContentBootstrapTask> tasks =
            new LinkedHashMap<>();
    private final ArrayList<String> diagnostics = new ArrayList<>();

    public <T> RegistryBuilder<T> declareRegistry(
            ContentRegistryDefinition<T> definition,
            String... processorTaskIds
    ) {
        lifecycle.require(RegistryLifecycle.REGISTERING, "declare registry");
        Set<Identifier> owners = Arrays.stream(processorTaskIds)
                .map(Identifier::parse)
                .collect(java.util.stream.Collectors.toUnmodifiableSet());
        RegistryBuilder<T> registry = definition.newBuilder();
        if (registries.putIfAbsent(definition, registry) != null) {
            throw new IllegalArgumentException(
                    "Duplicate registry key " + definition.id());
        }
        processorOwners.put(definition, owners);
        return registry;
    }

    @SuppressWarnings("unchecked")
    public <T> RegistryView<T> registry(
            ContentRegistryDefinition<T> definition
    ) {
        RegistryBuilder<?> registry = registries.get(definition);
        if (registry == null) {
            throw new IllegalArgumentException(
                    "Registry is not declared: " + definition.id());
        }
        return (RegistryView<T>) registry;
    }

    public void task(ContentBootstrapTask task) {
        lifecycle.require(
                RegistryLifecycle.REGISTERING, "register bootstrap task");
        ContentBootstrapTask previous = tasks.putIfAbsent(task.id(), task);
        if (previous != null) {
            throw new IllegalArgumentException(
                    "Duplicate bootstrap task id " + task.id());
        }
    }

    public void diagnostic(String diagnostic) {
        if (diagnostic != null && !diagnostic.isBlank()) {
            diagnostics.add(diagnostic);
        }
    }

    ContentBootstrapPlan seal(List<ResourcePackCandidate> packs, List<ResourceType<?>> types) {
        return new ContentBootstrapPlan(
                lifecycle,
                packs,
                types,
                registries,
                processorOwners,
                tasks,
                diagnostics);
    }

    Map<ContentRegistryDefinition<?>, RegistryBuilder<?>> registries() {
        return registries;
    }

    List<ContentBootstrapTask> tasks() {
        return List.copyOf(tasks.values());
    }
}

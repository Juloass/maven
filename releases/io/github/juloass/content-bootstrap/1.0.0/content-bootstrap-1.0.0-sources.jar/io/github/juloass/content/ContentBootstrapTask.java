package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/** Tofuxia metadata and action for one content bootstrap task. */
public record ContentBootstrapTask(
        Identifier id,
        BootstrapStage stage,
        String label,
        float weight,
        Set<Identifier> dependencies,
        Set<ExecutionProfile> profiles,
        Action action
) {
    public ContentBootstrapTask {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(stage, "stage");
        if (label == null || label.isBlank()) {
            throw new IllegalArgumentException(
                    "Bootstrap task label is blank: " + id);
        }
        if (!Float.isFinite(weight) || weight <= 0) {
            throw new IllegalArgumentException("Invalid task weight: " + id);
        }
        dependencies = Set.copyOf(new LinkedHashSet<>(
                Objects.requireNonNull(dependencies, "dependencies")));
        profiles = Set.copyOf(new LinkedHashSet<>(
                Objects.requireNonNull(profiles, "profiles")));
        if (profiles.isEmpty()) {
            throw new IllegalArgumentException(
                    "Bootstrap task has no execution profile: " + id);
        }
        Objects.requireNonNull(action, "action");
    }

    public static ContentBootstrapTask of(
            String id,
            BootstrapStage stage,
            String label,
            float weight,
            Set<String> dependencies,
            Set<ExecutionProfile> profiles,
            Action action
    ) {
        LinkedHashSet<Identifier> parsedDependencies = new LinkedHashSet<>();
        dependencies.forEach(value ->
                parsedDependencies.add(Identifier.parse(value)));
        return new ContentBootstrapTask(
                Identifier.parse(id),
                stage,
                label,
                weight,
                parsedDependencies,
                profiles,
                action);
    }

    @FunctionalInterface
    public interface Action {
        void run(ContentProcessingContext context) throws Exception;
    }
}
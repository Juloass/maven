package io.github.juloass.content;

/** Broad loading-screen group. Individual processors use dynamic task ids and labels. */
public enum BootstrapStage {
    CONFIGURATION,
    CONTENT_REGISTRATION,
    CONTENT_PROCESSING,
    RENDERER,
    NETWORK,
    SCENES
}

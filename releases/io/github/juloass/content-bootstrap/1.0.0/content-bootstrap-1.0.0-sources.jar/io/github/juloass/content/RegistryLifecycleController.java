package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;

final class RegistryLifecycleController {
    private RegistryLifecycle lifecycle = RegistryLifecycle.REGISTERING;
    private Identifier currentTask;

    RegistryLifecycle lifecycle() {
        return lifecycle;
    }

    Identifier currentTask() {
        return currentTask;
    }

    void beginProcessing() {
        require(RegistryLifecycle.REGISTERING, "seal registration");
        lifecycle = RegistryLifecycle.PROCESSING;
    }

    void beginTask(Identifier task) {
        require(RegistryLifecycle.PROCESSING, "begin task");
        if (currentTask != null) throw new IllegalStateException("Bootstrap task already active: " + currentTask);
        currentTask = task;
    }

    void endTask(Identifier task) {
        if (!task.equals(currentTask)) throw new IllegalStateException("Bootstrap task ownership mismatch");
        currentTask = null;
    }

    void freeze() {
        require(RegistryLifecycle.PROCESSING, "freeze registries");
        if (currentTask != null) throw new IllegalStateException("Cannot freeze during task " + currentTask);
        lifecycle = RegistryLifecycle.FROZEN;
    }

    void require(RegistryLifecycle expected, String operation) {
        if (lifecycle != expected) {
            throw new IllegalStateException("Cannot " + operation + " while registries are " + lifecycle);
        }
    }
}

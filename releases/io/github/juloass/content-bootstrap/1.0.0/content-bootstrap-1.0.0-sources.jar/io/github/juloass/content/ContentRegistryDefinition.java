package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.registry.RegistryBuilder;
import io.github.juloass.registry.RegistryKey;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/** Tofuxia metadata for one shared registry. */
public record ContentRegistryDefinition<T>(
        RegistryKey<T> key,
        FingerprintScope fingerprintScope,
        Function<T, String> fingerprintEncoder,
        List<Identifier> leadingIds
) implements Comparable<ContentRegistryDefinition<?>> {
    public ContentRegistryDefinition {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(fingerprintScope, "fingerprintScope");
        Objects.requireNonNull(fingerprintEncoder, "fingerprintEncoder");
        leadingIds = List.copyOf(Objects.requireNonNull(leadingIds, "leadingIds"));
    }

    public Identifier id() {
        return key.id();
    }

    public Class<T> valueType() {
        return key.valueType();
    }

    public RegistryBuilder<T> newBuilder() {
        Comparator<Identifier> order = Comparator
                .comparingInt((Identifier id) -> {
                    int leading = leadingIds.indexOf(id);
                    return leading >= 0 ? leading : leadingIds.size();
                })
                .thenComparing(Comparator.naturalOrder());
        return RegistryBuilder.create(key, order);
    }

    public static <T> ContentRegistryDefinition<T> of(
            String id,
            Class<T> type,
            FingerprintScope scope,
            Function<T, String> encoder
    ) {
        return new ContentRegistryDefinition<>(
                RegistryKey.of(id, type), scope, encoder, List.of());
    }

    public static <T> ContentRegistryDefinition<T> of(
            String id,
            Class<T> type,
            FingerprintScope scope,
            Function<T, String> encoder,
            List<Identifier> leadingIds
    ) {
        return new ContentRegistryDefinition<>(
                RegistryKey.of(id, type), scope, encoder, leadingIds);
    }

    public static <T> ContentRegistryDefinition<T> diagnostic(
            String id,
            Class<T> type
    ) {
        return of(id, type, FingerprintScope.NONE, String::valueOf);
    }

    @Override
    public int compareTo(ContentRegistryDefinition<?> other) {
        return key.compareTo(other.key);
    }
}
package io.github.juloass.content;

/** Enforced lifecycle shared by every registry participating in one bootstrap. */
public enum RegistryLifecycle {
    REGISTERING,
    PROCESSING,
    FROZEN
}

package io.github.juloass.content;

import io.github.juloass.registry.RegistrySet;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public record ContentBootstrapResult(
        RegistrySet registries,
        List<String> diagnostics,
        String gameplayFingerprint,
        Optional<String> clientAssetFingerprint,
        Map<ResourceDomain, Map<ResourcePath, Integer>> resourceReadCounts
) {
    public ContentBootstrapResult {
        diagnostics = List.copyOf(diagnostics);
        clientAssetFingerprint = clientAssetFingerprint == null
                ? Optional.empty() : clientAssetFingerprint;
        EnumMap<ResourceDomain, Map<ResourcePath, Integer>> copy =
                new EnumMap<>(ResourceDomain.class);
        resourceReadCounts.forEach((domain, counts) ->
                copy.put(domain, Map.copyOf(counts)));
        resourceReadCounts = Map.copyOf(copy);
    }

    public Map<ResourcePath, Integer> readCounts(ResourceDomain domain) {
        return resourceReadCounts.getOrDefault(domain, Map.of());
    }
}
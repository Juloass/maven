package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;

public final class ContentBootstrapFailure extends RuntimeException {
    private final Identifier taskId;
    private final String taskLabel;

    ContentBootstrapFailure(ContentBootstrapTask task, Throwable cause) {
        super("Bootstrap task " + task.id() + " (" + task.label()
                + ") failed: " + readable(cause), cause);
        this.taskId = task.id();
        this.taskLabel = task.label();
    }

    public Identifier taskId() {
        return taskId;
    }

    public String taskLabel() {
        return taskLabel;
    }

    private static String readable(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null) root = root.getCause();
        return root.getClass().getSimpleName()
                + (root.getMessage() == null ? "" : ": " + root.getMessage());
    }
}
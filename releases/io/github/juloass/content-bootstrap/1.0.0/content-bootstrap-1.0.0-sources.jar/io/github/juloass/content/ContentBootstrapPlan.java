package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.registry.Registry;
import io.github.juloass.registry.RegistryBuilder;
import io.github.juloass.registry.RegistryEntry;
import io.github.juloass.registry.RegistrySet;
import io.github.juloass.taskgraph.Task;
import io.github.juloass.taskgraph.TaskGraph;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.ResourceType;
import io.github.juloass.resource.pack.ResourceManager;
import io.github.juloass.resource.pack.ResourcePackCandidate;
import io.github.juloass.resource.pack.ResourceSnapshot;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Validated content tasks and registry state for one execution. */
public final class ContentBootstrapPlan {
    private final RegistryLifecycleController lifecycle;
    private final List<ResourcePackCandidate> resourcePacks;
    private final List<ResourceType<?>> resourceTypes;
    private ResourceManager assetManager;
    private ResourceManager dataManager;
    private ResourceSnapshot assetSnapshot;
    private ResourceSnapshot dataSnapshot;
    private ContentResources assets;
    private ContentResources data;
    private final Map<ContentRegistryDefinition<?>, RegistryBuilder<?>>
            registries;
    private final Map<ContentRegistryDefinition<?>, Set<Identifier>>
            processorOwners;
    private final List<ContentBootstrapTask> tasks;
    private final ArrayList<String> diagnostics;
    private boolean started;

    ContentBootstrapPlan(
            RegistryLifecycleController lifecycle,
            List<ResourcePackCandidate> resourcePacks,
            List<ResourceType<?>> resourceTypes,
            Map<ContentRegistryDefinition<?>, RegistryBuilder<?>> registries,
            Map<ContentRegistryDefinition<?>, Set<Identifier>> processorOwners,
            Map<Identifier, ContentBootstrapTask> tasks,
            List<String> diagnostics
    ) {
        this.lifecycle = lifecycle;
        this.resourcePacks = List.copyOf(resourcePacks);
        this.resourceTypes = List.copyOf(resourceTypes);
        this.registries = Map.copyOf(new LinkedHashMap<>(registries));
        this.processorOwners =
                Map.copyOf(new LinkedHashMap<>(processorOwners));
        this.tasks = List.copyOf(tasks.values());
        this.diagnostics = new ArrayList<>(diagnostics);
    }

    public static Builder builder() {
        return new Builder();
    }

    public synchronized ContentBootstrapSession start(
            ExecutionProfile profile
    ) {
        if (started) {
            throw new IllegalStateException(
                    "Content bootstrap plan has already started");
        }
        LinkedHashMap<Identifier, ContentBootstrapTask> selected =
                selectedTasks(profile);
        if (selected.isEmpty()) {
            throw new IllegalStateException(
                    "No bootstrap tasks selected for " + profile);
        }
        TaskGraph<ContentBootstrapSession> graph = taskGraph(selected);
        openResources(profile);
        started = true;
        lifecycle.beginProcessing();
        return new ContentBootstrapSession(this, profile, selected, graph);
    }

    public List<ContentBootstrapTask> orderedTasks(
            ExecutionProfile profile
    ) {
        LinkedHashMap<Identifier, ContentBootstrapTask> selected =
                selectedTasks(profile);
        return taskGraph(selected).tasks().stream()
                .map(task -> selected.get(task.id()))
                .toList();
    }

    private LinkedHashMap<Identifier, ContentBootstrapTask> selectedTasks(
            ExecutionProfile profile
    ) {
        LinkedHashMap<Identifier, ContentBootstrapTask> selected =
                new LinkedHashMap<>();
        for (ContentBootstrapTask task : tasks) {
            if (task.profiles().contains(profile)) {
                selected.put(task.id(), task);
            }
        }
        return selected;
    }

    private static TaskGraph<ContentBootstrapSession> taskGraph(
            Map<Identifier, ContentBootstrapTask> selected
    ) {
        TaskGraph.Builder<ContentBootstrapSession> builder =
                TaskGraph.builder();
        selected.values().forEach(task -> builder.add(new Task<>(
                task.id(),
                task.dependencies(),
                session -> session.run(task))));
        return builder.build();
    }

    ContentProcessingContext processingContext(WorkProgress progress) {
        return new ContentProcessingContext(
                lifecycle,
                assets,
                data,
                registries,
                processorOwners,
                diagnostics,
                progress);
    }

    private void openResources(ExecutionProfile profile) {
        try {
            dataManager = manager(ResourceDomain.DATA);
            dataSnapshot = dataManager.acquireSnapshot();
            data = new ContentResources(lifecycle, dataSnapshot);
            if (profile != ExecutionProfile.DEDICATED_SERVER) {
                assetManager = manager(ResourceDomain.ASSETS);
                assetSnapshot = assetManager.acquireSnapshot();
                assets = new ContentResources(lifecycle, assetSnapshot);
            }
        } catch (RuntimeException failure) {
            closeResources();
            throw failure;
        }
    }

    private ResourceManager manager(ResourceDomain domain) {
        ResourceManager.Builder builder = ResourceManager.builder(
                domain, resourcePacks);
        resourceTypes.stream()
                .filter(type -> type.domain() == domain)
                .forEach(builder::registerType);
        return builder.build();
    }

    void closeResources() {
        if (assetSnapshot != null) assetSnapshot.close();
        if (dataSnapshot != null) dataSnapshot.close();
        if (assetManager != null) assetManager.close();
        if (dataManager != null) dataManager.close();
        assetSnapshot = null;
        dataSnapshot = null;
        assetManager = null;
        dataManager = null;
    }

    void beginTask(ContentBootstrapTask task) {
        lifecycle.beginTask(task.id());
    }

    void endTask(ContentBootstrapTask task) {
        lifecycle.endTask(task.id());
    }

    ContentBootstrapResult freeze() {
        lifecycle.freeze();
        LinkedHashMap<ContentRegistryDefinition<?>, Registry<?>> frozen =
                new LinkedHashMap<>();
        RegistrySet.Builder registrySet = RegistrySet.builder();
        registries.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    Registry<?> registry = entry.getValue().build();
                    frozen.put(entry.getKey(), registry);
                    registrySet.add(registry);
                });
        String gameplay = fingerprint(frozen, FingerprintScope.GAMEPLAY);
        boolean hasClient = frozen.entrySet().stream()
                .anyMatch(entry ->
                        entry.getKey().fingerprintScope()
                                == FingerprintScope.CLIENT_ASSET
                        && entry.getValue().size() > 0);
        String client = hasClient
                ? fingerprint(frozen, FingerprintScope.CLIENT_ASSET)
                : null;
        Map<ResourceDomain, Map<ResourcePath, Integer>> readCounts = Map.of(
                ResourceDomain.DATA,
                data == null ? Map.of() : data.physicalReadCounts(),
                ResourceDomain.ASSETS,
                assets == null ? Map.of() : assets.physicalReadCounts());
        closeResources();
        return new ContentBootstrapResult(
                registrySet.build(),
                diagnostics,
                gameplay,
                java.util.Optional.ofNullable(client),
                readCounts);
    }

    private static String fingerprint(
            Map<ContentRegistryDefinition<?>, Registry<?>> registries,
            FingerprintScope scope
    ) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            registries.entrySet().stream()
                    .filter(entry ->
                            entry.getKey().fingerprintScope() == scope)
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> updateRegistry(
                            digest, entry.getKey(), entry.getValue()));
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(
                    "SHA-256 unavailable", impossible);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void updateRegistry(
            MessageDigest digest,
            ContentRegistryDefinition definition,
            Registry registry
    ) {
        update(digest, definition.id().value());
        for (Object value : registry.entries()) {
            RegistryEntry<Object> entry = (RegistryEntry<Object>) value;
            update(digest, entry.id().value());
            update(digest, String.valueOf(
                    definition.fingerprintEncoder().apply(entry.value())));
        }
    }

    private static void update(MessageDigest digest, String value) {
        digest.update(value.getBytes(StandardCharsets.UTF_8));
        digest.update((byte) 0);
    }

    public static final class Builder {
        private final List<ResourcePackCandidate> resourcePacks =
                new ArrayList<>();
        private final List<ContentModule> modules = new ArrayList<>();
        private final List<ResourceType<?>> resourceTypes = new ArrayList<>();

        public Builder resourcePack(ResourcePackCandidate pack) {
            resourcePacks.add(java.util.Objects.requireNonNull(pack, "pack"));
            return this;
        }

        public Builder resourceTypes(
                java.util.Collection<? extends ResourceType<?>> types
        ) {
            types.forEach(this::resourceType);
            return this;
        }

        public Builder resourceType(ResourceType<?> type) {
            resourceTypes.add(java.util.Objects.requireNonNull(type, "type"));
            return this;
        }

        public Builder module(ContentModule module) {
            modules.add(java.util.Objects.requireNonNull(module, "module"));
            return this;
        }

        public ContentBootstrapPlan build() {
            ContentRegistrationContext context =
                    new ContentRegistrationContext();
            modules.forEach(module -> module.register(context));
            return context.seal(resourcePacks, resourceTypes);
        }
    }
}
package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.registry.RegistryBuilder;
import io.github.juloass.registry.RegistryView;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Processing-only API passed to the current content task. */
public final class ContentProcessingContext {
    private final RegistryLifecycleController lifecycle;
    private final ContentResources assets;
    private final ContentResources data;
    private final Map<ContentRegistryDefinition<?>, RegistryBuilder<?>>
            registries;
    private final Map<ContentRegistryDefinition<?>, Set<Identifier>>
            processorOwners;
    private final List<String> diagnostics;
    private final WorkProgress progress;

    ContentProcessingContext(
            RegistryLifecycleController lifecycle,
            ContentResources assets,
            ContentResources data,
            Map<ContentRegistryDefinition<?>, RegistryBuilder<?>> registries,
            Map<ContentRegistryDefinition<?>, Set<Identifier>> processorOwners,
            List<String> diagnostics,
            WorkProgress progress
    ) {
        this.lifecycle = lifecycle;
        this.assets = assets;
        this.data = data;
        this.registries = registries;
        this.processorOwners = processorOwners;
        this.diagnostics = diagnostics;
        this.progress = progress == null ? WorkProgress.none() : progress;
    }

    public ContentResources assets() {
        if (assets == null) {
            throw new IllegalStateException(
                    "The current execution profile does not load ASSETS");
        }
        return assets;
    }

    public ContentResources data() {
        return data;
    }

    public RegistryLifecycle lifecycle() {
        return lifecycle.lifecycle();
    }

    public WorkProgress progress() {
        return progress;
    }

    @SuppressWarnings("unchecked")
    public <T> RegistryView<T> registry(
            ContentRegistryDefinition<T> definition
    ) {
        lifecycle.require(
                RegistryLifecycle.PROCESSING, "access processing registry");
        RegistryBuilder<?> registry = registries.get(definition);
        if (registry == null) {
            throw new IllegalArgumentException(
                    "Registry is not declared: " + definition.id());
        }
        return (RegistryView<T>) registry;
    }

    @SuppressWarnings("unchecked")
    public <T> void register(
            ContentRegistryDefinition<T> definition,
            Identifier id,
            T value
    ) {
        lifecycle.require(
                RegistryLifecycle.PROCESSING, "register processed content");
        RegistryBuilder<?> registry = registries.get(definition);
        if (registry == null) {
            throw new IllegalArgumentException(
                    "Registry is not declared: " + definition.id());
        }
        Set<Identifier> owners = processorOwners.getOrDefault(
                definition, Set.of());
        if (!owners.contains(lifecycle.currentTask())) {
            throw new IllegalStateException(
                    "Task " + lifecycle.currentTask()
                            + " does not own registry " + definition.id());
        }
        ((RegistryBuilder<T>) registry).register(id, value);
    }

    public void diagnostic(String message) {
        if (message != null && !message.isBlank()) {
            diagnostics.add(message);
        }
    }
}

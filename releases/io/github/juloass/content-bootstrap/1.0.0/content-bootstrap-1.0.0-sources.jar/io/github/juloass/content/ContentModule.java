package io.github.juloass.content;

/** A deterministic source of identities, definitions and processors. */
@FunctionalInterface
public interface ContentModule {
    void register(ContentRegistrationContext context);
}

package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.taskgraph.TaskExecutionException;
import io.github.juloass.taskgraph.TaskGraph;
import io.github.juloass.taskgraph.TaskSession;

import java.util.List;
import java.util.Map;

/** Incremental execution used by loading screens and server startup. */
public final class ContentBootstrapSession {
    private final ContentBootstrapPlan plan;
    private final ExecutionProfile profile;
    private final Map<Identifier, ContentBootstrapTask> tasksById;
    private final List<ContentBootstrapTask> tasks;
    private final TaskSession<ContentBootstrapSession> session;
    private WorkProgress currentProgress = WorkProgress.none();
    private ContentBootstrapTask failedTask;
    private Throwable failure;
    private ContentBootstrapResult result;

    ContentBootstrapSession(
            ContentBootstrapPlan plan,
            ExecutionProfile profile,
            Map<Identifier, ContentBootstrapTask> tasksById,
            TaskGraph<ContentBootstrapSession> graph
    ) {
        this.plan = plan;
        this.profile = profile;
        this.tasksById = Map.copyOf(tasksById);
        this.tasks = graph.tasks().stream()
                .map(task -> tasksById.get(task.id()))
                .toList();
        this.session = graph.start(this);
    }

    public ExecutionProfile profile() {
        return profile;
    }

    public List<ContentBootstrapTask> tasks() {
        return tasks;
    }

    public int completedTasks() {
        return session.completedTaskCount();
    }

    public boolean done() {
        return result != null;
    }

    public boolean failed() {
        return failure != null;
    }

    public ContentBootstrapTask currentTask() {
        return session.nextTask()
                .map(task -> tasksById.get(task.id()))
                .orElse(null);
    }

    public ContentBootstrapTask failedTask() {
        return failedTask;
    }

    public Throwable failure() {
        return failure;
    }

    public boolean executeNext() {
        return executeNext(WorkProgress.none());
    }

    public boolean executeNext(WorkProgress progress) {
        if (failed()) {
            throw new IllegalStateException(
                    "Content bootstrap already failed", failure);
        }
        if (done()) return false;
        currentProgress = progress == null ? WorkProgress.none() : progress;
        try {
            boolean executed = session.executeNext();
            if (session.complete()) result = plan.freeze();
            return executed;
        } catch (TaskExecutionException taskFailure) {
            failedTask = tasksById.get(taskFailure.taskId());
            failure = taskFailure.getCause();
            plan.closeResources();
            throw new ContentBootstrapFailure(failedTask, failure);
        } finally {
            currentProgress = WorkProgress.none();
        }
    }

    void run(ContentBootstrapTask task) throws Exception {
        plan.beginTask(task);
        try {
            task.action().run(plan.processingContext(currentProgress));
        } finally {
            plan.endTask(task);
        }
    }

    public ContentBootstrapResult executeAll() {
        while (!done()) executeNext();
        return result;
    }

    public ContentBootstrapResult result() {
        if (!done()) {
            throw new IllegalStateException(
                    "Content bootstrap is not complete");
        }
        return result;
    }
}
package io.github.juloass.content;

/** Reports completed, countable units for the currently executing startup task. */
@FunctionalInterface
public interface WorkProgress {
    WorkProgress NONE = (completed, total, unit, detail) -> {};

    /**
     * Publishes an honest progress checkpoint. A non-positive total denotes work
     * whose size cannot be measured and must be presented as indeterminate.
     */
    void report(long completed, long total, String unit, String detail);

    default void begin(long total, String unit, String detail) {
        report(0, total, unit, detail);
    }

    default void indeterminate(String detail) {
        report(0, 0, "", detail);
    }

    static WorkProgress none() {
        return NONE;
    }
}

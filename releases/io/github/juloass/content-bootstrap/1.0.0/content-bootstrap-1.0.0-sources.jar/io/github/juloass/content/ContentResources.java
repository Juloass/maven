package io.github.juloass.content;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.LoadedResource;
import io.github.juloass.resource.MetadataSectionType;
import io.github.juloass.resource.ResolvedMetadata;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourceKey;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.ResourceType;
import io.github.juloass.resource.pack.ResourceSnapshot;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Applies Tofuxia lifecycle and read-count policy to one resource snapshot. */
public final class ContentResources {
    private final RegistryLifecycleController lifecycle;
    private final ResourceSnapshot snapshot;
    private final Map<ResourcePath, byte[]> readCache = new LinkedHashMap<>();
    private final Map<ResourcePath, Integer> physicalReads = new LinkedHashMap<>();

    ContentResources(
            RegistryLifecycleController lifecycle,
            ResourceSnapshot snapshot
    ) {
        this.lifecycle = lifecycle;
        this.snapshot = snapshot;
    }

    public ResourceDomain domain() {
        return snapshot.domain();
    }

    public byte[] readBytes(ResourcePath path) throws IOException {
        requireProcessing();
        byte[] cached = readCache.get(path);
        if (cached == null) {
            cached = snapshot.requireResource(path).readAllBytes(Long.MAX_VALUE);
            readCache.put(path, cached);
            physicalReads.merge(path, 1, Integer::sum);
        }
        return cached.clone();
    }

    public <T> java.util.Optional<ResolvedMetadata<T>> metadata(
            ResourcePath path,
            MetadataSectionType<T> type
    ) {
        requireProcessing();
        return snapshot.requireResource(path).metadata().find(type);
    }

    public boolean contains(ResourcePath path) {
        requireProcessing();
        return snapshot.findResource(path).isPresent();
    }

    public String readString(ResourcePath path) throws IOException {
        String value = new String(readBytes(path), StandardCharsets.UTF_8);
        return value.startsWith("\uFEFF") ? value.substring(1) : value;
    }

    public List<ResourcePath> resourcePaths(
            String namespace,
            String prefix,
            String suffix
    ) {
        requireProcessing();
        return snapshot.listResources(prefix, path ->
                        path.namespace().equals(namespace)
                                && (suffix == null
                                || path.path().endsWith(suffix)))
                .keySet().stream().toList();
    }

    public <T> LoadedResource<T> load(ResourceKey<T> key) {
        requireProcessing();
        return snapshot.load(key);
    }

    public <T> LoadedResource<T> load(ResourceType<T> type, Identifier id) {
        return load(type.key(id));
    }

    public Map<ResourcePath, Integer> physicalReadCounts() {
        return Map.copyOf(physicalReads);
    }

    public List<ResourcePath> duplicatePhysicalReads() {
        ArrayList<ResourcePath> duplicates = new ArrayList<>();
        physicalReads.forEach((path, count) -> {
            if (count > 1) {
                duplicates.add(path);
            }
        });
        duplicates.sort(ResourcePath::compareTo);
        return List.copyOf(duplicates);
    }

    private void requireProcessing() {
        lifecycle.require(RegistryLifecycle.PROCESSING, "read resource");
    }
}

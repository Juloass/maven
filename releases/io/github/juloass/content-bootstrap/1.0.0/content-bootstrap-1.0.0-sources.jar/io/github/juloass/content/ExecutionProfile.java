package io.github.juloass.content;

public enum ExecutionProfile {
    CLIENT,
    DEDICATED_SERVER,
    TEST
}

package io.github.juloass.content;

public enum FingerprintScope {
    GAMEPLAY,
    CLIENT_ASSET,
    NONE
}

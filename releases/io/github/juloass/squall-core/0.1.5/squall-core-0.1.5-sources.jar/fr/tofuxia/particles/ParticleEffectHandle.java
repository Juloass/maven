package fr.tofuxia.particles;

public record ParticleEffectHandle(int id) {
}

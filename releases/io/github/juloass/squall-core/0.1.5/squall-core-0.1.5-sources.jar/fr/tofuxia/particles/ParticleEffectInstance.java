package fr.tofuxia.particles;

public final class ParticleEffectInstance {
    private final ParticleEngine.Instance internal;

    ParticleEffectInstance(ParticleEngine.Instance internal) {
        this.internal = internal;
    }

    public void setTransform(Vec3 position, float yawDegrees) {
        internal.setTransform(position, yawDegrees);
    }

    public void setPosition(Vec3 position) {
        internal.setPosition(position);
    }

    public void setYawDegrees(float yawDegrees) {
        internal.setYawDegrees(yawDegrees);
    }

    public void setContextVariable(String name, double value) {
        internal.setContextVariable(name, value);
    }

    public void removeContextVariable(String name) {
        internal.removeContextVariable(name);
    }

    public void clearContextVariables() {
        internal.clearContextVariables();
    }

    public void stopEmitting() {
        internal.stopEmitting();
    }

    public void kill() {
        internal.kill();
    }

    public boolean isAlive() {
        return internal.isAlive();
    }

    public boolean isEmitting() {
        return internal.isEmitting();
    }
}

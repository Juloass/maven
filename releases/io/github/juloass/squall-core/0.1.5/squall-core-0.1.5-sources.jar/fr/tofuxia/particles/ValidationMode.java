package fr.tofuxia.particles;

public enum ValidationMode {
    STRICT,
    LENIENT
}

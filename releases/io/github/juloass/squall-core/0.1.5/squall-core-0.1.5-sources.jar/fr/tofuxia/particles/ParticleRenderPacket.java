package fr.tofuxia.particles;

import io.github.juloass.color.Color;

public record ParticleRenderPacket(String effectIdentifier, String material, String texture,
                                   Vec3 position, Vec2 size, float rotationDegrees,
                                   BillboardMode billboardMode, Vec3 customDirection,
                                   Rect uvPixels, Vec2 textureSize, Color color,
                                   float age, float lifetime, float sortDistance, int layer,
                                   float emitterYawDegrees, boolean worldLighting) {
    public ParticleRenderPacket(String effectIdentifier, String material, String texture,
                                Vec3 position, Vec2 size, float rotationDegrees,
                                BillboardMode billboardMode, Vec3 customDirection,
                                Rect uvPixels, Vec2 textureSize, Color color,
                                float age, float lifetime, float sortDistance, int layer) {
        this(effectIdentifier, material, texture, position, size, rotationDegrees, billboardMode,
                customDirection, uvPixels, textureSize, color, age, lifetime, sortDistance, layer, 0, false);
    }
}

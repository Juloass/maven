package fr.tofuxia.particles;

public record Rect(float x, float y, float w, float h) {
}

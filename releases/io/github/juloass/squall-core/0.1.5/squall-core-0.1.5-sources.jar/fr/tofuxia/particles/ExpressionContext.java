package fr.tofuxia.particles;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import team.unnamed.mocha.MochaEngine;
import team.unnamed.mocha.runtime.value.Function;
import team.unnamed.mocha.runtime.value.NumberValue;
import team.unnamed.mocha.runtime.value.ObjectProperty;
import team.unnamed.mocha.runtime.value.ObjectValue;
import team.unnamed.mocha.runtime.value.Value;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Per-emitter/particle Molang state bound into a cached Mocha AST. */
final class ExpressionContext {
    final Map<String, Double> variables = new HashMap<>();
    final Random random;
    ExpressionFunctionResolver functionResolver = ExpressionFunctionResolver.NONE;

    private final MochaEngine<ExpressionContext> engine;

    ExpressionContext(long seed) {
        random = new Random(seed);
        NamespaceValue variable = new NamespaceValue(this, "variable", true);
        NamespaceValue context = new NamespaceValue(this, "context", false);
        NamespaceValue query = new NamespaceValue(this, "query", false);
        engine = MochaEngine.create(this, scope -> {
            scope.set("variable", variable);
            scope.set("v", variable);
            scope.set("context", context);
            scope.set("c", context);
            scope.set("query", query);
            scope.set("q", query);
            scope.set("math", SquallMath.BINDING);
        });
    }

    double eval(List<team.unnamed.mocha.parser.ast.Expression> program) {
        return engine.eval(program);
    }

    double variable(String name) {
        return variables.getOrDefault(name.toLowerCase(Locale.ROOT), 0D);
    }

    void set(String name, double value) {
        variables.put(name.toLowerCase(Locale.ROOT), value);
    }

    double function(String name, double[] arguments) {
        return functionResolver.resolve(name, arguments);
    }

    /** A lazy namespace node that supports arbitrary-depth Snowstorm variables. */
    private static final class NamespaceValue implements ObjectValue, Function<ExpressionContext> {
        private final ExpressionContext owner;
        private final String path;
        private final boolean writable;

        private NamespaceValue(ExpressionContext owner, String path, boolean writable) {
            this.owner = owner;
            this.path = path.toLowerCase(Locale.ROOT);
            this.writable = writable;
        }

        @Override
        public @NotNull ObjectProperty getProperty(@NotNull String name) {
            return ObjectProperty.property(new NamespaceValue(owner, path + "." + name, writable), !writable);
        }

        @Override
        public boolean set(@NotNull String name, @Nullable Value value) {
            if (!writable) return false;
            owner.set(path + "." + name, value == null ? 0D : value.getAsNumber());
            return true;
        }

        @Override
        public double getAsNumber() {
            return owner.variable(path);
        }

        @Override
        public boolean getAsBoolean() {
            return getAsNumber() != 0D;
        }

        @Override
        public @NotNull String getAsString() {
            return Double.toString(getAsNumber());
        }

        @Override
        public @NotNull Value evaluate(@NotNull team.unnamed.mocha.runtime.ExecutionContext<ExpressionContext> context,
                                       @NotNull Arguments arguments) {
            double[] values = new double[arguments.length()];
            for (int i = 0; i < values.length; i++) {
                Value value = arguments.next().eval();
                values[i] = value == null ? 0D : value.getAsNumber();
            }
            return NumberValue.of(owner.function(path, values));
        }
    }
}

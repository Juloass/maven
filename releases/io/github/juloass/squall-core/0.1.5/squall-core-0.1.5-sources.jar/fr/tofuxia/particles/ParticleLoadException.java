package fr.tofuxia.particles;

public final class ParticleLoadException extends RuntimeException {
    public ParticleLoadException(String message) {
        super(message);
    }
}

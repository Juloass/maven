package fr.tofuxia.particles;

import team.unnamed.mocha.MochaEngine;
import team.unnamed.mocha.parser.ParseException;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Cached Mocha-backed Molang expression. Parsed ASTs are shared and immutable. */
final class Expression {
    private static final Map<String, List<team.unnamed.mocha.parser.ast.Expression>> CACHE = new ConcurrentHashMap<>();
    private static final MochaEngine<?> PARSER = MochaEngine.create();
    private static final Pattern ASSIGNMENT = Pattern.compile(
            "(?i)(?:^|[;{}])\\s*([a-z_][a-z0-9_.]*)\\s*=(?!=)");

    private final List<team.unnamed.mocha.parser.ast.Expression> program;
    private final Double constant;

    private Expression(Object source) {
        if (source instanceof Number number) {
            constant = number.doubleValue();
            program = null;
        } else if (source instanceof Boolean bool) {
            constant = bool ? 1D : 0D;
            program = null;
        } else if (source instanceof Map<?, ?> item && item.get("expression") instanceof String value) {
            constant = null;
            program = compile(value);
        } else if (source instanceof String value) {
            constant = null;
            program = compile(value);
        } else {
            constant = 0D;
            program = null;
        }
    }

    static Expression of(Object source) {
        return new Expression(source);
    }

    double eval(ExpressionContext context) {
        return program == null ? constant : context.eval(program);
    }

    static void executeStatements(String source, ExpressionContext context) {
        context.eval(compile(source));
    }

    private static List<team.unnamed.mocha.parser.ast.Expression> compile(String source) {
        if (source == null || source.isBlank()) return List.of();
        validateAssignments(source);
        return CACHE.computeIfAbsent(source, Expression::parse);
    }

    private static synchronized List<team.unnamed.mocha.parser.ast.Expression> parse(String source) {
        try {
            return List.copyOf(PARSER.parse(source));
        } catch (ParseException exception) {
            throw new ParticleLoadException("Invalid Molang expression `" + source + "`: " + exception.getMessage());
        }
    }

    private static void validateAssignments(String source) {
        Matcher matcher = ASSIGNMENT.matcher(source);
        while (matcher.find()) {
            String target = normalize(matcher.group(1));
            if (target.startsWith("context.")) {
                throw new ParticleLoadException("Cannot assign read-only context variable: " + target);
            }
            if (target.startsWith("query.")) {
                throw new ParticleLoadException("Cannot assign read-only query value: " + target);
            }
            if (!target.startsWith("variable.") && !target.startsWith("temp.")) {
                throw new ParticleLoadException("Can only assign variable.* or temp.* values: " + target);
            }
        }
    }

    private static String normalize(String raw) {
        String value = raw.toLowerCase(Locale.ROOT);
        if (value.startsWith("v.")) return "variable." + value.substring(2);
        if (value.startsWith("q.")) return "query." + value.substring(2);
        if (value.startsWith("t.")) return "temp." + value.substring(2);
        if (value.startsWith("c.")) return "context." + value.substring(2);
        return value;
    }
}

package fr.tofuxia.particles;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

final class CurveEvaluator {
    private CurveEvaluator() {}

    static double evaluate(CurveDefinition curve, ExpressionContext ctx) {
        double input = Expression.of(curve.input()).eval(ctx);
        if ("bezier_chain".equals(curve.type())) return bezierChain(curve, ctx, input);
        List<?> nodes = list(curve.nodes());
        if (nodes.isEmpty()) return 0;
        double range = Math.max(0.0000001, Expression.of(curve.horizontalRange()).eval(ctx));
        double t = clamp(input / range);
        return switch (curve.type()) {
            case "linear" -> linear(nodes, ctx, t);
            case "bezier" -> bezier(nodes, ctx, t);
            case "catmull_rom" -> catmull(nodes, ctx, t);
            default -> 0;
        };
    }

    private static double linear(List<?> nodes, ExpressionContext ctx, double t) {
        if (nodes.size() == 1) return value(nodes.getFirst(), ctx);
        double scaled = t * (nodes.size() - 1);
        int index = Math.min(nodes.size() - 2, (int)Math.floor(scaled));
        double local = scaled - index;
        return lerp(value(nodes.get(index), ctx), value(nodes.get(index + 1), ctx), local);
    }

    private static double bezier(List<?> nodes, ExpressionContext ctx, double t) {
        if (nodes.size() != 4) return linear(nodes, ctx, t);
        double p0=value(nodes.get(0),ctx),p1=value(nodes.get(1),ctx),p2=value(nodes.get(2),ctx),p3=value(nodes.get(3),ctx);
        double u=1-t;
        return u*u*u*p0+3*u*u*t*p1+3*u*t*t*p2+t*t*t*p3;
    }

    private static double catmull(List<?> nodes, ExpressionContext ctx, double t) {
        if (nodes.size() < 4) return linear(nodes, ctx, t);
        int segments = nodes.size() - 3;
        double scaled = t * segments;
        int segment = Math.min(segments - 1, (int)Math.floor(scaled));
        double local = segment == segments - 1 && t >= 1 ? 1 : scaled - segment;
        double p0=value(nodes.get(segment),ctx),p1=value(nodes.get(segment+1),ctx);
        double p2=value(nodes.get(segment+2),ctx),p3=value(nodes.get(segment+3),ctx);
        double t2=local*local,t3=t2*local;
        return .5*((2*p1)+(-p0+p2)*local+(2*p0-5*p1+4*p2-p3)*t2+(-p0+3*p1-3*p2+p3)*t3);
    }

    private static double bezierChain(CurveDefinition curve, ExpressionContext ctx, double input) {
        if (!(curve.nodes() instanceof Map<?,?> raw) || raw.isEmpty()) return 0;
        List<ChainNode> nodes = new ArrayList<>();
        for (Map.Entry<?,?> entry : raw.entrySet()) {
            double position = Double.parseDouble(String.valueOf(entry.getKey()));
            if (!(entry.getValue() instanceof Map<?,?> data)) continue;
            double value = eval(data.get("value"), ctx, 0);
            double left = tangent(data, "left_value", "left_slope", value, ctx, true);
            double right = tangent(data, "right_value", "right_slope", value, ctx, false);
            nodes.add(new ChainNode(position,value,left,right));
        }
        nodes.sort(Comparator.comparingDouble(ChainNode::position));
        if (nodes.size() == 1 || input <= nodes.getFirst().position) return nodes.getFirst().value;
        for (int i=1;i<nodes.size();i++) {
            ChainNode a=nodes.get(i-1),b=nodes.get(i);
            if (input <= b.position) {
                double span=Math.max(.0000001,b.position-a.position),t=clamp((input-a.position)/span),u=1-t;
                double c1=a.right, c2=b.left;
                return u*u*u*a.value+3*u*u*t*c1+3*u*t*t*c2+t*t*t*b.value;
            }
        }
        return nodes.getLast().value;
    }

    private static double tangent(Map<?,?> data,String valueKey,String slopeKey,double value,ExpressionContext ctx,boolean left) {
        if (data.containsKey(valueKey)) return eval(data.get(valueKey),ctx,value);
        String shared="slope";
        if (data.containsKey(slopeKey) || data.containsKey(shared)) {
            double slope=eval(data.containsKey(slopeKey)?data.get(slopeKey):data.get(shared),ctx,0);
            return value+(left?-1:1)*slope/3.0;
        }
        return value;
    }

    private static double eval(Object value,ExpressionContext ctx,double fallback){return value==null?fallback:Expression.of(value).eval(ctx);}
    private static double value(Object value,ExpressionContext ctx){return Expression.of(value).eval(ctx);}
    private static double lerp(double a,double b,double t){return a+(b-a)*t;}
    private static double clamp(double value){return Math.max(0,Math.min(1,value));}
    private static List<?> list(Object value){return value instanceof List<?> list?list:List.of();}
    private record ChainNode(double position,double value,double left,double right){}
}

package fr.tofuxia.particles;

import io.github.juloass.color.Color;

/** Bedrock particle colors use alpha-first {@code #AARRGGBB}, unlike CSS {@code #RRGGBBAA}. */
final class BedrockColor {
    private BedrockColor() {
    }

    static Color parse(String value) {
        String text = value.trim();
        if (text.matches("#[0-9a-fA-F]{8}")) {
            return Color.srgb(
                    component(text, 3),
                    component(text, 5),
                    component(text, 7),
                    component(text, 1));
        }
        if (text.matches("#[0-9a-fA-F]{6}")) {
            return Color.srgb(component(text, 1), component(text, 3), component(text, 5), 1.0);
        }
        return Color.parse(text);
    }

    private static double component(String text, int offset) {
        return Integer.parseInt(text.substring(offset, offset + 2), 16) / 255.0;
    }
}

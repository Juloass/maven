package fr.tofuxia.particles;

import java.util.List;
import java.util.Map;

public record ParticleEffectDefinition(String identifier, String material, String texture,
                                       Map<String, CurveDefinition> curves,
                                       Map<String, ParticleEventNode> events,
                                       Map<String, Object> components,
                                       List<ParticleDiagnostic> diagnostics) {
    public Map<String, Object> componentMap(String name) {
        Object value = components.get(name);
        return value instanceof Map<?, ?> map ? castMap(map) : Map.of();
    }

    public boolean has(String name) {
        return components.containsKey(name);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> castMap(Map<?, ?> map) {
        return (Map<String, Object>) map;
    }
}

package fr.tofuxia.particles;

import io.github.juloass.identifier.Identifier;
import java.util.List;

sealed interface ParticleEventNode permits ParticleEventNode.ExpressionNode, ParticleEventNode.SpawnNode,
        ParticleEventNode.SoundNode, ParticleEventNode.LogNode, ParticleEventNode.SequenceNode,
        ParticleEventNode.RandomNode, ParticleEventNode.EmitNode {
    record ExpressionNode(String expression, String preEffectExpression) implements ParticleEventNode {
    }

    record SpawnNode(String effect, SpawnKind kind, String preEffectExpression) implements ParticleEventNode {
    }

    record SoundNode(Identifier soundId, Object volume, Object pitch) implements ParticleEventNode {
    }

    record LogNode(String message) implements ParticleEventNode {
    }

    record SequenceNode(List<ParticleEventNode> nodes) implements ParticleEventNode {
    }

    record RandomNode(List<WeightedNode> nodes) implements ParticleEventNode {
    }

    record EmitNode(Object count) implements ParticleEventNode {
    }

    record WeightedNode(double weight, ParticleEventNode node) {
    }

    enum SpawnKind {
        EMITTER,
        EMITTER_BOUND,
        PARTICLE,
        PARTICLE_WITH_VELOCITY
    }
}

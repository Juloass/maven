package fr.tofuxia.particles;

public record ParticleDiagnostic(Severity severity, String message) {
    public enum Severity {
        WARNING,
        ERROR
    }
}

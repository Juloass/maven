package fr.tofuxia.particles;

public record CurveDefinition(String name, String type, Object input, Object horizontalRange, Object nodes) {
}

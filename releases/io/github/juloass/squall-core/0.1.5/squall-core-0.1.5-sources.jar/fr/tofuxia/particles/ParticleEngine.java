package fr.tofuxia.particles;

import io.github.juloass.color.Color;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Collections;

public final class ParticleEngine {
    private final Map<ParticleEffectHandle, ParticleEffectDefinition> definitions = new LinkedHashMap<>();
    private final List<Instance> instances = new ArrayList<>();
    private final List<Instance> pendingInstances = new ArrayList<>();
    private final List<ParticleRenderPacket> packets = new ArrayList<>();
    private int nextHandle = 1;

    public ParticleEffectHandle register(ParticleEffectDefinition definition) {
        ParticleEffectHandle handle = new ParticleEffectHandle(nextHandle++);
        definitions.put(handle, definition);
        return handle;
    }

    public ParticleEffectInstance spawn(ParticleEffectHandle handle, ParticleSpawnContext context) {
        ParticleEffectDefinition definition = definitions.get(handle);
        if (definition == null) throw new IllegalArgumentException("Unknown particle handle: " + handle.id());
        Instance instance = new Instance(this, handle, definition, context);
        instances.add(instance);
        return new ParticleEffectInstance(instance);
    }

    public void update(float dt, ParticleUpdateContext context) {
        packets.clear();
        for (Instance instance : instances) {
            instance.followBoundParent();
            instance.update(dt, context);
            instance.collect(context, packets);
        }
        instances.addAll(pendingInstances);
        pendingInstances.clear();
        instances.removeIf(instance -> {
            if (instance.alive) return false;
            if (instance.eventParent != null) instance.eventParent.childEmitters.remove(instance);
            return true;
        });
        packets.sort(Comparator.comparingDouble(ParticleRenderPacket::sortDistance).reversed());
    }

    public List<ParticleRenderPacket> collectRenderPackets() {
        return Collections.unmodifiableList(packets);
    }

    /** Removes all running effects while retaining the registered definitions. */
    public void clearInstances() {
        instances.clear();
        pendingInstances.clear();
        packets.clear();
    }

    static final class Instance {
        final ParticleEffectHandle handle;
        final ParticleEngine owner;
        final ParticleEffectDefinition def;
        final ExpressionContext emitterCtx;
        final Random random;
        final List<Particle> particles = new ArrayList<>();
        final List<Instance> childEmitters = new ArrayList<>();
        final Map<String, Double> instanceContextVariables = new LinkedHashMap<>();
        final Map<String, Double> initialLocalVariables;
        final String initialPreEffectExpression;
        final Vec3 inheritedParticleVelocity;
        final Instance eventParent;
        final Instance boundParent;
        Vec3 worldPosition;
        Vec3 lastWorldPosition;
        Vec3 emitterVelocity = Vec3.ZERO;
        float yawDegrees;
        double emitterRandom1;
        double emitterRandom2;
        double emitterRandom3;
        double emitterRandom4;
        float age;
        float spawnDebt;
        boolean instantDone;
        int loopIndex;
        boolean emitting = true;
        boolean currentlyEmitting = true;
        boolean alive = true;
        boolean creationEventFired;
        boolean expirationEventFired;
        boolean previousActive;
        final List<Float> firedEmitterTimeline = new ArrayList<>();
        final List<String> expireInEnvironments;
        final List<String> expireNotInEnvironments;

        Instance(ParticleEngine owner, ParticleEffectHandle handle, ParticleEffectDefinition def, ParticleSpawnContext spawn) {
            this(owner, handle, def, spawn, null, null, null, null);
        }

        Instance(ParticleEngine owner, ParticleEffectHandle handle, ParticleEffectDefinition def, ParticleSpawnContext spawn,
                 Instance eventParent, Instance boundParent, String preEffectExpression, Vec3 inheritedParticleVelocity) {
            this.owner = owner;
            this.handle = handle;
            this.def = def;
            this.eventParent = eventParent;
            this.boundParent = boundParent;
            this.initialPreEffectExpression = preEffectExpression;
            this.inheritedParticleVelocity = inheritedParticleVelocity;
            this.worldPosition = spawn.worldPosition();
            this.lastWorldPosition = this.worldPosition;
            this.yawDegrees = spawn.yawDegrees();
            this.emitterCtx = new ExpressionContext(spawn.seed());
            this.random = new Random(spawn.seed() ^ 0x5DEECE66DL);
            this.initialLocalVariables = spawn.localVariables() == null ? Map.of() : Map.copyOf(spawn.localVariables());
            this.expireInEnvironments = environmentNames(def.components().get("minecraft:particle_expire_if_in_blocks"));
            this.expireNotInEnvironments = environmentNames(def.components().get("minecraft:particle_expire_if_not_in_blocks"));
            if (spawn.contextVariables() != null) {
                for (Map.Entry<String, Double> entry : spawn.contextVariables().entrySet()) {
                    setContextVariable(entry.getKey(), entry.getValue());
                }
            }
            initializeEmitterRandoms();
            initializeEmitterCycle();
        }

        void setTransform(Vec3 position, float yawDegrees) {
            this.worldPosition = position == null ? Vec3.ZERO : position;
            this.yawDegrees = yawDegrees;
        }

        void setPosition(Vec3 position) {
            this.worldPosition = position == null ? Vec3.ZERO : position;
        }

        void setYawDegrees(float yawDegrees) {
            this.yawDegrees = yawDegrees;
        }

        void setContextVariable(String name, double value) {
            instanceContextVariables.put(contextName(name), value);
        }

        void removeContextVariable(String name) {
            instanceContextVariables.remove(contextName(name));
        }

        void clearContextVariables() {
            instanceContextVariables.clear();
        }

        void stopEmitting() {
            emitting = false;
            currentlyEmitting = false;
            // Explicit stop is not natural lifetime expiration in Snowstorm and must not launch
            // expiration-event child effects while the already emitted particles wind down.
            expirationEventFired = true;
            for (Instance child : List.copyOf(childEmitters)) child.stopEmitting();
        }

        void kill() {
            emitting = false;
            currentlyEmitting = false;
            alive = false;
            particles.clear();
            for (Instance child : List.copyOf(childEmitters)) child.kill();
        }

        boolean isAlive() {
            return alive;
        }

        boolean isEmitting() {
            return alive && emitting && currentlyEmitting;
        }

        void followBoundParent() {
            if (boundParent != null) {
                worldPosition = boundParent.worldPosition;
                yawDegrees = boundParent.yawDegrees;
            }
        }

        void update(float dt, ParticleUpdateContext context) {
            if (!alive) return;
            if (dt > 0) emitterVelocity = worldPosition.sub(lastWorldPosition).mul(1f / dt);
            lastWorldPosition = worldPosition;
            emitterCtx.functionResolver = context.functionResolver() == null ? ExpressionFunctionResolver.NONE : context.functionResolver();
            applyContextVariables(emitterCtx, context.variables());
            if (!creationEventFired) {
                creationEventFired = true;
                fireEmitterEvent("creation_event", context, null);
            }
            age += dt;
            LoopState loop = loopState();
            if (loop.index != loopIndex) {
                loopIndex = loop.index;
                instantDone = false;
                spawnDebt = 0.0f;
                initializeEmitterRandoms();
                initializeEmitterCycle();
                firedEmitterTimeline.clear();
                expirationEventFired = false;
                fireEmitterEvent("creation_event", context, null);
            }
            updateEmitterBuiltins(loop);
            Object emitterUpdate = def.componentMap("minecraft:emitter_initialization").get("per_update_expression");
            if (emitterUpdate instanceof String expression) Expression.executeStatements(expression, emitterCtx);
            applyCurves(emitterCtx);
            currentlyEmitting = active();
            fireEmitterTimeline(context, loop);
            if (currentlyEmitting) emit(dt, context);
            ParticleCollisionProvider collision = context.collisionProvider() == null ? ParticleCollisionProvider.NONE : context.collisionProvider();
            for (Particle p : particles) updateParticle(p, dt, collision, context);
            for (Particle p : particles) {
                if (!p.expirationEventFired && (!p.alive || p.age > p.lifetime)) {
                    p.expirationEventFired = true;
                    fireParticleEvent("expiration_event", context, p);
                }
            }
            particles.removeIf(p -> !p.alive || p.age > p.lifetime);
            currentlyEmitting = active();
            if (previousActive && !currentlyEmitting && !expirationEventFired) {
                expirationEventFired = true;
                fireEmitterEvent("expiration_event", context, null);
            }
            previousActive = currentlyEmitting;
            alive = currentlyEmitting || !particles.isEmpty();
        }

        private boolean active() {
            if (!alive || !emitting) return false;
            LoopState loop = loopState();
            updateEmitterBuiltins(loop);
            if (!loop.active) return false;
            Map<String, Object> expr = def.componentMap("minecraft:emitter_lifetime_expression");
            if (expr.containsKey("expiration_expression") && Expression.of(expr.get("expiration_expression")).eval(emitterCtx) != 0.0) {
                emitting = false;
                return false;
            }
            if (expr.containsKey("activation_expression")) return Expression.of(expr.get("activation_expression")).eval(emitterCtx) != 0.0;
            return true;
        }

        private LoopState loopState() {
            Map<String, Object> once = def.componentMap("minecraft:emitter_lifetime_once");
            if (!once.isEmpty()) {
                float activeTime = Math.max(0.001f, (float) Expression.of(once.getOrDefault("active_time", 1)).eval(emitterCtx));
                return new LoopState(Math.min(age, activeTime), 0, age <= activeTime, activeTime);
            }
            Map<String, Object> loop = def.componentMap("minecraft:emitter_lifetime_looping");
            if (loop.isEmpty()) return new LoopState(age, 0, true, 0.0f);
            float activeTime = Math.max(0.001f, (float) Expression.of(loop.getOrDefault("active_time", 1)).eval(emitterCtx));
            if (eventParent != null) {
                return new LoopState(Math.min(age, activeTime), 0, age <= activeTime, activeTime);
            }
            float sleepTime = Math.max(0.0f, (float) Expression.of(loop.getOrDefault("sleep_time", 0)).eval(emitterCtx));
            float cycle = Math.max(0.001f, activeTime + sleepTime);
            int index = (int) Math.floor(age / cycle);
            float localAge = age - index * cycle;
            return new LoopState(localAge, index, localAge <= activeTime, activeTime);
        }

        private void emit(float dt, ParticleUpdateContext context) {
            Map<String, Object> instant = def.componentMap("minecraft:emitter_rate_instant");
            if (!instant.isEmpty() && !instantDone) {
                int count = (int) Math.round(Expression.of(instant.getOrDefault("num_particles", 0)).eval(emitterCtx));
                for (int i = 0; i < count; i++) spawnParticle(context);
                instantDone = true;
            }
            Map<String, Object> steady = def.componentMap("minecraft:emitter_rate_steady");
            if (!steady.isEmpty()) {
                int max = (int) Math.round(Expression.of(steady.getOrDefault("max_particles", 1000)).eval(emitterCtx));
                double rate = Expression.of(steady.getOrDefault("spawn_rate", 0)).eval(emitterCtx);
                spawnDebt += (float) (rate * dt);
                while (spawnDebt >= 1.0f && particles.size() < max) {
                    spawnParticle(context);
                    spawnDebt -= 1.0f;
                }
            }
        }

        private void emitManual(int count, ParticleUpdateContext context) {
            int max = (int) Math.round(Expression.of(def.componentMap("minecraft:emitter_rate_manual").getOrDefault("max_particles", 1000)).eval(emitterCtx));
            for (int i = 0; i < count && particles.size() < max; i++) spawnParticle(context);
        }

        private void spawnParticle(ParticleUpdateContext context) {
            Particle p = new Particle();
            p.expressionSeed = random.nextLong();
            p.r1 = random.nextDouble();
            p.r2 = random.nextDouble();
            p.r3 = random.nextDouble();
            p.r4 = random.nextDouble();
            ExpressionContext ctx = particleCtx(p);
            ShapeResult shape = shape(ctx);
            p.localPosition = localSpacePosition();
            p.localRotation = localSpaceRotation();
            Vec3 spawnOffset = p.localPosition ? shape.offset : transformDirection(shape.offset, p.localRotation);
            p.position = p.localPosition ? spawnOffset : worldPosition.add(spawnOffset);
            p.spawnPosition = p.position;
            p.parametricOrigin = p.localPosition ? Vec3.ZERO : worldPosition;
            Vec3 direction = p.localPosition ? shape.direction : transformDirection(shape.direction, p.localRotation);
            Object initialSpeed = componentValue("minecraft:particle_initial_speed", 0);
            p.velocity = initialSpeed instanceof List<?> ? vec(initialSpeed, ctx, Vec3.ZERO)
                    : direction.normalize().mul((float) Expression.of(initialSpeed).eval(ctx));
            boolean inheritedVelocity = inheritedParticleVelocity != null && inheritsParticleVelocity();
            if (inheritedVelocity) {
                p.velocity = inheritedParticleVelocity;
            }
            if (!inheritedVelocity && !p.localPosition && p.localRotation && initialSpeed instanceof List<?>) {
                p.velocity = transformDirection(p.velocity, true);
            }
            if (Boolean.TRUE.equals(def.componentMap("minecraft:emitter_local_space").get("velocity"))) {
                p.velocity = p.velocity.add(p.localPosition ? inverseTransformDirection(emitterVelocity, p.localRotation) : emitterVelocity);
            }
            p.lifetime = Math.max(0.001f, (float) Expression.of(def.componentMap("minecraft:particle_lifetime_expression").getOrDefault("max_lifetime", 1)).eval(ctx));
            Map<String, Object> spin = def.componentMap("minecraft:particle_initial_spin");
            p.initialRotation = (float) Expression.of(spin.getOrDefault("rotation", 0)).eval(ctx);
            p.rotation = p.initialRotation;
            p.rotationRate = (float) Expression.of(spin.getOrDefault("rotation_rate", 0)).eval(ctx);
            syncEmitterSpawnAssignments(ctx);
            particles.add(p);
            fireParticleEvent("creation_event", context, p);
            Object particleCreation = def.componentMap("minecraft:particle_initialization").get("per_render_expression");
            if (particleCreation == null) particleCreation = def.componentMap("minecraft:particle_initialization").get("creation_expression");
            if (particleCreation instanceof String expression) Expression.executeStatements(expression, ctx);
        }

        private Object componentValue(String component, Object fallback) {
            Object value = def.components().get(component);
            return value == null ? fallback : value;
        }

        private void syncEmitterSpawnAssignments(ExpressionContext particleContext) {
            for (Map.Entry<String, Double> entry : particleContext.variables.entrySet()) {
                String name = entry.getKey();
                if (!name.startsWith("variable.") || isParticleBuiltin(name)) continue;
                emitterCtx.set(name, entry.getValue());
            }
        }

        private static boolean isParticleBuiltin(String name) {
            return name.equals("variable.particle_age")
                    || name.equals("variable.particle_lifetime")
                    || name.equals("variable.particle_random_1")
                    || name.equals("variable.particle_random_2")
                    || name.equals("variable.particle_random_3")
                    || name.equals("variable.particle_random_4");
        }

        private boolean inheritsParticleVelocity() {
            for (String shape : List.of("minecraft:emitter_shape_custom", "minecraft:emitter_shape_entity_aabb",
                    "minecraft:emitter_shape_sphere", "minecraft:emitter_shape_box", "minecraft:emitter_shape_disc",
                    "minecraft:emitter_shape_point")) {
                if (!def.has(shape)) continue;
                Object direction = def.componentMap(shape).get("direction");
                return direction == null || "outwards".equals(direction);
            }
            return true;
        }

        private ShapeResult shape(ExpressionContext ctx) {
            if (def.has("minecraft:emitter_shape_custom")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_custom");
                Vec3 direction = c.containsKey("direction")
                        ? shapeDirection(c.get("direction"), ctx, Vec3.ZERO, Vec3.ZERO)
                        : randomEulerDirection();
                return new ShapeResult(vec(c.get("offset"), ctx, Vec3.ZERO), direction);
            }
            if (def.has("minecraft:emitter_shape_entity_aabb")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_entity_aabb");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                float width = Math.max(0, (float) Expression.of(c.getOrDefault("half_width", c.getOrDefault("width", 0.5))).eval(ctx));
                float height = Math.max(0, (float) Expression.of(c.getOrDefault("height", 1)).eval(ctx));
                Vec3 relative = new Vec3(rand(-width, width), rand(0, height), rand(-width, width));
                if (Boolean.TRUE.equals(c.get("surface_only"))) relative = boxSurface(relative, new Vec3(width, height * .5f, width)).add(new Vec3(0, height * .5f, 0));
                return new ShapeResult(off.add(relative), shapeDirection(c.get("direction"), ctx, relative.normalize(), relative));
            }
            if (def.has("minecraft:emitter_shape_sphere")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_sphere");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                float radius = Math.max(0.0f, (float) Expression.of(c.getOrDefault("radius", 0)).eval(ctx));
                Vec3 unit = randomEulerDirection();
                float r = Boolean.TRUE.equals(c.get("surface_only")) ? radius : radius * random.nextFloat();
                Vec3 radial = unit.mul(r);
                Vec3 dir = shapeDirection(c.get("direction"), ctx, unit, unit);
                return new ShapeResult(off.add(radial), dir.normalize());
            }
            if (def.has("minecraft:emitter_shape_box")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_box");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                Vec3 half = vec(c.get("half_dimensions"), ctx, Vec3.ZERO);
                Vec3 relative = new Vec3(rand(-half.x(), half.x()), rand(-half.y(), half.y()), rand(-half.z(), half.z()));
                if (Boolean.TRUE.equals(c.get("surface_only"))) relative = boxSurface(relative, half);
                return new ShapeResult(off.add(relative), shapeDirection(c.get("direction"), ctx, relative.normalize(), relative));
            }
            if (def.has("minecraft:emitter_shape_disc")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_disc");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                float radius = (float) Expression.of(c.getOrDefault("radius", 0)).eval(ctx);
                double a = random.nextDouble() * Math.PI * 2.0;
                float r = Boolean.TRUE.equals(c.get("surface_only")) ? radius : radius * (float) Math.sqrt(random.nextDouble());
                Vec3 normal = vec(c.get("plane_normal"), ctx, new Vec3(0, 1, 0)).normalize();
                Vec3 tangent = Math.abs(normal.y()) < .99f ? normal.cross(new Vec3(0, 1, 0)).normalize() : new Vec3(1, 0, 0);
                Vec3 bitangent = normal.cross(tangent).normalize();
                Vec3 radial = tangent.mul((float) Math.cos(a) * r).add(bitangent.mul((float) Math.sin(a) * r));
                Vec3 dir = shapeDirection(c.get("direction"), ctx, radial.normalize(), radial.normalize());
                return new ShapeResult(off.add(radial), dir);
            }
            Map<String, Object> point = def.componentMap("minecraft:emitter_shape_point");
            Object rawPointDirection = point.get("direction");
            Vec3 pointDirection;
            if (rawPointDirection == null || "outwards".equals(rawPointDirection)) {
                pointDirection = randomEulerDirection();
            } else if ("inwards".equals(rawPointDirection)) {
                pointDirection = randomEulerDirection().mul(-1);
            } else {
                pointDirection = shapeDirection(rawPointDirection, ctx, Vec3.ZERO, Vec3.ZERO);
            }
            return new ShapeResult(vec(point.get("offset"), ctx, Vec3.ZERO), pointDirection);
        }

        private Vec3 boxSurface(Vec3 relative, Vec3 half) {
            int face = random.nextInt(3);
            float sign = random.nextBoolean() ? 1 : -1;
            return switch (face) {
                case 0 -> new Vec3(half.x() * sign, relative.y(), relative.z());
                case 1 -> new Vec3(relative.x(), half.y() * sign, relative.z());
                default -> new Vec3(relative.x(), relative.y(), half.z() * sign);
            };
        }

        private Vec3 shapeDirection(Object raw, ExpressionContext ctx, Vec3 fallback, Vec3 outward) {
            if ("outwards".equals(raw)) return outward.normalize();
            if ("inwards".equals(raw)) return outward.normalize().mul(-1);
            return vec(raw, ctx, fallback).normalize();
        }

        private void updateParticle(Particle p, float dt, ParticleCollisionProvider collision, ParticleUpdateContext context) {
            float previousAge = p.age;
            p.age += dt;
            ExpressionContext ctx = particleCtx(p);
            Object particleUpdate = def.componentMap("minecraft:particle_initialization").get("per_update_expression");
            if (particleUpdate instanceof String expression) Expression.executeStatements(expression, ctx);
            Vec3 previousPosition = p.position;
            Vec3 acceleration = vec(def.componentMap("minecraft:particle_motion_dynamic").get("linear_acceleration"), ctx, Vec3.ZERO);
            float drag = (float) Expression.of(def.componentMap("minecraft:particle_motion_dynamic").getOrDefault("linear_drag_coefficient", 0)).eval(ctx);
            p.velocity = p.velocity.add(acceleration.sub(p.velocity.mul(drag)).mul(dt));
            p.position = p.position.add(p.velocity.mul(dt));
            Map<String, Object> parametric = def.componentMap("minecraft:particle_motion_parametric");
            if (!parametric.isEmpty()) {
                applyCurves(ctx);
                if (parametric.containsKey("relative_position") || parametric.containsKey("position")) {
                    Object position = parametric.containsKey("relative_position")
                            ? parametric.get("relative_position") : parametric.get("position");
                    p.position = p.parametricOrigin.add(vec(position, ctx, Vec3.ZERO));
                }
                if (parametric.containsKey("direction")) {
                    p.velocity = vec(parametric.get("direction"), ctx, p.velocity);
                }
            }
            Map<String, Object> dynamic = def.componentMap("minecraft:particle_motion_dynamic");
            if (parametric.containsKey("rotation")) {
                p.rotation = (float) Expression.of(parametric.get("rotation")).eval(ctx);
            } else {
                float rotationAcceleration = (float) Expression.of(dynamic.getOrDefault("rotation_acceleration", 0)).eval(ctx);
                float rotationDrag = (float) Expression.of(dynamic.getOrDefault("rotation_drag_coefficient", 0)).eval(ctx);
                p.rotationRate += (rotationAcceleration - rotationDrag * p.rotationRate) * dt;
                p.rotation = p.initialRotation + p.rotationRate * p.age;
            }
            p.travelDistance += p.position.sub(previousPosition).length();
            fireParticleTimeline(context, p, previousAge);
            fireParticleTravelEvents(context, p);
            Map<String, Object> collisionComponent = def.componentMap("minecraft:particle_motion_collision");
            // An empty collision component is still an enabled component with Bedrock defaults.
            if (def.has("minecraft:particle_motion_collision")
                    && Expression.of(collisionComponent.getOrDefault("enabled", 1)).eval(ctx) != 0) {
                float radius = (float) Expression.of(collisionComponent.getOrDefault("collision_radius", 0)).eval(ctx);
                Vec3 from = p.localPosition ? worldPosition.add(transformDirection(previousPosition, p.localRotation)) : previousPosition;
                ParticleCollision contact = collision.sweep(from, renderPosition(p), radius);
                if (contact.hit()) {
                    p.position = p.localPosition ? inverseTransformDirection(contact.position().sub(worldPosition), p.localRotation) : contact.position();
                    float normalSpeed = p.velocity.dot(contact.normal());
                    float restitution = (float) Expression.of(collisionComponent.getOrDefault("coefficient_of_restitution", 0)).eval(ctx);
                    if (!p.collisionEventFired) {
                        p.collisionEventFired = true;
                        fireParticleEvent("collision_event", context, p);
                    }
                    fireCollisionEvents(collisionComponent.get("events"), Math.abs(normalSpeed), context, p);
                    if (Boolean.TRUE.equals(collisionComponent.get("expire_on_contact"))) p.alive = false;
                    // Collision events observe the incoming velocity in Wintersky. Bounce is
                    // applied only after those events (important for particle_with_velocity).
                    if (normalSpeed < 0) p.velocity = p.velocity.sub(contact.normal().mul((1 + restitution) * normalSpeed));
                    float cdrag = (float) Expression.of(collisionComponent.getOrDefault("collision_drag", 0)).eval(ctx);
                    p.velocity = p.velocity.mul(Math.max(0.0f, 1.0f - cdrag * dt));
                    float minimumSpeed = (float) Expression.of(collisionComponent.getOrDefault("minimum_speed", 0)).eval(ctx);
                    if (p.velocity.length() < minimumSpeed) p.velocity = Vec3.ZERO;
                }
            }
            Object expiration = def.componentMap("minecraft:particle_lifetime_expression").get("expiration_expression");
            if (expiration != null && Expression.of(expiration).eval(ctx) != 0) p.alive = false;
            Object killPlaneRaw = def.components().get("minecraft:particle_kill_plane");
            if (killPlaneRaw instanceof List<?> plane && plane.size() >= 4) {
                Vec3 world = renderPosition(p);
                double side = Expression.of(plane.get(0)).eval(ctx) * world.x() + Expression.of(plane.get(1)).eval(ctx) * world.y()
                        + Expression.of(plane.get(2)).eval(ctx) * world.z() + Expression.of(plane.get(3)).eval(ctx);
                if (side < 0) p.alive = false;
            }
            if (!expireInEnvironments.isEmpty()
                    && collision.isInsideAnyEnvironment(renderPosition(p), expireInEnvironments)) {
                p.alive = false;
            }
            if (!expireNotInEnvironments.isEmpty()
                    && !collision.isInsideAnyEnvironment(renderPosition(p), expireNotInEnvironments)) {
                    p.alive = false;
            }
        }

        private static List<String> environmentNames(Object value) {
            if (!(value instanceof List<?> values) || values.isEmpty()) return List.of();
            ArrayList<String> names = new ArrayList<>(values.size());
            for (Object entry : values) names.add(String.valueOf(entry));
            return List.copyOf(names);
        }

        void collect(ParticleUpdateContext context, List<ParticleRenderPacket> out) {
            if (!alive) return;
            applyContextVariables(emitterCtx, context.variables());
            for (Particle p : particles) {
                if (!p.alive) continue;
                ExpressionContext ctx = particleCtx(p);
                applyCurves(ctx);
                Object perRender = def.componentMap("minecraft:particle_initialization").get("per_render_expression");
                if (perRender instanceof String expression) Expression.executeStatements(expression, ctx);
                Map<String, Object> billboard = def.componentMap("minecraft:particle_appearance_billboard");
                Vec2 size = vec2(billboard.get("size"), ctx, new Vec2(0.1f, 0.1f));
                Map<String, Object> uv = ParticleDefinitionLoader.asMap(billboard.get("uv"), "uv");
                Rect rect = uvRect(uv, p);
                Vec2 texSize = new Vec2((float) Expression.of(uv.getOrDefault("texture_width", 128)).eval(ctx),
                        (float) Expression.of(uv.getOrDefault("texture_height", 128)).eval(ctx));
                BillboardMode mode = mode(String.valueOf(billboard.getOrDefault("facing_camera_mode", "rotate_xyz")));
                Vec3 camera = context.cameraPosition() == null ? Vec3.ZERO : context.cameraPosition();
                Vec3 renderPosition = renderPosition(p);
                float dx = renderPosition.x() - camera.x();
                float dy = renderPosition.y() - camera.y();
                float dz = renderPosition.z() - camera.z();
                out.add(new ParticleRenderPacket(def.identifier(), def.material(), texture(billboard, p, ctx), renderPosition, size,
                        p.rotation, mode, customDirection(billboard, ctx, p), rect, texSize, color(ctx), p.age, p.lifetime,
                        dx * dx + dy * dy + dz * dz, 0, yawDegrees, def.has("minecraft:particle_appearance_lighting")));
            }
        }

        private String texture(Map<String, Object> billboard, Particle p, ExpressionContext ctx) {
            Object framesRaw = billboard.get("texture_frames");
            if (!(framesRaw instanceof Map<?, ?> raw)) return def.texture();
            @SuppressWarnings("unchecked") Map<String, Object> frames = (Map<String, Object>) raw;
            Object frameList = frames.get("frames");
            if (!(frameList instanceof List<?> list) || list.isEmpty()) return def.texture();
            int frame;
            String mode = String.valueOf(frames.getOrDefault("mode", "expression"));
            if ("lifetime".equals(mode)) {
                frame = (int) Math.floor((p.age / Math.max(0.001f, p.lifetime)) * list.size());
            } else if ("random".equals(mode)) {
                Object random = frames.getOrDefault("random", "variable.particle_random_2");
                frame = (int) Math.floor(Expression.of(random).eval(ctx) * list.size());
            } else {
                frame = (int) Math.floor(Expression.of(frames.getOrDefault("frame", 0)).eval(ctx));
            }
            frame = Math.max(0, Math.min(list.size() - 1, frame));
            return String.valueOf(list.get(frame));
        }

        private Color color(ExpressionContext ctx) {
            Map<String, Object> tint = def.componentMap("minecraft:particle_appearance_tinting");
            Object color = tint.get("color");
            if (color instanceof List<?> list) {
                return Color.srgb(clampChannel(Expression.of(list.get(0)).eval(ctx)),
                        clampChannel(Expression.of(list.get(1)).eval(ctx)),
                        clampChannel(Expression.of(list.get(2)).eval(ctx)),
                        clampChannel(list.size() > 3 ? Expression.of(list.get(3)).eval(ctx) : 1));
            }
            if (color instanceof String string) return BedrockColor.parse(string);
            if (color instanceof Map<?, ?> map) {
                double t = Expression.of(map.get("interpolant")).eval(ctx);
                Object gradient = map.get("gradient");
                return gradient(gradient, t);
            }
            return Color.srgb(1, 1, 1);
        }

        private Color gradient(Object rawGradient, double t) {
            if (rawGradient instanceof List<?> values && !values.isEmpty()) {
                double scaled = Math.max(0, Math.min(1, t)) * (values.size() - 1);
                int lower = (int) Math.floor(scaled), upper = Math.min(values.size() - 1, lower + 1);
                return parsedColor(values.get(lower)).interpolate(parsedColor(values.get(upper)), (float) (scaled - lower), Color.InterpolationSpace.SRGB, Color.HueInterpolation.SHORTER);
            }
            if (!(rawGradient instanceof Map<?, ?> raw)) return Color.srgb(1, 1, 1);
            java.util.List<Map.Entry<Double, Object>> stops = raw.entrySet().stream()
                    .map(entry -> Map.entry(Double.parseDouble(String.valueOf(entry.getKey())), entry.getValue()))
                    .sorted(Map.Entry.comparingByKey())
                    .toList();
            if (stops.isEmpty()) return Color.srgb(1, 1, 1);
            double clamped = Math.max(stops.get(0).getKey(), Math.min(stops.get(stops.size() - 1).getKey(), t));
            Map.Entry<Double, Object> previous = stops.get(0);
            Map.Entry<Double, Object> next = stops.get(stops.size() - 1);
            for (Map.Entry<Double, Object> stop : stops) {
                if (stop.getKey() <= clamped) previous = stop;
                if (stop.getKey() >= clamped) { next = stop; break; }
            }
            Color a = parsedColor(previous.getValue());
            Color b = parsedColor(next.getValue());
            float f = next.getKey().equals(previous.getKey()) ? 0
                    : (float) ((clamped - previous.getKey()) / (next.getKey() - previous.getKey()));
            return a.interpolate(b, f, Color.InterpolationSpace.SRGB, Color.HueInterpolation.SHORTER);
        }

        private Color hex(String s) {
            return BedrockColor.parse(s);
        }

        private Color parsedColor(Object value) {
            if (value instanceof List<?> list && list.size() >= 3) return Color.srgb(number(list.get(0)), number(list.get(1)), number(list.get(2)), list.size() > 3 ? number(list.get(3)) : 1);
            return hex(String.valueOf(value));
        }

        private double number(Object value) { return value instanceof Number number ? number.doubleValue() : Double.parseDouble(String.valueOf(value)); }

        private double clampChannel(double value) {
            return Math.max(0.0, Math.min(1.0, value));
        }

        private Rect uvRect(Map<String, Object> uv, Particle p) {
            ExpressionContext ctx = particleCtx(p);
            if (uv.get("flipbook") instanceof Map<?, ?> fbRaw) {
                @SuppressWarnings("unchecked") Map<String, Object> fb = (Map<String, Object>) fbRaw;
                Vec2 base = vec2(fb.get("base_UV"), ctx, Vec2.ZERO);
                Vec2 size = vec2(fb.get("size_UV"), ctx, new Vec2(8, 8));
                Vec2 step = vec2(fb.get("step_UV"), ctx, Vec2.ZERO);
            boolean hasMax = fb.containsKey("max_frame");
            int max = hasMax ? (int) Expression.of(fb.get("max_frame")).eval(ctx) : 0;
            int frame;
            if (Boolean.TRUE.equals(fb.get("stretch_to_lifetime")) && max > 0) frame = (int) Math.floor((p.age / p.lifetime) * max);
            else frame = (int) Math.floor(p.age * Expression.of(fb.getOrDefault("frames_per_second", 1)).eval(ctx));
            if (Boolean.TRUE.equals(fb.get("loop")) && max > 0) frame = Math.floorMod(frame, max);
            else if (hasMax && max > 0) frame = Math.max(0, Math.min(max - 1, frame));
            else frame = Math.max(0, frame);
                return new Rect(base.x() + step.x() * frame, base.y() + step.y() * frame, size.x(), size.y());
            }
            Vec2 pos = vec2(uv.get("uv"), ctx, Vec2.ZERO);
            Vec2 size = vec2(uv.get("uv_size"), ctx, new Vec2(8, 8));
            return new Rect(pos.x(), pos.y(), size.x(), size.y());
        }

        private ExpressionContext particleCtx(Particle p) {
            ExpressionContext ctx = p.context;
            if (ctx == null) p.context = ctx = new ExpressionContext(p.expressionSeed);
            ctx.variables.keySet().removeIf(name -> name.startsWith("context."));
            ctx.variables.putAll(emitterCtx.variables);
            ctx.functionResolver = emitterCtx.functionResolver;
            updateEmitterBuiltins(ctx, loopState());
            ctx.set("variable.particle_age", p.age);
            ctx.set("variable.particle_lifetime", p.lifetime);
            ctx.set("variable.particle_random_1", p.r1);
            ctx.set("variable.particle_random_2", p.r2);
            ctx.set("variable.particle_random_3", p.r3);
            ctx.set("variable.particle_random_4", p.r4);
            // Snowstorm resolves curves through Molang's variable handler, so a curve must be
            // visible anywhere an expression is evaluated (shape, speed, lifetime, motion, etc.),
            // not only while constructing the final render packet.
            applyCurves(ctx);
            return ctx;
        }

        private Vec3 customDirection(Map<String, Object> billboard, ExpressionContext ctx, Particle p) {
            Object direction = billboard.get("direction");
            Vec3 custom = new Vec3(0, 0, -1);
            if (direction instanceof Map<?, ?> map) {
                String mode = String.valueOf(map.containsKey("mode") ? map.get("mode") : "custom");
                custom = "derive_from_velocity".equals(mode) ? p.velocity.normalize() : vec(map.get("custom_direction"), ctx, custom);
                float threshold = (float) Expression.of(map.containsKey("min_speed_threshold") ? map.get("min_speed_threshold") : 0.01).eval(ctx);
                if (p.velocity.length() < threshold && "derive_from_velocity".equals(mode)) custom = new Vec3(0, 0, -1);
            } else {
                String facing = String.valueOf(billboard.getOrDefault("facing_camera_mode", "rotate_xyz"));
                if (facing.startsWith("direction") || "lookat_direction".equals(facing)) {
                    custom = p.velocity.length() >= 0.01f ? p.velocity.normalize() : new Vec3(0, 0, -1);
                }
            }
            return p.localPosition ? transformDirection(custom, p.localRotation) : custom;
        }

        private BillboardMode mode(String s) {
            return switch (s) {
                case "lookat_xyz" -> BillboardMode.LOOKAT_XYZ;
                case "lookat_y" -> BillboardMode.LOOKAT_Y;
                case "lookat_direction" -> BillboardMode.LOOKAT_DIRECTION;
                case "direction_x" -> BillboardMode.DIRECTION_X;
                case "direction_y" -> BillboardMode.DIRECTION_Y;
                case "direction_z" -> BillboardMode.DIRECTION_Z;
                case "emitter_transform_xy" -> BillboardMode.EMITTER_TRANSFORM_XY;
                case "emitter_transform_xz" -> BillboardMode.EMITTER_TRANSFORM_XZ;
                case "emitter_transform_yz" -> BillboardMode.EMITTER_TRANSFORM_YZ;
                case "rotate_y" -> BillboardMode.ROTATE_Y;
                default -> BillboardMode.ROTATE_XYZ;
            };
        }

        private Vec3 vec(Object value, ExpressionContext ctx, Vec3 fallback) {
            if (!(value instanceof List<?> list) || list.size() < 3) return fallback;
            return new Vec3((float) Expression.of(list.get(0)).eval(ctx), (float) Expression.of(list.get(1)).eval(ctx), (float) Expression.of(list.get(2)).eval(ctx));
        }

        private Vec2 vec2(Object value, ExpressionContext ctx, Vec2 fallback) {
            if (!(value instanceof List<?> list) || list.size() < 2) return fallback;
            return new Vec2((float) Expression.of(list.get(0)).eval(ctx), (float) Expression.of(list.get(1)).eval(ctx));
        }

        private float rand(float min, float max) {
            return min + random.nextFloat() * (max - min);
        }

        private Vec3 randomUnitVector() {
            double z = random.nextDouble() * 2.0 - 1.0;
            double a = random.nextDouble() * Math.PI * 2.0;
            double r = Math.sqrt(Math.max(0.0, 1.0 - z * z));
            return new Vec3((float) (Math.cos(a) * r), (float) z, (float) (Math.sin(a) * r));
        }

        /** Wintersky rotates the +X axis by three independently random Euler angles. */
        private Vec3 randomEulerDirection() {
            random.nextDouble(); // X rotation does not move +X, but Wintersky still samples it.
            double y = random.nextDouble() * Math.PI * 2.0 - Math.PI;
            double z = random.nextDouble() * Math.PI * 2.0 - Math.PI;
            double cosY = Math.cos(y);
            return new Vec3((float) (cosY * Math.cos(z)), (float) (cosY * Math.sin(z)), (float) -Math.sin(y));
        }

        private boolean localSpacePosition() {
            return Boolean.TRUE.equals(def.componentMap("minecraft:emitter_local_space").get("position"));
        }

        private boolean localSpaceRotation() {
            return Boolean.TRUE.equals(def.componentMap("minecraft:emitter_local_space").get("rotation"));
        }

        private Vec3 renderPosition(Particle p) {
            return p.localPosition ? worldPosition.add(transformDirection(p.position, p.localRotation)) : p.position;
        }

        private Vec3 transformDirection(Vec3 value, boolean rotate) {
            if (!rotate) return value;
            double radians = Math.toRadians(yawDegrees);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            return new Vec3(value.x() * cos - value.z() * sin, value.y(), value.x() * sin + value.z() * cos);
        }

        private Vec3 inverseTransformDirection(Vec3 value, boolean rotate) {
            if (!rotate) return value;
            double radians = Math.toRadians(-yawDegrees);
            float cos = (float) Math.cos(radians), sin = (float) Math.sin(radians);
            return new Vec3(value.x() * cos - value.z() * sin, value.y(), value.x() * sin + value.z() * cos);
        }

        private void applyContextVariables(ExpressionContext ctx, Map<String, Double> updateVariables) {
            ctx.variables.keySet().removeIf(name -> name.startsWith("context."));
            if (updateVariables != null) {
                for (Map.Entry<String, Double> entry : updateVariables.entrySet()) {
                    ctx.set(contextName(entry.getKey()), entry.getValue());
                }
            }
            for (Map.Entry<String, Double> entry : instanceContextVariables.entrySet()) {
                ctx.set(entry.getKey(), entry.getValue());
            }
        }

        private static String contextName(String name) {
            String normalized = name == null ? "" : name.trim().toLowerCase();
            return normalized.startsWith("context.") ? normalized : "context." + normalized;
        }

        private void initializeEmitterRandoms() {
            emitterRandom1 = random.nextDouble();
            emitterRandom2 = random.nextDouble();
            emitterRandom3 = random.nextDouble();
            emitterRandom4 = random.nextDouble();
        }

        private void initializeEmitterCycle() {
            emitterCtx.variables.keySet().removeIf(name -> name.startsWith("variable.") || name.startsWith("temp."));
            applyContextVariables(emitterCtx, Map.of());
            Object expression = def.componentMap("minecraft:emitter_initialization").get("creation_expression");
            if (expression instanceof String source) Expression.executeStatements(source, emitterCtx);
            for (Map.Entry<String, Double> entry : initialLocalVariables.entrySet()) {
                emitterCtx.set(localVariableName(entry.getKey()), entry.getValue());
            }
            if (initialPreEffectExpression != null) {
                Expression.executeStatements(initialPreEffectExpression, emitterCtx);
            }
            applyCurves(emitterCtx);
        }

        private void updateEmitterBuiltins(LoopState loop) {
            updateEmitterBuiltins(emitterCtx, loop);
        }

        private void updateEmitterBuiltins(ExpressionContext ctx, LoopState loop) {
            ctx.set("variable.emitter_age", loop.localAge);
            ctx.set("variable.emitter_lifetime", loop.lifetime);
            ctx.set("variable.emitter_random_1", emitterRandom1);
            ctx.set("variable.emitter_random_2", emitterRandom2);
            ctx.set("variable.emitter_random_3", emitterRandom3);
            ctx.set("variable.emitter_random_4", emitterRandom4);
        }

        private void applyCurves(ExpressionContext ctx) {
            for (CurveDefinition curve : def.curves().values()) {
                ctx.set(curve.name(), CurveEvaluator.evaluate(curve, ctx));
            }
        }

        private void fireEmitterEvent(String field, ParticleUpdateContext context, Particle p) {
            Object event = def.componentMap("minecraft:emitter_lifetime_events").get(field);
            executeEventReferences(event, context, p, worldPosition, Vec3.ZERO);
        }

        private void fireEmitterTimeline(ParticleUpdateContext context, LoopState loop) {
            Object timeline = def.componentMap("minecraft:emitter_lifetime_events").get("timeline");
            if (!(timeline instanceof Map<?, ?> map)) return;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                float time = Float.parseFloat(entry.getKey().toString());
                if (loop.localAge >= time && !firedEmitterTimeline.contains(time)) {
                    firedEmitterTimeline.add(time);
                    executeEventReferences(entry.getValue(), context, null, worldPosition, Vec3.ZERO);
                }
            }
        }

        private void fireParticleEvent(String field, ParticleUpdateContext context, Particle p) {
            Object event = def.componentMap("minecraft:particle_lifetime_events").get(field);
            executeEventReferences(event, context, p, renderPosition(p), p.velocity);
        }

        private void fireParticleTimeline(ParticleUpdateContext context, Particle p, float previousAge) {
            Object timeline = def.componentMap("minecraft:particle_lifetime_events").get("timeline");
            if (!(timeline instanceof Map<?, ?> map)) return;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                float time = Float.parseFloat(entry.getKey().toString());
                if (previousAge <= time && p.age > time && !p.firedTimeline.contains(time)) {
                    p.firedTimeline.add(time);
                    executeEventReferences(entry.getValue(), context, p, renderPosition(p), p.velocity);
                }
            }
        }

        private void fireParticleTravelEvents(ParticleUpdateContext context, Particle p) {
            Object raw = def.componentMap("minecraft:particle_lifetime_events").get("travel_distance_events");
            if (!(raw instanceof Map<?, ?> map)) return;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                float distance = Float.parseFloat(entry.getKey().toString());
                if (p.travelDistance >= distance && !p.firedTravelDistances.contains(distance)) {
                    p.firedTravelDistances.add(distance);
                    executeEventReferences(entry.getValue(), context, p, renderPosition(p), p.velocity);
                }
            }
        }

        private void fireCollisionEvents(Object raw, float speed, ParticleUpdateContext context, Particle p) {
            if (raw instanceof List<?> list) { for (Object value : list) fireCollisionEvents(value, speed, context, p); return; }
            if (!(raw instanceof Map<?, ?> event)) return;
            float minimum = (float) Expression.of(event.containsKey("min_speed") ? event.get("min_speed") : 2).eval(particleCtx(p));
            if (speed >= minimum) executeEventReferences(event.get("event"), context, p, renderPosition(p), p.velocity);
        }

        private void executeEventReferences(Object value, ParticleUpdateContext context, Particle p, Vec3 position, Vec3 velocity) {
            if (value instanceof String name) executeNamedEvent(name, context, p, position, velocity);
            else if (value instanceof List<?> list) for (Object entry : list) executeEventReferences(entry, context, p, position, velocity);
        }

        private void executeNamedEvent(String name, ParticleUpdateContext update, Particle p, Vec3 position, Vec3 velocity) {
            ParticleEventNode node = def.events().get(name);
            if (node == null) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), name, "Missing particle event: " + name, position));
                return;
            }
            // Emitter events execute on the emitter's Molang VM; their assignments remain visible
            // to later event sequence entries and future ticks.
            ExpressionContext eventCtx = p == null ? emitterCtx : particleCtx(p);
            eventCtx.functionResolver = update.functionResolver() == null ? ExpressionFunctionResolver.NONE : update.functionResolver();
            eventCtx.variables.putAll(emitterCtx.variables);
            applyContextVariables(eventCtx, update.variables());
            eventCtx.set("variable.event_position_x", position.x());
            eventCtx.set("variable.event_position_y", position.y());
            eventCtx.set("variable.event_position_z", position.z());
            eventCtx.set("variable.event_velocity_x", velocity.x());
            eventCtx.set("variable.event_velocity_y", velocity.y());
            eventCtx.set("variable.event_velocity_z", velocity.z());
            executeEventNode(name, node, update, p, position, velocity, eventCtx);
        }

        private void executeEventNode(String eventName, ParticleEventNode node, ParticleUpdateContext update, Particle p,
                                      Vec3 position, Vec3 velocity, ExpressionContext eventCtx) {
            if (node instanceof ParticleEventNode.ExpressionNode expression) {
                if (expression.expression() != null) Expression.executeStatements(expression.expression(), eventCtx);
                if (expression.preEffectExpression() != null) Expression.executeStatements(expression.preEffectExpression(), eventCtx);
                return;
            }
            if (node instanceof ParticleEventNode.SequenceNode sequence) {
                for (ParticleEventNode child : sequence.nodes()) executeEventNode(eventName, child, update, p, position, velocity, eventCtx);
                return;
            }
            if (node instanceof ParticleEventNode.RandomNode randomNode) {
                double total = 0.0;
                for (ParticleEventNode.WeightedNode weighted : randomNode.nodes()) total += weighted.weight();
                double roll = random.nextDouble() * Math.max(0.0001, total);
                double cursor = 0.0;
                for (ParticleEventNode.WeightedNode weighted : randomNode.nodes()) {
                    cursor += weighted.weight();
                    if (roll <= cursor) {
                        executeEventNode(eventName, weighted.node(), update, p, position, velocity, eventCtx);
                        return;
                    }
                }
                return;
            }
            if (node instanceof ParticleEventNode.EmitNode emit) {
                emitManual(Math.max(0, (int) Math.round(Expression.of(emit.count()).eval(eventCtx))), update);
                return;
            }
            if (node instanceof ParticleEventNode.SoundNode sound) {
                update.eventSink().playSound(new ParticleSoundEvent(def.identifier(), eventName, sound.soundId(), position,
                        (float) Expression.of(sound.volume()).eval(eventCtx), (float) Expression.of(sound.pitch()).eval(eventCtx)));
                return;
            }
            if (node instanceof ParticleEventNode.LogNode log) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), eventName, log.message(), position));
                return;
            }
            if (node instanceof ParticleEventNode.SpawnNode spawn) {
                spawnChild(eventName, spawn, update, p, position, velocity, eventCtx);
            }
        }

        private void spawnChild(String eventName, ParticleEventNode.SpawnNode spawn, ParticleUpdateContext update, Particle p,
                                Vec3 position, Vec3 velocity, ExpressionContext eventCtx) {
            Map<String, Double> contextVars = new LinkedHashMap<>();
            Map<String, Double> localVars = new LinkedHashMap<>();
            for (Map.Entry<String, Double> entry : eventCtx.variables.entrySet()) {
                if (entry.getKey().startsWith("context.")) contextVars.put(entry.getKey(), entry.getValue());
            }
            // pre_effect_expression belongs to the new emitter's Molang state. Evaluating it on
            // the parent leaks/overwrites unrelated parent variables and differs from Wintersky.
            if (spawn.preEffectExpression() != null) {
                ExpressionContext preEffect = new ExpressionContext(random.nextLong());
                for (Map.Entry<String, Double> entry : contextVars.entrySet()) preEffect.set(entry.getKey(), entry.getValue());
                Expression.executeStatements(spawn.preEffectExpression(), preEffect);
                for (Map.Entry<String, Double> entry : preEffect.variables.entrySet()) {
                    if (entry.getKey().startsWith("variable.")) localVars.put(entry.getKey(), entry.getValue());
                }
            }
            ParticleChildSpawnRequest request = new ParticleChildSpawnRequest(def.identifier(), spawn.effect(), eventName,
                    position, spawn.kind() == ParticleEventNode.SpawnKind.PARTICLE_WITH_VELOCITY ? velocity : Vec3.ZERO,
                    spawn.kind() == ParticleEventNode.SpawnKind.EMITTER_BOUND, Map.copyOf(contextVars), Map.copyOf(localVars));
            update.eventSink().spawnEffect(request);
            ParticleEffectHandle childHandle = findHandle(spawn.effect());
            if (childHandle == null) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), eventName, "Missing child effect: " + spawn.effect(), position));
                return;
            }
            ParticleSpawnContext spawnContext = new ParticleSpawnContext(position, yawDegrees, random.nextLong(), contextVars, Map.of());
            Instance child = new Instance(owner, childHandle, owner.definitions.get(childHandle), spawnContext, this,
                    spawn.kind() == ParticleEventNode.SpawnKind.EMITTER_BOUND ? this : null,
                    spawn.preEffectExpression(),
                    spawn.kind() == ParticleEventNode.SpawnKind.PARTICLE_WITH_VELOCITY ? velocity : null);
            childEmitters.add(child);
            owner.pendingInstances.add(child);
        }

        private ParticleEffectHandle findHandle(String identifier) {
            for (Map.Entry<ParticleEffectHandle, ParticleEffectDefinition> entry : owner.definitions.entrySet()) {
                if (entry.getValue().identifier().equals(identifier)) return entry.getKey();
            }
            return null;
        }
    }

    private record ShapeResult(Vec3 offset, Vec3 direction) {
    }

    private record LoopState(float localAge, int index, boolean active, float lifetime) {
    }

    private static final class Particle {
        Vec3 position = Vec3.ZERO;
        Vec3 spawnPosition = Vec3.ZERO;
        Vec3 parametricOrigin = Vec3.ZERO;
        Vec3 velocity = Vec3.ZERO;
        float age;
        float lifetime = 1;
        float rotation;
        float initialRotation;
        float rotationRate;
        long expressionSeed;
        double r1;
        double r2;
        double r3;
        double r4;
        boolean localPosition;
        boolean localRotation;
        boolean collisionEventFired;
        boolean expirationEventFired;
        final List<Float> firedTimeline = new ArrayList<>();
        final List<Float> firedTravelDistances = new ArrayList<>();
        ExpressionContext context;
        float travelDistance;
        boolean alive = true;
    }

    private static String localVariableName(String name) {
        String normalized = name == null ? "" : name.trim().toLowerCase();
        return normalized.startsWith("variable.") ? normalized : "variable." + normalized;
    }
}

package fr.tofuxia.particles;

/** Host-provided Molang query/function bridge. */
@FunctionalInterface
public interface ExpressionFunctionResolver {
    ExpressionFunctionResolver NONE = (name, arguments) -> 0;
    double resolve(String name, double[] arguments);
}

package fr.tofuxia.particles;

import team.unnamed.mocha.runtime.value.Function;
import team.unnamed.mocha.runtime.value.MutableObjectBinding;
import team.unnamed.mocha.runtime.value.NumberValue;
import team.unnamed.mocha.runtime.value.Value;

/** Bedrock/Snowstorm math bindings with deterministic context-local randomness. */
final class SquallMath {
    static final MutableObjectBinding BINDING = create();

    private SquallMath() {
    }

    private static MutableObjectBinding create() {
        MutableObjectBinding math = new MutableObjectBinding();
        math.set("pi", NumberValue.of(Math.PI));
        bind(math, "abs", (c, a) -> Math.abs(arg(a, 0)));
        bind(math, "acos", (c, a) -> Math.toDegrees(Math.acos(arg(a, 0))));
        bind(math, "asin", (c, a) -> Math.toDegrees(Math.asin(arg(a, 0))));
        bind(math, "atan", (c, a) -> Math.toDegrees(Math.atan(arg(a, 0))));
        bind(math, "atan2", (c, a) -> Math.toDegrees(Math.atan2(arg(a, 0), arg(a, 1))));
        bind(math, "ceil", (c, a) -> Math.ceil(arg(a, 0)));
        bind(math, "clamp", (c, a) -> Math.max(arg(a, 1), Math.min(arg(a, 2), arg(a, 0))));
        bind(math, "copy_sign", (c, a) -> Math.copySign(arg(a, 0), arg(a, 1)));
        bind(math, "cos", (c, a) -> Math.cos(Math.toRadians(arg(a, 0))));
        bind(math, "exp", (c, a) -> Math.exp(arg(a, 0)));
        bind(math, "floor", (c, a) -> Math.floor(arg(a, 0)));
        bind(math, "hermite_blend", (c, a) -> arg(a, 0) * arg(a, 0) * (3D - 2D * arg(a, 0)));
        bind(math, "inverse_lerp", (c, a) -> arg(a, 1) == arg(a, 0) ? 0D : (arg(a, 2) - arg(a, 0)) / (arg(a, 1) - arg(a, 0)));
        bind(math, "lerp", (c, a) -> arg(a, 0) + (arg(a, 1) - arg(a, 0)) * arg(a, 2));
        bind(math, "lerprotate", (c, a) -> arg(a, 0) + minAngle(arg(a, 1) - arg(a, 0)) * arg(a, 2));
        bind(math, "ln", (c, a) -> Math.log(arg(a, 0)));
        bind(math, "max", (c, a) -> Math.max(arg(a, 0), arg(a, 1)));
        bind(math, "min", (c, a) -> Math.min(arg(a, 0), arg(a, 1)));
        bind(math, "min_angle", (c, a) -> minAngle(arg(a, 0)));
        bind(math, "mod", (c, a) -> arg(a, 1) == 0D ? 0D : arg(a, 0) % arg(a, 1));
        bind(math, "pow", (c, a) -> Math.pow(arg(a, 0), arg(a, 1)));
        bind(math, "random", (c, a) -> arg(a, 0) + c.random.nextDouble() * (arg(a, 1) - arg(a, 0)));
        bind(math, "random_integer", (c, a) -> Math.floor(arg(a, 0) + c.random.nextDouble() * (arg(a, 1) - arg(a, 0) + 1D)));
        bind(math, "round", (c, a) -> Math.round(arg(a, 0)));
        bind(math, "sign", (c, a) -> arg(a, 0) >= 0D ? 1D : -1D);
        bind(math, "sin", (c, a) -> Math.sin(Math.toRadians(arg(a, 0))));
        bind(math, "sqrt", (c, a) -> Math.sqrt(Math.max(0D, arg(a, 0))));
        bind(math, "trunc", (c, a) -> arg(a, 0) < 0D ? Math.ceil(arg(a, 0)) : Math.floor(arg(a, 0)));
        bind(math, "die_roll", (c, a) -> die(c, arg(a, 0), arg(a, 1), arg(a, 2), false));
        bind(math, "die_roll_integer", (c, a) -> die(c, arg(a, 0), arg(a, 1), arg(a, 2), true));

        String[] families = {"sine", "quad", "cubic", "quart", "quint", "expo", "circ", "back", "elastic", "bounce"};
        for (String family : families) {
            for (String direction : new String[]{"in", "out", "in_out"}) {
                String name = direction + "_" + family;
                bind(math, "ease_" + name, (c, a) -> easing(name, arg(a, 0), arg(a, 1), arg(a, 2)));
            }
        }
        math.block();
        return math;
    }

    private static void bind(MutableObjectBinding binding, String name, MolangFunction function) {
        binding.set(name, (Function<ExpressionContext>) (execution, arguments) -> {
            double[] values = new double[arguments.length()];
            for (int i = 0; i < values.length; i++) {
                Value value = arguments.next().eval();
                values[i] = value == null ? 0D : value.getAsNumber();
            }
            return NumberValue.of(function.apply(execution.entity(), values));
        });
    }

    private static double arg(double[] values, int index) {
        return index < values.length ? values[index] : 0D;
    }

    private static double minAngle(double value) {
        double angle = value % 360D;
        if (angle >= 180D) angle -= 360D;
        if (angle < -180D) angle += 360D;
        return angle;
    }

    private static double die(ExpressionContext context, double count, double low, double high, boolean integer) {
        double sum = 0D;
        for (int i = 0; i < Math.max(0, (int) count); i++) {
            double value = low + context.random.nextDouble() * (high - low + (integer ? 1D : 0D));
            sum += integer ? Math.floor(value) : value;
        }
        return sum;
    }

    private static double easing(String name, double start, double end, double t) {
        double x = Math.max(0D, Math.min(1D, t));
        double y;
        switch (name) {
            case "in_sine" -> y = 1D - Math.cos(x * Math.PI / 2D);
            case "out_sine" -> y = Math.sin(x * Math.PI / 2D);
            case "in_out_sine" -> y = -(Math.cos(Math.PI * x) - 1D) / 2D;
            case "in_quad" -> y = x * x;
            case "out_quad" -> y = 1D - (1D - x) * (1D - x);
            case "in_out_quad" -> y = x < .5D ? 2D * x * x : 1D - Math.pow(-2D * x + 2D, 2D) / 2D;
            case "in_cubic" -> y = x * x * x;
            case "out_cubic" -> y = 1D - Math.pow(1D - x, 3D);
            case "in_out_cubic" -> y = x < .5D ? 4D * x * x * x : 1D - Math.pow(-2D * x + 2D, 3D) / 2D;
            case "in_quart" -> y = Math.pow(x, 4D);
            case "out_quart" -> y = 1D - Math.pow(1D - x, 4D);
            case "in_out_quart" -> y = x < .5D ? 8D * Math.pow(x, 4D) : 1D - Math.pow(-2D * x + 2D, 4D) / 2D;
            case "in_quint" -> y = Math.pow(x, 5D);
            case "out_quint" -> y = 1D - Math.pow(1D - x, 5D);
            case "in_out_quint" -> y = x < .5D ? 16D * Math.pow(x, 5D) : 1D - Math.pow(-2D * x + 2D, 5D) / 2D;
            case "in_expo" -> y = x == 0D ? 0D : Math.pow(2D, 10D * x - 10D);
            case "out_expo" -> y = x == 1D ? 1D : 1D - Math.pow(2D, -10D * x);
            case "in_out_expo" -> y = x == 0D ? 0D : x == 1D ? 1D : x < .5D ? Math.pow(2D, 20D * x - 10D) / 2D : (2D - Math.pow(2D, -20D * x + 10D)) / 2D;
            case "in_circ" -> y = 1D - Math.sqrt(1D - x * x);
            case "out_circ" -> y = Math.sqrt(1D - Math.pow(x - 1D, 2D));
            case "in_out_circ" -> y = x < .5D ? (1D - Math.sqrt(1D - Math.pow(2D * x, 2D))) / 2D : (Math.sqrt(1D - Math.pow(-2D * x + 2D, 2D)) + 1D) / 2D;
            case "in_back" -> { double c = 1.70158D; y = (c + 1D) * x * x * x - c * x * x; }
            case "out_back" -> { double c = 1.70158D; y = 1D + (c + 1D) * Math.pow(x - 1D, 3D) + c * Math.pow(x - 1D, 2D); }
            case "in_out_back" -> { double c = 1.70158D * 1.525D; y = x < .5D ? Math.pow(2D * x, 2D) * ((c + 1D) * 2D * x - c) / 2D : (Math.pow(2D * x - 2D, 2D) * ((c + 1D) * (x * 2D - 2D) + c) + 2D) / 2D; }
            case "in_elastic" -> { double c = 2D * Math.PI / 3D; y = x == 0D ? 0D : x == 1D ? 1D : -Math.pow(2D, 10D * x - 10D) * Math.sin((x * 10D - 10.75D) * c); }
            case "out_elastic" -> { double c = 2D * Math.PI / 3D; y = x == 0D ? 0D : x == 1D ? 1D : Math.pow(2D, -10D * x) * Math.sin((x * 10D - .75D) * c) + 1D; }
            case "in_out_elastic" -> { double c = 2D * Math.PI / 4.5D; y = x == 0D ? 0D : x == 1D ? 1D : x < .5D ? -(Math.pow(2D, 20D * x - 10D) * Math.sin((20D * x - 11.125D) * c)) / 2D : Math.pow(2D, -20D * x + 10D) * Math.sin((20D * x - 11.125D) * c) / 2D + 1D; }
            case "out_bounce" -> y = outBounce(x);
            case "in_bounce" -> y = 1D - outBounce(1D - x);
            case "in_out_bounce" -> y = x < .5D ? (1D - outBounce(1D - 2D * x)) / 2D : (1D + outBounce(2D * x - 1D)) / 2D;
            default -> y = x;
        }
        return start + (end - start) * y;
    }

    private static double outBounce(double x) {
        double n = 7.5625D;
        double d = 2.75D;
        if (x < 1D / d) return n * x * x;
        if (x < 2D / d) { x -= 1.5D / d; return n * x * x + .75D; }
        if (x < 2.5D / d) { x -= 2.25D / d; return n * x * x + .9375D; }
        x -= 2.625D / d;
        return n * x * x + .984375D;
    }

    @FunctionalInterface
    private interface MolangFunction {
        double apply(ExpressionContext context, double[] arguments);
    }
}

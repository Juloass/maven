package fr.tofuxia.particles;

import io.github.juloass.identifier.Identifier;

public record ParticleSoundEvent(String sourceEffect, String eventName, Identifier soundId,
                                 Vec3 position, float volume, float pitch) {
}

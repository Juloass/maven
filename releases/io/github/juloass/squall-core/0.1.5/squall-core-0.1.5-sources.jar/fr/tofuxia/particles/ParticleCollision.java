package fr.tofuxia.particles;

/** Result of sweeping a spherical particle through world geometry. */
public record ParticleCollision(boolean hit, Vec3 position, Vec3 normal, float impactSpeed) {
    public static ParticleCollision miss(Vec3 position) {
        return new ParticleCollision(false, position, Vec3.ZERO, 0);
    }
}

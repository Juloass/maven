package fr.tofuxia.particles;

import java.util.Map;

public record ParticleChildSpawnRequest(String sourceEffect, String childEffect, String eventName,
                                        Vec3 position, Vec3 velocity, boolean bound,
                                        Map<String, Double> contextVariables,
                                        Map<String, Double> localVariables) {
}

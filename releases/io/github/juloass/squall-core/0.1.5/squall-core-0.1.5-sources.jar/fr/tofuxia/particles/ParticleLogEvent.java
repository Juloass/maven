package fr.tofuxia.particles;

public record ParticleLogEvent(String sourceEffect, String eventName, String message, Vec3 position) {
}

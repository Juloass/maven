package fr.tofuxia.particles;

import java.util.Map;

public record ParticleUpdateContext(Vec3 cameraPosition, ParticleCollisionProvider collisionProvider,
                                    Map<String, Double> variables, ParticleEventSink eventSink,
                                    ExpressionFunctionResolver functionResolver) {
    public ParticleUpdateContext(Vec3 cameraPosition, ParticleCollisionProvider collisionProvider,
                                 Map<String, Double> variables, ParticleEventSink eventSink) {
        this(cameraPosition, collisionProvider, variables, eventSink, ExpressionFunctionResolver.NONE);
    }

    public ParticleUpdateContext(Vec3 cameraPosition, ParticleCollisionProvider collisionProvider,
                                 Map<String, Double> variables) {
        this(cameraPosition, collisionProvider, variables, ParticleEventSink.NONE);
    }

    public static ParticleUpdateContext basic(Vec3 cameraPosition) {
        return new ParticleUpdateContext(cameraPosition, ParticleCollisionProvider.NONE, Map.of(), ParticleEventSink.NONE,
                ExpressionFunctionResolver.NONE);
    }
}

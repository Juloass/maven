package fr.tofuxia.particles;

public interface ParticleEventSink {
    ParticleEventSink NONE = new ParticleEventSink() {
    };

    default void spawnEffect(ParticleChildSpawnRequest request) {
    }

    default void playSound(ParticleSoundEvent event) {
    }

    default void log(ParticleLogEvent event) {
    }
}

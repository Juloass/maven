package fr.tofuxia.particles;

import java.util.List;

public interface ParticleCollisionProvider {
    ParticleCollisionProvider NONE = new ParticleCollisionProvider() {
    };

    default boolean collides(Vec3 position, float radius) {
        return false;
    }

    /**
     * Sweeps from {@code from} to {@code to}. Integrations should override this
     * to provide contact normals and de-penetrated positions. The legacy point
     * query remains a compatibility fallback.
     */
    default ParticleCollision sweep(Vec3 from, Vec3 to, float radius) {
        return collides(to, radius)
                ? new ParticleCollision(true, from, to.sub(from).normalize().mul(-1), to.sub(from).length())
                : ParticleCollision.miss(to);
    }

    default boolean isInsideAnyEnvironment(Vec3 position, List<String> environmentIds) {
        return true;
    }

    default boolean isInsideAllowedBlock(Vec3 position, List<String> blockIds) {
        return isInsideAnyEnvironment(position, blockIds);
    }
}

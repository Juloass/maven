package io.github.juloass.particle;

import java.util.List;

public interface ParticleCollisionProvider {
    ParticleCollisionProvider NONE = new ParticleCollisionProvider() {
    };

    default boolean collides(Vec3 position, float radius) {
        return false;
    }

    default boolean isInsideAnyEnvironment(Vec3 position, List<String> environmentIds) {
        return true;
    }

    default boolean isInsideAllowedBlock(Vec3 position, List<String> blockIds) {
        return isInsideAnyEnvironment(position, blockIds);
    }
}

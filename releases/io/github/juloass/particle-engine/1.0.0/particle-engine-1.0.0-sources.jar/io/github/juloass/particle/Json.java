package io.github.juloass.particle;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Json {
    private final String s;
    private int p;

    private Json(String s) {
        this.s = s;
    }

    static Object parse(String text) {
        Json json = new Json(text);
        Object value = json.value();
        json.ws();
        if (json.p != json.s.length()) throw new ParticleLoadException("Trailing JSON content at " + json.p);
        return value;
    }

    private Object value() {
        ws();
        if (p >= s.length()) throw new ParticleLoadException("Unexpected end of JSON");
        char c = s.charAt(p);
        if (c == '{') return object();
        if (c == '[') return array();
        if (c == '"') return string();
        if (c == 't' && take("true")) return Boolean.TRUE;
        if (c == 'f' && take("false")) return Boolean.FALSE;
        if (c == 'n' && take("null")) return null;
        return number();
    }

    private Map<String, Object> object() {
        p++;
        Map<String, Object> out = new LinkedHashMap<>();
        ws();
        if (peek('}')) return out;
        while (true) {
            String key = string();
            ws();
            expect(':');
            out.put(key, value());
            ws();
            if (peek('}')) return out;
            expect(',');
        }
    }

    private List<Object> array() {
        p++;
        List<Object> out = new ArrayList<>();
        ws();
        if (peek(']')) return out;
        while (true) {
            out.add(value());
            ws();
            if (peek(']')) return out;
            expect(',');
        }
    }

    private String string() {
        expect('"');
        StringBuilder out = new StringBuilder();
        while (p < s.length()) {
            char c = s.charAt(p++);
            if (c == '"') return out.toString();
            if (c == '\\') {
                char e = s.charAt(p++);
                switch (e) {
                    case '"', '\\', '/' -> out.append(e);
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case 'u' -> {
                        out.append((char) Integer.parseInt(s.substring(p, p + 4), 16));
                        p += 4;
                    }
                    default -> throw new ParticleLoadException("Bad JSON escape \\" + e);
                }
            } else {
                out.append(c);
            }
        }
        throw new ParticleLoadException("Unterminated JSON string");
    }

    private Number number() {
        int start = p;
        if (s.charAt(p) == '-') p++;
        while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
        if (p < s.length() && s.charAt(p) == '.') {
            p++;
            while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
        }
        if (p < s.length() && (s.charAt(p) == 'e' || s.charAt(p) == 'E')) {
            p++;
            if (s.charAt(p) == '+' || s.charAt(p) == '-') p++;
            while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
        }
        return Double.parseDouble(s.substring(start, p));
    }

    private void ws() {
        while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++;
    }

    private boolean take(String token) {
        if (!s.startsWith(token, p)) return false;
        p += token.length();
        return true;
    }

    private boolean peek(char c) {
        if (p < s.length() && s.charAt(p) == c) {
            p++;
            return true;
        }
        return false;
    }

    private void expect(char c) {
        ws();
        if (p >= s.length() || s.charAt(p) != c) throw new ParticleLoadException("Expected '" + c + "' at " + p);
        p++;
    }
}

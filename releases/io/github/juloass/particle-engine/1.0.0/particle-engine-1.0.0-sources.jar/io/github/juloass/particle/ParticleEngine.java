package io.github.juloass.particle;

import io.github.juloass.color.Color;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Collections;

public final class ParticleEngine {
    private final Map<ParticleEffectHandle, ParticleEffectDefinition> definitions = new LinkedHashMap<>();
    private final List<Instance> instances = new ArrayList<>();
    private final List<Instance> pendingInstances = new ArrayList<>();
    private final List<ParticleRenderPacket> packets = new ArrayList<>();
    private int nextHandle = 1;

    public ParticleEffectHandle register(ParticleEffectDefinition definition) {
        ParticleEffectHandle handle = new ParticleEffectHandle(nextHandle++);
        definitions.put(handle, definition);
        return handle;
    }

    public ParticleEffectInstance spawn(ParticleEffectHandle handle, ParticleSpawnContext context) {
        ParticleEffectDefinition definition = definitions.get(handle);
        if (definition == null) throw new IllegalArgumentException("Unknown particle handle: " + handle.id());
        Instance instance = new Instance(this, handle, definition, context);
        instances.add(instance);
        return new ParticleEffectInstance(instance);
    }

    public void update(float dt, ParticleUpdateContext context) {
        packets.clear();
        for (Instance instance : instances) {
            instance.followBoundParent();
            instance.update(dt, context);
            instance.collect(context, packets);
        }
        instances.addAll(pendingInstances);
        pendingInstances.clear();
        instances.removeIf(i -> !i.alive);
        packets.sort(Comparator.comparingDouble(ParticleRenderPacket::sortDistance).reversed());
    }

    public List<ParticleRenderPacket> collectRenderPackets() {
        return Collections.unmodifiableList(packets);
    }

    static final class Instance {
        final ParticleEffectHandle handle;
        final ParticleEngine owner;
        final ParticleEffectDefinition def;
        final ExpressionContext emitterCtx;
        final Random random;
        final List<Particle> particles = new ArrayList<>();
        final Map<String, Double> instanceContextVariables = new LinkedHashMap<>();
        final Instance boundParent;
        Vec3 worldPosition;
        float yawDegrees;
        double emitterRandom1;
        double emitterRandom2;
        double emitterRandom3;
        double emitterRandom4;
        float age;
        float spawnDebt;
        boolean instantDone;
        int loopIndex;
        boolean emitting = true;
        boolean currentlyEmitting = true;
        boolean alive = true;
        boolean creationEventFired;
        boolean expirationEventFired;
        boolean previousActive;
        final List<Float> firedEmitterTimeline = new ArrayList<>();
        final List<String> expireInEnvironments;
        final List<String> expireNotInEnvironments;

        Instance(ParticleEngine owner, ParticleEffectHandle handle, ParticleEffectDefinition def, ParticleSpawnContext spawn) {
            this(owner, handle, def, spawn, null);
        }

        Instance(ParticleEngine owner, ParticleEffectHandle handle, ParticleEffectDefinition def, ParticleSpawnContext spawn, Instance boundParent) {
            this.owner = owner;
            this.handle = handle;
            this.def = def;
            this.boundParent = boundParent;
            this.worldPosition = spawn.worldPosition();
            this.yawDegrees = spawn.yawDegrees();
            this.emitterCtx = new ExpressionContext(spawn.seed());
            this.random = new Random(spawn.seed() ^ 0x5DEECE66DL);
            this.expireInEnvironments = environmentNames(def.components().get("minecraft:particle_expire_if_in_blocks"));
            this.expireNotInEnvironments = environmentNames(def.components().get("minecraft:particle_expire_if_not_in_blocks"));
            if (spawn.contextVariables() != null) {
                for (Map.Entry<String, Double> entry : spawn.contextVariables().entrySet()) {
                    setContextVariable(entry.getKey(), entry.getValue());
                }
            }
            if (spawn.localVariables() != null) {
                for (Map.Entry<String, Double> entry : spawn.localVariables().entrySet()) {
                    emitterCtx.set(localVariableName(entry.getKey()), entry.getValue());
                }
            }
            initializeEmitterRandoms();
            applyContextVariables(emitterCtx, Map.of());
            Map<String, Object> init = def.componentMap("minecraft:emitter_initialization");
            Object expr = init.get("creation_expression");
            if (expr instanceof String s) Expression.executeStatements(s, emitterCtx);
        }

        void setTransform(Vec3 position, float yawDegrees) {
            this.worldPosition = position == null ? Vec3.ZERO : position;
            this.yawDegrees = yawDegrees;
        }

        void setPosition(Vec3 position) {
            this.worldPosition = position == null ? Vec3.ZERO : position;
        }

        void setYawDegrees(float yawDegrees) {
            this.yawDegrees = yawDegrees;
        }

        void setContextVariable(String name, double value) {
            instanceContextVariables.put(contextName(name), value);
        }

        void removeContextVariable(String name) {
            instanceContextVariables.remove(contextName(name));
        }

        void clearContextVariables() {
            instanceContextVariables.clear();
        }

        void stopEmitting() {
            emitting = false;
            currentlyEmitting = false;
        }

        void kill() {
            emitting = false;
            currentlyEmitting = false;
            alive = false;
            particles.clear();
        }

        boolean isAlive() {
            return alive;
        }

        boolean isEmitting() {
            return alive && emitting && currentlyEmitting;
        }

        void followBoundParent() {
            if (boundParent != null) {
                worldPosition = boundParent.worldPosition;
                yawDegrees = boundParent.yawDegrees;
            }
        }

        void update(float dt, ParticleUpdateContext context) {
            if (!alive) return;
            applyContextVariables(emitterCtx, context.variables());
            if (!creationEventFired) {
                creationEventFired = true;
                fireEmitterEvent("creation_event", context, null);
            }
            age += dt;
            LoopState loop = loopState();
            if (loop.index != loopIndex) {
                loopIndex = loop.index;
                instantDone = false;
                spawnDebt = 0.0f;
                initializeEmitterRandoms();
                firedEmitterTimeline.clear();
                fireEmitterEvent("creation_event", context, null);
            }
            updateEmitterBuiltins(loop);
            currentlyEmitting = active();
            fireEmitterTimeline(context, loop);
            if (currentlyEmitting) emit(dt, context);
            ParticleCollisionProvider collision = context.collisionProvider() == null ? ParticleCollisionProvider.NONE : context.collisionProvider();
            for (Particle p : particles) updateParticle(p, dt, collision, context);
            for (Particle p : particles) {
                if (!p.expirationEventFired && (!p.alive || p.age >= p.lifetime)) {
                    p.expirationEventFired = true;
                    fireParticleEvent("expiration_event", context, p);
                }
            }
            particles.removeIf(p -> !p.alive || p.age >= p.lifetime);
            currentlyEmitting = active();
            if (previousActive && !currentlyEmitting && !expirationEventFired) {
                expirationEventFired = true;
                fireEmitterEvent("expiration_event", context, null);
            }
            previousActive = currentlyEmitting;
            alive = currentlyEmitting || !particles.isEmpty();
        }

        private boolean active() {
            if (!alive || !emitting) return false;
            LoopState loop = loopState();
            updateEmitterBuiltins(loop);
            if (!loop.active) return false;
            Map<String, Object> expr = def.componentMap("minecraft:emitter_lifetime_expression");
            if (expr.containsKey("activation_expression")) return Expression.of(expr.get("activation_expression")).eval(emitterCtx) != 0.0;
            return true;
        }

        private LoopState loopState() {
            Map<String, Object> once = def.componentMap("minecraft:emitter_lifetime_once");
            if (!once.isEmpty()) {
                float activeTime = Math.max(0.001f, (float) Expression.of(once.getOrDefault("active_time", 1)).eval(emitterCtx));
                return new LoopState(Math.min(age, activeTime), 0, age <= activeTime, activeTime);
            }
            Map<String, Object> loop = def.componentMap("minecraft:emitter_lifetime_looping");
            if (loop.isEmpty()) return new LoopState(age, 0, true, 0.0f);
            float activeTime = Math.max(0.001f, (float) Expression.of(loop.getOrDefault("active_time", 1)).eval(emitterCtx));
            float sleepTime = Math.max(0.0f, (float) Expression.of(loop.getOrDefault("sleep_time", 0)).eval(emitterCtx));
            float cycle = Math.max(0.001f, activeTime + sleepTime);
            int index = (int) Math.floor(age / cycle);
            float localAge = age - index * cycle;
            return new LoopState(localAge, index, localAge <= activeTime, activeTime);
        }

        private void emit(float dt, ParticleUpdateContext context) {
            Map<String, Object> instant = def.componentMap("minecraft:emitter_rate_instant");
            if (!instant.isEmpty() && !instantDone) {
                int count = (int) Math.round(Expression.of(instant.getOrDefault("num_particles", 0)).eval(emitterCtx));
                for (int i = 0; i < count; i++) spawnParticle(context);
                instantDone = true;
            }
            Map<String, Object> steady = def.componentMap("minecraft:emitter_rate_steady");
            if (!steady.isEmpty()) {
                int max = (int) Math.round(Expression.of(steady.getOrDefault("max_particles", 1000)).eval(emitterCtx));
                double rate = Expression.of(steady.getOrDefault("spawn_rate", 0)).eval(emitterCtx);
                spawnDebt += (float) (rate * dt);
                while (spawnDebt >= 1.0f && particles.size() < max) {
                    spawnParticle(context);
                    spawnDebt -= 1.0f;
                }
            }
        }

        private void emitManual(int count, ParticleUpdateContext context) {
            int max = (int) Math.round(Expression.of(def.componentMap("minecraft:emitter_rate_manual").getOrDefault("max_particles", 1000)).eval(emitterCtx));
            for (int i = 0; i < count && particles.size() < max; i++) spawnParticle(context);
        }

        private void spawnParticle(ParticleUpdateContext context) {
            Particle p = new Particle();
            p.expressionSeed = random.nextLong();
            p.r1 = random.nextDouble();
            p.r2 = random.nextDouble();
            p.r3 = random.nextDouble();
            p.r4 = random.nextDouble();
            ExpressionContext ctx = particleCtx(p);
            ShapeResult shape = shape(ctx);
            p.localPosition = localSpacePosition();
            p.localRotation = localSpaceRotation();
            Vec3 spawnOffset = p.localPosition ? shape.offset : transformDirection(shape.offset, p.localRotation);
            p.position = p.localPosition ? spawnOffset : worldPosition.add(spawnOffset);
            p.spawnPosition = p.position;
            double speed = Expression.of(componentValue("minecraft:particle_initial_speed", 0)).eval(ctx);
            Vec3 direction = p.localPosition ? shape.direction : transformDirection(shape.direction, p.localRotation);
            p.velocity = direction.normalize().mul((float) speed);
            p.lifetime = Math.max(0.001f, (float) Expression.of(def.componentMap("minecraft:particle_lifetime_expression").getOrDefault("max_lifetime", 1)).eval(ctx));
            Map<String, Object> spin = def.componentMap("minecraft:particle_initial_spin");
            p.rotation = (float) Expression.of(spin.getOrDefault("rotation", 0)).eval(ctx);
            p.rotationRate = (float) Expression.of(spin.getOrDefault("rotation_rate", 0)).eval(ctx);
            particles.add(p);
            fireParticleEvent("creation_event", context, p);
        }

        private Object componentValue(String component, Object fallback) {
            Object value = def.components().get(component);
            return value == null ? fallback : value;
        }

        private ShapeResult shape(ExpressionContext ctx) {
            if (def.has("minecraft:emitter_shape_sphere")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_sphere");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                float radius = Math.max(0.0f, (float) Expression.of(c.getOrDefault("radius", 0)).eval(ctx));
                Vec3 unit = randomUnitVector();
                float r = Boolean.TRUE.equals(c.get("surface_only")) ? radius : radius * (float) Math.cbrt(random.nextDouble());
                Vec3 radial = unit.mul(r);
                Object directionRaw = c.get("direction");
                Vec3 dir = "outwards".equals(directionRaw) ? unit : vec(directionRaw, ctx, new Vec3(0, 1, 0));
                return new ShapeResult(off.add(radial), dir.normalize());
            }
            if (def.has("minecraft:emitter_shape_box")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_box");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                Vec3 half = vec(c.get("half_dimensions"), ctx, Vec3.ZERO);
                Vec3 pos = new Vec3(off.x() + rand(-half.x(), half.x()), off.y() + rand(-half.y(), half.y()), off.z() + rand(-half.z(), half.z()));
                return new ShapeResult(pos, vec(c.get("direction"), ctx, new Vec3(0, 1, 0)));
            }
            if (def.has("minecraft:emitter_shape_disc")) {
                Map<String, Object> c = def.componentMap("minecraft:emitter_shape_disc");
                Vec3 off = vec(c.get("offset"), ctx, Vec3.ZERO);
                float radius = (float) Expression.of(c.getOrDefault("radius", 0)).eval(ctx);
                double a = random.nextDouble() * Math.PI * 2.0;
                float r = Boolean.TRUE.equals(c.get("surface_only")) ? radius : radius * (float) Math.sqrt(random.nextDouble());
                Vec3 radial = new Vec3((float) Math.cos(a) * r, (float) Math.sin(a) * r, 0);
                Vec3 dir = "outwards".equals(c.get("direction")) ? radial.normalize() : new Vec3(0, 1, 0);
                return new ShapeResult(off.add(radial), dir);
            }
            Map<String, Object> point = def.componentMap("minecraft:emitter_shape_point");
            return new ShapeResult(vec(point.get("offset"), ctx, Vec3.ZERO), new Vec3(0, 1, 0));
        }

        private void updateParticle(Particle p, float dt, ParticleCollisionProvider collision, ParticleUpdateContext context) {
            float previousAge = p.age;
            p.age += dt;
            ExpressionContext ctx = particleCtx(p);
            Vec3 acceleration = vec(def.componentMap("minecraft:particle_motion_dynamic").get("linear_acceleration"), ctx, Vec3.ZERO);
            p.velocity = p.velocity.add(acceleration.mul(dt));
            float drag = (float) Expression.of(def.componentMap("minecraft:particle_motion_dynamic").getOrDefault("linear_drag_coefficient", 0)).eval(ctx);
            p.velocity = p.velocity.mul(Math.max(0.0f, 1.0f - drag * dt));
            p.position = p.position.add(p.velocity.mul(dt));
            Map<String, Object> parametric = def.componentMap("minecraft:particle_motion_parametric");
            if (!parametric.isEmpty()) {
                applyCurves(ctx);
                Object position = parametric.containsKey("relative_position") ? parametric.get("relative_position") : parametric.get("position");
                p.position = p.spawnPosition.add(vec(position, ctx, Vec3.ZERO));
            }
            p.rotation += p.rotationRate * dt;
            fireParticleTimeline(context, p, previousAge);
            Map<String, Object> collisionComponent = def.componentMap("minecraft:particle_motion_collision");
            if (!collisionComponent.isEmpty()) {
                float radius = (float) Expression.of(collisionComponent.getOrDefault("collision_radius", 0)).eval(ctx);
                if (collision.collides(renderPosition(p), radius)) {
                    if (!p.collisionEventFired) {
                        p.collisionEventFired = true;
                        fireParticleEvent("collision_event", context, p);
                    }
                    if (Boolean.TRUE.equals(collisionComponent.get("expire_on_contact"))) p.alive = false;
                    float cdrag = (float) Expression.of(collisionComponent.getOrDefault("collision_drag", 0)).eval(ctx);
                    p.velocity = p.velocity.mul(Math.max(0.0f, 1.0f - cdrag * dt));
                }
            }
            if (!expireInEnvironments.isEmpty()
                    && collision.isInsideAnyEnvironment(renderPosition(p), expireInEnvironments)) {
                p.alive = false;
            }
            if (!expireNotInEnvironments.isEmpty()
                    && !collision.isInsideAnyEnvironment(renderPosition(p), expireNotInEnvironments)) {
                p.alive = false;
            }
        }

        private static List<String> environmentNames(Object value) {
            if (!(value instanceof List<?> values) || values.isEmpty()) return List.of();
            ArrayList<String> names = new ArrayList<>(values.size());
            for (Object entry : values) names.add(String.valueOf(entry));
            return List.copyOf(names);
        }

        void collect(ParticleUpdateContext context, List<ParticleRenderPacket> out) {
            if (!alive) return;
            applyContextVariables(emitterCtx, context.variables());
            for (Particle p : particles) {
                if (!p.alive) continue;
                ExpressionContext ctx = particleCtx(p);
                applyCurves(ctx);
                Map<String, Object> billboard = def.componentMap("minecraft:particle_appearance_billboard");
                Vec2 size = vec2(billboard.get("size"), ctx, new Vec2(0.1f, 0.1f));
                Map<String, Object> uv = ParticleDefinitionLoader.asMap(billboard.get("uv"), "uv");
                Rect rect = uvRect(uv, p);
                Vec2 texSize = new Vec2((float) Expression.of(uv.getOrDefault("texture_width", 128)).eval(ctx),
                        (float) Expression.of(uv.getOrDefault("texture_height", 128)).eval(ctx));
                BillboardMode mode = mode(String.valueOf(billboard.getOrDefault("facing_camera_mode", "rotate_xyz")));
                Vec3 camera = context.cameraPosition() == null ? Vec3.ZERO : context.cameraPosition();
                Vec3 renderPosition = renderPosition(p);
                float dx = renderPosition.x() - camera.x();
                float dy = renderPosition.y() - camera.y();
                float dz = renderPosition.z() - camera.z();
                out.add(new ParticleRenderPacket(def.identifier(), def.material(), texture(billboard, p, ctx), renderPosition, size,
                        p.rotation, mode, customDirection(billboard, ctx, p), rect, texSize, color(ctx), p.age, p.lifetime,
                        dx * dx + dy * dy + dz * dz, 0));
            }
        }

        private String texture(Map<String, Object> billboard, Particle p, ExpressionContext ctx) {
            Object framesRaw = billboard.get("texture_frames");
            if (!(framesRaw instanceof Map<?, ?> raw)) return def.texture();
            @SuppressWarnings("unchecked") Map<String, Object> frames = (Map<String, Object>) raw;
            Object frameList = frames.get("frames");
            if (!(frameList instanceof List<?> list) || list.isEmpty()) return def.texture();
            int frame;
            String mode = String.valueOf(frames.getOrDefault("mode", "expression"));
            if ("lifetime".equals(mode)) {
                frame = (int) Math.floor((p.age / Math.max(0.001f, p.lifetime)) * list.size());
            } else if ("random".equals(mode)) {
                Object random = frames.getOrDefault("random", "variable.particle_random_2");
                frame = (int) Math.floor(Expression.of(random).eval(ctx) * list.size());
            } else {
                frame = (int) Math.floor(Expression.of(frames.getOrDefault("frame", 0)).eval(ctx));
            }
            frame = Math.max(0, Math.min(list.size() - 1, frame));
            return String.valueOf(list.get(frame));
        }

        private Color color(ExpressionContext ctx) {
            Map<String, Object> tint = def.componentMap("minecraft:particle_appearance_tinting");
            Object color = tint.get("color");
            if (color instanceof List<?> list) {
                return Color.srgb(Expression.of(list.get(0)).eval(ctx), Expression.of(list.get(1)).eval(ctx),
                        Expression.of(list.get(2)).eval(ctx), list.size() > 3 ? Expression.of(list.get(3)).eval(ctx) : 1);
            }
            if (color instanceof Map<?, ?> map) {
                double t = Expression.of(map.get("interpolant")).eval(ctx);
                @SuppressWarnings("unchecked") Map<String, Object> gradient = (Map<String, Object>) map.get("gradient");
                return gradient(gradient, t);
            }
            return Color.srgb(1, 1, 1);
        }

        private Color gradient(Map<String, Object> gradient, double t) {
            double prevK = 0;
            double nextK = 1;
            String prev = null;
            String next = null;
            for (String key : gradient.keySet()) {
                double k = Double.parseDouble(key);
                if (k <= t && (prev == null || k >= prevK)) { prevK = k; prev = gradient.get(key).toString(); }
                if (k >= t && (next == null || k <= nextK)) { nextK = k; next = gradient.get(key).toString(); }
            }
            Color a = hex(prev == null ? next : prev);
            Color b = hex(next == null ? prev : next);
            float f = nextK == prevK ? 0 : (float) ((t - prevK) / (nextK - prevK));
            return a.interpolate(b, f, Color.InterpolationSpace.SRGB, Color.HueInterpolation.SHORTER);
        }

        private Color hex(String s) {
            return Color.parse(s);
        }

        private Rect uvRect(Map<String, Object> uv, Particle p) {
            ExpressionContext ctx = particleCtx(p);
            if (uv.get("flipbook") instanceof Map<?, ?> fbRaw) {
                @SuppressWarnings("unchecked") Map<String, Object> fb = (Map<String, Object>) fbRaw;
                Vec2 base = vec2(fb.get("base_UV"), ctx, Vec2.ZERO);
                Vec2 size = vec2(fb.get("size_UV"), ctx, new Vec2(8, 8));
                Vec2 step = vec2(fb.get("step_UV"), ctx, Vec2.ZERO);
                int max = (int) Expression.of(fb.getOrDefault("max_frame", 1)).eval(ctx);
                int frame = Boolean.TRUE.equals(fb.get("stretch_to_lifetime"))
                        ? Math.max(0, Math.min(max - 1, (int) Math.floor((p.age / p.lifetime) * max))) : 0;
                return new Rect(base.x() + step.x() * frame, base.y() + step.y() * frame, size.x(), size.y());
            }
            Vec2 pos = vec2(uv.get("uv"), ctx, Vec2.ZERO);
            Vec2 size = vec2(uv.get("uv_size"), ctx, new Vec2(8, 8));
            return new Rect(pos.x(), pos.y(), size.x(), size.y());
        }

        private ExpressionContext particleCtx(Particle p) {
            long ageBits = Float.floatToIntBits(p.age) & 0xffffffffL;
            ExpressionContext ctx = new ExpressionContext(p.expressionSeed ^ (ageBits * 0x9E3779B97F4A7C15L));
            ctx.variables.putAll(emitterCtx.variables);
            updateEmitterBuiltins(ctx, loopState());
            ctx.set("variable.particle_age", p.age);
            ctx.set("variable.particle_lifetime", p.lifetime);
            ctx.set("variable.particle_random_1", p.r1);
            ctx.set("variable.particle_random_2", p.r2);
            ctx.set("variable.particle_random_3", p.r3);
            ctx.set("variable.particle_random_4", p.r4);
            return ctx;
        }

        private Vec3 customDirection(Map<String, Object> billboard, ExpressionContext ctx, Particle p) {
            Object direction = billboard.get("direction");
            Vec3 custom = new Vec3(0, 0, -1);
            if (direction instanceof Map<?, ?> map) custom = vec(((Map<?, ?>) map).get("custom_direction"), ctx, custom);
            return p.localPosition ? transformDirection(custom, p.localRotation) : custom;
        }

        private BillboardMode mode(String s) {
            return switch (s) {
                case "lookat_xyz" -> BillboardMode.LOOKAT_XYZ;
                case "lookat_y" -> BillboardMode.LOOKAT_Y;
                case "direction_x" -> BillboardMode.DIRECTION_X;
                case "direction_y" -> BillboardMode.DIRECTION_Y;
                case "direction_z" -> BillboardMode.DIRECTION_Z;
                default -> BillboardMode.ROTATE_XYZ;
            };
        }

        private Vec3 vec(Object value, ExpressionContext ctx, Vec3 fallback) {
            if (!(value instanceof List<?> list) || list.size() < 3) return fallback;
            return new Vec3((float) Expression.of(list.get(0)).eval(ctx), (float) Expression.of(list.get(1)).eval(ctx), (float) Expression.of(list.get(2)).eval(ctx));
        }

        private Vec2 vec2(Object value, ExpressionContext ctx, Vec2 fallback) {
            if (!(value instanceof List<?> list) || list.size() < 2) return fallback;
            return new Vec2((float) Expression.of(list.get(0)).eval(ctx), (float) Expression.of(list.get(1)).eval(ctx));
        }

        private float rand(float min, float max) {
            return min + random.nextFloat() * (max - min);
        }

        private Vec3 randomUnitVector() {
            double z = random.nextDouble() * 2.0 - 1.0;
            double a = random.nextDouble() * Math.PI * 2.0;
            double r = Math.sqrt(Math.max(0.0, 1.0 - z * z));
            return new Vec3((float) (Math.cos(a) * r), (float) z, (float) (Math.sin(a) * r));
        }

        private boolean localSpacePosition() {
            return Boolean.TRUE.equals(def.componentMap("minecraft:emitter_local_space").get("position"));
        }

        private boolean localSpaceRotation() {
            return Boolean.TRUE.equals(def.componentMap("minecraft:emitter_local_space").get("rotation"));
        }

        private Vec3 renderPosition(Particle p) {
            return p.localPosition ? worldPosition.add(transformDirection(p.position, p.localRotation)) : p.position;
        }

        private Vec3 transformDirection(Vec3 value, boolean rotate) {
            if (!rotate) return value;
            double radians = Math.toRadians(yawDegrees);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            return new Vec3(value.x() * cos - value.z() * sin, value.y(), value.x() * sin + value.z() * cos);
        }

        private void applyContextVariables(ExpressionContext ctx, Map<String, Double> updateVariables) {
            ctx.variables.keySet().removeIf(name -> name.startsWith("context."));
            if (updateVariables != null) {
                for (Map.Entry<String, Double> entry : updateVariables.entrySet()) {
                    ctx.set(contextName(entry.getKey()), entry.getValue());
                }
            }
            for (Map.Entry<String, Double> entry : instanceContextVariables.entrySet()) {
                ctx.set(entry.getKey(), entry.getValue());
            }
        }

        private static String contextName(String name) {
            String normalized = name == null ? "" : name.trim().toLowerCase();
            return normalized.startsWith("context.") ? normalized : "context." + normalized;
        }

        private void initializeEmitterRandoms() {
            emitterRandom1 = random.nextDouble();
            emitterRandom2 = random.nextDouble();
            emitterRandom3 = random.nextDouble();
            emitterRandom4 = random.nextDouble();
        }

        private void updateEmitterBuiltins(LoopState loop) {
            updateEmitterBuiltins(emitterCtx, loop);
        }

        private void updateEmitterBuiltins(ExpressionContext ctx, LoopState loop) {
            ctx.set("variable.emitter_age", loop.localAge);
            ctx.set("variable.emitter_lifetime", loop.lifetime);
            ctx.set("variable.emitter_random_1", emitterRandom1);
            ctx.set("variable.emitter_random_2", emitterRandom2);
            ctx.set("variable.emitter_random_3", emitterRandom3);
            ctx.set("variable.emitter_random_4", emitterRandom4);
        }

        private void applyCurves(ExpressionContext ctx) {
            for (CurveDefinition curve : def.curves().values()) {
                ctx.set(curve.name(), CurveEvaluator.evaluate(curve, ctx));
            }
        }

        private void fireEmitterEvent(String field, ParticleUpdateContext context, Particle p) {
            Object event = def.componentMap("minecraft:emitter_lifetime_events").get(field);
            if (event instanceof String name) executeNamedEvent(name, context, p, worldPosition, Vec3.ZERO);
        }

        private void fireEmitterTimeline(ParticleUpdateContext context, LoopState loop) {
            Object timeline = def.componentMap("minecraft:emitter_lifetime_events").get("timeline");
            if (!(timeline instanceof Map<?, ?> map)) return;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                float time = Float.parseFloat(entry.getKey().toString());
                if (loop.localAge >= time && !firedEmitterTimeline.contains(time)) {
                    firedEmitterTimeline.add(time);
                    if (entry.getValue() instanceof String name) executeNamedEvent(name, context, null, worldPosition, Vec3.ZERO);
                }
            }
        }

        private void fireParticleEvent(String field, ParticleUpdateContext context, Particle p) {
            Object event = def.componentMap("minecraft:particle_lifetime_events").get(field);
            if (event instanceof String name) executeNamedEvent(name, context, p, renderPosition(p), p.velocity);
        }

        private void fireParticleTimeline(ParticleUpdateContext context, Particle p, float previousAge) {
            Object timeline = def.componentMap("minecraft:particle_lifetime_events").get("timeline");
            if (!(timeline instanceof Map<?, ?> map)) return;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                float time = Float.parseFloat(entry.getKey().toString());
                if (previousAge < time && p.age >= time && !p.firedTimeline.contains(time)) {
                    p.firedTimeline.add(time);
                    if (entry.getValue() instanceof String name) executeNamedEvent(name, context, p, renderPosition(p), p.velocity);
                }
            }
        }

        private void executeNamedEvent(String name, ParticleUpdateContext update, Particle p, Vec3 position, Vec3 velocity) {
            ParticleEventNode node = def.events().get(name);
            if (node == null) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), name, "Missing particle event: " + name, position));
                return;
            }
            ExpressionContext eventCtx = p == null ? new ExpressionContext(random.nextLong()) : particleCtx(p);
            eventCtx.variables.putAll(emitterCtx.variables);
            applyContextVariables(eventCtx, update.variables());
            eventCtx.set("variable.event_position_x", position.x());
            eventCtx.set("variable.event_position_y", position.y());
            eventCtx.set("variable.event_position_z", position.z());
            eventCtx.set("variable.event_velocity_x", velocity.x());
            eventCtx.set("variable.event_velocity_y", velocity.y());
            eventCtx.set("variable.event_velocity_z", velocity.z());
            executeEventNode(name, node, update, p, position, velocity, eventCtx);
        }

        private void executeEventNode(String eventName, ParticleEventNode node, ParticleUpdateContext update, Particle p,
                                      Vec3 position, Vec3 velocity, ExpressionContext eventCtx) {
            if (node instanceof ParticleEventNode.ExpressionNode expression) {
                if (expression.expression() != null) Expression.executeStatements(expression.expression(), eventCtx);
                if (expression.preEffectExpression() != null) Expression.executeStatements(expression.preEffectExpression(), eventCtx);
                return;
            }
            if (node instanceof ParticleEventNode.SequenceNode sequence) {
                for (ParticleEventNode child : sequence.nodes()) executeEventNode(eventName, child, update, p, position, velocity, eventCtx);
                return;
            }
            if (node instanceof ParticleEventNode.RandomNode randomNode) {
                double total = 0.0;
                for (ParticleEventNode.WeightedNode weighted : randomNode.nodes()) total += weighted.weight();
                double roll = random.nextDouble() * Math.max(0.0001, total);
                double cursor = 0.0;
                for (ParticleEventNode.WeightedNode weighted : randomNode.nodes()) {
                    cursor += weighted.weight();
                    if (roll <= cursor) {
                        executeEventNode(eventName, weighted.node(), update, p, position, velocity, eventCtx);
                        return;
                    }
                }
                return;
            }
            if (node instanceof ParticleEventNode.EmitNode emit) {
                emitManual(Math.max(0, (int) Math.round(Expression.of(emit.count()).eval(eventCtx))), update);
                return;
            }
            if (node instanceof ParticleEventNode.SoundNode sound) {
                update.eventSink().playSound(new ParticleSoundEvent(def.identifier(), eventName, sound.soundId(), position,
                        (float) Expression.of(sound.volume()).eval(eventCtx), (float) Expression.of(sound.pitch()).eval(eventCtx)));
                return;
            }
            if (node instanceof ParticleEventNode.LogNode log) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), eventName, log.message(), position));
                return;
            }
            if (node instanceof ParticleEventNode.SpawnNode spawn) {
                spawnChild(eventName, spawn, update, p, position, velocity, eventCtx);
            }
        }

        private void spawnChild(String eventName, ParticleEventNode.SpawnNode spawn, ParticleUpdateContext update, Particle p,
                                Vec3 position, Vec3 velocity, ExpressionContext eventCtx) {
            if (spawn.preEffectExpression() != null) Expression.executeStatements(spawn.preEffectExpression(), eventCtx);
            Map<String, Double> contextVars = new LinkedHashMap<>();
            Map<String, Double> localVars = new LinkedHashMap<>();
            for (Map.Entry<String, Double> entry : eventCtx.variables.entrySet()) {
                if (entry.getKey().startsWith("context.")) contextVars.put(entry.getKey(), entry.getValue());
                if (entry.getKey().startsWith("variable.")) localVars.put(entry.getKey(), entry.getValue());
            }
            ParticleChildSpawnRequest request = new ParticleChildSpawnRequest(def.identifier(), spawn.effect(), eventName,
                    position, spawn.kind() == ParticleEventNode.SpawnKind.PARTICLE_WITH_VELOCITY ? velocity : Vec3.ZERO,
                    spawn.kind() == ParticleEventNode.SpawnKind.EMITTER_BOUND, Map.copyOf(contextVars), Map.copyOf(localVars));
            update.eventSink().spawnEffect(request);
            ParticleEffectHandle childHandle = findHandle(spawn.effect());
            if (childHandle == null) {
                update.eventSink().log(new ParticleLogEvent(def.identifier(), eventName, "Missing child effect: " + spawn.effect(), position));
                return;
            }
            ParticleSpawnContext spawnContext = new ParticleSpawnContext(position, yawDegrees, random.nextLong(), contextVars, localVars);
            Instance child = new Instance(owner, childHandle, owner.definitions.get(childHandle), spawnContext,
                    spawn.kind() == ParticleEventNode.SpawnKind.EMITTER_BOUND ? this : null);
            owner.pendingInstances.add(child);
        }

        private ParticleEffectHandle findHandle(String identifier) {
            for (Map.Entry<ParticleEffectHandle, ParticleEffectDefinition> entry : owner.definitions.entrySet()) {
                if (entry.getValue().identifier().equals(identifier)) return entry.getKey();
            }
            return null;
        }
    }

    private record ShapeResult(Vec3 offset, Vec3 direction) {
    }

    private record LoopState(float localAge, int index, boolean active, float lifetime) {
    }

    private static final class Particle {
        Vec3 position = Vec3.ZERO;
        Vec3 spawnPosition = Vec3.ZERO;
        Vec3 velocity = Vec3.ZERO;
        float age;
        float lifetime = 1;
        float rotation;
        float rotationRate;
        long expressionSeed;
        double r1;
        double r2;
        double r3;
        double r4;
        boolean localPosition;
        boolean localRotation;
        boolean collisionEventFired;
        boolean expirationEventFired;
        final List<Float> firedTimeline = new ArrayList<>();
        boolean alive = true;
    }

    private static String localVariableName(String name) {
        String normalized = name == null ? "" : name.trim().toLowerCase();
        return normalized.startsWith("variable.") ? normalized : "variable." + normalized;
    }
}

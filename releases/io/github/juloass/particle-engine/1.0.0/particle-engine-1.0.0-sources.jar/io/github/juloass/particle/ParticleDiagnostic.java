package io.github.juloass.particle;

public record ParticleDiagnostic(Severity severity, String message) {
    public enum Severity {
        WARNING,
        ERROR
    }
}

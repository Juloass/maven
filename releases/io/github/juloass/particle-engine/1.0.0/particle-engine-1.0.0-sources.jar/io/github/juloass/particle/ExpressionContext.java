package io.github.juloass.particle;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

final class ExpressionContext {
    final Map<String, Double> variables = new HashMap<>();
    final Random random;

    ExpressionContext(long seed) {
        this.random = new Random(seed);
    }

    double variable(String name) {
        return variables.getOrDefault(name.toLowerCase(), 0.0);
    }

    void set(String name, double value) {
        variables.put(name.toLowerCase(), value);
    }
}

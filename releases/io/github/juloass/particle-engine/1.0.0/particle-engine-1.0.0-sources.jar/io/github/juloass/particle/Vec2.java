package io.github.juloass.particle;

public record Vec2(float x, float y) {
    public static final Vec2 ZERO = new Vec2(0, 0);
}

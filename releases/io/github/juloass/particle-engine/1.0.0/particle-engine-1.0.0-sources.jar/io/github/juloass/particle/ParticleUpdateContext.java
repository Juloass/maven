package io.github.juloass.particle;

import java.util.Map;

public record ParticleUpdateContext(Vec3 cameraPosition, ParticleCollisionProvider collisionProvider,
                                    Map<String, Double> variables, ParticleEventSink eventSink) {
    public ParticleUpdateContext(Vec3 cameraPosition, ParticleCollisionProvider collisionProvider,
                                 Map<String, Double> variables) {
        this(cameraPosition, collisionProvider, variables, ParticleEventSink.NONE);
    }

    public static ParticleUpdateContext basic(Vec3 cameraPosition) {
        return new ParticleUpdateContext(cameraPosition, ParticleCollisionProvider.NONE, Map.of(), ParticleEventSink.NONE);
    }
}

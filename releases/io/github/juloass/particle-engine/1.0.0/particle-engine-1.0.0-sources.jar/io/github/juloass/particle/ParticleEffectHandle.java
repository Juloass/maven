package io.github.juloass.particle;

public record ParticleEffectHandle(int id) {
}

package io.github.juloass.particle;

import java.util.Map;

public record ParticleSpawnContext(Vec3 worldPosition, float yawDegrees, long seed,
                                   Map<String, Double> contextVariables,
                                   Map<String, Double> localVariables) {
    public ParticleSpawnContext(Vec3 worldPosition, float yawDegrees, long seed) {
        this(worldPosition, yawDegrees, seed, Map.of(), Map.of());
    }

    public ParticleSpawnContext(Vec3 worldPosition, float yawDegrees, long seed, Map<String, Double> contextVariables) {
        this(worldPosition, yawDegrees, seed, contextVariables, Map.of());
    }

    public static ParticleSpawnContext at(Vec3 position, long seed) {
        return new ParticleSpawnContext(position, 0, seed, Map.of());
    }

    public static ParticleSpawnContext at(Vec3 position, long seed, Map<String, Double> contextVariables) {
        return new ParticleSpawnContext(position, 0, seed, contextVariables, Map.of());
    }
}

package io.github.juloass.particle;

public final class ParticleLoadException extends RuntimeException {
    public ParticleLoadException(String message) {
        super(message);
    }
}

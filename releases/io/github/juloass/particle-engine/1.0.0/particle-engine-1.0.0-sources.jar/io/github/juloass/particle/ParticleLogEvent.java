package io.github.juloass.particle;

public record ParticleLogEvent(String sourceEffect, String eventName, String message, Vec3 position) {
}

package io.github.juloass.particle;

final class CurveEvaluator {
    private CurveEvaluator() {
    }

    static double evaluate(CurveDefinition curve, ExpressionContext ctx) {
        double input = Expression.of(curve.input()).eval(ctx);
        double range = Math.max(0.0001, Expression.of(curve.horizontalRange()).eval(ctx));
        double t = Math.max(0.0, Math.min(1.0, input / range));
        int n = curve.nodes().size();
        if (n == 0) return 0.0;
        if (n == 1) return node(curve, 0, ctx);
        if ("linear".equals(curve.type())) return linear(curve, ctx, t);
        if ("bezier".equals(curve.type())) return bezier(curve, ctx, t);
        double scaled = t * (n - 1);
        int i = (int) Math.floor(scaled);
        double local = scaled - i;
        double p0 = node(curve, i - 1, ctx);
        double p1 = node(curve, i, ctx);
        double p2 = node(curve, i + 1, ctx);
        double p3 = node(curve, i + 2, ctx);
        return 0.5 * ((2 * p1) + (-p0 + p2) * local
                + (2 * p0 - 5 * p1 + 4 * p2 - p3) * local * local
                + (-p0 + 3 * p1 - 3 * p2 + p3) * local * local * local);
    }

    private static double linear(CurveDefinition curve, ExpressionContext ctx, double t) {
        double scaled = t * (curve.nodes().size() - 1);
        int i = (int) Math.floor(scaled);
        double f = scaled - i;
        double a = node(curve, i, ctx);
        double b = node(curve, i + 1, ctx);
        return a + (b - a) * f;
    }

    private static double bezier(CurveDefinition curve, ExpressionContext ctx, double t) {
        if (curve.nodes().size() == 2) return linear(curve, ctx, t);
        if (curve.nodes().size() == 3) {
            double a = node(curve, 0, ctx);
            double b = node(curve, 1, ctx);
            double c = node(curve, 2, ctx);
            double u = 1.0 - t;
            return u * u * a + 2.0 * u * t * b + t * t * c;
        }
        double a = node(curve, 0, ctx);
        double b = node(curve, 1, ctx);
        double c = node(curve, 2, ctx);
        double d = node(curve, 3, ctx);
        double u = 1.0 - t;
        return u * u * u * a + 3.0 * u * u * t * b + 3.0 * u * t * t * c + t * t * t * d;
    }

    private static double node(CurveDefinition curve, int i, ExpressionContext ctx) {
        int clamped = Math.max(0, Math.min(curve.nodes().size() - 1, i));
        return Expression.of(curve.nodes().get(clamped)).eval(ctx);
    }
}

package io.github.juloass.particle;

public enum BillboardMode {
    ROTATE_XYZ,
    LOOKAT_XYZ,
    LOOKAT_Y,
    DIRECTION_X,
    DIRECTION_Y,
    DIRECTION_Z
}

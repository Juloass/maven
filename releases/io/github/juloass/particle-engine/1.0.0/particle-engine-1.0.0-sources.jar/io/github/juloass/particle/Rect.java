package io.github.juloass.particle;

public record Rect(float x, float y, float w, float h) {
}

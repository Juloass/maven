package io.github.juloass.particle;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class Expression {
    private static final Map<String, Node> NODE_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, Program> PROGRAM_CACHE = new ConcurrentHashMap<>();

    private final Object source;
    private final Node node;
    private final Double constant;

    private Expression(Object source) {
        this.source = source;
        if (source instanceof Number n) {
            this.constant = n.doubleValue();
            this.node = null;
        } else if (source instanceof Boolean b) {
            this.constant = b ? 1.0 : 0.0;
            this.node = null;
        } else if (source instanceof String s) {
            this.constant = null;
            this.node = NODE_CACHE.computeIfAbsent(s, key -> new Parser(key).parse());
        } else {
            this.constant = 0.0;
            this.node = null;
        }
    }

    static Expression of(Object source) {
        return new Expression(source);
    }

    double eval(ExpressionContext ctx) {
        return node == null ? constant : node.eval(ctx);
    }

    static void executeStatements(String statements, ExpressionContext ctx) {
        PROGRAM_CACHE.computeIfAbsent(statements, Program::compile).execute(ctx);
    }

    private interface Node {
        double eval(ExpressionContext ctx);
    }

    private record ConstNode(double value) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            return value;
        }
    }

    private record VariableNode(String name) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            return ctx.variable(name);
        }
    }

    private record UnaryNode(char op, Node node) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            double v = node.eval(ctx);
            return switch (op) {
                case '-' -> -v;
                case '!' -> v == 0.0 ? 1.0 : 0.0;
                default -> v;
            };
        }
    }

    private record BinaryNode(String op, Node left, Node right) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            double a = left.eval(ctx);
            double b = right.eval(ctx);
            return switch (op) {
                case "+" -> a + b;
                case "-" -> a - b;
                case "*" -> a * b;
                case "/" -> a / Math.max(0.0000001, b);
                case ">" -> a > b ? 1.0 : 0.0;
                case "<" -> a < b ? 1.0 : 0.0;
                case ">=" -> a >= b ? 1.0 : 0.0;
                case "<=" -> a <= b ? 1.0 : 0.0;
                case "==" -> nearly(a, b) ? 1.0 : 0.0;
                case "!=" -> !nearly(a, b) ? 1.0 : 0.0;
                case "&&" -> (a != 0.0 && b != 0.0) ? 1.0 : 0.0;
                case "||" -> (a != 0.0 || b != 0.0) ? 1.0 : 0.0;
                default -> 0.0;
            };
        }
    }

    private record TernaryNode(Node condition, Node ifTrue, Node ifFalse) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            return condition.eval(ctx) != 0.0 ? ifTrue.eval(ctx) : ifFalse.eval(ctx);
        }
    }

    private record CallNode(String function, Node a, Node b, Node c) implements Node {
        @Override
        public double eval(ExpressionContext ctx) {
            double av = a.eval(ctx);
            double bv = b.eval(ctx);
            double cv = c.eval(ctx);
            return switch (function.toLowerCase()) {
                case "math.sin" -> Math.sin(Math.toRadians(av));
                case "math.cos" -> Math.cos(Math.toRadians(av));
                case "math.floor" -> Math.floor(av);
                case "math.ceil" -> Math.ceil(av);
                case "math.round" -> Math.round(av);
                case "math.abs" -> Math.abs(av);
                case "math.min" -> Math.min(av, bv);
                case "math.max" -> Math.max(av, bv);
                case "math.random" -> av + ctx.random.nextDouble() * (bv - av);
                case "math.clamp" -> Math.max(bv, Math.min(cv, av));
                default -> 0.0;
            };
        }
    }

    private static boolean nearly(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private interface Statement {
        void execute(ExpressionContext ctx);
    }

    private record EvalStatement(Node node) implements Statement {
        @Override
        public void execute(ExpressionContext ctx) {
            node.eval(ctx);
        }
    }

    private record AssignStatement(String name, Node value) implements Statement {
        @Override
        public void execute(ExpressionContext ctx) {
            ctx.set(name, value.eval(ctx));
        }
    }

    private record Program(Statement[] statements) {
        static Program compile(String source) {
            String[] raw = source.split(";");
            java.util.ArrayList<Statement> compiled = new java.util.ArrayList<>();
            for (String stmt : raw) {
                if (stmt.isBlank()) continue;
                int eq = stmt.indexOf('=');
                if (eq > 0 && !comparisonOperatorAt(stmt, eq)) {
                    String name = stmt.substring(0, eq).trim();
                    if (name.toLowerCase().startsWith("context.")) {
                        throw new ParticleLoadException("Cannot assign read-only context variable: " + name);
                    }
                    if (!name.toLowerCase().startsWith("variable.")) {
                        throw new ParticleLoadException("Can only assign particle-local variable.* values: " + name);
                    }
                    compiled.add(new AssignStatement(name, new Parser(stmt.substring(eq + 1)).parse()));
                } else {
                    compiled.add(new EvalStatement(new Parser(stmt).parse()));
                }
            }
            return new Program(compiled.toArray(Statement[]::new));
        }

        void execute(ExpressionContext ctx) {
            for (Statement statement : statements) statement.execute(ctx);
        }

        private static boolean comparisonOperatorAt(String stmt, int eq) {
            return (eq > 0 && (stmt.charAt(eq - 1) == '!' || stmt.charAt(eq - 1) == '<' || stmt.charAt(eq - 1) == '>'))
                    || (eq + 1 < stmt.length() && stmt.charAt(eq + 1) == '=');
        }
    }

    private static final class Parser {
        private final String s;
        private int p;

        Parser(String s) {
            this.s = s;
        }

        Node parse() {
            Node v = ternary();
            ws();
            return v;
        }

        private Node ternary() {
            Node c = or();
            ws();
            if (peek('?')) {
                Node a = ternary();
                expect(':');
                Node b = ternary();
                return new TernaryNode(c, a, b);
            }
            return c;
        }

        private Node or() {
            Node v = and();
            while (true) {
                ws();
                if (peek("||")) v = new BinaryNode("||", v, and());
                else return v;
            }
        }

        private Node and() {
            Node v = equality();
            while (true) {
                ws();
                if (peek("&&")) v = new BinaryNode("&&", v, equality());
                else return v;
            }
        }

        private Node equality() {
            Node v = comparison();
            while (true) {
                ws();
                if (peek("==")) v = new BinaryNode("==", v, comparison());
                else if (peek("!=")) v = new BinaryNode("!=", v, comparison());
                else return v;
            }
        }

        private Node comparison() {
            Node v = add();
            while (true) {
                ws();
                if (peek(">=")) v = new BinaryNode(">=", v, add());
                else if (peek("<=")) v = new BinaryNode("<=", v, add());
                else if (peek('>')) v = new BinaryNode(">", v, add());
                else if (peek('<')) v = new BinaryNode("<", v, add());
                else return v;
            }
        }

        private Node add() {
            Node v = mul();
            while (true) {
                ws();
                if (peek('+')) v = new BinaryNode("+", v, mul());
                else if (peek('-')) v = new BinaryNode("-", v, mul());
                else return v;
            }
        }

        private Node mul() {
            Node v = unary();
            while (true) {
                ws();
                if (peek('*')) v = new BinaryNode("*", v, unary());
                else if (peek('/')) v = new BinaryNode("/", v, unary());
                else return v;
            }
        }

        private Node unary() {
            ws();
            if (peek('-')) return new UnaryNode('-', unary());
            if (peek('+')) return unary();
            if (peek('!')) return new UnaryNode('!', unary());
            return primary();
        }

        private Node primary() {
            ws();
            if (peek('(')) {
                Node v = ternary();
                expect(')');
                return v;
            }
            if (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) return number();
            String id = identifier();
            ws();
            if (peek('(')) {
                Node a = ternary();
                Node b = new ConstNode(0);
                Node c = new ConstNode(0);
                if (peek(',')) b = ternary();
                if (peek(',')) c = ternary();
                expect(')');
                return new CallNode(id, a, b, c);
            }
            return new VariableNode(id);
        }

        private String identifier() {
            ws();
            int start = p;
            while (p < s.length()) {
                char c = s.charAt(p);
                if (Character.isLetterOrDigit(c) || c == '_' || c == '.') p++;
                else break;
            }
            return s.substring(start, p);
        }

        private Node number() {
            int start = p;
            while (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) p++;
            return new ConstNode(Double.parseDouble(s.substring(start, p)));
        }

        private boolean peek(char c) {
            ws();
            if (p < s.length() && s.charAt(p) == c) {
                p++;
                return true;
            }
            return false;
        }

        private boolean peek(String token) {
            ws();
            if (s.startsWith(token, p)) {
                p += token.length();
                return true;
            }
            return false;
        }

        private void expect(char c) {
            if (!peek(c)) throw new ParticleLoadException("Expected '" + c + "' in expression: " + s);
        }

        private void ws() {
            while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++;
        }
    }
}

package io.github.juloass.particle;

public enum ValidationMode {
    STRICT,
    LENIENT
}

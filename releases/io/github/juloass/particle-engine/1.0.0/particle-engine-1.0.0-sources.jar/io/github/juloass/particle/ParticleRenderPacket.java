package io.github.juloass.particle;

import io.github.juloass.color.Color;

public record ParticleRenderPacket(String effectIdentifier, String material, String texture,
                                   Vec3 position, Vec2 size, float rotationDegrees,
                                   BillboardMode billboardMode, Vec3 customDirection,
                                   Rect uvPixels, Vec2 textureSize, Color color,
                                   float age, float lifetime, float sortDistance, int layer) {
}

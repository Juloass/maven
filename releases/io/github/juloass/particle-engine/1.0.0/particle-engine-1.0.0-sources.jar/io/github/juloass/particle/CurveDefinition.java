package io.github.juloass.particle;

import java.util.List;

public record CurveDefinition(String name, String type, Object input, Object horizontalRange, List<Object> nodes) {
}

package io.github.juloass.particle;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ParticleDefinitionLoader {
    private static final String[] SUPPORTED_COMPONENTS = {
            "minecraft:emitter_initialization", "minecraft:emitter_lifetime_expression",
            "minecraft:emitter_lifetime_events", "minecraft:emitter_lifetime_looping", "minecraft:emitter_lifetime_once", "minecraft:emitter_local_space",
            "minecraft:emitter_rate_instant", "minecraft:emitter_rate_manual", "minecraft:emitter_rate_steady",
            "minecraft:emitter_shape_box", "minecraft:emitter_shape_disc", "minecraft:emitter_shape_point",
            "minecraft:emitter_shape_sphere",
            "minecraft:particle_appearance_billboard", "minecraft:particle_appearance_tinting",
            "minecraft:particle_expire_if_in_blocks", "minecraft:particle_expire_if_not_in_blocks", "minecraft:particle_initial_speed",
            "minecraft:particle_initial_spin", "minecraft:particle_lifetime_events", "minecraft:particle_lifetime_expression",
            "minecraft:particle_motion_collision", "minecraft:particle_motion_dynamic", "minecraft:particle_motion_parametric"
    };

    private ParticleDefinitionLoader() {
    }

    public static ParticleEffectDefinition load(Path path, ValidationMode mode) throws IOException {
        return load(Files.readString(path), mode);
    }

    public static ParticleEffectDefinition load(String json, ValidationMode mode) {
        List<ParticleDiagnostic> diagnostics = new ArrayList<>();
        Map<String, Object> root = asMap(Json.parse(json), "root");
        String format = string(root.get("format_version"), "format_version");
        if (!"1.10.0".equals(format)) diagnostic(diagnostics, mode, "Unsupported format_version: " + format);
        Map<String, Object> effect = asMap(root.get("particle_effect"), "particle_effect");
        Map<String, Object> description = asMap(effect.get("description"), "description");
        String identifier = string(description.get("identifier"), "description.identifier");
        Map<String, Object> render = asMap(description.get("basic_render_parameters"), "basic_render_parameters");
        String material = string(render.get("material"), "material");
        String texture = string(render.get("texture"), "texture");

        Map<String, Object> components = asMap(effect.get("components"), "components");
        for (String component : components.keySet()) {
            if (!isSupported(component)) diagnostic(diagnostics, mode, "Unsupported component: " + component);
        }

        Map<String, CurveDefinition> curves = new LinkedHashMap<>();
        Object curveObj = effect.get("curves");
        if (curveObj instanceof Map<?, ?> cm) {
            for (Map.Entry<?, ?> entry : cm.entrySet()) {
                Map<String, Object> c = asMap(entry.getValue(), "curve");
                List<Object> nodes = new ArrayList<>(asList(c.get("nodes"), "curve.nodes"));
                String name = entry.getKey().toString();
                if (!name.startsWith("variable.")) name = "variable." + name;
                CurveDefinition curve = new CurveDefinition(name,
                        string(c.get("type"), "curve.type"), c.get("input"), c.get("horizontal_range"), nodes);
                if (!"catmull_rom".equals(curve.type()) && !"linear".equals(curve.type()) && !"bezier".equals(curve.type())) {
                    diagnostic(diagnostics, mode, "Unsupported curve type: " + curve.type());
                }
                curves.put(curve.name(), curve);
            }
        }
        Map<String, ParticleEventNode> events = parseEvents(effect.get("events"), diagnostics, mode);
        validateEventReferences(components, events, diagnostics, mode);
        return new ParticleEffectDefinition(identifier, material, texture, curves, events, components, List.copyOf(diagnostics));
    }

    private static Map<String, ParticleEventNode> parseEvents(Object eventObj, List<ParticleDiagnostic> diagnostics, ValidationMode mode) {
        Map<String, ParticleEventNode> events = new LinkedHashMap<>();
        if (eventObj == null) return events;
        Map<String, Object> rawEvents = asMap(eventObj, "events");
        for (Map.Entry<String, Object> entry : rawEvents.entrySet()) {
            events.put(entry.getKey(), parseEventNode(entry.getValue(), diagnostics, mode));
        }
        return events;
    }

    private static ParticleEventNode parseEventNode(Object value, List<ParticleDiagnostic> diagnostics, ValidationMode mode) {
        if (value instanceof String s) return new ParticleEventNode.LogNode(s);
        Map<String, Object> map = asMap(value, "event");
        if (map.containsKey("sequence")) {
            List<ParticleEventNode> nodes = new ArrayList<>();
            for (Object node : asList(map.get("sequence"), "event.sequence")) nodes.add(parseEventNode(node, diagnostics, mode));
            return new ParticleEventNode.SequenceNode(List.copyOf(nodes));
        }
        if (map.containsKey("randomize")) {
            List<ParticleEventNode.WeightedNode> nodes = new ArrayList<>();
            for (Object node : asList(map.get("randomize"), "event.randomize")) {
                Map<String, Object> weighted = asMap(node, "event.randomize.entry");
                double weight = weighted.containsKey("weight") ? number(weighted.get("weight"), "event.weight") : 1.0;
                if (weight <= 0) diagnostic(diagnostics, mode, "Event randomize weight must be positive");
                Object nested = weighted.getOrDefault("event", weighted);
                nodes.add(new ParticleEventNode.WeightedNode(Math.max(0.0001, weight), parseEventNode(nested, diagnostics, mode)));
            }
            return new ParticleEventNode.RandomNode(List.copyOf(nodes));
        }
        if (map.containsKey("particle_effect")) return spawnNode(map.get("particle_effect"), ParticleEventNode.SpawnKind.EMITTER, diagnostics, mode);
        if (map.containsKey("emitter")) return spawnNode(map.get("emitter"), ParticleEventNode.SpawnKind.EMITTER, diagnostics, mode);
        if (map.containsKey("emitter_bound")) return spawnNode(map.get("emitter_bound"), ParticleEventNode.SpawnKind.EMITTER_BOUND, diagnostics, mode);
        if (map.containsKey("particle")) return spawnNode(map.get("particle"), ParticleEventNode.SpawnKind.PARTICLE, diagnostics, mode);
        if (map.containsKey("particle_with_velocity")) return spawnNode(map.get("particle_with_velocity"), ParticleEventNode.SpawnKind.PARTICLE_WITH_VELOCITY, diagnostics, mode);
        if (map.containsKey("sound_effect")) return soundNode(map.get("sound_effect"));
        if (map.containsKey("log")) return new ParticleEventNode.LogNode(String.valueOf(map.get("log")));
        if (map.containsKey("emit")) return new ParticleEventNode.EmitNode(map.get("emit"));
        String expression = map.get("expression") instanceof String s ? s : null;
        String pre = map.get("pre_effect_expression") instanceof String s ? s : null;
        if (expression != null || pre != null) return new ParticleEventNode.ExpressionNode(expression, pre);
        diagnostic(diagnostics, mode, "Unsupported empty event node");
        return new ParticleEventNode.SequenceNode(List.of());
    }

    private static ParticleEventNode spawnNode(Object value, ParticleEventNode.SpawnKind kind,
                                               List<ParticleDiagnostic> diagnostics, ValidationMode mode) {
        if (value instanceof String s) return new ParticleEventNode.SpawnNode(s, kind, null);
        Map<String, Object> map = asMap(value, "event.spawn");
        String effect = String.valueOf(map.getOrDefault("effect", map.getOrDefault("particle", "")));
        if (effect.isBlank()) diagnostic(diagnostics, mode, "Particle spawn event missing effect");
        String pre = map.get("pre_effect_expression") instanceof String s ? s : null;
        return new ParticleEventNode.SpawnNode(effect, kind, pre);
    }

    private static ParticleEventNode soundNode(Object value) {
        if (value instanceof String s) return new ParticleEventNode.SoundNode(soundIdentifier(s), 1, 1);
        Map<String, Object> map = asMap(value, "event.sound_effect");
        return new ParticleEventNode.SoundNode(soundIdentifier(String.valueOf(
                        map.getOrDefault("sound", map.getOrDefault("event_name", "")))),
                map.getOrDefault("volume", 1), map.getOrDefault("pitch", 1));
    }

    private static io.github.juloass.identifier.Identifier soundIdentifier(
            String value
    ) {
        try {
            return io.github.juloass.identifier.Identifier.parse(value);
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException(
                    "event.sound_effect sound must be a canonical identifier: "
                            + value,
                    exception);
        }
    }

    private static void validateEventReferences(Map<String, Object> components, Map<String, ParticleEventNode> events,
                                                List<ParticleDiagnostic> diagnostics, ValidationMode mode) {
        validateEventComponent(ParticleDefinitionLoader.asMapOrEmpty(components.get("minecraft:emitter_lifetime_events")), events, diagnostics, mode);
        validateEventComponent(ParticleDefinitionLoader.asMapOrEmpty(components.get("minecraft:particle_lifetime_events")), events, diagnostics, mode);
    }

    private static void validateEventComponent(Map<String, Object> component, Map<String, ParticleEventNode> events,
                                               List<ParticleDiagnostic> diagnostics, ValidationMode mode) {
        for (String key : List.of("creation_event", "expiration_event", "collision_event")) {
            Object value = component.get(key);
            if (value instanceof String s && !events.containsKey(s)) diagnostic(diagnostics, mode, "Missing event reference: " + s);
        }
        Object timeline = component.get("timeline");
        if (timeline instanceof Map<?, ?> map) {
            for (Object value : map.values()) {
                if (value instanceof String s && !events.containsKey(s)) diagnostic(diagnostics, mode, "Missing event reference: " + s);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMapOrEmpty(Object value) {
        return value instanceof Map<?, ?> map ? (Map<String, Object>) map : Map.of();
    }

    private static boolean isSupported(String component) {
        for (String c : SUPPORTED_COMPONENTS) if (c.equals(component)) return true;
        return false;
    }

    private static void diagnostic(List<ParticleDiagnostic> diagnostics, ValidationMode mode, String message) {
        diagnostics.add(new ParticleDiagnostic(mode == ValidationMode.STRICT
                ? ParticleDiagnostic.Severity.ERROR : ParticleDiagnostic.Severity.WARNING, message));
        if (mode == ValidationMode.STRICT) throw new ParticleLoadException(message);
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> asMap(Object value, String name) {
        if (value instanceof Map<?, ?> map) return (Map<String, Object>) map;
        throw new ParticleLoadException("Expected object: " + name);
    }

    @SuppressWarnings("unchecked")
    static List<Object> asList(Object value, String name) {
        if (value instanceof List<?> list) return (List<Object>) list;
        throw new ParticleLoadException("Expected array: " + name);
    }

    static String string(Object value, String name) {
        if (value instanceof String s) return s;
        throw new ParticleLoadException("Expected string: " + name);
    }

    static double number(Object value, String name) {
        if (value instanceof Number n) return n.doubleValue();
        throw new ParticleLoadException("Expected number: " + name);
    }
}

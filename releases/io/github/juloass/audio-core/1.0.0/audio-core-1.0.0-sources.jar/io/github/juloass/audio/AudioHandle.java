package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.time.Duration;
import java.util.concurrent.CompletionStage;

/** Thread-safe playback control handle. */
public interface AudioHandle {
    Identifier id(); AudioState state(); CompletionStage<PlayResult> startResult();
    void pause(); void resume(); void stop(); void seekFrame(long frame); default void seek(Duration value){if(value.isNegative())throw new IllegalArgumentException("position must not be negative");seekFrame(Math.round(value.toNanos()/1_000_000_000.0*format().sampleRate()));}
    void gain(double gain); void pitch(double pitch); void fadeTo(double gain,Duration duration); AudioFormat format();
}


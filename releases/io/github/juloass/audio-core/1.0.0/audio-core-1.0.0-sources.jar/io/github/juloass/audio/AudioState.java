package io.github.juloass.audio;

/** Playback lifecycle state. */
public enum AudioState { QUEUED, STARTING, PLAYING, PAUSED, STOPPED, COMPLETE, REJECTED, FAILED }


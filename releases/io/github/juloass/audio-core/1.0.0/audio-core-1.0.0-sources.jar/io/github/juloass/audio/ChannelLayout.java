package io.github.juloass.audio;

/** Supported decoded channel layouts. */
public enum ChannelLayout {
    MONO(1), STEREO(2);
    private final int channels;
    ChannelLayout(int channels) { this.channels = channels; }
    public int channels() { return channels; }
    public static ChannelLayout forChannels(int channels) {
        return switch (channels) { case 1 -> MONO; case 2 -> STEREO; default -> throw new IllegalArgumentException("unsupported channel count: " + channels); };
    }
}


package io.github.juloass.audio;

import java.util.Objects;

/** Positional emitter state. */
public record AudioEmitter(AudioVector3 position, AudioVector3 velocity, AudioVector3 direction,
                           double innerConeDegrees, double outerConeDegrees, double outerConeGain,
                           DistanceParameters distance) {
    public AudioEmitter {
        Objects.requireNonNull(position); Objects.requireNonNull(velocity); Objects.requireNonNull(direction); Objects.requireNonNull(distance);
        if (!Double.isFinite(innerConeDegrees)||!Double.isFinite(outerConeDegrees)||innerConeDegrees<0||outerConeDegrees<innerConeDegrees||outerConeDegrees>360
                ||!Double.isFinite(outerConeGain)||outerConeGain<0||outerConeGain>1) throw new IllegalArgumentException("invalid emitter cone");
        if (outerConeDegrees < 360 && direction.lengthSquared() == 0) {
            throw new IllegalArgumentException("a directional cone requires a nonzero direction");
        }
    }
    public static AudioEmitter at(AudioVector3 position) { return new AudioEmitter(position,AudioVector3.ZERO,AudioVector3.ZERO,360,360,1,DistanceParameters.none()); }
}

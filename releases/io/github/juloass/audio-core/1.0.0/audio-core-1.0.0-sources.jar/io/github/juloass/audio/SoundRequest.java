package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.*;

/** Immutable sound playback request. */
public record SoundRequest(Identifier id,AudioAsset asset,Identifier bus,int priority,double gain,double pitch,
                           LoopMode loopMode,Optional<LoopRegion> loopRegion,SpatialMode spatialMode,
                           Optional<AudioEmitter> emitter,boolean stealable){
    public SoundRequest{Objects.requireNonNull(id);Objects.requireNonNull(asset);Objects.requireNonNull(bus);Objects.requireNonNull(loopMode);
        loopRegion=Objects.requireNonNull(loopRegion);Objects.requireNonNull(spatialMode);emitter=Objects.requireNonNull(emitter);
        if(!Double.isFinite(gain)||gain<0||!Double.isFinite(pitch)||pitch<=0)throw new IllegalArgumentException("gain and pitch must be valid");
        if(spatialMode==SpatialMode.POSITIONAL&&(emitter.isEmpty()||asset.format().channelLayout()!=ChannelLayout.MONO))throw new IllegalArgumentException("positional playback requires an emitter and mono audio");
        if(spatialMode==SpatialMode.NON_SPATIAL&&emitter.isPresent())throw new IllegalArgumentException("non-spatial playback cannot have an emitter");
        if (loopRegion.isPresent() && asset instanceof DecodedAudio decoded
                && loopRegion.get().endFrame() > decoded.pcm().frameCount()) {
            throw new IllegalArgumentException("loop region exceeds decoded audio");
        }}
    public static SoundRequest once(Identifier id,AudioAsset asset,Identifier bus){return new SoundRequest(id,asset,bus,0,1,1,LoopMode.ONCE,Optional.empty(),SpatialMode.NON_SPATIAL,Optional.empty(),true);}
}

package io.github.juloass.audio;

import java.util.*;

/** Result of asynchronous playback start. */
public record PlayResult(boolean started, Optional<AudioProblem> problem) {
    public PlayResult {
        problem = Objects.requireNonNull(problem, "problem");
    }

    public static PlayResult success() {
        return new PlayResult(true, Optional.empty());
    }

    public static PlayResult rejected(AudioProblem problem) {
        return new PlayResult(false, Optional.of(Objects.requireNonNull(problem, "problem")));
    }
}

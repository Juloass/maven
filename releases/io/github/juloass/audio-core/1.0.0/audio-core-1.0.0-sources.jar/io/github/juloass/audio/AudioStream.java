package io.github.juloass.audio;

import java.io.IOException;
import java.util.OptionalLong;

/** A closeable frame stream. */
public interface AudioStream extends AutoCloseable {
    AudioFormat format();
    OptionalLong frameCount();
    long positionFrame();
    int readFrames(float[] destination, int offsetFrames, int maximumFrames) throws IOException;
    void seekFrame(long frame) throws IOException;
    default void reset() throws IOException { seekFrame(0); }
    @Override void close() throws IOException;
}


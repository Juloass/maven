package io.github.juloass.audio;

import java.util.Objects;

/** Parameters for positional attenuation. */
public record DistanceParameters(DistanceModel model, double referenceDistance, double maximumDistance, double rolloff) {
    public DistanceParameters {
        Objects.requireNonNull(model, "model");
        if (!Double.isFinite(referenceDistance) || !Double.isFinite(maximumDistance) || !Double.isFinite(rolloff)
                || referenceDistance < 0 || maximumDistance < referenceDistance || rolloff < 0)
            throw new IllegalArgumentException("invalid distance parameters");
    }
    public static DistanceParameters none() { return new DistanceParameters(DistanceModel.NONE, 0, 0, 0); }
    public double gain(double distance) {
        if (!Double.isFinite(distance) || distance < 0) throw new IllegalArgumentException("distance must be non-negative and finite");
        if (model == DistanceModel.NONE || distance <= referenceDistance) return 1;
        if (distance >= maximumDistance) return model == DistanceModel.INVERSE || model == DistanceModel.EXPONENTIAL
                ? attenuation(maximumDistance) : 0;
        return attenuation(distance);
    }
    private double attenuation(double distance) { return Math.max(0, switch (model) {
        case NONE -> 1; case LINEAR -> 1-rolloff*(distance-referenceDistance)/Math.max(1e-12,maximumDistance-referenceDistance);
        case INVERSE -> referenceDistance/Math.max(1e-12,referenceDistance+rolloff*(distance-referenceDistance));
        case EXPONENTIAL -> Math.pow(Math.max(1e-12,distance/referenceDistance),-rolloff); }); }
}

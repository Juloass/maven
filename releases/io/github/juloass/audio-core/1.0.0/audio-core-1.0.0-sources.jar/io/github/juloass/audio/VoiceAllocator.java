package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.*;

/** Deterministic priority and age based voice selection. */
public final class VoiceAllocator {
    public record Voice(Identifier id,Identifier bus,int priority,long sequence,boolean stealable){public Voice{Objects.requireNonNull(id);Objects.requireNonNull(bus);}}
    public Optional<Voice> replacement(Collection<Voice> active,Identifier bus,int newPriority){Objects.requireNonNull(active);Objects.requireNonNull(bus);
        return active.stream().filter(v->v.bus.equals(bus)&&v.stealable&&v.priority<=newPriority).min(Comparator.comparingInt(Voice::priority).thenComparingLong(Voice::sequence));}
}


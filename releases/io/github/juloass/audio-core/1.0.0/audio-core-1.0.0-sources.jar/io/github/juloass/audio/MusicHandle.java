package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;

/** Playback handle for music transport. */
public interface MusicHandle extends AudioHandle {
    /** Moves this transport to another existing mixer bus. */
    void bus(Identifier bus);
}

package io.github.juloass.audio;

/** Inclusive start and exclusive end frame. */
public record LoopRegion(long startFrame,long endFrame){public LoopRegion{if(startFrame<0||endFrame<=startFrame)throw new IllegalArgumentException("invalid loop region");}}


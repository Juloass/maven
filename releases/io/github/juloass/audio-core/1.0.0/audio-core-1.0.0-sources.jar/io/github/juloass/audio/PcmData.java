package io.github.juloass.audio;

import java.util.Arrays;
import java.util.Objects;

/** Immutable interleaved normalized float PCM. */
public final class PcmData {
    private final AudioFormat format;
    private final float[] samples;
    public PcmData(AudioFormat format, float[] samples) {
        this.format = Objects.requireNonNull(format, "format");
        if (samples == null || samples.length == 0 || samples.length % format.channelLayout().channels() != 0)
            throw new IllegalArgumentException("samples must contain complete nonempty frames");
        this.samples = samples.clone();
        for (float sample : this.samples) if (!Float.isFinite(sample) || sample < -1 || sample > 1)
            throw new IllegalArgumentException("samples must be finite and within [-1, 1]");
    }
    public AudioFormat format() { return format; }
    public int frameCount() { return samples.length / format.channelLayout().channels(); }
    public int sampleCount() { return samples.length; }
    public float[] samples() { return samples.clone(); }
    public float sample(int frame, int channel) { return samples[Math.addExact(Math.multiplyExact(frame, format.channelLayout().channels()), channel)]; }
    @Override public boolean equals(Object other) { return other instanceof PcmData data && format.equals(data.format) && Arrays.equals(samples, data.samples); }
    @Override public int hashCode() { return 31 * format.hashCode() + Arrays.hashCode(samples); }
}


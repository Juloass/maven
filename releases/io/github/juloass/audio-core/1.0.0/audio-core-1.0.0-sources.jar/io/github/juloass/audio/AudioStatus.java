package io.github.juloass.audio;

import java.util.*;

/** Current backend availability. */
public record AudioStatus(boolean available,String backend,Optional<String> device,Optional<AudioProblem> problem){
    public AudioStatus{Objects.requireNonNull(backend);device=Objects.requireNonNull(device);problem=Objects.requireNonNull(problem);}
}


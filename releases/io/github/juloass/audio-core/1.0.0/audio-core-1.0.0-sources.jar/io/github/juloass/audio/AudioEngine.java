package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.List;
import java.util.concurrent.CompletionStage;

/** Thread-safe game-agnostic audio engine. */
public interface AudioEngine extends AutoCloseable {
    AudioStatus status(); AudioHandle play(SoundRequest request); MusicHandle playMusic(MusicRequest request);
    void setListener(AudioListener listener); void setEmitter(AudioHandle handle,AudioEmitter emitter);
    void setBusGain(Identifier bus,double gain); void setBusMuted(Identifier bus,boolean muted); void setBusPaused(Identifier bus,boolean paused);
    AudioEngineSnapshot snapshot(); List<AudioEvent> drainEvents(); CompletionStage<AudioCloseResult> closeAsync();
    @Override default void close(){closeAsync().toCompletableFuture().join();}
}


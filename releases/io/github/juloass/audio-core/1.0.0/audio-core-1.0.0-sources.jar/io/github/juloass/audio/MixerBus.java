package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;
import java.util.Optional;

/** Immutable mixer bus definition. */
public record MixerBus(Identifier id, Optional<Identifier> parent, int voiceLimit, double gain, boolean muted, boolean paused) {
    public MixerBus {
        Objects.requireNonNull(id); parent=Objects.requireNonNull(parent); if(voiceLimit<1)throw new IllegalArgumentException("voiceLimit must be positive");
        if(!Double.isFinite(gain)||gain<0)throw new IllegalArgumentException("gain must be non-negative and finite");
    }
    public static MixerBus root(Identifier id,int voiceLimit){return new MixerBus(id,Optional.empty(),voiceLimit,1,false,false);}
}


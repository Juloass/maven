package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.*;

/** Immutable event emitted by an audio engine. */
public record AudioEvent(Type type,Optional<Identifier> playbackId,Optional<AudioProblem> problem){
    public enum Type { STARTED, STOPPED, COMPLETED, REJECTED, FAILED, STREAM_UNDERRUN, DEVICE_LOST, DEVICE_REOPENED }
    public AudioEvent{Objects.requireNonNull(type);playbackId=Objects.requireNonNull(playbackId);problem=Objects.requireNonNull(problem);}
}


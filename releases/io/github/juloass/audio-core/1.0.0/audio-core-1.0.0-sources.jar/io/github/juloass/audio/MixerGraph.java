package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.*;

/** Immutable validated mixer hierarchy. */
public final class MixerGraph {
    private final Map<Identifier,MixerBus> buses; private final Identifier root;
    private MixerGraph(Map<Identifier,MixerBus> values){buses=Map.copyOf(values);List<MixerBus> roots=values.values().stream().filter(v->v.parent().isEmpty()).toList();
        if(roots.size()!=1)throw new IllegalArgumentException("mixer graph requires exactly one root");root=roots.getFirst().id();
        for(MixerBus bus:values.values())bus.parent().ifPresent(parent->{if(!values.containsKey(parent))throw new IllegalArgumentException("missing parent: "+parent);});
        for(Identifier id:values.keySet()){Set<Identifier> seen=new HashSet<>();Identifier cursor=id;while(cursor!=null){if(!seen.add(cursor))throw new IllegalArgumentException("mixer bus cycle: "+id);cursor=values.get(cursor).parent().orElse(null);}}
    }
    public static Builder builder(){return new Builder();} public Identifier root(){return root;} public Set<Identifier> ids(){return buses.keySet();}
    public MixerBus require(Identifier id){MixerBus value=buses.get(id);if(value==null)throw new IllegalArgumentException("unknown mixer bus: "+id);return value;}
    public List<MixerBus> ancestry(Identifier id){List<MixerBus> result=new ArrayList<>();MixerBus current=require(id);while(current!=null){result.add(current);current=current.parent().map(buses::get).orElse(null);}return List.copyOf(result);}
    public static final class Builder { private final LinkedHashMap<Identifier,MixerBus> values=new LinkedHashMap<>();
        public Builder add(MixerBus bus){Objects.requireNonNull(bus);if(values.putIfAbsent(bus.id(),bus)!=null)throw new IllegalArgumentException("duplicate mixer bus: "+bus.id());return this;}
        public MixerGraph build(){if(values.isEmpty())throw new IllegalStateException("mixer graph must not be empty");return new MixerGraph(values);}}
}


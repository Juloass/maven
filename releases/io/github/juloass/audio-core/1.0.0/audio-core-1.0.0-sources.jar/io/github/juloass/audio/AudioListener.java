package io.github.juloass.audio;

import java.util.Objects;

/** Listener state in caller-defined consistent units. */
public record AudioListener(AudioVector3 position, AudioVector3 velocity, AudioVector3 forward,
                            AudioVector3 up, double dopplerFactor, double speedOfSound) {
    public AudioListener {
        Objects.requireNonNull(position); Objects.requireNonNull(velocity); Objects.requireNonNull(forward); Objects.requireNonNull(up);
        if (forward.lengthSquared() == 0 || up.lengthSquared() == 0) throw new IllegalArgumentException("orientation vectors must be nonzero");
        double crossX = forward.y() * up.z() - forward.z() * up.y();
        double crossY = forward.z() * up.x() - forward.x() * up.z();
        double crossZ = forward.x() * up.y() - forward.y() * up.x();
        if (crossX * crossX + crossY * crossY + crossZ * crossZ < 1.0e-20) {
            throw new IllegalArgumentException("forward and up vectors must not be parallel");
        }
        if (!Double.isFinite(dopplerFactor) || dopplerFactor < 0 || !Double.isFinite(speedOfSound) || speedOfSound <= 0)
            throw new IllegalArgumentException("invalid doppler parameters");
    }
    public static AudioListener defaults() { return new AudioListener(AudioVector3.ZERO, AudioVector3.ZERO,
            new AudioVector3(0,0,-1), new AudioVector3(0,1,0), 1, 343.3); }
}

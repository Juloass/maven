package io.github.juloass.audio;

/** Bounds for encoded and decoded audio. */
public record AudioDecodeLimits(long maximumEncodedBytes, long maximumFrames, int maximumSampleRate) {
    public AudioDecodeLimits {
        if (maximumEncodedBytes < 1 || maximumFrames < 1 || maximumSampleRate < 1)
            throw new IllegalArgumentException("decode limits must be positive and supported");
    }
    public static AudioDecodeLimits defaults() { return new AudioDecodeLimits(64L << 20, 192_000L * 60L * 30L, 192_000); }
}

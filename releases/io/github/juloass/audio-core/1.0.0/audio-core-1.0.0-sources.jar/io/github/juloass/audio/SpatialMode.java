package io.github.juloass.audio;

/** Playback positioning mode. */
public enum SpatialMode { NON_SPATIAL, POSITIONAL }


package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Structured unavailable engine for safe startup without an audio device. */
public final class SilentAudioEngine implements AudioEngine {
    private final AudioProblem problem;private final AtomicBoolean closed=new AtomicBoolean();
    public SilentAudioEngine(AudioProblem problem){this.problem=Objects.requireNonNull(problem);}
    @Override public AudioStatus status(){return new AudioStatus(false,"silent",Optional.empty(),Optional.of(problem));}
    @Override public AudioHandle play(SoundRequest request){Objects.requireNonNull(request);return new RejectedHandle(request.id(),request.asset().format(),problem);}
    @Override public MusicHandle playMusic(MusicRequest request){Objects.requireNonNull(request);return new RejectedMusicHandle(request.id(),request.audio().format(),problem);}
    @Override public void setListener(AudioListener value){Objects.requireNonNull(value);}
    @Override public void setEmitter(AudioHandle h,AudioEmitter e){Objects.requireNonNull(h);Objects.requireNonNull(e);}
    @Override public void setBusGain(Identifier b,double g){Objects.requireNonNull(b);if(!Double.isFinite(g)||g<0)throw new IllegalArgumentException("invalid gain");}
    @Override public void setBusMuted(Identifier b,boolean v){Objects.requireNonNull(b);}@Override public void setBusPaused(Identifier b,boolean v){Objects.requireNonNull(b);}
    @Override public AudioEngineSnapshot snapshot(){return new AudioEngineSnapshot(0,Map.of(),0);}@Override public List<AudioEvent> drainEvents(){return List.of();}
    @Override public CompletionStage<AudioCloseResult> closeAsync(){closed.set(true);return CompletableFuture.completedFuture(new AudioCloseResult(true,Optional.empty()));}
    private static class RejectedHandle implements AudioHandle {private final Identifier id;private final AudioFormat format;private final CompletionStage<PlayResult> result;
        RejectedHandle(Identifier id,AudioFormat format,AudioProblem p){this.id=id;this.format=format;result=CompletableFuture.completedFuture(PlayResult.rejected(p));}
        public Identifier id(){return id;}public AudioState state(){return AudioState.REJECTED;}public CompletionStage<PlayResult> startResult(){return result;}
        public void pause(){}public void resume(){}public void stop(){}public void seekFrame(long f){if(f<0)throw new IllegalArgumentException();}public void gain(double g){}public void pitch(double p){}public void fadeTo(double g,Duration d){}public AudioFormat format(){return format;}}
    private static final class RejectedMusicHandle extends RejectedHandle implements MusicHandle{
        RejectedMusicHandle(Identifier i,AudioFormat f,AudioProblem p){super(i,f,p);}
        @Override public void bus(Identifier bus){Objects.requireNonNull(bus,"bus");}
    }
}

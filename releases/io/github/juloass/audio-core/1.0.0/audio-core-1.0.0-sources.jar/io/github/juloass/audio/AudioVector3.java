package io.github.juloass.audio;

/** Immutable three-dimensional audio value. */
public record AudioVector3(double x, double y, double z) {
    public static final AudioVector3 ZERO = new AudioVector3(0, 0, 0);
    public AudioVector3 { if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) throw new IllegalArgumentException("coordinates must be finite"); }
    public double lengthSquared() { return x*x+y*y+z*z; }
    public double distanceTo(AudioVector3 other) { return Math.sqrt(Math.pow(x-other.x,2)+Math.pow(y-other.y,2)+Math.pow(z-other.z,2)); }
}


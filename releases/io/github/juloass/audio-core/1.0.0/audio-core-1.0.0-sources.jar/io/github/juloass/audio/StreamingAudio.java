package io.github.juloass.audio;

import java.util.Objects;

/** Repeatable streaming audio. */
public record StreamingAudio(AudioFormat format, AudioStreamSource source) implements AudioAsset {
    public StreamingAudio { Objects.requireNonNull(format, "format"); Objects.requireNonNull(source, "source"); }
}


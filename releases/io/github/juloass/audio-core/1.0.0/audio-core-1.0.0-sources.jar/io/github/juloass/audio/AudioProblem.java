package io.github.juloass.audio;

import java.util.*;

/** Structured audio failure without logging policy. */
public record AudioProblem(AudioProblemCode code,String message,Optional<Throwable> cause){
    public AudioProblem{Objects.requireNonNull(code);Objects.requireNonNull(message);cause=Objects.requireNonNull(cause);}
    public static AudioProblem of(AudioProblemCode code,String message){return new AudioProblem(code,message,Optional.empty());}
}


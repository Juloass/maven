package io.github.juloass.audio;

import java.util.*;

/** Result of bounded engine shutdown. */
public record AudioCloseResult(boolean closed,Optional<AudioProblem> problem){public AudioCloseResult{problem=Objects.requireNonNull(problem);}}


package io.github.juloass.audio;

import java.util.Objects;

/** Decoded audio format. */
public record AudioFormat(int sampleRate, ChannelLayout channelLayout) {
    public AudioFormat {
        if (sampleRate < 1) throw new IllegalArgumentException("sampleRate must be positive");
        Objects.requireNonNull(channelLayout, "channelLayout");
    }
}

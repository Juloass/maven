package io.github.juloass.audio;

import java.util.Objects;

/** Eager decoded audio. */
public record DecodedAudio(PcmData pcm) implements AudioAsset {
    public DecodedAudio { Objects.requireNonNull(pcm, "pcm"); }
    @Override public AudioFormat format() { return pcm.format(); }
}


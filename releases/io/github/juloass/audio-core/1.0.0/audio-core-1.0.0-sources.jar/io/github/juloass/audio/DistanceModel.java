package io.github.juloass.audio;

/** Distance attenuation rule. */
public enum DistanceModel { NONE, LINEAR, INVERSE, EXPONENTIAL }


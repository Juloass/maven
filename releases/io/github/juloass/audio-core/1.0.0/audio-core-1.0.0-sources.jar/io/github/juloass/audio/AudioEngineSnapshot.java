package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.util.*;

/** Immutable latest audio-thread state. */
public record AudioEngineSnapshot(long sequence,Map<Identifier,PlaybackSnapshot> playbacks,int activeVoices){
    public AudioEngineSnapshot{playbacks=Map.copyOf(Objects.requireNonNull(playbacks));if(activeVoices<0)throw new IllegalArgumentException("activeVoices must not be negative");}
    public record PlaybackSnapshot(AudioState state,long positionFrame,double gain,double pitch){public PlaybackSnapshot{Objects.requireNonNull(state);}}
}


package io.github.juloass.audio;

/** Deterministic procedural PCM synthesis. */
public final class ProceduralAudio {
    public enum Waveform{SINE,SQUARE,TRIANGLE,SAW}
    private ProceduralAudio(){}
    public static PcmData tone(Waveform waveform,int rate,int milliseconds,double frequency,double amplitude){
        return tone(waveform, rate, milliseconds, frequency, amplitude, defaultEnvelope(rate, milliseconds));
    }
    public static PcmData tone(Waveform waveform,int rate,int milliseconds,double frequency,double amplitude,AmplitudeEnvelope envelope){
        if(frequency<=0||!Double.isFinite(frequency)||frequency>=rate*.5)throw new IllegalArgumentException("frequency must be below Nyquist");validate(rate,milliseconds,amplitude);
        java.util.Objects.requireNonNull(envelope,"envelope");int count=Math.max(1,Math.toIntExact((long)rate*milliseconds/1000));float[] samples=new float[count];for(int i=0;i<count;i++){double cycle=frequency*i/rate-Math.floor(frequency*i/rate);double wave=switch(waveform){case SINE->Math.sin(2*Math.PI*cycle);case SQUARE->cycle<.5?1:-1;case TRIANGLE->1-4*Math.abs(cycle-.5);case SAW->2*cycle-1;};samples[i]=(float)(wave*amplitude*envelope(i,count,rate,envelope));}return new PcmData(new AudioFormat(rate,ChannelLayout.MONO),samples);}
    public static PcmData whiteNoise(int rate,int milliseconds,double amplitude,long seed){return whiteNoise(rate,milliseconds,amplitude,seed,defaultEnvelope(rate,milliseconds));}
    public static PcmData whiteNoise(int rate,int milliseconds,double amplitude,long seed,AmplitudeEnvelope envelope){validate(rate,milliseconds,amplitude);java.util.Objects.requireNonNull(envelope,"envelope");int count=Math.max(1,Math.toIntExact((long)rate*milliseconds/1000));float[] samples=new float[count];long state=seed;for(int i=0;i<count;i++){state^=state<<13;state^=state>>>7;state^=state<<17;samples[i]=(float)((((state>>>40)&0xffffff)/(double)0x800000-1)*amplitude*envelope(i,count,rate,envelope));}return new PcmData(new AudioFormat(rate,ChannelLayout.MONO),samples);}
    private static void validate(int r,int d,double a){if(r<1||d<1||d>60000||!Double.isFinite(a)||a<0||a>1)throw new IllegalArgumentException("invalid synthesis parameters");}
    private static AmplitudeEnvelope defaultEnvelope(int rate,int milliseconds){int count=Math.max(1,Math.toIntExact((long)rate*milliseconds/1000));int ramp=Math.max(1,Math.min(count/8,240));long nanos=Math.round(ramp*1_000_000_000.0/rate);return new AmplitudeEnvelope(java.time.Duration.ofNanos(nanos),java.time.Duration.ofNanos(nanos));}
    private static double envelope(int index,int count,int rate,AmplitudeEnvelope value){long attack=Math.round(value.attack().toNanos()*rate/1_000_000_000.0);long release=Math.round(value.release().toNanos()*rate/1_000_000_000.0);double attackGain=attack==0?1:Math.min(1,(index+1.0)/attack);double releaseGain=release==0?1:Math.min(1,(count-index)/(double)release);return Math.min(attackGain,releaseGain);}
}

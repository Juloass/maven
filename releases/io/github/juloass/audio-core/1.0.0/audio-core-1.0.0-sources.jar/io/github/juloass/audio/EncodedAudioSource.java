package io.github.juloass.audio;

import java.io.IOException;
import java.io.InputStream;

/** A repeatable source of encoded audio bytes. */
@FunctionalInterface
public interface EncodedAudioSource {
    InputStream openStream() throws IOException;
}

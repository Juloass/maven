package io.github.juloass.audio;

import java.time.Duration;
import java.util.Objects;

/** Linear attack and release durations for procedural synthesis. */
public record AmplitudeEnvelope(Duration attack, Duration release) {
    public AmplitudeEnvelope {
        attack = Objects.requireNonNull(attack, "attack");
        release = Objects.requireNonNull(release, "release");
        if (attack.isNegative() || release.isNegative()) {
            throw new IllegalArgumentException("envelope durations must not be negative");
        }
    }

    public static AmplitudeEnvelope none() {
        return new AmplitudeEnvelope(Duration.ZERO, Duration.ZERO);
    }
}

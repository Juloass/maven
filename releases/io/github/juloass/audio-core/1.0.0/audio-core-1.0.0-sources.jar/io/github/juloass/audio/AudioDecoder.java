package io.github.juloass.audio;

import java.io.IOException;
import java.io.InputStream;

/** Decoder for one encoded audio format. */
public interface AudioDecoder {
    PcmData decode(InputStream input, AudioDecodeLimits limits) throws IOException;
    AudioStream stream(EncodedAudioSource encodedSource, AudioDecodeLimits limits) throws IOException;
}

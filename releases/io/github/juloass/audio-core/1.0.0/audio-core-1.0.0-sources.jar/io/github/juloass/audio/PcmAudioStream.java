package io.github.juloass.audio;

import java.io.IOException;
import java.util.Objects;
import java.util.OptionalLong;

/** A seekable stream over immutable decoded PCM data. */
public final class PcmAudioStream implements AudioStream {
    private final PcmData data;
    private long position;
    private boolean closed;

    public PcmAudioStream(PcmData data) {
        this.data = Objects.requireNonNull(data, "data");
    }

    @Override public AudioFormat format() { return data.format(); }
    @Override public OptionalLong frameCount() { return OptionalLong.of(data.frameCount()); }
    @Override public long positionFrame() { return position; }

    @Override
    public int readFrames(float[] destination, int offsetFrames, int maximumFrames) throws IOException {
        ensureOpen();
        Objects.requireNonNull(destination, "destination");
        if (offsetFrames < 0 || maximumFrames < 0) throw new IndexOutOfBoundsException("frame bounds must be non-negative");
        int channels = format().channelLayout().channels();
        int offset = Math.multiplyExact(offsetFrames, channels);
        int requestedSamples = Math.multiplyExact(maximumFrames, channels);
        if (offset > destination.length || requestedSamples > destination.length - offset) {
            throw new IndexOutOfBoundsException("destination does not contain the requested frame range");
        }
        int frames = (int) Math.min(maximumFrames, data.frameCount() - position);
        float[] source = data.samples();
        System.arraycopy(source, Math.toIntExact(position * channels), destination, offset, frames * channels);
        position += frames;
        return frames;
    }

    @Override
    public void seekFrame(long frame) throws IOException {
        ensureOpen();
        if (frame < 0 || frame > data.frameCount()) throw new IllegalArgumentException("frame is outside the stream");
        position = frame;
    }

    @Override public void close() { closed = true; }

    private void ensureOpen() throws IOException {
        if (closed) throw new IOException("audio stream is closed");
    }
}

package io.github.juloass.audio;

/** Playback loop rule. */
public enum LoopMode { ONCE, LOOP }


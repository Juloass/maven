package io.github.juloass.audio;

/** Decoded or streaming audio input. */
public sealed interface AudioAsset permits DecodedAudio, StreamingAudio { AudioFormat format(); }


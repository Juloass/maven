package io.github.juloass.audio;

import io.github.juloass.identifier.Identifier;
import java.time.Duration;
import java.util.*;

/** Streaming music request with transport transition data. */
public record MusicRequest(Identifier id,StreamingAudio audio,Identifier bus,int priority,double gain,
                           Optional<LoopRegion> loopRegion,Duration fadeIn,Duration crossfade,boolean gapless){
    public MusicRequest{Objects.requireNonNull(id);Objects.requireNonNull(audio);Objects.requireNonNull(bus);loopRegion=Objects.requireNonNull(loopRegion);
        Objects.requireNonNull(fadeIn);Objects.requireNonNull(crossfade);if(fadeIn.isNegative()||crossfade.isNegative()||!Double.isFinite(gain)||gain<0)throw new IllegalArgumentException("invalid music request");}
}


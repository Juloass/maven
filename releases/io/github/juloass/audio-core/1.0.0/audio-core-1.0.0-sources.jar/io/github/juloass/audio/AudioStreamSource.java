package io.github.juloass.audio;

import java.io.IOException;

/** Repeatable source for decoded streams. */
@FunctionalInterface
public interface AudioStreamSource { AudioStream open() throws IOException; }


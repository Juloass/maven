package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Wraps an exception raised by a task action. */
public final class TaskExecutionException extends RuntimeException {
    private final Identifier taskId;

    TaskExecutionException(Identifier taskId, Exception cause) {
        super("Task " + taskId + " failed: " + readable(cause), cause);
        this.taskId = Objects.requireNonNull(taskId, "taskId");
    }

    public Identifier taskId() { return taskId; }

    private static String readable(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null) root = root.getCause();
        return root.getClass().getSimpleName()
                + (root.getMessage() == null ? "" : ": " + root.getMessage());
    }
}

package io.github.juloass.taskgraph;

/** Executes one task against a consumer-owned context. */
@FunctionalInterface
public interface TaskAction<C> {
    /** Executes the task. */
    void execute(C context) throws Exception;
}

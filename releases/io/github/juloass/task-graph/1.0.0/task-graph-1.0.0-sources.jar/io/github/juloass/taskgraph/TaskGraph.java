package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** An immutable validated graph of sequential tasks. */
public final class TaskGraph<C> {
    private final List<Task<C>> orderedTasks;

    private TaskGraph(List<Task<C>> orderedTasks) {
        this.orderedTasks = List.copyOf(orderedTasks);
    }

    public static <C> Builder<C> builder() { return new Builder<>(); }

    /** Returns tasks in their stable execution order. */
    public List<Task<C>> tasks() { return orderedTasks; }

    /** Starts an independent execution session. */
    public TaskSession<C> start(C context) {
        return new TaskSession<>(orderedTasks, Objects.requireNonNull(context, "context"));
    }

    /** Builds one immutable task graph. */
    public static final class Builder<C> {
        private final LinkedHashMap<Identifier, Task<C>> tasks = new LinkedHashMap<>();
        private TaskGraph<C> built;

        /** Adds one task. */
        public Builder<C> add(Task<C> task) {
            Objects.requireNonNull(task, "task");
            if (built != null) throw new IllegalStateException("Task graph is already built");
            if (tasks.putIfAbsent(task.id(), task) != null) {
                throw new DuplicateTaskException(task.id());
            }
            return this;
        }

        /** Validates and builds the graph. */
        public TaskGraph<C> build() {
            if (built == null) built = new TaskGraph<>(orderedTasks(tasks));
            return built;
        }
    }

    private static <C> List<Task<C>> orderedTasks(LinkedHashMap<Identifier, Task<C>> tasks) {
        tasks.values().forEach(task -> task.dependencies().forEach(dependency -> {
            if (!tasks.containsKey(dependency)) {
                throw new MissingTaskDependencyException(task.id(), dependency);
            }
        }));

        LinkedHashMap<Identifier, Integer> indegree = new LinkedHashMap<>();
        LinkedHashMap<Identifier, List<Identifier>> outgoing = new LinkedHashMap<>();
        tasks.keySet().forEach(id -> {
            indegree.put(id, 0);
            outgoing.put(id, new ArrayList<>());
        });
        tasks.values().forEach(task -> task.dependencies().forEach(dependency -> {
            outgoing.get(dependency).add(task.id());
            indegree.compute(task.id(), (ignored, count) -> count + 1);
        }));

        ArrayDeque<Identifier> ready = new ArrayDeque<>();
        indegree.forEach((id, count) -> { if (count == 0) ready.addLast(id); });
        ArrayList<Task<C>> ordered = new ArrayList<>(tasks.size());
        while (!ready.isEmpty()) {
            Identifier id = ready.removeFirst();
            ordered.add(tasks.get(id));
            for (Identifier dependent : outgoing.get(id)) {
                int remaining = indegree.compute(dependent, (ignored, count) -> count - 1);
                if (remaining == 0) ready.addLast(dependent);
            }
        }
        if (ordered.size() != tasks.size()) {
            throw new TaskDependencyCycleException(findCycle(tasks));
        }
        return ordered;
    }

    private static <C> List<Identifier> findCycle(Map<Identifier, Task<C>> tasks) {
        Map<Identifier, Integer> states = new HashMap<>();
        ArrayList<Identifier> path = new ArrayList<>();
        for (Identifier id : tasks.keySet()) {
            List<Identifier> cycle = visit(id, tasks, states, path);
            if (cycle != null) return cycle;
        }
        throw new IllegalStateException("Cycle detection did not locate a cycle");
    }

    private static <C> List<Identifier> visit(
            Identifier id,
            Map<Identifier, Task<C>> tasks,
            Map<Identifier, Integer> states,
            ArrayList<Identifier> path
    ) {
        int state = states.getOrDefault(id, 0);
        if (state == 2) return null;
        if (state == 1) {
            int start = path.indexOf(id);
            ArrayList<Identifier> cycle = new ArrayList<>(path.subList(start, path.size()));
            cycle.add(id);
            return cycle;
        }
        states.put(id, 1);
        path.add(id);
        for (Identifier dependency : tasks.get(id).dependencies()) {
            List<Identifier> cycle = visit(dependency, tasks, states, path);
            if (cycle != null) return cycle;
        }
        path.remove(path.size() - 1);
        states.put(id, 2);
        return null;
    }
}

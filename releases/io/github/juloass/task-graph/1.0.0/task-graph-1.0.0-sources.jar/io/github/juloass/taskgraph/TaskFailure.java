package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** The task and cause retained by a failed session. */
public record TaskFailure(Identifier taskId, Throwable cause) {
    public TaskFailure {
        Objects.requireNonNull(taskId, "taskId");
        Objects.requireNonNull(cause, "cause");
    }
}

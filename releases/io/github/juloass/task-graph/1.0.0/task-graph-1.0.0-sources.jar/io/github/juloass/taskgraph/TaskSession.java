package io.github.juloass.taskgraph;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * One stateful sequential execution of a task graph.
 *
 * @param <C> consumer-owned context type
 */
public final class TaskSession<C> {
    private final List<Task<C>> tasks;
    private final C context;
    private int completedTaskCount;
    private TaskFailure failure;

    TaskSession(List<Task<C>> tasks, C context) {
        this.tasks = List.copyOf(tasks);
        this.context = Objects.requireNonNull(context, "context");
    }

    /** Returns the total task count. */
    public int taskCount() { return tasks.size(); }

    /** Returns the successfully completed task count. */
    public int completedTaskCount() { return completedTaskCount; }

    /** Reports whether every task completed successfully. */
    public boolean complete() { return failure == null && completedTaskCount == tasks.size(); }

    /** Reports whether execution stopped after a failure. */
    public boolean failed() { return failure != null; }

    /** Returns the next task, or an empty value when complete or failed. */
    public Optional<Task<C>> nextTask() {
        return failed() || complete() ? Optional.empty() : Optional.of(tasks.get(completedTaskCount));
    }

    /** Returns the retained failure, if any. */
    public Optional<TaskFailure> failure() { return Optional.ofNullable(failure); }

    /**
     * Executes the next task.
     *
     * @return true when a task ran; false when the session was already complete
     * @throws TaskExecutionException when the task throws an exception
     * @throws IllegalStateException when the session has already failed
     */
    public boolean executeNext() {
        if (failed()) throw new IllegalStateException("Task session has failed", failure.cause());
        if (complete()) return false;
        Task<C> task = tasks.get(completedTaskCount);
        try {
            task.action().execute(context);
        } catch (Exception exception) {
            failure = new TaskFailure(task.id(), exception);
            throw new TaskExecutionException(task.id(), exception);
        } catch (Error error) {
            failure = new TaskFailure(task.id(), error);
            throw error;
        }
        completedTaskCount++;
        return true;
    }

    /** Executes all remaining tasks sequentially. */
    public void executeAll() {
        while (executeNext()) {
            // Execute until no task remains.
        }
    }

    /** Returns the consumer-owned context. */
    public C context() { return context; }
}
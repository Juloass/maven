package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

/** One task and its direct dependencies. */
public record Task<C>(Identifier id, Set<Identifier> dependencies, TaskAction<C> action) {
    public Task {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(dependencies, "dependencies");
        Objects.requireNonNull(action, "action");
        LinkedHashSet<Identifier> copy = new LinkedHashSet<>();
        for (Identifier dependency : dependencies) {
            copy.add(Objects.requireNonNull(dependency, "dependency"));
        }
        dependencies = Collections.unmodifiableSet(copy);
    }

    /** Creates a task without dependencies. */
    public static <C> Task<C> of(Identifier id, TaskAction<C> action) {
        return new Task<>(id, Set.of(), action);
    }
}

package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports a dependency that does not identify a registered task. */
public final class MissingTaskDependencyException extends IllegalArgumentException {
    private final Identifier taskId;
    private final Identifier dependencyId;

    MissingTaskDependencyException(Identifier taskId, Identifier dependencyId) {
        super("Task " + taskId + " has missing dependency " + dependencyId);
        this.taskId = Objects.requireNonNull(taskId, "taskId");
        this.dependencyId = Objects.requireNonNull(dependencyId, "dependencyId");
    }

    public Identifier taskId() { return taskId; }
    public Identifier dependencyId() { return dependencyId; }
}

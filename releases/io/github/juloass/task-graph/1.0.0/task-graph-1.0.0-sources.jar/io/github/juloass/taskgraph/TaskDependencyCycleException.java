package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.List;

/** Reports one complete ordered dependency cycle. */
public final class TaskDependencyCycleException extends IllegalArgumentException {
    private final List<Identifier> cycle;

    TaskDependencyCycleException(List<Identifier> cycle) {
        super("Task dependency cycle: " + cycle);
        this.cycle = List.copyOf(cycle);
    }

    /** Returns the cycle with its first identifier repeated at the end. */
    public List<Identifier> cycle() { return cycle; }
}

package io.github.juloass.taskgraph;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports a task identifier that is already registered. */
public final class DuplicateTaskException extends IllegalArgumentException {
    private final Identifier taskId;

    DuplicateTaskException(Identifier taskId) {
        super("Duplicate task identifier " + taskId);
        this.taskId = Objects.requireNonNull(taskId, "taskId");
    }

    public Identifier taskId() { return taskId; }
}

/** Immutable dependency graphs and deterministic sequential task execution. */
package io.github.juloass.taskgraph;

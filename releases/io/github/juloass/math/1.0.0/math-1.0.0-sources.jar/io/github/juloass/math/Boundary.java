package io.github.juloass.math;

/** Defines whether a numeric range includes one boundary. */
public enum Boundary {
    INCLUSIVE,
    EXCLUSIVE
}
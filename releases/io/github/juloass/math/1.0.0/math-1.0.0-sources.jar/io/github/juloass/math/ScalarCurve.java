package io.github.juloass.math;

/** A scalar function over unit parameter progress. */
public interface ScalarCurve {
    double valueAt(double parameter);

    double derivativeAt(double parameter);

    /** Returns the scalar tangent, which equals the first derivative. */
    default double tangentAt(double parameter) {
        return derivativeAt(parameter);
    }

    /**
     * Approximates the length of the parameter-value graph with line segments.
     */
    default double approximateLength(int segments) {
        if (segments < 1) {
            throw new IllegalArgumentException("segments must be positive");
        }
        double length = 0.0;
        double previousParameter = 0.0;
        double previousValue = valueAt(0.0);
        for (int index = 1; index <= segments; index++) {
            double parameter = (double) index / segments;
            double value = valueAt(parameter);
            length += Math.hypot(
                    parameter - previousParameter,
                    value - previousValue);
            previousParameter = parameter;
            previousValue = value;
        }
        return length;
    }
}
package io.github.juloass.math;

import java.util.Objects;

/** An immutable floating-point comparison policy. */
public record NumericComparison(
        double absoluteTolerance,
        double relativeTolerance,
        NaNPolicy nanPolicy,
        InfinityPolicy infinityPolicy) {

    public NumericComparison {
        if (!Double.isFinite(absoluteTolerance) || absoluteTolerance < 0.0) {
            throw new IllegalArgumentException(
                    "absoluteTolerance must be finite and nonnegative");
        }
        if (!Double.isFinite(relativeTolerance) || relativeTolerance < 0.0) {
            throw new IllegalArgumentException(
                    "relativeTolerance must be finite and nonnegative");
        }
        Objects.requireNonNull(nanPolicy, "nanPolicy");
        Objects.requireNonNull(infinityPolicy, "infinityPolicy");
    }

    public static NumericComparison absolute(double tolerance) {
        return combined(tolerance, 0.0);
    }

    public static NumericComparison relative(double tolerance) {
        return combined(0.0, tolerance);
    }

    public static NumericComparison combined(
            double absoluteTolerance,
            double relativeTolerance) {
        return new NumericComparison(
                absoluteTolerance,
                relativeTolerance,
                NaNPolicy.NEVER_EQUAL,
                InfinityPolicy.EQUAL_SAME_SIGN);
    }

    public NumericComparison withNaNPolicy(NaNPolicy policy) {
        return new NumericComparison(
                absoluteTolerance,
                relativeTolerance,
                policy,
                infinityPolicy);
    }

    public NumericComparison withInfinityPolicy(InfinityPolicy policy) {
        return new NumericComparison(
                absoluteTolerance,
                relativeTolerance,
                nanPolicy,
                policy);
    }

    public boolean test(double first, double second) {
        if (Double.isNaN(first) || Double.isNaN(second)) {
            return compareNaN(first, second);
        }
        if (Double.isInfinite(first) || Double.isInfinite(second)) {
            return compareInfinity(first, second);
        }
        if (first == second) {
            return true;
        }
        double difference = Math.abs(first - second);
        double relativeLimit = relativeTolerance
                * Math.max(Math.abs(first), Math.abs(second));
        return difference <= Math.max(absoluteTolerance, relativeLimit);
    }

    public static boolean isFinite(double value) {
        return Double.isFinite(value);
    }

    public static boolean isFinite(float value) {
        return Float.isFinite(value);
    }

    private boolean compareNaN(double first, double second) {
        return switch (nanPolicy) {
            case NEVER_EQUAL -> false;
            case EQUAL_TO_NAN -> Double.isNaN(first) && Double.isNaN(second);
            case REJECT -> throw new IllegalArgumentException(
                    "NaN is not accepted by this comparison policy");
        };
    }

    private boolean compareInfinity(double first, double second) {
        return switch (infinityPolicy) {
            case EQUAL_SAME_SIGN -> first == second;
            case NEVER_EQUAL -> false;
            case REJECT -> throw new IllegalArgumentException(
                    "Infinity is not accepted by this comparison policy");
        };
    }
}
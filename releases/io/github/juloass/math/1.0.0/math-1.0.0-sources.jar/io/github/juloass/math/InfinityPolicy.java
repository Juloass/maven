package io.github.juloass.math;

/** Defines comparison behavior when either value is infinite. */
public enum InfinityPolicy {
    EQUAL_SAME_SIGN,
    NEVER_EQUAL,
    REJECT
}
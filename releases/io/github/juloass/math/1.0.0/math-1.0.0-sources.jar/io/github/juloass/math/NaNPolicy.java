package io.github.juloass.math;

/** Defines comparison behavior when either value is NaN. */
public enum NaNPolicy {
    NEVER_EQUAL,
    EQUAL_TO_NAN,
    REJECT
}
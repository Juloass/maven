package io.github.juloass.math;

import java.util.Objects;
import java.util.Optional;

/** A finite double range with an explicit rule for each boundary. */
public record DoubleRange(
        double minimum,
        double maximum,
        Boundary minimumBoundary,
        Boundary maximumBoundary) {

    public DoubleRange {
        Scalars.requireFinite(minimum, "minimum");
        Scalars.requireFinite(maximum, "maximum");
        Objects.requireNonNull(minimumBoundary, "minimumBoundary");
        Objects.requireNonNull(maximumBoundary, "maximumBoundary");
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
        if (minimum == maximum
                && (minimumBoundary == Boundary.EXCLUSIVE
                || maximumBoundary == Boundary.EXCLUSIVE)) {
            throw new IllegalArgumentException(
                    "An equal-bound range must include both boundaries");
        }
    }

    public static DoubleRange closed(double minimum, double maximum) {
        return new DoubleRange(
                minimum, maximum, Boundary.INCLUSIVE, Boundary.INCLUSIVE);
    }

    public static DoubleRange open(double minimum, double maximum) {
        return new DoubleRange(
                minimum, maximum, Boundary.EXCLUSIVE, Boundary.EXCLUSIVE);
    }

    public static DoubleRange closedOpen(double minimum, double maximum) {
        return new DoubleRange(
                minimum, maximum, Boundary.INCLUSIVE, Boundary.EXCLUSIVE);
    }

    public static DoubleRange openClosed(double minimum, double maximum) {
        return new DoubleRange(
                minimum, maximum, Boundary.EXCLUSIVE, Boundary.INCLUSIVE);
    }

    public boolean contains(double value) {
        if (Double.isNaN(value)) {
            return false;
        }
        boolean aboveMinimum = minimumBoundary == Boundary.INCLUSIVE
                ? value >= minimum
                : value > minimum;
        boolean belowMaximum = maximumBoundary == Boundary.INCLUSIVE
                ? value <= maximum
                : value < maximum;
        return aboveMinimum && belowMaximum;
    }

    public boolean overlaps(DoubleRange other) {
        return intersection(other).isPresent();
    }

    public Optional<DoubleRange> intersection(DoubleRange other) {
        Objects.requireNonNull(other, "other");
        double nextMinimum = Math.max(minimum, other.minimum);
        double nextMaximum = Math.min(maximum, other.maximum);
        if (nextMinimum > nextMaximum) {
            return Optional.empty();
        }

        Boundary nextMinimumBoundary = boundaryAtMinimum(other, nextMinimum);
        Boundary nextMaximumBoundary = boundaryAtMaximum(other, nextMaximum);
        if (nextMinimum == nextMaximum
                && (nextMinimumBoundary == Boundary.EXCLUSIVE
                || nextMaximumBoundary == Boundary.EXCLUSIVE)) {
            return Optional.empty();
        }
        return Optional.of(new DoubleRange(
                nextMinimum,
                nextMaximum,
                nextMinimumBoundary,
                nextMaximumBoundary));
    }

    /** Clamps to the nearest value that this range contains. */
    public double clamp(double value) {
        Scalars.requireFinite(value, "value");
        double effectiveMinimum = minimumBoundary == Boundary.INCLUSIVE
                ? minimum
                : Math.nextUp(minimum);
        double effectiveMaximum = maximumBoundary == Boundary.INCLUSIVE
                ? maximum
                : Math.nextDown(maximum);
        if (effectiveMinimum > effectiveMaximum) {
            throw new ArithmeticException(
                    "The range contains no representable double value");
        }
        return Scalars.clamp(value, effectiveMinimum, effectiveMaximum);
    }

    /** Normalizes a contained value. A singleton range returns zero. */
    public double normalize(double value) {
        if (!contains(value)) {
            throw new IllegalArgumentException("value must be contained by the range");
        }
        return normalizeUnbounded(value);
    }

    /** Normalizes a value without requiring containment. */
    public double normalizeUnbounded(double value) {
        Scalars.requireFinite(value, "value");
        if (minimum == maximum) {
            return 0.0;
        }
        return Scalars.normalizeUnbounded(value, minimum, maximum);
    }

    public double remap(double value, DoubleRange target) {
        Objects.requireNonNull(target, "target");
        return target.valueAt(normalize(value));
    }

    public double remapUnbounded(double value, DoubleRange target) {
        Objects.requireNonNull(target, "target");
        return target.valueAtUnbounded(normalizeUnbounded(value));
    }

    /** Evaluates this range with progress in {@code [0, 1]}. */
    public double valueAt(double progress) {
        if (minimum == maximum) {
            Scalars.requireUnit(progress, "progress");
            return minimum;
        }
        return Scalars.lerp(minimum, maximum, progress);
    }

    /** Evaluates this range with unbounded progress. */
    public double valueAtUnbounded(double progress) {
        if (minimum == maximum) {
            Scalars.requireFinite(progress, "progress");
            return minimum;
        }
        return Scalars.extrapolate(minimum, maximum, progress);
    }

    private Boundary boundaryAtMinimum(DoubleRange other, double candidate) {
        if (minimum == candidate && other.minimum == candidate) {
            return minimumBoundary == Boundary.INCLUSIVE
                    && other.minimumBoundary == Boundary.INCLUSIVE
                    ? Boundary.INCLUSIVE : Boundary.EXCLUSIVE;
        }
        return minimum == candidate ? minimumBoundary : other.minimumBoundary;
    }

    private Boundary boundaryAtMaximum(DoubleRange other, double candidate) {
        if (maximum == candidate && other.maximum == candidate) {
            return maximumBoundary == Boundary.INCLUSIVE
                    && other.maximumBoundary == Boundary.INCLUSIVE
                    ? Boundary.INCLUSIVE : Boundary.EXCLUSIVE;
        }
        return maximum == candidate ? maximumBoundary : other.maximumBoundary;
    }
}
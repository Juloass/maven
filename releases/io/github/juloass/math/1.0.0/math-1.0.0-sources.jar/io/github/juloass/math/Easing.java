package io.github.juloass.math;

/** Transforms unit progress without applying a domain action. */
@FunctionalInterface
public interface Easing {
    /**
     * Transforms finite progress in {@code [0, 1]}.
     * Implementations can return values outside that range.
     */
    double apply(double progress);

    /** Clamps progress before this easing transforms it. */
    default double applyClamped(double progress) {
        Scalars.requireFinite(progress, "progress");
        return apply(Scalars.clamp(progress, 0.0, 1.0));
    }
}
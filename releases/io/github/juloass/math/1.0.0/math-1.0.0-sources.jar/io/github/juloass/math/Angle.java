package io.github.juloass.math;

import java.util.Objects;

/** An immutable angle with radians as its canonical value. */
public record Angle(double inRadians) implements Comparable<Angle> {
    private static final double FULL_TURN = 2.0 * Math.PI;

    public Angle {
        Scalars.requireFinite(inRadians, "inRadians");
    }

    public static Angle radians(double radians) {
        return new Angle(radians);
    }

    public static Angle degrees(double degrees) {
        Scalars.requireFinite(degrees, "degrees");
        return new Angle(Math.toRadians(degrees));
    }

    public double inDegrees() {
        return Math.toDegrees(inRadians);
    }

    /** Returns an equivalent angle in {@code [0, 2*pi)}. */
    public Angle normalizedPositive() {
        return new Angle(Scalars.wrap(inRadians, 0.0, FULL_TURN));
    }

    /** Returns an equivalent angle in {@code [-pi, pi)}. */
    public Angle normalizedSigned() {
        return new Angle(Scalars.wrap(inRadians, -Math.PI, Math.PI));
    }

    /** Returns the unsigned shortest distance in {@code [0, pi]}. */
    public Angle distanceTo(Angle other) {
        return new Angle(Math.abs(shortestDelta(Objects.requireNonNull(other, "other"))));
    }

    /** Returns the increasing distance in {@code [0, 2*pi)}. */
    public Angle increasingDistanceTo(Angle other) {
        Objects.requireNonNull(other, "other");
        return new Angle(Scalars.wrap(other.inRadians - inRadians, 0.0, FULL_TURN));
    }

    /** Returns the decreasing distance in {@code (-2*pi, 0]}. */
    public Angle decreasingDistanceTo(Angle other) {
        Objects.requireNonNull(other, "other");
        double increasing = Scalars.wrap(other.inRadians - inRadians, 0.0, FULL_TURN);
        return new Angle(increasing == 0.0 ? 0.0 : increasing - FULL_TURN);
    }

    /** Uses the increasing direction for an exact half-turn tie. */
    public Angle interpolateShortest(Angle other, double progress) {
        Objects.requireNonNull(other, "other");
        Scalars.requireUnit(progress, "progress");
        return new Angle(inRadians + shortestDelta(other) * progress);
    }

    public Angle interpolateIncreasing(Angle other, double progress) {
        Scalars.requireUnit(progress, "progress");
        return new Angle(inRadians
                + increasingDistanceTo(Objects.requireNonNull(other, "other")).inRadians
                * progress);
    }

    public Angle interpolateDecreasing(Angle other, double progress) {
        Scalars.requireUnit(progress, "progress");
        return new Angle(inRadians
                + decreasingDistanceTo(Objects.requireNonNull(other, "other")).inRadians
                * progress);
    }

    @Override
    public int compareTo(Angle other) {
        return Double.compare(inRadians, Objects.requireNonNull(other, "other").inRadians);
    }

    private double shortestDelta(Angle other) {
        double delta = Scalars.wrap(other.inRadians - inRadians, -Math.PI, Math.PI);
        return delta == -Math.PI ? Math.PI : delta;
    }
}
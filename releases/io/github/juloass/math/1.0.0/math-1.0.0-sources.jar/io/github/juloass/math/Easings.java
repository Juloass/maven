package io.github.juloass.math;

/** Common easing families and CSS-style cubic Bezier easing. */
public final class Easings {
    private static final double DEFAULT_BACK_OVERSHOOT = 1.70158;
    private static final double TWO_PI = 2.0 * Math.PI;

    public static final Easing LINEAR = checked(progress -> progress);

    public static final Easing QUADRATIC_IN = polynomialIn(2);
    public static final Easing QUADRATIC_OUT = polynomialOut(2);
    public static final Easing QUADRATIC_IN_OUT = polynomialInOut(2);
    public static final Easing CUBIC_IN = polynomialIn(3);
    public static final Easing CUBIC_OUT = polynomialOut(3);
    public static final Easing CUBIC_IN_OUT = polynomialInOut(3);

    public static final Easing SINE_IN = checked(
            progress -> 1.0 - Math.cos(progress * Math.PI * 0.5));
    public static final Easing SINE_OUT = checked(
            progress -> Math.sin(progress * Math.PI * 0.5));
    public static final Easing SINE_IN_OUT = checked(
            progress -> -(Math.cos(Math.PI * progress) - 1.0) * 0.5);

    public static final Easing EXPONENTIAL_IN = checked(progress ->
            progress == 0.0 ? 0.0 : Math.pow(2.0, 10.0 * progress - 10.0));
    public static final Easing EXPONENTIAL_OUT = checked(progress ->
            progress == 1.0 ? 1.0 : 1.0 - Math.pow(2.0, -10.0 * progress));
    public static final Easing EXPONENTIAL_IN_OUT = checked(progress -> {
        if (progress == 0.0 || progress == 1.0) {
            return progress;
        }
        return progress < 0.5
                ? Math.pow(2.0, 20.0 * progress - 10.0) * 0.5
                : (2.0 - Math.pow(2.0, -20.0 * progress + 10.0)) * 0.5;
    });

    public static final Easing CIRCULAR_IN = checked(
            progress -> 1.0 - Math.sqrt(1.0 - progress * progress));
    public static final Easing CIRCULAR_OUT = checked(progress -> {
        double shifted = progress - 1.0;
        return Math.sqrt(1.0 - shifted * shifted);
    });
    public static final Easing CIRCULAR_IN_OUT = checked(progress ->
            progress < 0.5
                    ? (1.0 - Math.sqrt(1.0 - square(2.0 * progress))) * 0.5
                    : (Math.sqrt(1.0 - square(-2.0 * progress + 2.0)) + 1.0) * 0.5);

    public static final Easing BACK_IN = backIn(DEFAULT_BACK_OVERSHOOT);
    public static final Easing BACK_OUT = backOut(DEFAULT_BACK_OVERSHOOT);
    public static final Easing BACK_IN_OUT = backInOut(DEFAULT_BACK_OVERSHOOT);

    public static final Easing ELASTIC_IN = checked(progress -> {
        if (progress == 0.0 || progress == 1.0) {
            return progress;
        }
        return -Math.pow(2.0, 10.0 * progress - 10.0)
                * Math.sin((progress * 10.0 - 10.75) * TWO_PI / 3.0);
    });
    public static final Easing ELASTIC_OUT = checked(progress -> {
        if (progress == 0.0 || progress == 1.0) {
            return progress;
        }
        return Math.pow(2.0, -10.0 * progress)
                * Math.sin((progress * 10.0 - 0.75) * TWO_PI / 3.0) + 1.0;
    });
    public static final Easing ELASTIC_IN_OUT = checked(progress -> {
        if (progress == 0.0 || progress == 1.0) {
            return progress;
        }
        double sine = Math.sin((20.0 * progress - 11.125) * TWO_PI / 4.5);
        return progress < 0.5
                ? -(Math.pow(2.0, 20.0 * progress - 10.0) * sine) * 0.5
                : Math.pow(2.0, -20.0 * progress + 10.0) * sine * 0.5 + 1.0;
    });

    public static final Easing BOUNCE_OUT = checked(Easings::bounceOut);
    public static final Easing BOUNCE_IN = checked(
            progress -> 1.0 - bounceOut(1.0 - progress));
    public static final Easing BOUNCE_IN_OUT = checked(progress ->
            progress < 0.5
                    ? (1.0 - bounceOut(1.0 - 2.0 * progress)) * 0.5
                    : (1.0 + bounceOut(2.0 * progress - 1.0)) * 0.5);

    private Easings() {
    }

    public static Easing polynomialIn(int exponent) {
        requireExponent(exponent);
        return checked(progress -> Math.pow(progress, exponent));
    }

    public static Easing polynomialOut(int exponent) {
        requireExponent(exponent);
        return checked(progress -> 1.0 - Math.pow(1.0 - progress, exponent));
    }

    public static Easing polynomialInOut(int exponent) {
        requireExponent(exponent);
        return checked(progress -> progress < 0.5
                ? Math.pow(2.0, exponent - 1) * Math.pow(progress, exponent)
                : 1.0 - Math.pow(-2.0 * progress + 2.0, exponent) * 0.5);
    }

    public static Easing backIn(double overshoot) {
        requireOvershoot(overshoot);
        return checked(progress -> (overshoot + 1.0) * cube(progress)
                - overshoot * square(progress));
    }

    public static Easing backOut(double overshoot) {
        requireOvershoot(overshoot);
        return checked(progress -> {
            double shifted = progress - 1.0;
            return 1.0 + (overshoot + 1.0) * cube(shifted)
                    + overshoot * square(shifted);
        });
    }

    public static Easing backInOut(double overshoot) {
        requireOvershoot(overshoot);
        double scaled = overshoot * 1.525;
        return checked(progress -> progress < 0.5
                ? square(2.0 * progress)
                * ((scaled + 1.0) * 2.0 * progress - scaled) * 0.5
                : (square(2.0 * progress - 2.0)
                * ((scaled + 1.0) * (2.0 * progress - 2.0) + scaled) + 2.0) * 0.5);
    }

    /** Creates a CSS-style cubic Bezier easing with fixed iteration count. */
    public static Easing cubicBezier(double x1, double y1, double x2, double y2) {
        requireControl(x1, "x1");
        requireControl(x2, "x2");
        Scalars.requireFinite(y1, "y1");
        Scalars.requireFinite(y2, "y2");
        return checked(progress -> {
            if (progress == 0.0 || progress == 1.0) {
                return progress;
            }
            double low = 0.0;
            double high = 1.0;
            for (int step = 0; step < 24; step++) {
                double parameter = (low + high) * 0.5;
                if (bezierCoordinate(parameter, x1, x2) < progress) {
                    low = parameter;
                } else {
                    high = parameter;
                }
            }
            return bezierCoordinate((low + high) * 0.5, y1, y2);
        });
    }

    private static Easing checked(Easing function) {
        return progress -> {
            Scalars.requireUnit(progress, "progress");
            return function.apply(progress);
        };
    }

    private static double bezierCoordinate(
            double parameter,
            double first,
            double second) {
        double inverse = 1.0 - parameter;
        return 3.0 * inverse * inverse * parameter * first
                + 3.0 * inverse * parameter * parameter * second
                + parameter * parameter * parameter;
    }

    private static double bounceOut(double progress) {
        double coefficient = 7.5625;
        double divisor = 2.75;
        if (progress < 1.0 / divisor) {
            return coefficient * progress * progress;
        }
        if (progress < 2.0 / divisor) {
            double shifted = progress - 1.5 / divisor;
            return coefficient * shifted * shifted + 0.75;
        }
        if (progress < 2.5 / divisor) {
            double shifted = progress - 2.25 / divisor;
            return coefficient * shifted * shifted + 0.9375;
        }
        double shifted = progress - 2.625 / divisor;
        return coefficient * shifted * shifted + 0.984375;
    }

    private static double square(double value) {
        return value * value;
    }

    private static double cube(double value) {
        return value * value * value;
    }

    private static void requireExponent(int exponent) {
        if (exponent < 1) {
            throw new IllegalArgumentException("exponent must be positive");
        }
    }

    private static void requireOvershoot(double overshoot) {
        Scalars.requireFinite(overshoot, "overshoot");
        if (overshoot < 0.0) {
            throw new IllegalArgumentException("overshoot must be nonnegative");
        }
    }

    private static void requireControl(double value, String name) {
        Scalars.requireUnit(value, name);
    }
}
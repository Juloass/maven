package io.github.juloass.math;

import java.util.Objects;
import java.util.OptionalDouble;

/** Generic scalar operations with explicit bounded and unbounded variants. */
public final class Scalars {
    private Scalars() {
    }

    public static double clamp(double value, double minimum, double maximum) {
        requireNotNaN(value, "value");
        requireOrdered(minimum, maximum);
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static float clamp(float value, float minimum, float maximum) {
        if (Float.isNaN(value) || Float.isNaN(minimum) || Float.isNaN(maximum)) {
            throw new IllegalArgumentException("Clamp values must not be NaN");
        }
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static int clamp(int value, int minimum, int maximum) {
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static long clamp(long value, long minimum, long maximum) {
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
        return Math.max(minimum, Math.min(maximum, value));
    }

    /** Wraps a finite value into the half-open interval {@code [minimum, maximum)}. */
    public static double wrap(double value, double minimum, double maximum) {
        requireFinite(value, "value");
        requireFinite(minimum, "minimum");
        requireFinite(maximum, "maximum");
        if (!(minimum < maximum)) {
            throw new IllegalArgumentException("minimum must be less than maximum");
        }
        double width = maximum - minimum;
        double wrapped = value - width * Math.floor((value - minimum) / width);
        return wrapped >= maximum ? minimum : wrapped;
    }

    /** Wraps a value into the half-open interval {@code [minimum, maximum)}. */
    public static int wrap(int value, int minimum, int maximum) {
        if (minimum >= maximum) {
            throw new IllegalArgumentException("minimum must be less than maximum");
        }
        long width = (long) maximum - minimum;
        return (int) (minimum + Math.floorMod((long) value - minimum, width));
    }

    /** Snaps to the nearest step. Halfway values use ties-to-even rounding. */
    public static double snap(double value, double step) {
        return snap(value, step, 0.0);
    }

    /** Snaps to the nearest step relative to an origin. */
    public static double snap(double value, double step, double origin) {
        requireFinite(value, "value");
        requireFinite(step, "step");
        requireFinite(origin, "origin");
        if (!(step > 0.0)) {
            throw new IllegalArgumentException("step must be positive");
        }
        return origin + Math.rint((value - origin) / step) * step;
    }

    /** Interpolates with progress in {@code [0, 1]}. */
    public static double lerp(double start, double end, double progress) {
        requireFinite(start, "start");
        requireFinite(end, "end");
        requireUnit(progress, "progress");
        return start + (end - start) * progress;
    }

    /** Interpolates with progress in {@code [0, 1]}. */
    public static float lerp(float start, float end, float progress) {
        return (float) lerp((double) start, end, progress);
    }

    /** Evaluates the linear rule with unbounded progress. */
    public static double extrapolate(double start, double end, double progress) {
        requireFinite(start, "start");
        requireFinite(end, "end");
        requireFinite(progress, "progress");
        return start + (end - start) * progress;
    }
    /** Evaluates the linear rule with unbounded progress. */
    public static float extrapolate(float start, float end, float progress) {
        return (float) extrapolate((double) start, end, progress);
    }

    public static double inverseLerp(double start, double end, double value) {
        double progress = inverseLerpUnbounded(start, end, value);
        requireUnit(progress, "inverse interpolation result");
        return progress;
    }

    public static double inverseLerpUnbounded(double start, double end, double value) {
        requireFinite(start, "start");
        requireFinite(end, "end");
        requireFinite(value, "value");
        if (start == end) {
            throw new IllegalArgumentException("start and end must differ");
        }
        return (value - start) / (end - start);
    }

    public static double normalize(double value, double minimum, double maximum) {
        if (!(minimum < maximum)) {
            throw new IllegalArgumentException("minimum must be less than maximum");
        }
        return inverseLerp(minimum, maximum, value);
    }

    public static double normalizeUnbounded(double value, double minimum, double maximum) {
        if (!(minimum < maximum)) {
            throw new IllegalArgumentException("minimum must be less than maximum");
        }
        return inverseLerpUnbounded(minimum, maximum, value);
    }

    public static double remap(
            double value,
            double sourceMinimum,
            double sourceMaximum,
            double targetMinimum,
            double targetMaximum) {
        return lerp(
                targetMinimum,
                targetMaximum,
                normalize(value, sourceMinimum, sourceMaximum));
    }

    public static double remapUnbounded(
            double value,
            double sourceMinimum,
            double sourceMaximum,
            double targetMinimum,
            double targetMaximum) {
        return extrapolate(
                targetMinimum,
                targetMaximum,
                normalizeUnbounded(value, sourceMinimum, sourceMaximum));
    }

    /** Returns the conventional clamped smoothstep value. */
    public static double smoothstep(double edge0, double edge1, double value) {
        double progress = clampedProgress(edge0, edge1, value);
        return progress * progress * (3.0 - 2.0 * progress);
    }

    /** Returns the conventional clamped smootherstep value. */
    public static double smootherstep(double edge0, double edge1, double value) {
        double progress = clampedProgress(edge0, edge1, value);
        return progress * progress * progress
                * (progress * (progress * 6.0 - 15.0) + 10.0);
    }

    /** Returns a finite quotient, or an empty value for an unsafe division. */
    public static OptionalDouble safeDivide(double numerator, double denominator) {
        if (!Double.isFinite(numerator)
                || !Double.isFinite(denominator)
                || denominator == 0.0) {
            return OptionalDouble.empty();
        }
        double quotient = numerator / denominator;
        return Double.isFinite(quotient)
                ? OptionalDouble.of(quotient)
                : OptionalDouble.empty();
    }

    public static double min(double first, double... remaining) {
        Objects.requireNonNull(remaining, "remaining");
        requireNotNaN(first, "first");
        double result = first;
        for (double value : remaining) {
            requireNotNaN(value, "remaining value");
            result = Math.min(result, value);
        }
        return result;
    }

    public static double max(double first, double... remaining) {
        Objects.requireNonNull(remaining, "remaining");
        requireNotNaN(first, "first");
        double result = first;
        for (double value : remaining) {
            requireNotNaN(value, "remaining value");
            result = Math.max(result, value);
        }
        return result;
    }

    public static double sqrt(double value) {
        return Math.sqrt(value);
    }

    public static double cbrt(double value) {
        return Math.cbrt(value);
    }

    public static double pow(double value, double exponent) {
        return Math.pow(value, exponent);
    }

    public static double exp(double value) {
        return Math.exp(value);
    }

    public static double log(double value) {
        return Math.log(value);
    }

    public static double log10(double value) {
        return Math.log10(value);
    }

    public static double sin(Angle angle) {
        return Math.sin(Objects.requireNonNull(angle, "angle").inRadians());
    }

    public static double cos(Angle angle) {
        return Math.cos(Objects.requireNonNull(angle, "angle").inRadians());
    }

    public static double tan(Angle angle) {
        return Math.tan(Objects.requireNonNull(angle, "angle").inRadians());
    }

    public static Angle asin(double value) {
        return Angle.radians(Math.asin(value));
    }

    public static Angle acos(double value) {
        return Angle.radians(Math.acos(value));
    }

    public static Angle atan(double value) {
        return Angle.radians(Math.atan(value));
    }

    public static Angle atan2(double y, double x) {
        return Angle.radians(Math.atan2(y, x));
    }

    private static double clampedProgress(double edge0, double edge1, double value) {
        requireFinite(edge0, "edge0");
        requireFinite(edge1, "edge1");
        requireFinite(value, "value");
        if (!(edge0 < edge1)) {
            throw new IllegalArgumentException("edge0 must be less than edge1");
        }
        return clamp((value - edge0) / (edge1 - edge0), 0.0, 1.0);
    }

    static void requireUnit(double value, String name) {
        requireFinite(value, name);
        if (value < 0.0 || value > 1.0) {
            throw new IllegalArgumentException(name + " must be within [0, 1]");
        }
    }

    static void requireFinite(double value, String name) {
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException(name + " must be finite");
        }
    }

    private static void requireNotNaN(double value, String name) {
        if (Double.isNaN(value)) {
            throw new IllegalArgumentException(name + " must not be NaN");
        }
    }

    private static void requireOrdered(double minimum, double maximum) {
        requireNotNaN(minimum, "minimum");
        requireNotNaN(maximum, "maximum");
        if (minimum > maximum) {
            throw new IllegalArgumentException("minimum must not exceed maximum");
        }
    }
}
package io.github.juloass.math;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** An immutable scalar Bezier curve of any positive degree. */
public final class BezierCurve implements ScalarCurve {
    private final List<Double> controlValues;

    public BezierCurve(List<Double> controlValues) {
        Objects.requireNonNull(controlValues, "controlValues");
        if (controlValues.size() < 2) {
            throw new IllegalArgumentException(
                    "A Bezier curve needs at least two control values");
        }
        ArrayList<Double> copy = new ArrayList<>(controlValues.size());
        for (int index = 0; index < controlValues.size(); index++) {
            Double value = Objects.requireNonNull(
                    controlValues.get(index), "controlValues[" + index + "]");
            Scalars.requireFinite(value, "control value");
            copy.add(value);
        }
        this.controlValues = List.copyOf(copy);
    }

    public static BezierCurve of(double... controlValues) {
        Objects.requireNonNull(controlValues, "controlValues");
        ArrayList<Double> values = new ArrayList<>(controlValues.length);
        for (double value : controlValues) {
            values.add(value);
        }
        return new BezierCurve(values);
    }

    public List<Double> controlValues() {
        return controlValues;
    }

    public int degree() {
        return controlValues.size() - 1;
    }

    @Override
    public double valueAt(double parameter) {
        Scalars.requireUnit(parameter, "parameter");
        return evaluate(controlValues, parameter);
    }

    @Override
    public double derivativeAt(double parameter) {
        Scalars.requireUnit(parameter, "parameter");
        int degree = degree();
        ArrayList<Double> derivativeControls = new ArrayList<>(degree);
        for (int index = 0; index < degree; index++) {
            derivativeControls.add(degree
                    * (controlValues.get(index + 1) - controlValues.get(index)));
        }
        return evaluate(derivativeControls, parameter);
    }

    public double secondDerivativeAt(double parameter) {
        Scalars.requireUnit(parameter, "parameter");
        int degree = degree();
        if (degree < 2) {
            return 0.0;
        }
        ArrayList<Double> controls = new ArrayList<>(degree - 1);
        for (int index = 0; index < degree - 1; index++) {
            double difference = controlValues.get(index + 2)
                    - 2.0 * controlValues.get(index + 1)
                    + controlValues.get(index);
            controls.add(degree * (degree - 1) * difference);
        }
        return evaluate(controls, parameter);
    }

    private static double evaluate(List<Double> controls, double parameter) {
        if (controls.size() == 1) {
            return controls.getFirst();
        }
        double[] work = new double[controls.size()];
        for (int index = 0; index < controls.size(); index++) {
            work[index] = controls.get(index);
        }
        for (int level = work.length - 1; level > 0; level--) {
            for (int index = 0; index < level; index++) {
                work[index] = Scalars.lerp(
                        work[index], work[index + 1], parameter);
            }
        }
        return work[0];
    }
}
package io.github.juloass.math;

import java.util.Objects;

/** Explicit StrictMath operations and fixed-order numeric helpers. */
public final class DeterministicMath {
    private DeterministicMath() {
    }

    public static double sqrt(double value) { return StrictMath.sqrt(value); }
    public static double cbrt(double value) { return StrictMath.cbrt(value); }
    public static double pow(double value, double exponent) { return StrictMath.pow(value, exponent); }
    public static double exp(double value) { return StrictMath.exp(value); }
    public static double log(double value) { return StrictMath.log(value); }
    public static double log10(double value) { return StrictMath.log10(value); }
    public static double sin(Angle angle) { return StrictMath.sin(angle.inRadians()); }
    public static double cos(Angle angle) { return StrictMath.cos(angle.inRadians()); }
    public static double tan(Angle angle) { return StrictMath.tan(angle.inRadians()); }
    public static Angle asin(double value) { return Angle.radians(StrictMath.asin(value)); }
    public static Angle acos(double value) { return Angle.radians(StrictMath.acos(value)); }
    public static Angle atan(double value) { return Angle.radians(StrictMath.atan(value)); }
    public static Angle atan2(double y, double x) { return Angle.radians(StrictMath.atan2(y, x)); }
    public static double hypot(double first, double second) { return StrictMath.hypot(first, second); }

    /** Sums finite values in encounter order with compensated summation. */
    public static double sum(double... values) {
        Objects.requireNonNull(values, "values");
        double sum = 0.0;
        double compensation = 0.0;
        for (double value : values) {
            Scalars.requireFinite(value, "value");
            double next = sum + value;
            compensation += Math.abs(sum) >= Math.abs(value)
                    ? (sum - next) + value
                    : (value - next) + sum;
            sum = next;
        }
        return sum + compensation;
    }

    /** Returns the fixed-order compensated mean of one or more finite values. */
    public static double mean(double first, double... remaining) {
        Objects.requireNonNull(remaining, "remaining");
        double[] values = new double[remaining.length + 1];
        values[0] = first;
        System.arraycopy(remaining, 0, values, 1, remaining.length);
        return sum(values) / values.length;
    }
}
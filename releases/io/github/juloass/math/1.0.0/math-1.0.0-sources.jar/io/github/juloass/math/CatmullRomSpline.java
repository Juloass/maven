package io.github.juloass.math;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** An immutable uniform Catmull-Rom scalar spline over unit progress. */
public final class CatmullRomSpline implements ScalarCurve {
    private final List<Double> values;

    public CatmullRomSpline(List<Double> values) {
        Objects.requireNonNull(values, "values");
        if (values.size() < 2) {
            throw new IllegalArgumentException(
                    "A spline needs at least two values");
        }
        ArrayList<Double> copy = new ArrayList<>(values.size());
        for (int index = 0; index < values.size(); index++) {
            Double value = Objects.requireNonNull(
                    values.get(index), "values[" + index + "]");
            Scalars.requireFinite(value, "spline value");
            copy.add(value);
        }
        this.values = List.copyOf(copy);
    }

    public static CatmullRomSpline of(double... values) {
        Objects.requireNonNull(values, "values");
        ArrayList<Double> copy = new ArrayList<>(values.length);
        for (double value : values) {
            copy.add(value);
        }
        return new CatmullRomSpline(copy);
    }

    public List<Double> values() {
        return values;
    }

    @Override
    public double valueAt(double parameter) {
        Segment segment = segment(parameter);
        double t = segment.localParameter;
        double t2 = t * t;
        double t3 = t2 * t;
        return 0.5 * ((2.0 * segment.p1)
                + (-segment.p0 + segment.p2) * t
                + (2.0 * segment.p0 - 5.0 * segment.p1
                + 4.0 * segment.p2 - segment.p3) * t2
                + (-segment.p0 + 3.0 * segment.p1
                - 3.0 * segment.p2 + segment.p3) * t3);
    }

    @Override
    public double derivativeAt(double parameter) {
        Segment segment = segment(parameter);
        double t = segment.localParameter;
        double localDerivative = 0.5 * ((-segment.p0 + segment.p2)
                + 2.0 * (2.0 * segment.p0 - 5.0 * segment.p1
                + 4.0 * segment.p2 - segment.p3) * t
                + 3.0 * (-segment.p0 + 3.0 * segment.p1
                - 3.0 * segment.p2 + segment.p3) * t * t);
        return localDerivative * (values.size() - 1);
    }

    private Segment segment(double parameter) {
        Scalars.requireUnit(parameter, "parameter");
        int segmentCount = values.size() - 1;
        double scaled = parameter * segmentCount;
        int index = parameter == 1.0
                ? segmentCount - 1
                : (int) Math.floor(scaled);
        double local = parameter == 1.0 ? 1.0 : scaled - index;
        return new Segment(
                value(index - 1),
                value(index),
                value(index + 1),
                value(index + 2),
                local);
    }

    private double value(int index) {
        return values.get(Scalars.clamp(index, 0, values.size() - 1));
    }

    private record Segment(
            double p0,
            double p1,
            double p2,
            double p3,
            double localParameter) {
    }
}
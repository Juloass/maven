package io.github.juloass.audio.resource;

import io.github.juloass.audio.ChannelLayout;
import io.github.juloass.audio.PcmData;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;

/** Technical metadata attached to an encoded audio resource. */
public record AudioMetadata(
        OptionalLong loopStartFrame,
        OptionalLong loopEndFrame,
        Optional<ChannelLayout> channelLayout
) {
    public AudioMetadata {
        loopStartFrame = Objects.requireNonNull(loopStartFrame, "loopStartFrame");
        loopEndFrame = Objects.requireNonNull(loopEndFrame, "loopEndFrame");
        channelLayout = Objects.requireNonNull(channelLayout, "channelLayout");
        if (loopStartFrame.isPresent() != loopEndFrame.isPresent()) {
            throw new IllegalArgumentException("loopStartFrame and loopEndFrame must appear together");
        }
        if (loopStartFrame.isPresent()
                && (loopStartFrame.getAsLong() < 0 || loopEndFrame.getAsLong() <= loopStartFrame.getAsLong())) {
            throw new IllegalArgumentException("loop frame bounds are invalid");
        }
    }

    public static AudioMetadata empty() {
        return new AudioMetadata(OptionalLong.empty(), OptionalLong.empty(), Optional.empty());
    }

    public void validate(PcmData pcm) {
        Objects.requireNonNull(pcm, "pcm");
        if (loopEndFrame.isPresent() && loopEndFrame.getAsLong() > pcm.frameCount()) {
            throw new IllegalArgumentException("loop end exceeds the decoded frame count");
        }
        if (channelLayout.isPresent() && channelLayout.get() != pcm.format().channelLayout()) {
            throw new IllegalArgumentException("metadata channel layout does not match encoded audio");
        }
    }
}

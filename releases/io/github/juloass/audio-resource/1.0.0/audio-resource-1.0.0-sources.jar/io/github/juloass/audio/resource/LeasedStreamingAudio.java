package io.github.juloass.audio.resource;

import io.github.juloass.audio.StreamingAudio;
import io.github.juloass.resource.ResourceOrigin;
import io.github.juloass.resource.pack.ResourceSnapshot;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

/** A streaming audio value that owns one pinned Resource snapshot. */
public final class LeasedStreamingAudio implements AutoCloseable {
    private final StreamingAudio asset;
    private final long generation;
    private final ResourceOrigin origin;
    private final ResourceSnapshot snapshot;
    private final AtomicBoolean closed = new AtomicBoolean();

    LeasedStreamingAudio(StreamingAudio asset, long generation, ResourceOrigin origin, ResourceSnapshot snapshot) {
        this.asset = Objects.requireNonNull(asset, "asset");
        this.generation = generation;
        this.origin = Objects.requireNonNull(origin, "origin");
        this.snapshot = Objects.requireNonNull(snapshot, "snapshot");
    }

    public StreamingAudio asset() {
        if (closed.get()) throw new IllegalStateException("streaming audio lease is closed");
        return asset;
    }

    public long generation() { return generation; }
    public ResourceOrigin origin() { return origin; }

    @Override public void close() { if (closed.compareAndSet(false, true)) snapshot.close(); }
}

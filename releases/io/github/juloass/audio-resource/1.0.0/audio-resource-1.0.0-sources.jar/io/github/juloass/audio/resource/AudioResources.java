package io.github.juloass.audio.resource;

import io.github.juloass.audio.AudioDecodeLimits;
import io.github.juloass.audio.AudioStream;
import io.github.juloass.audio.ChannelLayout;
import io.github.juloass.audio.DecodedAudio;
import io.github.juloass.audio.StreamingAudio;
import io.github.juloass.audio.vorbis.VorbisDecoder;
import io.github.juloass.audio.wav.WavDecoder;
import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.MetadataSectionInput;
import io.github.juloass.resource.MetadataSectionType;
import io.github.juloass.resource.MetadataValue;
import io.github.juloass.resource.ResolvedMetadata;
import io.github.juloass.resource.Resource;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourceType;
import io.github.juloass.resource.pack.ResourceManager;
import io.github.juloass.resource.pack.ResourceSnapshot;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;

/** Standard typed resource definitions for WAV and Ogg Vorbis audio. */
public final class AudioResources {
    public static final MetadataSectionType<AudioMetadata> METADATA = MetadataSectionType
            .builder(Identifier.parse("foundation:audio"), AudioMetadata.class)
            .decoder(AudioResources::decodeMetadata)
            .build();

    private static final AudioDecodeLimits DEFAULT_LIMITS = AudioDecodeLimits.defaults();

    public static final ResourceType<DecodedAudio> WAV = ResourceType
            .builder(Identifier.parse("foundation:audio/wav"), DecodedAudio.class)
            .domain(ResourceDomain.ASSETS)
            .path("sounds", ".wav")
            .optionalMetadata(METADATA)
            .replaceWith((context, resource) -> decode(resource, new WavDecoder(), DEFAULT_LIMITS))
            .build();

    public static final ResourceType<DecodedAudio> VORBIS = ResourceType
            .builder(Identifier.parse("foundation:audio/vorbis"), DecodedAudio.class)
            .domain(ResourceDomain.ASSETS)
            .path("sounds", ".ogg")
            .optionalMetadata(METADATA)
            .replaceWith((context, resource) -> decode(resource, new VorbisDecoder(), DEFAULT_LIMITS))
            .build();

    private AudioResources() { }

    /** Opens a repeatable Vorbis stream and pins its resource generation until closure. */
    public static LeasedStreamingAudio openVorbisStream(
            ResourceManager manager,
            Identifier id,
            AudioDecodeLimits limits
    ) throws IOException {
        Objects.requireNonNull(manager, "manager");
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(limits, "limits");
        ResourceSnapshot snapshot = manager.acquireSnapshot();
        try {
            Resource resource = snapshot.requireResource(VORBIS.pathPattern().map(VORBIS.domain(), id));
            VorbisDecoder decoder = new VorbisDecoder();
            AudioStream probe = decoder.stream(resource::openStream, limits);
            var format = probe.format();
            probe.close();
            StreamingAudio asset = new StreamingAudio(format, () -> decoder.stream(resource::openStream, limits));
            return new LeasedStreamingAudio(asset, snapshot.generation(), resource.origin(), snapshot);
        } catch (IOException | RuntimeException exception) {
            snapshot.close();
            throw exception;
        }
    }

    private static DecodedAudio decode(Resource resource, io.github.juloass.audio.AudioDecoder decoder,
                                       AudioDecodeLimits limits) throws IOException {
        try (InputStream input = resource.openStream()) {
            DecodedAudio audio = new DecodedAudio(decoder.decode(input, limits));
            Optional<ResolvedMetadata<AudioMetadata>> metadata = resource.metadata().find(METADATA);
            metadata.ifPresent(value -> value.value().validate(audio.pcm()));
            return audio;
        }
    }

    private static AudioMetadata decodeMetadata(MetadataSectionInput input) {
        Set<String> known = Set.of("loopStartFrame", "loopEndFrame", "channelLayout");
        HashSet<String> unknown = new HashSet<>(input.data().values().keySet());
        unknown.removeAll(known);
        if (!unknown.isEmpty()) throw new IllegalArgumentException("Unknown audio metadata fields: " + unknown);
        OptionalLong start = optionalLong(input.data(), "loopStartFrame");
        OptionalLong end = optionalLong(input.data(), "loopEndFrame");
        Optional<ChannelLayout> layout = Optional.ofNullable(input.data().values().get("channelLayout"))
                .map(value -> {
                    if (!(value instanceof MetadataValue.StringValue text)) {
                        throw new IllegalArgumentException("channelLayout must be a string");
                    }
                    try { return ChannelLayout.valueOf(text.value()); }
                    catch (IllegalArgumentException exception) {
                        throw new IllegalArgumentException("Unsupported channelLayout " + text.value(), exception);
                    }
                });
        return new AudioMetadata(start, end, layout);
    }

    private static OptionalLong optionalLong(MetadataValue.ObjectValue object, String name) {
        MetadataValue value = object.values().get(name);
        if (value == null) return OptionalLong.empty();
        if (!(value instanceof MetadataValue.NumberValue number)) throw new IllegalArgumentException(name + " must be an integer");
        BigDecimal decimal = number.value();
        try { return OptionalLong.of(decimal.longValueExact()); }
        catch (ArithmeticException exception) { throw new IllegalArgumentException(name + " must be an integer", exception); }
    }
}

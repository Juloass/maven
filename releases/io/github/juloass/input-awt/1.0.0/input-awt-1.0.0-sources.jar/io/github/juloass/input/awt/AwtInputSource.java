package io.github.juloass.input.awt;

import io.github.juloass.input.*;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.*;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Collects input from one caller-owned AWT component. */
public final class AwtInputSource implements KeyListener, MouseListener, MouseMotionListener,
        MouseWheelListener, FocusListener, AutoCloseable {
    public static final int DEFAULT_CAPACITY = 1_024;
    private static final AtomicLong NEXT_ID = new AtomicLong();
    private final Component component;
    private final BoundedInputCollector collector;
    private final InputDeviceId keyboardId;
    private final InputDeviceId pointerId;
    private final Map<Long, HeldKey> keys = new LinkedHashMap<>();
    private final Map<Integer, PointerButton> buttons = new LinkedHashMap<>();
    private boolean closed;
    private char highSurrogate;

    public AwtInputSource(Component component) { this(component, DEFAULT_CAPACITY); }

    public AwtInputSource(Component component, int capacity) {
        this.component = Objects.requireNonNull(component, "component");
        collector = new BoundedInputCollector(capacity);
        long id = NEXT_ID.incrementAndGet();
        keyboardId = InputDeviceId.of("awt:keyboard/" + id);
        pointerId = InputDeviceId.of("awt:pointer/" + id);
        collector.connect(new InputDevice(keyboardId, InputDeviceClass.KEYBOARD, "AWT keyboard"), OptionalLong.empty());
        collector.connect(new InputDevice(pointerId, InputDeviceClass.POINTER, "AWT pointer"), OptionalLong.empty());
        collector.pointer(pointerId, InputVector2.ZERO, OptionalLong.empty());
        onEdt(this::install);
    }

    public InputDeviceId keyboardId() { return keyboardId; }
    public InputDeviceId pointerId() { return pointerId; }
    public InputPollResult poll() { return collector.poll(); }
    public RawInputSnapshot snapshot() { return collector.snapshot(); }

    @Override public void keyPressed(KeyEvent event) {
        requireEdt();
        if (closed) return;
        long id = keyId(event);
        HeldKey key = keys.get(id);
        ButtonTransitionKind kind = ButtonTransitionKind.REPEAT;
        if (key == null) {
            key = new HeldKey(key(event), logical(event));
            if (key.physical() == KeyboardKey.UNKNOWN) return;
            keys.put(id, key);
            kind = ButtonTransitionKind.PRESS;
        }
        collector.button(keyboardId, key.physical(), kind, key.logical(), time());
    }

    @Override public void keyReleased(KeyEvent event) {
        requireEdt();
        if (closed) return;
        HeldKey key = keys.remove(keyId(event));
        if (key == null) key = new HeldKey(key(event), logical(event));
        if (key.physical() == KeyboardKey.UNKNOWN) return;
        collector.button(keyboardId, key.physical(), ButtonTransitionKind.RELEASE, key.logical(), time());
    }

    @Override public void keyTyped(KeyEvent event) {
        requireEdt();
        if (closed || event.getKeyChar() == KeyEvent.CHAR_UNDEFINED) return;
        char value = event.getKeyChar();
        if (highSurrogate != 0) {
            char high = highSurrogate;
            highSurrogate = 0;
            if (Character.isLowSurrogate(value)) {
                collector.text(keyboardId, Character.toCodePoint(high, value), time());
                return;
            }
        }
        if (Character.isHighSurrogate(value)) highSurrogate = value;
        else collector.text(keyboardId, value, time());
    }

    @Override public void mousePressed(MouseEvent event) {
        requireEdt();
        if (closed) return;
        PointerButton button = pointerButton(event.getButton());
        if (button == null) return;
        ButtonTransitionKind kind = buttons.put(event.getButton(), button) == null
                ? ButtonTransitionKind.PRESS : ButtonTransitionKind.REPEAT;
        collector.button(pointerId, button, kind, null, time());
    }

    @Override public void mouseReleased(MouseEvent event) {
        requireEdt();
        if (closed) return;
        PointerButton button = buttons.remove(event.getButton());
        if (button == null) button = pointerButton(event.getButton());
        if (button != null) collector.button(pointerId, button, ButtonTransitionKind.RELEASE, null, time());
    }

    @Override public void mouseMoved(MouseEvent event) { pointer(event); }
    @Override public void mouseDragged(MouseEvent event) { pointer(event); }
    @Override public void mouseWheelMoved(MouseWheelEvent event) {
        requireEdt();
        if (!closed) collector.scroll(pointerId,
                new InputVector2(0.0, event.getPreciseWheelRotation()), time());
    }

    @Override public void focusLost(FocusEvent event) {
        requireEdt();
        if (closed) return;
        OptionalLong time = time();
        keys.values().forEach(key -> collector.button(keyboardId, key.physical(),
                ButtonTransitionKind.RELEASE, key.logical(), time));
        buttons.values().forEach(button -> collector.button(pointerId, button,
                ButtonTransitionKind.RELEASE, null, time));
        keys.clear();
        buttons.clear();
        highSurrogate = 0;
    }

    @Override public void close() {
        onEdt(() -> {
            if (closed) return;
            closed = true;
            component.removeKeyListener(this);
            component.removeMouseListener(this);
            component.removeMouseMotionListener(this);
            component.removeMouseWheelListener(this);
            component.removeFocusListener(this);
            keys.clear();
            buttons.clear();
            collector.close();
        });
    }

    @Override public void mouseClicked(MouseEvent event) { }
    @Override public void mouseEntered(MouseEvent event) { }
    @Override public void mouseExited(MouseEvent event) { }
    @Override public void focusGained(FocusEvent event) { }

    private void install() {
        component.addKeyListener(this);
        component.addMouseListener(this);
        component.addMouseMotionListener(this);
        component.addMouseWheelListener(this);
        component.addFocusListener(this);
    }

    private void pointer(MouseEvent event) {
        requireEdt();
        if (!closed) collector.pointer(pointerId, new InputVector2(event.getX(), event.getY()), time());
    }

    private static OptionalLong time() { return OptionalLong.of(System.nanoTime()); }
    private static long keyId(KeyEvent event) {
        return ((long) event.getKeyCode() << 32) | (event.getKeyLocation() & 0xffff_ffffL);
    }
    private static LogicalKey logical(KeyEvent event) {
        char value = event.getKeyChar();
        return value == KeyEvent.CHAR_UNDEFINED || Character.isISOControl(value)
                ? null : new LogicalKey(String.valueOf(value));
    }

    private static KeyboardKey key(KeyEvent event) {
        int code = event.getKeyCode();
        int location = event.getKeyLocation();
        if (code == KeyEvent.VK_SHIFT) return location == KeyEvent.KEY_LOCATION_RIGHT ? KeyboardKey.RIGHT_SHIFT : KeyboardKey.LEFT_SHIFT;
        if (code == KeyEvent.VK_CONTROL) return location == KeyEvent.KEY_LOCATION_RIGHT ? KeyboardKey.RIGHT_CONTROL : KeyboardKey.LEFT_CONTROL;
        if (code == KeyEvent.VK_ALT || code == KeyEvent.VK_ALT_GRAPH) return location == KeyEvent.KEY_LOCATION_RIGHT ? KeyboardKey.RIGHT_ALT : KeyboardKey.LEFT_ALT;
        if (code == KeyEvent.VK_META || code == KeyEvent.VK_WINDOWS) return location == KeyEvent.KEY_LOCATION_RIGHT ? KeyboardKey.RIGHT_SUPER : KeyboardKey.LEFT_SUPER;
        if (code >= KeyEvent.VK_A && code <= KeyEvent.VK_Z) return KeyboardKey.valueOf(String.valueOf((char) code));
        if (code >= KeyEvent.VK_0 && code <= KeyEvent.VK_9) return KeyboardKey.valueOf("DIGIT_" + (char) code);
        if (code >= KeyEvent.VK_F1 && code <= KeyEvent.VK_F12) return KeyboardKey.valueOf("F" + (code - KeyEvent.VK_F1 + 1));
        return switch (code) {
            case KeyEvent.VK_SPACE -> KeyboardKey.SPACE;
            case KeyEvent.VK_QUOTE -> KeyboardKey.APOSTROPHE;
            case KeyEvent.VK_COMMA -> KeyboardKey.COMMA;
            case KeyEvent.VK_MINUS -> KeyboardKey.MINUS;
            case KeyEvent.VK_PERIOD -> KeyboardKey.PERIOD;
            case KeyEvent.VK_SLASH -> KeyboardKey.SLASH;
            case KeyEvent.VK_SEMICOLON -> KeyboardKey.SEMICOLON;
            case KeyEvent.VK_EQUALS -> KeyboardKey.EQUAL;
            case KeyEvent.VK_OPEN_BRACKET -> KeyboardKey.LEFT_BRACKET;
            case KeyEvent.VK_BACK_SLASH -> KeyboardKey.BACKSLASH;
            case KeyEvent.VK_CLOSE_BRACKET -> KeyboardKey.RIGHT_BRACKET;
            case KeyEvent.VK_BACK_QUOTE -> KeyboardKey.GRAVE_ACCENT;
            case KeyEvent.VK_ESCAPE -> KeyboardKey.ESCAPE;
            case KeyEvent.VK_ENTER -> location == KeyEvent.KEY_LOCATION_NUMPAD ? KeyboardKey.KP_ENTER : KeyboardKey.ENTER;
            case KeyEvent.VK_TAB -> KeyboardKey.TAB;
            case KeyEvent.VK_BACK_SPACE -> KeyboardKey.BACKSPACE;
            case KeyEvent.VK_INSERT -> KeyboardKey.INSERT;
            case KeyEvent.VK_DELETE -> KeyboardKey.DELETE;
            case KeyEvent.VK_RIGHT -> KeyboardKey.RIGHT;
            case KeyEvent.VK_LEFT -> KeyboardKey.LEFT;
            case KeyEvent.VK_DOWN -> KeyboardKey.DOWN;
            case KeyEvent.VK_UP -> KeyboardKey.UP;
            case KeyEvent.VK_PAGE_UP -> KeyboardKey.PAGE_UP;
            case KeyEvent.VK_PAGE_DOWN -> KeyboardKey.PAGE_DOWN;
            case KeyEvent.VK_HOME -> KeyboardKey.HOME;
            case KeyEvent.VK_END -> KeyboardKey.END;
            case KeyEvent.VK_CAPS_LOCK -> KeyboardKey.CAPS_LOCK;
            case KeyEvent.VK_SCROLL_LOCK -> KeyboardKey.SCROLL_LOCK;
            case KeyEvent.VK_NUM_LOCK -> KeyboardKey.NUM_LOCK;
            case KeyEvent.VK_PRINTSCREEN -> KeyboardKey.PRINT_SCREEN;
            case KeyEvent.VK_PAUSE -> KeyboardKey.PAUSE;
            case KeyEvent.VK_CONTEXT_MENU -> KeyboardKey.MENU;
            default -> KeyboardKey.UNKNOWN;
        };
    }

    private static PointerButton pointerButton(int button) {
        return switch (button) {
            case MouseEvent.BUTTON1 -> PointerButton.PRIMARY;
            case MouseEvent.BUTTON2 -> PointerButton.MIDDLE;
            case MouseEvent.BUTTON3 -> PointerButton.SECONDARY;
            case 4 -> PointerButton.BUTTON_4;
            case 5 -> PointerButton.BUTTON_5;
            case 6 -> PointerButton.BUTTON_6;
            case 7 -> PointerButton.BUTTON_7;
            case 8 -> PointerButton.BUTTON_8;
            default -> null;
        };
    }

    private static void requireEdt() {
        if (!EventQueue.isDispatchThread()) throw new IllegalStateException("AWT input callbacks require the AWT event thread");
    }

    private static void onEdt(Runnable action) {
        if (EventQueue.isDispatchThread()) { action.run(); return; }
        try {
            EventQueue.invokeAndWait(action);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("interrupted while waiting for the AWT event thread", exception);
        } catch (InvocationTargetException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            if (cause instanceof Error error) throw error;
            throw new IllegalStateException("AWT listener operation failed", cause);
        }
    }

    private record HeldKey(KeyboardKey physical, LogicalKey logical) { }
}

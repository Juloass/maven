/** AWT input collection for the shared input foundation. */
package io.github.juloass.input.awt;


package io.github.juloass.audio.openal;

import java.util.Objects;

/** One OpenAL output device reported by the local implementation. */
public record OpenAlDevice(String id, String displayName) {
    public OpenAlDevice {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(displayName, "displayName");
        if (id.isBlank() || displayName.isBlank()) throw new IllegalArgumentException("device text must not be blank");
    }
}

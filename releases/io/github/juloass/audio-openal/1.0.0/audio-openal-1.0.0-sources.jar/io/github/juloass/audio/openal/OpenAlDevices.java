package io.github.juloass.audio.openal;

import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALC11;
import org.lwjgl.openal.ALUtil;

import java.util.List;

/** Side-effect-free OpenAL output device enumeration. */
public final class OpenAlDevices {
    private OpenAlDevices() { }

    public static List<OpenAlDevice> enumerate() {
        try {
            List<String> names = ALUtil.getStringList(0L, ALC11.ALC_ALL_DEVICES_SPECIFIER);
            if (names == null) {
                String value = ALC10.alcGetString(0L, ALC10.ALC_DEFAULT_DEVICE_SPECIFIER);
                return value == null || value.isBlank() ? List.of() : List.of(new OpenAlDevice(value, value));
            }
            return names.stream().distinct().sorted().map(name -> new OpenAlDevice(name, name)).toList();
        } catch (LinkageError | RuntimeException exception) {
            return List.of();
        }
    }
}

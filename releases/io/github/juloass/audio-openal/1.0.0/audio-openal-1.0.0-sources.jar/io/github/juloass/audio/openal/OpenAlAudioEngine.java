package io.github.juloass.audio.openal;

import io.github.juloass.audio.AudioAsset;
import io.github.juloass.audio.AudioCloseResult;
import io.github.juloass.audio.AudioEmitter;
import io.github.juloass.audio.AudioEngine;
import io.github.juloass.audio.AudioEngineSnapshot;
import io.github.juloass.audio.AudioEvent;
import io.github.juloass.audio.AudioFormat;
import io.github.juloass.audio.AudioHandle;
import io.github.juloass.audio.AudioListener;
import io.github.juloass.audio.AudioProblem;
import io.github.juloass.audio.AudioProblemCode;
import io.github.juloass.audio.AudioState;
import io.github.juloass.audio.AudioStatus;
import io.github.juloass.audio.AudioStream;
import io.github.juloass.audio.AudioVector3;
import io.github.juloass.audio.DecodedAudio;
import io.github.juloass.audio.LoopMode;
import io.github.juloass.audio.LoopRegion;
import io.github.juloass.audio.MixerBus;
import io.github.juloass.audio.MusicHandle;
import io.github.juloass.audio.MusicRequest;
import io.github.juloass.audio.PlayResult;
import io.github.juloass.audio.SilentAudioEngine;
import io.github.juloass.audio.SoundRequest;
import io.github.juloass.audio.SpatialMode;
import io.github.juloass.audio.StreamingAudio;
import io.github.juloass.identifier.Identifier;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALC10;
import org.lwjgl.openal.ALCCapabilities;
import org.lwjgl.openal.EXTDisconnect;
import org.lwjgl.system.MemoryUtil;

import java.io.IOException;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** Factory for the dedicated-thread LWJGL OpenAL backend. */
public final class OpenAlAudioEngine {
    private OpenAlAudioEngine() { }

    public static OpenAlEngine open(OpenAlConfiguration configuration) {
        return new ManagedEngine(Objects.requireNonNull(configuration,
                "configuration"));
    }

    private static AudioEngine openBackend(OpenAlConfiguration configuration) {
        Objects.requireNonNull(configuration, "configuration");
        Engine engine = new Engine(configuration);
        try {
            AudioProblem failure = engine.initialization.get(configuration.shutdownTimeout().toMillis(), TimeUnit.MILLISECONDS);
            if (failure == null) return engine;
            engine.forceClose();
            return new SilentAudioEngine(failure);
        } catch (Exception exception) {
            engine.forceClose();
            return new SilentAudioEngine(new AudioProblem(AudioProblemCode.DEVICE_UNAVAILABLE,
                    "OpenAL initialization did not complete", Optional.of(exception)));
        }
    }

    private static final class ManagedEngine implements OpenAlEngine {
        private final AtomicReference<AudioEngine> delegate;
        private final AtomicReference<OpenAlConfiguration> configuration;
        private final AtomicBoolean closed = new AtomicBoolean();

        private ManagedEngine(OpenAlConfiguration configuration) {
            this.configuration = new AtomicReference<>(configuration);
            delegate = new AtomicReference<>(openBackend(configuration));
        }

        @Override public AudioStatus status() { return delegate.get().status(); }
        @Override public AudioHandle play(SoundRequest request) { return delegate.get().play(request); }
        @Override public MusicHandle playMusic(MusicRequest request) { return delegate.get().playMusic(request); }
        @Override public void setListener(AudioListener listener) { delegate.get().setListener(listener); }
        @Override public void setEmitter(AudioHandle handle, AudioEmitter emitter) { delegate.get().setEmitter(handle, emitter); }
        @Override public void setBusGain(Identifier bus, double gain) { delegate.get().setBusGain(bus, gain); }
        @Override public void setBusMuted(Identifier bus, boolean muted) { delegate.get().setBusMuted(bus, muted); }
        @Override public void setBusPaused(Identifier bus, boolean paused) { delegate.get().setBusPaused(bus, paused); }
        @Override public AudioEngineSnapshot snapshot() { return delegate.get().snapshot(); }
        @Override public List<AudioEvent> drainEvents() { return delegate.get().drainEvents(); }

        @Override
        public CompletionStage<DeviceReopenResult> reopen(Optional<String> deviceIdentifier) {
            Objects.requireNonNull(deviceIdentifier, "deviceIdentifier");
            if (closed.get()) {
                return CompletableFuture.completedFuture(new DeviceReopenResult(false,
                        Optional.of(AudioProblem.of(AudioProblemCode.CLOSED_ENGINE,
                                "Audio engine is closed"))));
            }
            OpenAlConfiguration prior = configuration.get();
            OpenAlConfiguration next = new OpenAlConfiguration(deviceIdentifier,
                    prior.globalVoiceLimit(), prior.bufferCacheLimit(),
                    prior.commandQueueLimit(), prior.streamBufferCount(),
                    prior.framesPerStreamBuffer(), prior.decoderWorkerCount(),
                    prior.mixerGraph(), prior.initialListener(),
                    prior.shutdownTimeout());
            AudioEngine candidate = openBackend(next);
            if (!candidate.status().available()) {
                AudioProblem problem = candidate.status().problem().orElseGet(() ->
                        AudioProblem.of(AudioProblemCode.REOPEN_FAILED,
                                "OpenAL device reopen failed"));
                candidate.close();
                return CompletableFuture.completedFuture(new DeviceReopenResult(
                        false, Optional.of(new AudioProblem(
                                AudioProblemCode.REOPEN_FAILED,
                                problem.message(), problem.cause()))));
            }
            AudioEngine previous = delegate.getAndSet(candidate);
            configuration.set(next);
            previous.close();
            return CompletableFuture.completedFuture(
                    new DeviceReopenResult(true, Optional.empty()));
        }

        @Override
        public CompletionStage<AudioCloseResult> closeAsync() {
            if (closed.compareAndSet(false, true)) return delegate.get().closeAsync();
            return CompletableFuture.completedFuture(
                    new AudioCloseResult(true, Optional.empty()));
        }
    }

    private static final class Engine implements AudioEngine {
        private final OpenAlConfiguration configuration;
        private final ArrayBlockingQueue<Runnable> commands;
        private final ConcurrentLinkedQueue<AudioEvent> events = new ConcurrentLinkedQueue<>();
        private final AtomicReference<AudioEngineSnapshot> snapshot = new AtomicReference<>(
                new AudioEngineSnapshot(0, Map.of(), 0));
        private final AtomicReference<AudioStatus> status = new AtomicReference<>(
                new AudioStatus(false, "OpenAL", Optional.empty(), Optional.empty()));
        private final AtomicLong ids = new AtomicLong();
        private final AtomicBoolean closing = new AtomicBoolean();
        private final CompletableFuture<AudioCloseResult> closeResult = new CompletableFuture<>();
        private final CompletableFuture<AudioProblem> initialization = new CompletableFuture<>();
        private final ExecutorService decoders;
        private final Thread audioThread;
        private final Map<Identifier, Playback> playbacks = new LinkedHashMap<>();
        private final Map<Identifier, BusState> buses = new HashMap<>();
        private AudioListener listener;
        private long device;
        private long context;
        private boolean disconnectMonitoring;
        private long snapshotSequence;

        private Engine(OpenAlConfiguration configuration) {
            this.configuration = configuration;
            commands = new ArrayBlockingQueue<>(configuration.commandQueueLimit());
            decoders = Executors.newFixedThreadPool(configuration.decoderWorkerCount(), runnable -> {
                Thread thread = new Thread(runnable, "audio-decoder");
                thread.setDaemon(true);
                return thread;
            });
            listener = configuration.initialListener();
            for (Identifier id : configuration.mixerGraph().ids()) {
                MixerBus bus = configuration.mixerGraph().require(id);
                buses.put(id, new BusState(bus.gain(), bus.muted(), bus.paused()));
            }
            audioThread = new Thread(this::run, "openal-audio");
            audioThread.setDaemon(true);
            audioThread.start();
        }

        @Override public AudioStatus status() { return status.get(); }

        @Override
        public AudioHandle play(SoundRequest request) {
            Objects.requireNonNull(request, "request");
            configuration.mixerGraph().require(request.bus());
            Handle handle = new Handle(nextId(), request.asset().format(), false);
            PlaybackSpec spec = PlaybackSpec.sound(handle, request);
            if (!offer(() -> start(spec))) reject(handle, queueFull());
            return handle;
        }

        @Override
        public MusicHandle playMusic(MusicRequest request) {
            Objects.requireNonNull(request, "request");
            configuration.mixerGraph().require(request.bus());
            MusicHandleImpl handle = new MusicHandleImpl(nextId(), request.audio().format());
            PlaybackSpec spec = PlaybackSpec.music(handle, request);
            if (!offer(() -> start(spec))) reject(handle, queueFull());
            return handle;
        }

        @Override public void setListener(AudioListener value) {
            Objects.requireNonNull(value, "value");
            submitMutation(() -> { listener = value; applyListener(value); });
        }

        @Override public void setEmitter(AudioHandle handle, AudioEmitter emitter) {
            Objects.requireNonNull(handle, "handle");
            Objects.requireNonNull(emitter, "emitter");
            submitMutation(() -> {
                Playback playback = playbacks.get(handle.id());
                if (playback != null) { playback.emitter = emitter; applySpatial(playback); }
            });
        }

        @Override public void setBusGain(Identifier bus, double gain) {
            Objects.requireNonNull(bus, "bus");
            if (!Double.isFinite(gain) || gain < 0) throw new IllegalArgumentException("gain must be finite and non-negative");
            configuration.mixerGraph().require(bus);
            submitMutation(() -> buses.get(bus).gain = gain);
        }

        @Override public void setBusMuted(Identifier bus, boolean muted) {
            Objects.requireNonNull(bus, "bus"); configuration.mixerGraph().require(bus);
            submitMutation(() -> buses.get(bus).muted = muted);
        }

        @Override public void setBusPaused(Identifier bus, boolean paused) {
            Objects.requireNonNull(bus, "bus"); configuration.mixerGraph().require(bus);
            submitMutation(() -> buses.get(bus).paused = paused);
        }

        @Override public AudioEngineSnapshot snapshot() { return snapshot.get(); }

        @Override public List<AudioEvent> drainEvents() {
            ArrayList<AudioEvent> drained = new ArrayList<>();
            for (AudioEvent event; (event = events.poll()) != null;) drained.add(event);
            return List.copyOf(drained);
        }

        @Override
        public CompletionStage<AudioCloseResult> closeAsync() {
            if (closing.compareAndSet(false, true)) {
                if (!commands.offer(() -> { })) audioThread.interrupt();
                CompletableFuture.delayedExecutor(
                        configuration.shutdownTimeout().toMillis(),
                        TimeUnit.MILLISECONDS).execute(() -> {
                    if (!closeResult.isDone()) {
                        audioThread.interrupt();
                        closeResult.complete(new AudioCloseResult(false,
                                Optional.of(AudioProblem.of(
                                        AudioProblemCode.BACKEND_FAILURE,
                                        "OpenAL shutdown exceeded its timeout"))));
                    }
                });
            }
            return closeResult;
        }

        private Identifier nextId() { return Identifier.of("foundation", "audio_playback/" + ids.incrementAndGet()); }

        private void run() {
            try {
                initialize();
                initialization.complete(null);
                while (!closing.get()) {
                    drainCommands();
                    service();
                    Thread.sleep(5);
                }
                drainCommands();
            } catch (Throwable failure) {
                if (closing.get() && failure instanceof InterruptedException) {
                    Thread.currentThread().interrupt();
                    return;
                }
                AudioProblemCode code = device == 0 ? AudioProblemCode.DEVICE_UNAVAILABLE
                        : failure instanceof DeviceLostException ? AudioProblemCode.DEVICE_LOST
                        : AudioProblemCode.BACKEND_FAILURE;
                AudioProblem problem = new AudioProblem(code,
                        code == AudioProblemCode.DEVICE_LOST
                                ? "OpenAL device was disconnected"
                                : "OpenAL backend failed",
                        Optional.of(failure));
                initialization.complete(problem);
                status.set(new AudioStatus(false, "OpenAL", Optional.empty(), Optional.of(problem)));
                events.add(new AudioEvent(AudioEvent.Type.DEVICE_LOST, Optional.empty(), Optional.of(problem)));
            } finally {
                shutdownNative();
                closeResult.complete(new AudioCloseResult(true, Optional.empty()));
            }
        }

        private void initialize() {
            device = ALC10.alcOpenDevice(configuration.deviceIdentifier().orElse(null));
            if (device == 0) throw new IllegalStateException("OpenAL did not open the requested device");
            ALCCapabilities deviceCapabilities = ALC.createCapabilities(device);
            disconnectMonitoring = deviceCapabilities.ALC_EXT_disconnect;
            context = ALC10.alcCreateContext(device, (IntBuffer) null);
            if (context == 0 || !ALC10.alcMakeContextCurrent(context)) {
                throw new IllegalStateException("OpenAL did not create a current context");
            }
            AL.createCapabilities(deviceCapabilities);
            AL10.alDistanceModel(AL10.AL_NONE);
            applyListener(listener);
            String deviceName = ALC10.alcGetString(device, ALC10.ALC_DEVICE_SPECIFIER);
            status.set(new AudioStatus(true, "OpenAL", Optional.ofNullable(deviceName), Optional.empty()));
        }

        private void drainCommands() {
            for (Runnable command; (command = commands.poll()) != null;) command.run();
        }

        private void start(PlaybackSpec spec) {
            if (closing.get()) { reject(spec.handle, AudioProblem.of(AudioProblemCode.CLOSED_ENGINE, "Audio engine is closed")); return; }
            List<Playback> priorMusic = spec.music
                    ? playbacks.values().stream()
                            .filter(value -> value.active() && value.music
                                    && value.bus.equals(spec.bus)).toList()
                    : List.of();
            if (spec.music && spec.crossfade.isZero() && !spec.gapless) {
                for (Playback prior : priorMusic) {
                    stop(prior, AudioState.STOPPED,
                            AudioEvent.Type.STOPPED, Optional.empty());
                }
                priorMusic = List.of();
            }
            Playback victim = selectVictim(spec);
            if (victim == Playback.REJECTED) {
                reject(spec.handle, AudioProblem.of(AudioProblemCode.VOICE_REJECTED, "No eligible audio voice is available"));
                return;
            }
            if (victim != null) stop(victim, AudioState.STOPPED, AudioEvent.Type.STOPPED, Optional.empty());
            Playback playback = new Playback(spec);
            if (spec.music && !priorMusic.isEmpty()) {
                if (!spec.crossfade.isZero()) {
                    long now = System.nanoTime();
                    for (Playback prior : priorMusic) {
                        prior.fade = new Fade(prior.gain, 0, now,
                                spec.crossfade.toNanos(), true);
                    }
                } else if (spec.gapless) {
                    playback.replaceOnBegin.addAll(priorMusic.stream()
                            .map(value -> value.handle.id()).toList());
                }
            }
            try {
                playback.source = AL10.alGenSources();
                applySource(playback);
                playbacks.put(playback.handle.id(), playback);
                playback.handle.state.set(AudioState.STARTING);
                if (spec.asset instanceof DecodedAudio decoded) startDecoded(playback, decoded);
                else startStreaming(playback, (StreamingAudio) spec.asset, 0);
            } catch (RuntimeException exception) {
                fail(playback, new AudioProblem(AudioProblemCode.BACKEND_FAILURE,
                        "OpenAL could not start playback", Optional.of(exception)));
            }
        }

        private Playback selectVictim(PlaybackSpec spec) {
            List<Playback> active = playbacks.values().stream().filter(Playback::active).toList();
            MixerBus bus = configuration.mixerGraph().require(spec.bus);
            List<Playback> inBus = active.stream().filter(value -> value.bus.equals(spec.bus)).toList();
            Playback busVictim = inBus.size() >= bus.voiceLimit() ? eligibleVictim(inBus, spec.priority) : null;
            if (inBus.size() >= bus.voiceLimit() && busVictim == null) return Playback.REJECTED;
            Playback globalVictim = active.size() >= configuration.globalVoiceLimit()
                    ? eligibleVictim(active, spec.priority) : null;
            if (active.size() >= configuration.globalVoiceLimit() && globalVictim == null) return Playback.REJECTED;
            if (busVictim == null) return globalVictim;
            if (globalVictim == null) return busVictim;
            return Comparator.comparingInt((Playback value) -> value.priority)
                    .thenComparingLong(value -> value.sequence).compare(busVictim, globalVictim) <= 0
                    ? busVictim : globalVictim;
        }

        private static Playback eligibleVictim(List<Playback> values, int newPriority) {
            return values.stream().filter(value -> value.stealable && value.priority <= newPriority)
                    .min(Comparator.comparingInt((Playback value) -> value.priority)
                            .thenComparingLong(value -> value.sequence)).orElse(null);
        }

        private void startDecoded(Playback playback, DecodedAudio audio) {
            playback.buffer = AL10.alGenBuffers();
            upload(playback.buffer, audio.pcm().samples(), audio.format());
            AL10.alSourcei(playback.source, AL10.AL_BUFFER, playback.buffer);
            AL10.alSourcei(playback.source, AL10.AL_LOOPING,
                    playback.loopMode == LoopMode.LOOP && playback.loopRegion.isEmpty() ? AL10.AL_TRUE : AL10.AL_FALSE);
            begin(playback);
        }

        private void startStreaming(Playback playback, StreamingAudio audio, long startFrame) {
            playback.stream = new StreamState(configuration.streamBufferCount());
            for (int index = 0; index < configuration.streamBufferCount(); index++) {
                playback.stream.freeBuffers.add(AL10.alGenBuffers());
            }
            StreamState state = playback.stream;
            decoders.execute(() -> feed(playback, audio, state, startFrame));
        }

        private void feed(Playback playback, StreamingAudio audio, StreamState state, long startFrame) {
            try (AudioStream stream = audio.source().open()) {
                state.openStream.set(stream);
                if (startFrame > 0) stream.seekFrame(startFrame);
                int channels = audio.format().channelLayout().channels();
                long cursor = startFrame;
                while (!state.cancelled.get()) {
                    long boundary = playback.loopRegion.map(LoopRegion::endFrame).orElse(Long.MAX_VALUE);
                    int requested = (int) Math.min(configuration.framesPerStreamBuffer(), boundary - cursor);
                    if (requested == 0) {
                        if (shouldLoop(playback)) { cursor = playback.loopRegion.map(LoopRegion::startFrame).orElse(0L); stream.seekFrame(cursor); continue; }
                        state.queue.put(StreamChunk.endMarker()); return;
                    }
                    float[] samples = new float[requested * channels];
                    int frames = stream.readFrames(samples, 0, requested);
                    if (frames == 0) {
                        if (shouldLoop(playback)) { cursor = playback.loopRegion.map(LoopRegion::startFrame).orElse(0L); stream.seekFrame(cursor); continue; }
                        state.queue.put(StreamChunk.endMarker()); return;
                    }
                    state.queue.put(new StreamChunk(cursor, frames,
                            frames == requested ? samples : java.util.Arrays.copyOf(samples, frames * channels), false, null));
                    cursor += frames;
                }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            } catch (Exception exception) {
                try { state.queue.put(StreamChunk.failure(exception)); }
                catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            } finally {
                state.openStream.set(null);
            }
        }

        private static boolean shouldLoop(Playback playback) {
            return playback.loopMode == LoopMode.LOOP || playback.music && playback.loopRegion.isPresent();
        }

        private void begin(Playback playback) {
            for (Identifier priorId : playback.replaceOnBegin) {
                Playback prior = playbacks.get(priorId);
                if (prior != null) {
                    stop(prior, AudioState.STOPPED,
                            AudioEvent.Type.STOPPED, Optional.empty());
                }
            }
            playback.replaceOnBegin.clear();
            AL10.alSourcePlay(playback.source);
            playback.handle.state.set(AudioState.PLAYING);
            playback.handle.start.complete(PlayResult.success());
            events.add(new AudioEvent(AudioEvent.Type.STARTED, Optional.of(playback.handle.id()), Optional.empty()));
        }

        private void service() {
            if (disconnectMonitoring
                    && ALC10.alcGetInteger(device, EXTDisconnect.ALC_CONNECTED)
                    == ALC10.ALC_FALSE) {
                throw new DeviceLostException();
            }
            long now = System.nanoTime();
            ArrayList<Playback> copy = new ArrayList<>(playbacks.values());
            for (Playback playback : copy) {
                if (!playback.active()) continue;
                if (playback.stream != null) serviceStream(playback);
                serviceFade(playback, now);
                applyEffectiveState(playback);
                if (playback.stream == null) serviceStaticLifecycle(playback);
            }
            publishSnapshot();
        }

        private void serviceStream(Playback playback) {
            StreamState stream = playback.stream;
            int processed = AL10.alGetSourcei(playback.source, AL10.AL_BUFFERS_PROCESSED);
            while (processed-- > 0) {
                int buffer = AL10.alSourceUnqueueBuffers(playback.source);
                stream.freeBuffers.add(buffer);
                if (!stream.queued.isEmpty()) stream.queued.removeFirst();
            }
            while (!stream.freeBuffers.isEmpty()) {
                StreamChunk chunk = stream.queue.poll();
                if (chunk == null) break;
                if (chunk.failure != null) { fail(playback, new AudioProblem(AudioProblemCode.DECODER_FAILURE,
                        "Streaming decoder failed", Optional.of(chunk.failure))); return; }
                if (chunk.end) { stream.ended = true; break; }
                int buffer = stream.freeBuffers.removeFirst();
                upload(buffer, chunk.samples, playback.format);
                AL10.alSourceQueueBuffers(playback.source, buffer);
                stream.queued.addLast(new QueuedChunk(buffer, chunk.startFrame, chunk.frames));
            }
            int sourceState = AL10.alGetSourcei(playback.source, AL10.AL_SOURCE_STATE);
            if (!stream.queued.isEmpty() && sourceState != AL10.AL_PLAYING && !effectivePaused(playback)) {
                if (playback.handle.state.get() == AudioState.STARTING) begin(playback);
                else {
                    AL10.alSourcePlay(playback.source);
                    events.add(new AudioEvent(AudioEvent.Type.STREAM_UNDERRUN, Optional.of(playback.handle.id()),
                            Optional.of(AudioProblem.of(AudioProblemCode.STREAM_UNDERRUN, "Streaming playback resumed after an underrun"))));
                }
            }
            if (stream.ended && stream.queued.isEmpty()) {
                stop(playback, AudioState.COMPLETE, AudioEvent.Type.COMPLETED, Optional.empty());
            }
        }

        private void serviceStaticLifecycle(Playback playback) {
            if (playback.loopRegion.isPresent() && playback.handle.state.get() == AudioState.PLAYING) {
                int position = AL10.alGetSourcei(playback.source, AL11.AL_SAMPLE_OFFSET);
                LoopRegion region = playback.loopRegion.get();
                if (position >= region.endFrame()) {
                    if (playback.loopMode == LoopMode.LOOP) AL10.alSourcei(playback.source, AL11.AL_SAMPLE_OFFSET, Math.toIntExact(region.startFrame()));
                    else stop(playback, AudioState.COMPLETE, AudioEvent.Type.COMPLETED, Optional.empty());
                    return;
                }
            }
            if (playback.handle.state.get() == AudioState.PLAYING
                    && AL10.alGetSourcei(playback.source, AL10.AL_SOURCE_STATE) == AL10.AL_STOPPED) {
                stop(playback, AudioState.COMPLETE, AudioEvent.Type.COMPLETED, Optional.empty());
            }
        }

        private void serviceFade(Playback playback, long now) {
            Fade fade = playback.fade;
            if (fade == null) return;
            double progress = fade.durationNanos == 0 ? 1 : Math.min(1, (now - fade.startNanos) / (double) fade.durationNanos);
            playback.gain = fade.from + (fade.to - fade.from) * progress;
            if (progress >= 1) {
                playback.fade = null;
                if (fade.stopAfter) stop(playback, AudioState.STOPPED, AudioEvent.Type.STOPPED, Optional.empty());
            }
        }

        private void applyEffectiveState(Playback playback) {
            boolean paused = effectivePaused(playback);
            AudioState state = playback.handle.state.get();
            if (paused && state == AudioState.PLAYING) {
                AL10.alSourcePause(playback.source); playback.handle.state.set(AudioState.PAUSED);
            } else if (!paused && state == AudioState.PAUSED) {
                AL10.alSourcePlay(playback.source); playback.handle.state.set(AudioState.PLAYING);
            }
            AL10.alSourcef(playback.source, AL10.AL_GAIN, (float) effectiveGain(playback));
            applySpatial(playback);
        }

        private boolean effectivePaused(Playback playback) {
            if (playback.manualPaused) return true;
            return configuration.mixerGraph().ancestry(playback.bus).stream().anyMatch(bus -> buses.get(bus.id()).paused);
        }

        private double effectiveGain(Playback playback) {
            double gain = playback.gain;
            for (MixerBus bus : configuration.mixerGraph().ancestry(playback.bus)) {
                BusState state = buses.get(bus.id());
                if (state.muted) return 0;
                gain *= state.gain;
            }
            if (playback.spatialMode == SpatialMode.POSITIONAL && playback.emitter != null) {
                gain *= playback.emitter.distance().gain(playback.emitter.position().distanceTo(listener.position()));
            }
            return gain;
        }

        private void applySource(Playback playback) {
            AL10.alSourcef(playback.source, AL10.AL_GAIN, (float) playback.gain);
            AL10.alSourcef(playback.source, AL10.AL_PITCH, (float) playback.pitch);
            applySpatial(playback);
        }

        private static void applySpatial(Playback playback) {
            if (playback.spatialMode == SpatialMode.NON_SPATIAL || playback.emitter == null) {
                AL10.alSourcei(playback.source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                AL10.alSource3f(playback.source, AL10.AL_POSITION, 0, 0, 0);
                return;
            }
            AudioEmitter emitter = playback.emitter;
            AL10.alSourcei(playback.source, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
            vectorSource(playback.source, AL10.AL_POSITION, emitter.position());
            vectorSource(playback.source, AL10.AL_VELOCITY, emitter.velocity());
            vectorSource(playback.source, AL10.AL_DIRECTION, emitter.direction());
            AL10.alSourcef(playback.source, AL10.AL_CONE_INNER_ANGLE, (float) emitter.innerConeDegrees());
            AL10.alSourcef(playback.source, AL10.AL_CONE_OUTER_ANGLE, (float) emitter.outerConeDegrees());
            AL10.alSourcef(playback.source, AL10.AL_CONE_OUTER_GAIN, (float) emitter.outerConeGain());
        }

        private static void vectorSource(int source, int property, AudioVector3 vector) {
            AL10.alSource3f(source, property, (float) vector.x(), (float) vector.y(), (float) vector.z());
        }

        private static void applyListener(AudioListener listener) {
            AudioVector3 position = listener.position();
            AudioVector3 velocity = listener.velocity();
            AL10.alListener3f(AL10.AL_POSITION, (float) position.x(), (float) position.y(), (float) position.z());
            AL10.alListener3f(AL10.AL_VELOCITY, (float) velocity.x(), (float) velocity.y(), (float) velocity.z());
            AL10.alListenerfv(AL10.AL_ORIENTATION, new float[]{
                    (float) listener.forward().x(), (float) listener.forward().y(), (float) listener.forward().z(),
                    (float) listener.up().x(), (float) listener.up().y(), (float) listener.up().z()});
            AL10.alDopplerFactor((float) listener.dopplerFactor());
            AL11.alSpeedOfSound((float) listener.speedOfSound());
        }

        private static void upload(int buffer, float[] samples, AudioFormat format) {
            ShortBuffer pcm16 = MemoryUtil.memAllocShort(samples.length);
            try {
                for (float sample : samples) {
                    int value = Math.round(sample * 32767.0f);
                    pcm16.put((short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, value)));
                }
                pcm16.flip();
                int openAlFormat = format.channelLayout().channels() == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
                AL10.alBufferData(buffer, openAlFormat, pcm16, format.sampleRate());
            } finally {
                MemoryUtil.memFree(pcm16);
            }
        }

        private void pause(Handle handle, boolean paused) {
            submitHandle(handle, playback -> playback.manualPaused = paused);
        }

        private void seek(Handle handle, long frame) {
            if (frame < 0) throw new IllegalArgumentException("frame must not be negative");
            submitHandle(handle, playback -> {
                if (playback.stream == null) {
                    AL10.alSourcei(playback.source, AL11.AL_SAMPLE_OFFSET, Math.toIntExact(frame));
                } else {
                    restartStream(playback, frame);
                }
            });
        }

        private void restartStream(Playback playback, long frame) {
            StreamingAudio audio = (StreamingAudio) playback.asset;
            cancelStream(playback.stream);
            AL10.alSourceStop(playback.source);
            int queued = AL10.alGetSourcei(playback.source, AL10.AL_BUFFERS_QUEUED);
            while (queued-- > 0) AL10.alSourceUnqueueBuffers(playback.source);
            for (QueuedChunk chunk : playback.stream.queued) AL10.alDeleteBuffers(chunk.buffer);
            for (int buffer : playback.stream.freeBuffers) AL10.alDeleteBuffers(buffer);
            playback.handle.state.set(AudioState.STARTING);
            startStreaming(playback, audio, frame);
        }

        private void submitHandle(Handle handle, java.util.function.Consumer<Playback> action) {
            if (!offer(() -> { Playback playback = playbacks.get(handle.id()); if (playback != null && playback.active()) action.accept(playback); })) {
                events.add(new AudioEvent(AudioEvent.Type.REJECTED, Optional.of(handle.id()), Optional.of(queueFull())));
            }
        }

        private void stop(Playback playback, AudioState state, AudioEvent.Type type, Optional<AudioProblem> problem) {
            if (!playback.active()) return;
            if (playback.stream != null) cancelStream(playback.stream);
            AL10.alSourceStop(playback.source);
            if (playback.stream != null) {
                int queued = AL10.alGetSourcei(playback.source, AL10.AL_BUFFERS_QUEUED);
                while (queued-- > 0) AL10.alSourceUnqueueBuffers(playback.source);
                for (QueuedChunk chunk : playback.stream.queued) AL10.alDeleteBuffers(chunk.buffer);
                for (int buffer : playback.stream.freeBuffers) AL10.alDeleteBuffers(buffer);
            }
            if (playback.buffer != 0) AL10.alDeleteBuffers(playback.buffer);
            AL10.alDeleteSources(playback.source);
            playback.handle.state.set(state);
            playbacks.remove(playback.handle.id());
            events.add(new AudioEvent(type, Optional.of(playback.handle.id()), problem));
        }

        private static void cancelStream(StreamState stream) {
            stream.cancelled.set(true);
            AudioStream open = stream.openStream.get();
            if (open != null) try { open.close(); } catch (IOException ignored) { }
        }

        private void fail(Playback playback, AudioProblem problem) {
            if (!playback.handle.start.isDone()) playback.handle.start.complete(PlayResult.rejected(problem));
            stop(playback, AudioState.FAILED, AudioEvent.Type.FAILED, Optional.of(problem));
        }

        private void reject(Handle handle, AudioProblem problem) {
            handle.state.set(AudioState.REJECTED);
            handle.start.complete(PlayResult.rejected(problem));
            events.add(new AudioEvent(AudioEvent.Type.REJECTED, Optional.of(handle.id()), Optional.of(problem)));
        }

        private void publishSnapshot() {
            HashMap<Identifier, AudioEngineSnapshot.PlaybackSnapshot> values = new HashMap<>();
            for (Playback playback : playbacks.values()) {
                long position;
                if (playback.stream != null && !playback.stream.queued.isEmpty()) {
                    position = playback.stream.queued.getFirst().startFrame
                            + AL10.alGetSourcei(playback.source, AL11.AL_SAMPLE_OFFSET);
                } else {
                    position = AL10.alGetSourcei(playback.source, AL11.AL_SAMPLE_OFFSET);
                }
                values.put(playback.handle.id(), new AudioEngineSnapshot.PlaybackSnapshot(
                        playback.handle.state.get(), position, playback.gain, playback.pitch));
            }
            snapshot.set(new AudioEngineSnapshot(++snapshotSequence, values, values.size()));
        }

        private boolean offer(Runnable command) { return !closing.get() && commands.offer(command); }
        private void submitMutation(Runnable command) {
            if (!offer(command)) events.add(new AudioEvent(AudioEvent.Type.REJECTED, Optional.empty(), Optional.of(queueFull())));
        }
        private static AudioProblem queueFull() { return AudioProblem.of(AudioProblemCode.COMMAND_QUEUE_FULL, "Audio command queue is full"); }

        private void shutdownNative() {
            decoders.shutdownNow();
            for (Playback playback : new ArrayList<>(playbacks.values())) {
                try { stop(playback, AudioState.STOPPED, AudioEvent.Type.STOPPED, Optional.empty()); }
                catch (RuntimeException ignored) { }
            }
            if (context != 0) {
                ALC10.alcMakeContextCurrent(0);
                ALC10.alcDestroyContext(context);
                context = 0;
            }
            if (device != 0) {
                ALC10.alcCloseDevice(device);
                device = 0;
            }
        }

        private void forceClose() { closing.set(true); audioThread.interrupt(); }

        private class Handle implements AudioHandle {
            private final Identifier id;
            private final AudioFormat format;
            private final boolean music;
            private final AtomicReference<AudioState> state = new AtomicReference<>(AudioState.QUEUED);
            private final CompletableFuture<PlayResult> start = new CompletableFuture<>();

            private Handle(Identifier id, AudioFormat format, boolean music) {
                this.id = id; this.format = format; this.music = music;
            }

            @Override public Identifier id() { return id; }
            @Override public AudioState state() { return state.get(); }
            @Override public CompletionStage<PlayResult> startResult() { return start; }
            @Override public void pause() { Engine.this.pause(this, true); }
            @Override public void resume() { Engine.this.pause(this, false); }
            @Override public void stop() { submitHandle(this, value -> Engine.this.stop(value, AudioState.STOPPED, AudioEvent.Type.STOPPED, Optional.empty())); }
            @Override public void seekFrame(long frame) { Engine.this.seek(this, frame); }
            @Override public void gain(double gain) {
                if (!Double.isFinite(gain) || gain < 0) throw new IllegalArgumentException("gain must be finite and non-negative");
                submitHandle(this, value -> value.gain = gain);
            }
            @Override public void pitch(double pitch) {
                if (!Double.isFinite(pitch) || pitch <= 0) throw new IllegalArgumentException("pitch must be finite and positive");
                submitHandle(this, value -> { value.pitch = pitch; AL10.alSourcef(value.source, AL10.AL_PITCH, (float) pitch); });
            }
            @Override public void fadeTo(double gain, Duration duration) {
                if (!Double.isFinite(gain) || gain < 0 || duration.isNegative()) throw new IllegalArgumentException("fade is invalid");
                submitHandle(this, value -> value.fade = new Fade(value.gain, gain, System.nanoTime(), duration.toNanos(), false));
            }
            @Override public AudioFormat format() { return format; }
        }

        private final class MusicHandleImpl extends Handle implements MusicHandle {
            private MusicHandleImpl(Identifier id, AudioFormat format) { super(id, format, true); }
            @Override public void bus(Identifier bus) {
                Objects.requireNonNull(bus, "bus");
                configuration.mixerGraph().require(bus);
                submitHandle(this, value -> value.bus = bus);
            }
        }

        private record PlaybackSpec(Handle handle, AudioAsset asset, Identifier bus, int priority,
                                    double gain, double pitch, LoopMode loopMode, Optional<LoopRegion> loopRegion,
                                    SpatialMode spatialMode, AudioEmitter emitter, boolean stealable, boolean music,
                                    Duration fadeIn, Duration crossfade, boolean gapless) {
            static PlaybackSpec sound(Handle handle, SoundRequest value) {
                return new PlaybackSpec(handle, value.asset(), value.bus(), value.priority(), value.gain(), value.pitch(),
                        value.loopMode(), value.loopRegion(), value.spatialMode(), value.emitter().orElse(null),
                        value.stealable(), false, Duration.ZERO,
                        Duration.ZERO, false);
            }
            static PlaybackSpec music(Handle handle, MusicRequest value) {
                return new PlaybackSpec(handle, value.audio(), value.bus(), value.priority(), value.gain(), 1,
                        LoopMode.ONCE, value.loopRegion(), SpatialMode.NON_SPATIAL, null,
                        false, true, value.fadeIn(), value.crossfade(),
                        value.gapless());
            }
        }

        private static final class Playback {
            static final Playback REJECTED = new Playback();
            final Handle handle;
            final AudioAsset asset;
            final AudioFormat format;
            Identifier bus;
            final int priority;
            final long sequence;
            final boolean stealable;
            final boolean music;
            final LoopMode loopMode;
            final Optional<LoopRegion> loopRegion;
            final SpatialMode spatialMode;
            int source;
            int buffer;
            double gain;
            double pitch;
            boolean manualPaused;
            AudioEmitter emitter;
            Fade fade;
            StreamState stream;
            final ArrayList<Identifier> replaceOnBegin = new ArrayList<>();

            private Playback() {
                handle = null; asset = null; format = null; bus = null; priority = 0; sequence = 0;
                stealable = false; music = false; loopMode = LoopMode.ONCE; loopRegion = Optional.empty();
                spatialMode = SpatialMode.NON_SPATIAL;
            }

            private Playback(PlaybackSpec spec) {
                handle = spec.handle; asset = spec.asset; format = spec.asset.format(); bus = spec.bus;
                priority = spec.priority; sequence = Long.parseLong(spec.handle.id().lastPathSegment());
                stealable = spec.stealable; music = spec.music; loopMode = spec.loopMode;
                loopRegion = spec.loopRegion; spatialMode = spec.spatialMode; emitter = spec.emitter;
                Duration entrance = !spec.crossfade.isZero()
                        ? spec.crossfade : spec.fadeIn;
                gain = entrance.isZero() ? spec.gain : 0; pitch = spec.pitch;
                if (!entrance.isZero()) fade = new Fade(0, spec.gain,
                        System.nanoTime(), entrance.toNanos(), false);
            }

            boolean active() { return handle != null && switch (handle.state.get()) {
                case QUEUED, STARTING, PLAYING, PAUSED -> true;
                default -> false;
            }; }
        }

        private static final class StreamState {
            final ArrayBlockingQueue<StreamChunk> queue;
            final ArrayDeque<Integer> freeBuffers = new ArrayDeque<>();
            final ArrayDeque<QueuedChunk> queued = new ArrayDeque<>();
            final AtomicBoolean cancelled = new AtomicBoolean();
            final AtomicReference<AudioStream> openStream = new AtomicReference<>();
            boolean ended;
            StreamState(int buffers) { queue = new ArrayBlockingQueue<>(buffers); }
        }

        private record StreamChunk(long startFrame, int frames, float[] samples, boolean end, Throwable failure) {
            static StreamChunk endMarker() { return new StreamChunk(0, 0, null, true, null); }
            static StreamChunk failure(Throwable value) { return new StreamChunk(0, 0, null, false, value); }
        }
        private record QueuedChunk(int buffer, long startFrame, int frames) { }
        private record Fade(double from, double to, long startNanos, long durationNanos, boolean stopAfter) { }
        private static final class BusState {
            double gain; boolean muted; boolean paused;
            BusState(double gain, boolean muted, boolean paused) { this.gain = gain; this.muted = muted; this.paused = paused; }
        }
        private static final class DeviceLostException extends RuntimeException { }
    }
}

package io.github.juloass.audio.openal;

import io.github.juloass.audio.AudioListener;
import io.github.juloass.audio.MixerGraph;

import java.time.Duration;
import java.util.Objects;
import java.util.Optional;

/** Immutable limits and initial state for one OpenAL engine. */
public record OpenAlConfiguration(
        Optional<String> deviceIdentifier,
        int globalVoiceLimit,
        int bufferCacheLimit,
        int commandQueueLimit,
        int streamBufferCount,
        int framesPerStreamBuffer,
        int decoderWorkerCount,
        MixerGraph mixerGraph,
        AudioListener initialListener,
        Duration shutdownTimeout
) {
    public OpenAlConfiguration {
        deviceIdentifier = Objects.requireNonNull(deviceIdentifier, "deviceIdentifier");
        mixerGraph = Objects.requireNonNull(mixerGraph, "mixerGraph");
        initialListener = Objects.requireNonNull(initialListener, "initialListener");
        shutdownTimeout = Objects.requireNonNull(shutdownTimeout, "shutdownTimeout");
        if (deviceIdentifier.isPresent() && deviceIdentifier.get().isBlank()) {
            throw new IllegalArgumentException("deviceIdentifier must not be blank");
        }
        if (globalVoiceLimit < 1 || bufferCacheLimit < 0 || commandQueueLimit < 1
                || streamBufferCount < 2 || framesPerStreamBuffer < 256 || decoderWorkerCount < 1
                || shutdownTimeout.isNegative() || shutdownTimeout.isZero()) {
            throw new IllegalArgumentException("OpenAL limits and shutdown timeout are invalid");
        }
    }

    public static OpenAlConfiguration defaults(MixerGraph mixerGraph) {
        return new OpenAlConfiguration(Optional.empty(), 64, 256, 4096, 4, 4096, 2,
                mixerGraph, AudioListener.defaults(), Duration.ofSeconds(5));
    }
}

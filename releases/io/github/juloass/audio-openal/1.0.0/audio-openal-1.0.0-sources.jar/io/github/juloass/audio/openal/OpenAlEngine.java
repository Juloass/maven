package io.github.juloass.audio.openal;

import io.github.juloass.audio.AudioEngine;

import java.util.Optional;
import java.util.concurrent.CompletionStage;

/** An Audio engine with explicit caller-controlled OpenAL device recovery. */
public interface OpenAlEngine extends AudioEngine {
    CompletionStage<DeviceReopenResult> reopen(Optional<String> deviceIdentifier);
}

package io.github.juloass.audio.openal;

import io.github.juloass.audio.AudioProblem;

import java.util.Objects;
import java.util.Optional;

/** Result of an explicit OpenAL device reopen request. */
public record DeviceReopenResult(boolean reopened, Optional<AudioProblem> problem) {
    public DeviceReopenResult { problem = Objects.requireNonNull(problem, "problem"); }
}

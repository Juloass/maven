package io.github.juloass.audio.wav;

import io.github.juloass.audio.AudioDecodeLimits;
import io.github.juloass.audio.AudioDecoder;
import io.github.juloass.audio.AudioFormat;
import io.github.juloass.audio.AudioStream;
import io.github.juloass.audio.EncodedAudioSource;
import io.github.juloass.audio.ChannelLayout;
import io.github.juloass.audio.PcmAudioStream;
import io.github.juloass.audio.PcmData;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/** Strict decoder for mono and stereo RIFF/WAVE audio. */
public final class WavDecoder implements AudioDecoder {
    private static final int PCM = 1;
    private static final int IEEE_FLOAT = 3;

    @Override
    public PcmData decode(InputStream input, AudioDecodeLimits limits) throws IOException {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(limits, "limits");
        byte[] encoded = readBounded(input, limits.maximumEncodedBytes());
        return decodeBytes(encoded, limits);
    }

    @Override
    public AudioStream stream(EncodedAudioSource source, AudioDecodeLimits limits) throws IOException {
        Objects.requireNonNull(source, "source");
        try (InputStream input = source.openStream()) {
            return new PcmAudioStream(decode(input, limits));
        }
    }

    private static PcmData decodeBytes(byte[] bytes, AudioDecodeLimits limits) throws IOException {
        ByteBuffer input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (input.remaining() < 12 || !fourCc(input).equals("RIFF")) throw malformed("missing RIFF header");
        long riffSize = unsignedInt(input.getInt());
        if (!fourCc(input).equals("WAVE")) throw malformed("RIFF form is not WAVE");
        if (riffSize != bytes.length - 8L) throw malformed("RIFF size does not match the encoded data");

        Format format = null;
        byte[] audio = null;
        while (input.hasRemaining()) {
            if (input.remaining() < 8) throw malformed("truncated chunk header");
            String id = fourCc(input);
            long size = unsignedInt(input.getInt());
            if (size > input.remaining()) throw malformed("chunk " + id + " is truncated");
            int chunkSize = Math.toIntExact(size);
            int end = input.position() + chunkSize;
            if (id.equals("fmt ")) {
                if (format != null) throw malformed("duplicate fmt chunk");
                format = parseFormat(input.slice(input.position(), chunkSize).order(ByteOrder.LITTLE_ENDIAN));
            } else if (id.equals("data")) {
                if (audio != null) throw malformed("duplicate data chunk");
                audio = new byte[chunkSize];
                input.get(audio);
            }
            input.position(end);
            if ((chunkSize & 1) != 0) {
                if (!input.hasRemaining()) throw malformed("missing chunk padding");
                input.get();
            }
        }
        if (format == null) throw malformed("missing fmt chunk");
        if (audio == null) throw malformed("missing data chunk");
        if (format.sampleRate > limits.maximumSampleRate()) throw malformed("sample rate exceeds the configured limit");
        if (audio.length % format.blockAlign != 0) throw malformed("data does not contain complete frames");
        long frameCount = audio.length / format.blockAlign;
        if (frameCount == 0) throw malformed("audio contains no frames");
        if (frameCount > limits.maximumFrames()) throw malformed("decoded frame count exceeds the configured limit");

        float[] samples = new float[Math.toIntExact(frameCount * format.channels)];
        ByteBuffer data = ByteBuffer.wrap(audio).order(ByteOrder.LITTLE_ENDIAN);
        for (int index = 0; index < samples.length; index++) samples[index] = readSample(data, format.encoding, format.bits);
        return new PcmData(new AudioFormat(format.sampleRate, ChannelLayout.forChannels(format.channels)), samples);
    }

    private static Format parseFormat(ByteBuffer chunk) throws IOException {
        if (chunk.remaining() < 16) throw malformed("fmt chunk is too short");
        int encoding = Short.toUnsignedInt(chunk.getShort());
        int channels = Short.toUnsignedInt(chunk.getShort());
        long sampleRate = unsignedInt(chunk.getInt());
        long byteRate = unsignedInt(chunk.getInt());
        int blockAlign = Short.toUnsignedInt(chunk.getShort());
        int bits = Short.toUnsignedInt(chunk.getShort());
        if (encoding != PCM && encoding != IEEE_FLOAT) throw malformed("unsupported WAVE compression code " + encoding);
        if (channels < 1 || channels > 2) throw malformed("only mono and stereo WAVE audio is supported");
        if (sampleRate < 1 || sampleRate > Integer.MAX_VALUE) throw malformed("invalid sample rate");
        boolean supportedBits = encoding == PCM && (bits == 8 || bits == 16 || bits == 24 || bits == 32)
                || encoding == IEEE_FLOAT && bits == 32;
        if (!supportedBits) throw malformed("unsupported sample encoding");
        int expectedAlign = channels * (bits / 8);
        if (blockAlign != expectedAlign || byteRate != sampleRate * expectedAlign) throw malformed("inconsistent WAVE format rates");
        return new Format(encoding, channels, (int) sampleRate, blockAlign, bits);
    }

    private static float readSample(ByteBuffer data, int encoding, int bits) throws IOException {
        if (encoding == IEEE_FLOAT) {
            float value = data.getFloat();
            if (!Float.isFinite(value) || value < -1.0f || value > 1.0f) throw malformed("float sample is outside [-1, 1]");
            return value;
        }
        return switch (bits) {
            case 8 -> (Byte.toUnsignedInt(data.get()) - 128) / 128.0f;
            case 16 -> data.getShort() / 32768.0f;
            case 24 -> {
                int value = Byte.toUnsignedInt(data.get()) | Byte.toUnsignedInt(data.get()) << 8 | data.get() << 16;
                yield value / 8_388_608.0f;
            }
            case 32 -> (float) (data.getInt() / 2_147_483_648.0);
            default -> throw new AssertionError(bits);
        };
    }

    private static byte[] readBounded(InputStream input, long maximum) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        long total = 0;
        for (int read; (read = input.read(buffer)) >= 0;) {
            if (read == 0) continue;
            total += read;
            if (total > maximum) throw new IOException("encoded audio exceeds the configured byte limit");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private static String fourCc(ByteBuffer input) throws EOFException {
        if (input.remaining() < 4) throw new EOFException("truncated four-character code");
        byte[] value = new byte[4];
        input.get(value);
        return new String(value, StandardCharsets.US_ASCII);
    }

    private static long unsignedInt(int value) { return Integer.toUnsignedLong(value); }
    private static IOException malformed(String message) { return new IOException("Malformed WAVE: " + message); }
    private record Format(int encoding, int channels, int sampleRate, int blockAlign, int bits) { }
}

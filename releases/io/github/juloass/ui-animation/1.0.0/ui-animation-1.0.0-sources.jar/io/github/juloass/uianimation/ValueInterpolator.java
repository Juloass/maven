package io.github.juloass.uianimation;

/** Interpolates one typed animation value. Progress can exceed zero through one. */
@FunctionalInterface
public interface ValueInterpolator<T> {
    T interpolate(T from, T to, double progress);
}


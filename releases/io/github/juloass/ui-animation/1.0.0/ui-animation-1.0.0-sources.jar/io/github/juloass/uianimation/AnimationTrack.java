package io.github.juloass.uianimation;

import java.util.Objects;

/** One typed value track within an animation phase. */
public final class AnimationTrack<T> {
    private final AnimationProperty<T> property;
    private final T start;
    private final AnimationSampler<T> sampler;
    private final ValueInterpolator<T> interpolator;
    private final UiMotionCategory motionCategory;

    private AnimationTrack(AnimationProperty<T> property, T start,
                           AnimationSampler<T> sampler, ValueInterpolator<T> interpolator,
                           UiMotionCategory motionCategory) {
        this.property = Objects.requireNonNull(property, "property");
        this.start = property.checked(start);
        this.sampler = Objects.requireNonNull(sampler, "sampler");
        this.interpolator = Objects.requireNonNull(interpolator, "interpolator");
        this.motionCategory = Objects.requireNonNull(motionCategory, "motionCategory");
        property.checked(sampler.sample(0.0));
        property.checked(sampler.sample(1.0));
    }

    public static <T> AnimationTrack<T> between(AnimationProperty<T> property, T from, T to,
                                                 ValueInterpolator<T> interpolator,
                                                 UiMotionCategory category) {
        property.checked(to);
        return new AnimationTrack<>(property, from,
                progress -> interpolator.interpolate(from, to, progress), interpolator, category);
    }

    public static <T> AnimationTrack<T> sampled(AnimationProperty<T> property, T baseline,
                                                 AnimationSampler<T> sampler,
                                                 ValueInterpolator<T> interpolator,
                                                 UiMotionCategory category) {
        return new AnimationTrack<>(property, baseline, sampler, interpolator, category);
    }

    public AnimationProperty<T> property() { return property; }
    public T start() { return start; }
    public UiMotionCategory motionCategory() { return motionCategory; }

    public T sample(double progress, UiMotionPolicy policy) {
        if (!Double.isFinite(progress)) throw new IllegalArgumentException("progress must be finite");
        T sampled = property.checked(sampler.sample(progress));
        return property.checked(interpolator.interpolate(start, sampled, policy.scale(motionCategory)));
    }

    AnimationTrack<T> retarget(Object value) {
        T replacement = property.checked(value);
        T end = property.checked(sampler.sample(1.0));
        return between(property, replacement, end, interpolator, motionCategory);
    }
}


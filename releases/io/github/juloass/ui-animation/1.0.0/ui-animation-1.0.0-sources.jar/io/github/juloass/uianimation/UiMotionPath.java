package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import java.util.Objects;

/** Spatial motion paths with separate time easing. */
public final class UiMotionPath {
    private UiMotionPath(){}
    public static UiAnimation cubicBezier(double x0,double y0,double x1,double y1,double x2,double y2,double x3,double y3,Easing easing){
        return(t,s)->sampleCubicBezier(x0,y0,x1,y1,x2,y2,x3,y3,t,easing,s);}
    public static UiAnimationState sampleCubicBezier(double x0,double y0,double x1,double y1,double x2,double y2,double x3,double y3,double time,Easing easing,UiAnimationState state){
        Objects.requireNonNull(easing);Objects.requireNonNull(state);double p=easing.applyClamped(time),q=1-p;
        return state.translate(q*q*q*x0+3*q*q*p*x1+3*q*p*p*x2+p*p*p*x3,q*q*q*y0+3*q*q*p*y1+3*q*p*p*y2+p*p*p*y3);}
}


package io.github.juloass.uianimation;

import io.github.juloass.math.Angle;
import java.util.Objects;

/** A visual transform that does not alter layout. */
public record UiTransform(UiVector2 translation, UiVector2 scale, Angle rotation,
                          UiVector2 pivot) {
    public static final UiTransform IDENTITY = new UiTransform(
            UiVector2.ZERO, new UiVector2(1.0, 1.0), Angle.radians(0.0),
            new UiVector2(0.5, 0.5));
    public static UiTransform identity() { return IDENTITY; }

    public UiTransform {
        Objects.requireNonNull(translation, "translation");
        Objects.requireNonNull(scale, "scale");
        Objects.requireNonNull(rotation, "rotation");
        Objects.requireNonNull(pivot, "pivot");
        if (pivot.x() < 0.0 || pivot.x() > 1.0 || pivot.y() < 0.0 || pivot.y() > 1.0)
            throw new IllegalArgumentException("pivot must be within [0, 1]");
    }
    public UiTransform(double translateX, double translateY, double scaleX, double scaleY,
                       double rotationRadians, double pivotX, double pivotY) {
        this(new UiVector2(translateX, translateY), new UiVector2(scaleX, scaleY),
                Angle.radians(rotationRadians), new UiVector2(pivotX, pivotY));
    }
    public float translateX() { return (float) translation.x(); }
    public float translateY() { return (float) translation.y(); }
    public float scaleX() { return (float) scale.x(); }
    public float scaleY() { return (float) scale.y(); }
    public float rotationRadians() { return (float) rotation.inRadians(); }
    public float pivotX() { return (float) pivot.x(); }
    public float pivotY() { return (float) pivot.y(); }
    public UiTransform withTranslation(double x,double y){return new UiTransform(x,y,scaleX(),scaleY(),rotationRadians(),pivotX(),pivotY());}
    public UiTransform withScale(double x,double y){return new UiTransform(translateX(),translateY(),x,y,rotationRadians(),pivotX(),pivotY());}
    public UiTransform withRotation(double radians){return new UiTransform(translateX(),translateY(),scaleX(),scaleY(),radians,pivotX(),pivotY());}

    public static UiTransform translated(double x, double y) {
        return new UiTransform(new UiVector2(x, y), new UiVector2(1.0, 1.0),
                Angle.radians(0.0), new UiVector2(0.5, 0.5));
    }

    public static UiTransform scaled(double scale) {
        return new UiTransform(UiVector2.ZERO, new UiVector2(scale, scale),
                Angle.radians(0.0), new UiVector2(0.5, 0.5));
    }
}

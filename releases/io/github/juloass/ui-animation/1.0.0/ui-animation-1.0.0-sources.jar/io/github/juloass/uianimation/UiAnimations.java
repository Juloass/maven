package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import java.util.Arrays;
import java.util.Objects;

/** Composition helpers for stateless UI animations. */
public final class UiAnimations {
    private UiAnimations(){}
    public static UiAnimation parallel(UiAnimation... values){UiAnimation[] copy=Arrays.copyOf(Objects.requireNonNull(values),values.length);
        if(copy.length==0)throw new IllegalArgumentException("parallel composition requires an animation");
        for(UiAnimation value:copy)Objects.requireNonNull(value);return(t,s)->{for(UiAnimation value:copy)value.apply(t,s);};}
    public static UiAnimation sequence(UiAnimationStep... steps) {
        UiAnimationStep[] copy=Arrays.copyOf(Objects.requireNonNull(steps),steps.length);
        if(copy.length==0)throw new IllegalArgumentException("sequence requires a step");
        double total=0;double[] ends=new double[copy.length];
        for(int i=0;i<copy.length;i++){Objects.requireNonNull(copy[i]);total+=copy[i].durationWeight();ends[i]=total;}
        double weight=total;return(time,state)->{double position=time*weight,start=0;
            for(int i=0;i<copy.length;i++){if(position<=ends[i]||i==copy.length-1){double local=Math.max(0,Math.min(1,(position-start)/(ends[i]-start)));copy[i].animation().apply(local,state);return;}start=ends[i];}};
    }
    public static UiAnimation transform(UiTransform from,UiTransform to,double fromOpacity,double toOpacity,Easing easing){
        Objects.requireNonNull(from);Objects.requireNonNull(to);Objects.requireNonNull(easing);return(time,state)->{
            double p=easing.apply(time);UiTransform value=Interpolators.TRANSFORM.interpolate(from,to,p);
            state.translate(value.translation().x(),value.translation().y()).scale(value.scale().x(),value.scale().y())
                    .rotate(value.rotation().inRadians()).fade(Interpolators.DOUBLE.interpolate(fromOpacity,toOpacity,p));};}
    public static UiAnimation transform(UiTransform from, UiTransform to, Easing easing) {
        return transform(from, to, 1.0, 1.0, easing);
    }
}

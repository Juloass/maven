package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import java.time.Duration;
import java.util.List;
import java.util.Objects;

/** One duration with parallel animation tracks. */
public record AnimationPhase(Duration duration, Easing easing, List<AnimationTrack<?>> tracks) {
    public AnimationPhase {
        Objects.requireNonNull(duration, "duration");
        Objects.requireNonNull(easing, "easing");
        if (duration.isNegative()) throw new IllegalArgumentException("duration must not be negative");
        tracks = List.copyOf(Objects.requireNonNull(tracks, "tracks"));
        tracks.forEach(track -> Objects.requireNonNull(track, "track"));
    }
}


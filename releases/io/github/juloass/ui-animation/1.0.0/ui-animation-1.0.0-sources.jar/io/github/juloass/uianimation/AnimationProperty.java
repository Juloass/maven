package io.github.juloass.uianimation;

import java.util.Objects;

/** A typed property within one animation owner. */
public record AnimationProperty<T>(String name, Class<T> valueType) {
    public AnimationProperty {
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(valueType, "valueType");
        if (name.isBlank()) throw new IllegalArgumentException("name must not be blank");
    }

    public static <T> AnimationProperty<T> of(String name, Class<T> type) {
        return new AnimationProperty<>(name, type);
    }

    T checked(Object value) {
        return valueType.cast(Objects.requireNonNull(value, "value"));
    }
}


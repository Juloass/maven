package io.github.juloass.uianimation;

import java.util.EnumMap;
import java.util.Map;

/** Immutable amplitude scales for visual-motion categories. */
public final class UiMotionPolicy {
    public static final UiMotionPolicy FULL = builder().build();
    public static final UiMotionPolicy REDUCED = builder().translation(0.2).scale(0.25)
            .rotation(0.0).screenShake(0.0).build();
    public static final UiMotionPolicy NONE = builder().translation(0.0).scale(0.0)
            .rotation(0.0).screenShake(0.0).other(0.0).build();
    private final Map<UiMotionCategory, Double> scales;

    private UiMotionPolicy(Map<UiMotionCategory, Double> values) { scales = Map.copyOf(values); }
    public double scale(UiMotionCategory category) { return scales.get(category); }
    public float translationScale() { return (float) scale(UiMotionCategory.TRANSLATION); }
    public float scaleAnimationScale() { return (float) scale(UiMotionCategory.SCALE); }
    public float rotationScale() { return (float) scale(UiMotionCategory.ROTATION); }
    public float screenShakeScale() { return (float) scale(UiMotionCategory.SCREEN_SHAKE); }
    public UiAnimationState apply(UiAnimationState state) {
        return java.util.Objects.requireNonNull(state, "state").applyMotionPolicy(this);
    }
    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private final EnumMap<UiMotionCategory, Double> values = new EnumMap<>(UiMotionCategory.class);
        private Builder() { for (UiMotionCategory category : UiMotionCategory.values()) values.put(category, 1.0); }
        public Builder opacity(double v) { return set(UiMotionCategory.OPACITY, v); }
        public Builder color(double v) { return set(UiMotionCategory.COLOR, v); }
        public Builder translation(double v) { return set(UiMotionCategory.TRANSLATION, v); }
        public Builder scale(double v) { return set(UiMotionCategory.SCALE, v); }
        public Builder rotation(double v) { return set(UiMotionCategory.ROTATION, v); }
        public Builder screenShake(double v) { return set(UiMotionCategory.SCREEN_SHAKE, v); }
        public Builder other(double v) { return set(UiMotionCategory.OTHER, v); }
        public Builder set(UiMotionCategory category, double value) {
            if (!Double.isFinite(value) || value < 0.0 || value > 1.0)
                throw new IllegalArgumentException("motion scale must be within [0, 1]");
            values.put(java.util.Objects.requireNonNull(category), value); return this;
        }
        public UiMotionPolicy build() { return new UiMotionPolicy(values); }
    }
}

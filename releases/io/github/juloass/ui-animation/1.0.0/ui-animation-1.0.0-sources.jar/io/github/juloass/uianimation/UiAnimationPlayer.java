package io.github.juloass.uianimation;

import java.util.Objects;

/** A stateful tick-derived player for a stateless UI animation. */
public final class UiAnimationPlayer {
    private UiAnimation animation=(time,state)->{}; private UiPlayback playback=UiPlayback.ONCE;
    private long startTick,durationTicks=1; private boolean playing;
    public UiAnimationPlayer play(UiAnimation value,long atTick,long duration,UiPlayback mode){
        animation=Objects.requireNonNull(value);playback=Objects.requireNonNull(mode);
        if(atTick<0||duration<=0)throw new IllegalArgumentException("ticks must be non-negative and duration must be positive");
        startTick=atTick;durationTicks=duration;playing=true;return this;}
    public UiAnimationState sample(long tick,UiMotionPolicy policy,UiAnimationState destination){
        if(tick<0)throw new IllegalArgumentException("tick must be non-negative");Objects.requireNonNull(policy);Objects.requireNonNull(destination).identity();
        if(!playing||tick<startTick)return destination;animation.apply(time(tick),destination);return policy.apply(destination);}
    public boolean isFinished(long tick){return playing&&playback==UiPlayback.ONCE&&tick>=saturatingAdd(startTick,durationTicks);}
    public UiAnimationPlayer stop(){playing=false;return this;} public boolean isPlaying(){return playing;}
    private double time(long tick){long elapsed=Math.max(0,tick-startTick);return switch(playback){
        case ONCE->Math.min(1,elapsed/(double)durationTicks);case LOOP->(elapsed%durationTicks)/(double)durationTicks;
        case PING_PONG->{long cycle=durationTicks>Long.MAX_VALUE/2?Long.MAX_VALUE:durationTicks*2;long within=elapsed%cycle;
            yield within<=durationTicks?within/(double)durationTicks:(cycle-within)/(double)durationTicks;}};}
    private static long saturatingAdd(long a,long b){try{return Math.addExact(a,b);}catch(ArithmeticException e){return Long.MAX_VALUE;}}
}


package io.github.juloass.uianimation;

import java.util.Objects;

/** One weighted step in a stateless animation sequence. */
public record UiAnimationStep(UiAnimation animation, double durationWeight) {
    public UiAnimationStep { Objects.requireNonNull(animation); if(!Double.isFinite(durationWeight)||durationWeight<=0)throw new IllegalArgumentException("weight must be positive and finite"); }
}


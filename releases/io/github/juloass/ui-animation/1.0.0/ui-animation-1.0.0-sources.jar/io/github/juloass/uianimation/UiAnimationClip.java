package io.github.juloass.uianimation;

import java.util.Objects;

/** One normalized interval in a stateless timeline. */
public record UiAnimationClip(double startTime,double endTime,UiAnimation animation) {
    public UiAnimationClip { if(!Double.isFinite(startTime)||!Double.isFinite(endTime)||startTime<0||endTime>1||endTime<=startTime)throw new IllegalArgumentException("clip interval must satisfy 0 <= start < end <= 1");Objects.requireNonNull(animation); }
}


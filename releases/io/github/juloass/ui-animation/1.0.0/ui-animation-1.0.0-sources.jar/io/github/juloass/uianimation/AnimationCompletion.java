package io.github.juloass.uianimation;

/** Receives a completed owner and handle. */
@FunctionalInterface
public interface AnimationCompletion<O> { void complete(O owner, AnimationHandle handle) throws Exception; }


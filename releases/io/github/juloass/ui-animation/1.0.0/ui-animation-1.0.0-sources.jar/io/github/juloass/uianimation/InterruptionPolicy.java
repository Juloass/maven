package io.github.juloass.uianimation;

/** Defines how a new clip handles conflicting active tracks. */
public enum InterruptionPolicy { RETARGET, REPLACE, QUEUE, BLEND, IGNORE }


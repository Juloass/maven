package io.github.juloass.uianimation;

/** A reusable transform and opacity accumulator for direct sampling. */
public final class UiAnimationState {
    private float translationX, translationY, scaleX = 1.0f, scaleY = 1.0f;
    private float rotationRadians, opacity = 1.0f, screenOffsetX, screenOffsetY;
    public UiAnimationState identity() { translationX=translationY=rotationRadians=screenOffsetX=screenOffsetY=0; scaleX=scaleY=opacity=1; return this; }
    public UiAnimationState translate(double x,double y){ finite(x,y); translationX+=(float)x;translationY+=(float)y;return this; }
    public UiAnimationState scale(double x,double y){ finite(x,y);scaleX*=(float)x;scaleY*=(float)y;return this; }
    public UiAnimationState rotate(double radians){ finite(radians);rotationRadians+=(float)radians;return this; }
    public UiAnimationState fade(double value){ finite(value);opacity*=(float)value;return this; }
    public UiAnimationState offsetScreen(double x,double y){ finite(x,y);screenOffsetX+=(float)x;screenOffsetY+=(float)y;return this; }
    public float translationX(){return translationX;} public float translationY(){return translationY;}
    public float scaleX(){return scaleX;} public float scaleY(){return scaleY;}
    public float rotationRadians(){return rotationRadians;} public float opacity(){return opacity;}
    public float screenOffsetX(){return screenOffsetX;} public float screenOffsetY(){return screenOffsetY;}
    UiAnimationState applyMotionPolicy(UiMotionPolicy p){ translationX*= (float)p.translationScale();translationY*=(float)p.translationScale();
        scaleX=1+(scaleX-1)*(float)p.scaleAnimationScale();scaleY=1+(scaleY-1)*(float)p.scaleAnimationScale();
        rotationRadians*=(float)p.rotationScale();screenOffsetX*=(float)p.screenShakeScale();screenOffsetY*=(float)p.screenShakeScale();return this;}
    private static void finite(double... values){for(double v:values)if(!Double.isFinite(v))throw new IllegalArgumentException("value must be finite");}
}

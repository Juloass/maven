package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import io.github.juloass.math.Easings;
import io.github.juloass.math.Scalars;
import java.util.Objects;

/** Renderer-independent UI motion presets. */
public final class UiAnimationPresets {
    private UiAnimationPresets(){}
    public static UiAnimation pop(){return(t,s)->{double scale=Scalars.extrapolate(.62,1,Easings.BACK_OUT.apply(t));s.scale(scale,scale).fade(Easings.QUADRATIC_OUT.apply(t));};}
    public static UiAnimation pulse(double amount){finite(amount);if(amount<0)throw new IllegalArgumentException("amount must not be negative");return(t,s)->{double v=1+Math.sin(t*Math.PI)*amount;s.scale(v,v);};}
    public static UiAnimation fadeIn(){return fade(0,1,Easings.QUADRATIC_OUT);} public static UiAnimation fadeOut(){return fade(1,0,Easings.QUADRATIC_IN);}
    public static UiAnimation fade(double from,double to,Easing easing){finite(from,to);Objects.requireNonNull(easing);return(t,s)->s.fade(Scalars.extrapolate(from,to,easing.apply(t)));}
    public static UiAnimation slide(double x1,double y1,double x2,double y2,Easing easing){finite(x1,y1,x2,y2);Objects.requireNonNull(easing);return(t,s)->{double p=easing.apply(t);s.translate(Scalars.extrapolate(x1,x2,p),Scalars.extrapolate(y1,y2,p));};}
    public static UiAnimation transition(double x,double y,Easing easing){return UiAnimations.parallel(slide(x,y,0,0,easing),fadeIn());}
    public static UiAnimation elementShake(double x,double y,double cycles){validate(x,y,cycles);return(t,s)->s.translate(wave(t,cycles)*x,wave(t,cycles*1.37)*y);}
    public static UiAnimation globalScreenShake(double x,double y,double cycles){validate(x,y,cycles);return(t,s)->s.offsetScreen(wave(t,cycles)*x,wave(t,cycles*1.61)*y);}
    public static UiAnimation globalScreenShake(long seed,double x,double y,double samples){validate(x,y,samples);return(t,s)->s.offsetScreen(noise(seed,t,samples,0)*x,noise(seed,t,samples,1)*y);}
    public static UiAnimation elementShakePixels(long seed,double x,double y,double samples){validate(x,y,samples);return(t,s)->s.translate(Math.round(noise(seed,t,samples,0)*x),Math.round(noise(seed,t,samples,1)*y));}
    public static UiAnimation globalScreenShakePixels(long seed,double x,double y,double samples){validate(x,y,samples);return(t,s)->s.offsetScreen(Math.round(noise(seed,t,samples,0)*x),Math.round(noise(seed,t,samples,1)*y));}
    private static double wave(double t,double cycles){return Math.sin(t*cycles*Math.PI*2)*(1-t);}
    private static double noise(long seed,double time,double samples,int axis){double sample=time*samples;long index=(long)Math.floor(sample);double f=sample-index;double smooth=f*f*(3-2*f);return Scalars.lerp(hash(seed,index,axis),hash(seed,index+1,axis),smooth)*4*time*(1-time);}
    private static double hash(long seed,long index,int axis){long v=seed^index*0x9E3779B97F4A7C15L^(long)axis*0xD1B54A32D192ED03L;v^=v>>>30;v*=0xBF58476D1CE4E5B9L;v^=v>>>27;v*=0x94D049BB133111EBL;v^=v>>>31;return((v>>>40)/(double)0xFFFFFF)*2-1;}
    private static void validate(double x,double y,double value){finite(x,y,value);if(value<=0)throw new IllegalArgumentException("sample count must be positive");}
    private static void finite(double... values){for(double value:values)if(!Double.isFinite(value))throw new IllegalArgumentException("value must be finite");}
}

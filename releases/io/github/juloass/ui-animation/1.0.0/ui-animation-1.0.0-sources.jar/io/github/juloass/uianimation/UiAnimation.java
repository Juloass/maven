package io.github.juloass.uianimation;

/** A stateless normalized-time contribution to a UI animation state. */
@FunctionalInterface
public interface UiAnimation {
    void apply(double normalizedTime, UiAnimationState accumulator);
    default UiAnimationState sample(double time, UiAnimationState destination) {
        java.util.Objects.requireNonNull(destination).identity(); apply(clamp(time), destination); return destination;
    }
    private static double clamp(double value){if(!Double.isFinite(value))throw new IllegalArgumentException("time must be finite");return Math.max(0,Math.min(1,value));}
}


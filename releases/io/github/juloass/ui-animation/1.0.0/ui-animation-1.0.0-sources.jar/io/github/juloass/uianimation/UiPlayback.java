package io.github.juloass.uianimation;

/** Tick-derived playback mapping for direct animation sampling. */
public enum UiPlayback { ONCE, LOOP, PING_PONG }


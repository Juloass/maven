package io.github.juloass.uianimation;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

/** An immutable normalized timeline whose completed clips retain their end state. */
public final class UiTimeline implements UiAnimation {
    private final UiAnimationClip[] clips;
    public UiTimeline(UiAnimationClip... values){clips=Arrays.copyOf(Objects.requireNonNull(values),values.length);if(clips.length==0)throw new IllegalArgumentException("timeline requires a clip");for(UiAnimationClip value:clips)Objects.requireNonNull(value);Arrays.sort(clips,Comparator.comparing(UiAnimationClip::startTime));}
    public void apply(double time,UiAnimationState state){for(UiAnimationClip clip:clips){if(time<clip.startTime())break;double local=Math.max(0,Math.min(1,(time-clip.startTime())/(clip.endTime()-clip.startTime())));clip.animation().apply(local,state);}}
}


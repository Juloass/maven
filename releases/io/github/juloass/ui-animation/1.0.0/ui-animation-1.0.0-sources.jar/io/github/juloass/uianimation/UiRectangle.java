package io.github.juloass.uianimation;

/** An immutable renderer-independent rectangle. */
public record UiRectangle(double x, double y, double width, double height) {
    public UiRectangle {
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(width)
                || !Double.isFinite(height)) throw new IllegalArgumentException("values must be finite");
    }
}


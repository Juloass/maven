package io.github.juloass.uianimation;

/** A visual-motion category used by an accessibility policy. */
public enum UiMotionCategory { OPACITY, COLOR, TRANSLATION, SCALE, ROTATION, SCREEN_SHAKE, OTHER }


package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/** Owner-thread retained scalar transitions for immediate-mode UI code. */
public final class UiTransitionStore<O> {
    private final Map<Key<O>, Channel> channels = new HashMap<>();
    private Thread ownerThread;
    private long frame;

    public void beginFrame() { checkThread(); frame++; }

    public double approach(O owner, AnimationProperty<Double> property, double target,
                           double speed, Duration elapsed) {
        check(owner, property, target, speed, elapsed);
        Channel channel = channel(owner, property, target);
        double k = 1.0 - Math.exp(-Math.max(0.0, speed) * seconds(elapsed));
        channel.value += (target - channel.value) * k; channel.velocity = 0.0; return channel.value;
    }

    public double transition(O owner, AnimationProperty<Double> property, double target,
                             Duration duration, Easing easing, Duration elapsed) {
        check(owner, property, target, 0.0, elapsed); Objects.requireNonNull(duration); Objects.requireNonNull(easing);
        if (duration.isNegative()) throw new IllegalArgumentException("duration must not be negative");
        Channel channel = channel(owner, property, target);
        if (Double.compare(channel.target, target) != 0) {
            channel.start = channel.value; channel.target = target; channel.elapsed = Duration.ZERO; channel.duration = duration;
        }
        channel.elapsed = minimum(channel.duration, channel.elapsed.plus(elapsed));
        double progress = channel.duration.isZero() ? 1.0 : seconds(channel.elapsed) / seconds(channel.duration);
        channel.value = Interpolators.DOUBLE.interpolate(channel.start, channel.target, easing.apply(progress));
        return channel.value;
    }

    public double spring(O owner, AnimationProperty<Double> property, double target,
                         double stiffness, double damping, Duration elapsed) {
        check(owner, property, target, stiffness, elapsed);
        if (!Double.isFinite(damping) || damping < 0.0) throw new IllegalArgumentException("damping must be non-negative and finite");
        Channel channel = channel(owner, property, target);
        double remaining = Math.min(0.25, seconds(elapsed));
        while (remaining > 0.0) {
            double step = Math.min(1.0 / 120.0, remaining);
            double force = (target - channel.value) * Math.max(0.0, stiffness);
            channel.velocity = (channel.velocity + force * step) * Math.exp(-damping * step);
            channel.value += channel.velocity * step; remaining -= step;
        }
        channel.target = target; return channel.value;
    }

    public void remove(O owner, AnimationProperty<?> property) { checkThread(); channels.remove(new Key<>(owner, property)); }
    public int collectStale(long maximumStaleFrames) {
        checkThread(); if (maximumStaleFrames < 0) throw new IllegalArgumentException("maximumStaleFrames must not be negative");
        int removed = 0; Iterator<Channel> iterator = channels.values().iterator();
        while (iterator.hasNext()) if (frame - iterator.next().lastFrame > maximumStaleFrames) { iterator.remove(); removed++; }
        return removed;
    }
    public int channelCount() { return channels.size(); }

    private Channel channel(O owner, AnimationProperty<Double> property, double initial) {
        Key<O> key = new Key<>(Objects.requireNonNull(owner), Objects.requireNonNull(property));
        Channel channel = channels.computeIfAbsent(key, ignored -> new Channel(initial, frame)); channel.lastFrame = frame; return channel;
    }
    private void check(O owner, AnimationProperty<Double> property, double target, double parameter, Duration elapsed) {
        checkThread(); Objects.requireNonNull(owner); Objects.requireNonNull(property); Objects.requireNonNull(elapsed);
        if (elapsed.isNegative()) throw new IllegalArgumentException("elapsed must not be negative");
        if (!Double.isFinite(target) || !Double.isFinite(parameter) || parameter < 0.0)
            throw new IllegalArgumentException("numeric parameters must be non-negative and finite where required");
    }
    private void checkThread() {
        Thread current = Thread.currentThread(); if (ownerThread == null) ownerThread = current;
        else if (ownerThread != current) throw new IllegalStateException("transition store used from another thread");
    }
    private static double seconds(Duration value) { return value.getSeconds() + value.getNano() / 1_000_000_000.0; }
    private static Duration minimum(Duration a, Duration b) { return a.compareTo(b) <= 0 ? a : b; }
    private record Key<O>(O owner, AnimationProperty<?> property) {}
    private static final class Channel {
        double value, start, target, velocity; Duration elapsed = Duration.ZERO, duration = Duration.ZERO; long lastFrame;
        Channel(double value, long frame) { this.value = value; start = value; target = value; lastFrame = frame; }
    }
}


package io.github.juloass.uianimation;

/** Samples one typed value at normalized progress. */
@FunctionalInterface
public interface AnimationSampler<T> {
    T sample(double normalizedProgress);
}


package io.github.juloass.uianimation;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;

/** Owner-thread playback for typed animation clips. */
public final class AnimationController<O> {
    private final List<Playback<O>> active = new ArrayList<>();
    private final Map<OwnerProperty<O>, Object> values = new HashMap<>();
    private final Map<O, Queue<Playback<O>>> queued = new HashMap<>();
    private final List<AnimationCallbackFailure> callbackFailures = new ArrayList<>();
    private UiMotionPolicy motionPolicy = UiMotionPolicy.FULL;
    private Thread ownerThread;
    private long nextId = 1L;

    public AnimationHandle play(O owner, AnimationClip clip, InterruptionPolicy interruption) {
        return play(owner, clip, interruption, 0.5, null);
    }

    public AnimationHandle play(O owner, AnimationClip clip, InterruptionPolicy interruption,
                                double blendFactor, AnimationCompletion<O> completion) {
        checkThread(); Objects.requireNonNull(owner, "owner"); Objects.requireNonNull(clip, "clip");
        Objects.requireNonNull(interruption, "interruption");
        if (!Double.isFinite(blendFactor) || blendFactor < 0.0 || blendFactor > 1.0)
            throw new IllegalArgumentException("blendFactor must be within [0, 1]");
        boolean conflict = hasConflict(owner, clip);
        PlaybackState initial = conflict && interruption == InterruptionPolicy.QUEUE
                ? PlaybackState.QUEUED : PlaybackState.PLAYING;
        if (conflict && interruption == InterruptionPolicy.IGNORE) initial = PlaybackState.IGNORED;
        AnimationHandle handle = new AnimationHandle(nextId++, initial, this::checkThread);
        handle.seeker = position -> seek(handle, position);
        AnimationClip effective = interruption == InterruptionPolicy.RETARGET
                ? clip.retarget(ownerValues(owner)) : clip;
        Playback<O> playback = new Playback<>(owner, effective, interruption, blendFactor, completion, handle);
        if (initial == PlaybackState.QUEUED) queued.computeIfAbsent(owner, ignored -> new ArrayDeque<>()).add(playback);
        else if (initial == PlaybackState.PLAYING) {
            if (conflict && (interruption == InterruptionPolicy.REPLACE || interruption == InterruptionPolicy.RETARGET))
                cancelConflicts(owner, clip);
            active.add(playback); sample(playback);
        }
        return handle;
    }

    public void advance(Duration elapsed) {
        checkThread(); requireNonNegative(elapsed);
        List<Playback<O>> completed = new ArrayList<>();
        Iterator<Playback<O>> iterator = active.iterator();
        while (iterator.hasNext()) {
            Playback<O> playback = iterator.next();
            AnimationHandle handle = playback.handle;
            if (handle.state == PlaybackState.CANCELLED) { iterator.remove(); continue; }
            if (handle.state == PlaybackState.PLAYING) handle.elapsed = addScaled(handle.elapsed, elapsed, handle.speed);
            sample(playback);
            if (isComplete(playback)) {
                handle.state = PlaybackState.COMPLETE; iterator.remove(); completed.add(playback);
            }
        }
        for (Playback<O> playback : completed) {
            if (playback.completion != null) {
                try { playback.completion.complete(playback.owner, playback.handle); }
                catch (Exception exception) { callbackFailures.add(new AnimationCallbackFailure(playback.handle, exception)); }
            }
            startNext(playback.owner);
        }
    }

    public void seek(AnimationHandle handle, Duration position) {
        checkThread(); Objects.requireNonNull(handle, "handle"); requireNonNegative(position);
        Playback<O> playback = find(handle);
        playback.handle.elapsed = position; sample(playback);
    }

    public <T> Optional<T> value(O owner, AnimationProperty<T> property) {
        Objects.requireNonNull(owner, "owner"); Objects.requireNonNull(property, "property");
        Object value = values.get(new OwnerProperty<>(owner, property));
        return value == null ? Optional.empty() : Optional.of(property.checked(value));
    }

    public <T> T valueOrElse(O owner, AnimationProperty<T> property, T fallback) {
        property.checked(fallback); return value(owner, property).orElse(fallback);
    }

    public AnimationController<O> motionPolicy(UiMotionPolicy policy) {
        checkThread(); motionPolicy = Objects.requireNonNull(policy, "policy"); return this;
    }
    public UiMotionPolicy motionPolicy() { return motionPolicy; }
    public int activeCount() { return active.size(); }
    public List<AnimationCallbackFailure> drainCallbackFailures() {
        checkThread(); List<AnimationCallbackFailure> result = List.copyOf(callbackFailures); callbackFailures.clear(); return result;
    }

    private void sample(Playback<O> playback) {
        double progress = progress(playback);
        Map<AnimationProperty<?>, Object> sampled = playback.clip.sample(progress, motionPolicy);
        sampled.forEach((property, value) -> {
            OwnerProperty<O> key = new OwnerProperty<>(playback.owner, property);
            if (playback.interruption == InterruptionPolicy.BLEND && values.containsKey(key))
                value = blendUnchecked(property, values.get(key), value, playback.blendFactor);
            values.put(key, value);
        });
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static Object blendUnchecked(AnimationProperty property, Object from, Object to, double factor) {
        if (from instanceof Double a && to instanceof Double b) return Interpolators.DOUBLE.interpolate(a, b, factor);
        if (from instanceof UiVector2 a && to instanceof UiVector2 b) return Interpolators.VECTOR2.interpolate(a, b, factor);
        if (from instanceof UiRectangle a && to instanceof UiRectangle b) return Interpolators.RECTANGLE.interpolate(a, b, factor);
        if (from instanceof UiTransform a && to instanceof UiTransform b) return Interpolators.TRANSFORM.interpolate(a, b, factor);
        return factor < 0.5 ? from : property.checked(to);
    }

    private double progress(Playback<O> playback) {
        double duration = seconds(playback.clip.duration());
        if (duration == 0.0) return 1.0;
        double elapsed = seconds(playback.handle.elapsed);
        if (elapsed <= 0.0) return 0.0;
        int repeats = playback.clip.repeatCount();
        if (repeats >= 0 && elapsed >= duration * (repeats + 1.0)) {
            return playback.clip.yoyo() && (repeats & 1) == 1 ? 0.0 : 1.0;
        }
        long cycle = (long) Math.floor(elapsed / duration);
        double local = (elapsed - cycle * duration) / duration;
        return playback.clip.yoyo() && (cycle & 1L) == 1L ? 1.0 - local : local;
    }

    private boolean isComplete(Playback<O> playback) {
        if (playback.clip.repeatsForever()) return false;
        return seconds(playback.handle.elapsed) >= seconds(playback.clip.duration()) * (playback.clip.repeatCount() + 1.0);
    }
    private boolean hasConflict(O owner, AnimationClip clip) {
        return active.stream().anyMatch(playback -> playback.owner.equals(owner)
                && !java.util.Collections.disjoint(playback.clip.properties(), clip.properties()));
    }
    private void cancelConflicts(O owner, AnimationClip clip) {
        active.removeIf(playback -> {
            boolean conflict = playback.owner.equals(owner)
                    && !java.util.Collections.disjoint(playback.clip.properties(), clip.properties());
            if (conflict) playback.handle.state = PlaybackState.CANCELLED;
            return conflict;
        });
    }
    private Map<AnimationProperty<?>, Object> ownerValues(O owner) {
        Map<AnimationProperty<?>, Object> result = new HashMap<>();
        values.forEach((key, value) -> { if (key.owner.equals(owner)) result.put(key.property, value); });
        return result;
    }
    private void startNext(O owner) {
        Queue<Playback<O>> queue = queued.get(owner);
        if (queue == null || queue.isEmpty()) return;
        Playback<O> next = queue.remove(); next.handle.state = PlaybackState.PLAYING; active.add(next); sample(next);
        if (queue.isEmpty()) queued.remove(owner);
    }
    private Playback<O> find(AnimationHandle handle) {
        return active.stream().filter(value -> value.handle == handle).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("handle is not active in this controller"));
    }
    private void checkThread() {
        Thread current = Thread.currentThread();
        if (ownerThread == null) ownerThread = current;
        else if (ownerThread != current) throw new IllegalStateException("animation controller used from another thread");
    }
    private static void requireNonNegative(Duration duration) {
        Objects.requireNonNull(duration, "duration"); if (duration.isNegative()) throw new IllegalArgumentException("duration must not be negative");
    }
    private static Duration addScaled(Duration current, Duration delta, double speed) {
        double value = seconds(current) + seconds(delta) * speed;
        if (value <= 0.0) return Duration.ZERO;
        if (!Double.isFinite(value) || value > Long.MAX_VALUE / 1_000_000_000.0)
            throw new ArithmeticException("animation elapsed time overflow");
        return Duration.ofNanos(Math.round(value * 1_000_000_000.0));
    }
    private static double seconds(Duration value) { return value.getSeconds() + value.getNano() / 1_000_000_000.0; }

    private record OwnerProperty<O>(O owner, AnimationProperty<?> property) {}
    private record Playback<O>(O owner, AnimationClip clip, InterruptionPolicy interruption,
                               double blendFactor, AnimationCompletion<O> completion, AnimationHandle handle) {}
}

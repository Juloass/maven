package io.github.juloass.uianimation;

import java.util.Objects;

/** One isolated completion callback failure. */
public record AnimationCallbackFailure(AnimationHandle handle, Exception cause) {
    public AnimationCallbackFailure { Objects.requireNonNull(handle); Objects.requireNonNull(cause); }
}


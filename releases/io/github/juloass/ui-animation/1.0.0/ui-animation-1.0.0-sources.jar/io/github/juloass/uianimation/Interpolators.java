package io.github.juloass.uianimation;

import io.github.juloass.color.Color;
import io.github.juloass.math.Angle;
import io.github.juloass.math.Scalars;
import java.util.Objects;

/** Standard immutable value interpolators. */
public final class Interpolators {
    private Interpolators() {}

    public static final ValueInterpolator<Double> DOUBLE = Scalars::extrapolate;
    public static final ValueInterpolator<UiVector2> VECTOR2 = (a, b, t) ->
            new UiVector2(Scalars.extrapolate(a.x(), b.x(), t), Scalars.extrapolate(a.y(), b.y(), t));
    public static final ValueInterpolator<UiRectangle> RECTANGLE = (a, b, t) ->
            new UiRectangle(Scalars.extrapolate(a.x(), b.x(), t), Scalars.extrapolate(a.y(), b.y(), t),
                    Scalars.extrapolate(a.width(), b.width(), t), Scalars.extrapolate(a.height(), b.height(), t));
    public static final ValueInterpolator<UiTransform> TRANSFORM = (a, b, t) -> new UiTransform(
            VECTOR2.interpolate(a.translation(), b.translation(), t),
            VECTOR2.interpolate(a.scale(), b.scale(), t),
            Angle.radians(Scalars.extrapolate(a.rotation().inRadians(), b.rotation().inRadians(), t)),
            VECTOR2.interpolate(a.pivot(), b.pivot(), t));

    public static ValueInterpolator<Color> color(Color.InterpolationSpace space,
                                                   Color.HueInterpolation direction) {
        Objects.requireNonNull(space, "space");
        Objects.requireNonNull(direction, "direction");
        return (from, to, progress) -> from.interpolate(to, progress, space, direction);
    }
}

package io.github.juloass.uianimation;

/** Current playback state. */
public enum PlaybackState { PLAYING, PAUSED, COMPLETE, CANCELLED, QUEUED, IGNORED }


package io.github.juloass.uianimation;

import io.github.juloass.math.Easing;
import io.github.juloass.math.Easings;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** An immutable sequence of animation phases. */
public final class AnimationClip {
    private final List<AnimationPhase> phases;
    private final int repeatCount;
    private final boolean yoyo;
    private final Duration duration;

    private AnimationClip(List<AnimationPhase> phases, int repeatCount, boolean yoyo) {
        this.phases = List.copyOf(phases);
        this.repeatCount = repeatCount;
        this.yoyo = yoyo;
        Duration total = Duration.ZERO;
        for (AnimationPhase phase : phases) total = safeAdd(total, phase.duration());
        duration = total;
    }

    public static Builder builder() { return new Builder(); }
    public List<AnimationPhase> phases() { return phases; }
    public int repeatCount() { return repeatCount; }
    public boolean repeatsForever() { return repeatCount == -1; }
    public boolean yoyo() { return yoyo; }
    public Duration duration() { return duration; }

    /** Samples values after all phases reached by the supplied progress. */
    public Map<AnimationProperty<?>, Object> sample(double normalizedProgress, UiMotionPolicy policy) {
        if (!Double.isFinite(normalizedProgress)) throw new IllegalArgumentException("progress must be finite");
        Objects.requireNonNull(policy, "policy");
        double position = Math.max(0.0, Math.min(1.0, normalizedProgress));
        long totalNanos = nanos(duration);
        double target = position * totalNanos;
        double cursor = 0.0;
        Map<AnimationProperty<?>, Object> result = new LinkedHashMap<>();
        for (AnimationPhase phase : phases) {
            long phaseNanos = nanos(phase.duration());
            if (target < cursor) break;
            double local = phaseNanos == 0L ? 1.0 : (target - cursor) / phaseNanos;
            local = Math.max(0.0, Math.min(1.0, local));
            double eased = phase.easing().apply(local);
            for (AnimationTrack<?> track : phase.tracks()) result.put(track.property(), track.sample(eased, policy));
            if (local < 1.0) break;
            cursor += phaseNanos;
        }
        return Map.copyOf(result);
    }

    AnimationClip retarget(Map<AnimationProperty<?>, Object> values) {
        List<AnimationPhase> changed = new ArrayList<>(phases.size());
        java.util.Set<AnimationProperty<?>> seen = new java.util.HashSet<>();
        for (AnimationPhase phase : phases) {
            List<AnimationTrack<?>> tracks = new ArrayList<>(phase.tracks().size());
            for (AnimationTrack<?> track : phase.tracks()) {
                Object current = values.get(track.property());
                tracks.add(current != null && seen.add(track.property()) ? track.retarget(current) : track);
            }
            changed.add(new AnimationPhase(phase.duration(), phase.easing(), tracks));
        }
        return new AnimationClip(changed, repeatCount, yoyo);
    }

    java.util.Set<AnimationProperty<?>> properties() {
        java.util.Set<AnimationProperty<?>> result = new java.util.HashSet<>();
        phases.forEach(phase -> phase.tracks().forEach(track -> result.add(track.property())));
        return java.util.Set.copyOf(result);
    }

    private static long nanos(Duration value) {
        try { return value.toNanos(); }
        catch (ArithmeticException exception) { throw new IllegalArgumentException("duration exceeds nanosecond range", exception); }
    }
    private static Duration safeAdd(Duration a, Duration b) {
        try { return a.plus(b); }
        catch (ArithmeticException exception) { throw new IllegalArgumentException("clip duration overflow", exception); }
    }

    public static final class Builder {
        private final List<AnimationPhase> phases = new ArrayList<>();
        private final List<AnimationTrack<?>> pending = new ArrayList<>();
        private int repeatCount;
        private boolean yoyo;

        public Builder track(AnimationTrack<?> track) { pending.add(Objects.requireNonNull(track)); return this; }
        public <T> Builder track(AnimationProperty<T> property, T from, T to,
                                 ValueInterpolator<T> interpolator, UiMotionCategory category) {
            return track(AnimationTrack.between(property, from, to, interpolator, category));
        }
        public Builder then(Duration duration, Easing easing) {
            phases.add(new AnimationPhase(duration, Objects.requireNonNullElse(easing, Easings.LINEAR), pending));
            pending.clear(); return this;
        }
        public Builder delay(Duration duration) {
            if (!pending.isEmpty()) throw new IllegalStateException("complete pending tracks before a delay");
            phases.add(new AnimationPhase(duration, Easings.LINEAR, List.of())); return this;
        }
        public Builder repeat(int count, boolean useYoyo) {
            if (count < -1) throw new IllegalArgumentException("repeat count must be -1 or greater");
            repeatCount = count; yoyo = useYoyo; return this;
        }
        public AnimationClip build() {
            if (!pending.isEmpty()) throw new IllegalStateException("complete pending tracks with then");
            if (phases.isEmpty()) throw new IllegalStateException("clip must contain a phase");
            return new AnimationClip(phases, repeatCount, yoyo);
        }
    }
}


package io.github.juloass.uianimation;

/** An immutable renderer-independent two-dimensional value. */
public record UiVector2(double x, double y) {
    public static final UiVector2 ZERO = new UiVector2(0.0, 0.0);
    public UiVector2 {
        requireFinite(x); requireFinite(y);
    }
    private static void requireFinite(double value) {
        if (!Double.isFinite(value)) throw new IllegalArgumentException("value must be finite");
    }
}


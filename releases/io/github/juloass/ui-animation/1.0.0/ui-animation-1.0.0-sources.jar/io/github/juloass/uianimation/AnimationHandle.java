package io.github.juloass.uianimation;

import java.time.Duration;
import java.util.function.Consumer;

/** A mutable owner-thread playback handle. */
public final class AnimationHandle {
    private final long id;
    private final Runnable threadCheck;
    PlaybackState state;
    Duration elapsed = Duration.ZERO;
    double speed = 1.0;
    Consumer<Duration> seeker = ignored -> { throw new IllegalStateException("handle is not attached"); };

    AnimationHandle(long id, PlaybackState state, Runnable threadCheck) {
        this.id = id; this.state = state; this.threadCheck = threadCheck;
    }
    public long id() { return id; }
    public PlaybackState state() { return state; }
    public Duration elapsed() { return elapsed; }
    public double speed() { return speed; }
    public boolean complete() { return state == PlaybackState.COMPLETE; }
    public AnimationHandle pause() { threadCheck.run(); if (state == PlaybackState.PLAYING) state = PlaybackState.PAUSED; return this; }
    public AnimationHandle resume() { threadCheck.run(); if (state == PlaybackState.PAUSED) state = PlaybackState.PLAYING; return this; }
    public AnimationHandle cancel() { threadCheck.run(); if (!complete()) state = PlaybackState.CANCELLED; return this; }
    public AnimationHandle speed(double value) {
        threadCheck.run(); if (!Double.isFinite(value) || value == 0.0) throw new IllegalArgumentException("speed must be finite and nonzero");
        speed = value; return this;
    }
    public AnimationHandle reverse() { threadCheck.run(); speed = -Math.abs(speed); return this; }
    public AnimationHandle seek(Duration position) { threadCheck.run(); seeker.accept(position); return this; }
}

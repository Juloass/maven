/** GLFW input collection for the shared input foundation. */
package io.github.juloass.input.glfw;


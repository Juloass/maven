package io.github.juloass.input.glfw;

import io.github.juloass.input.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.OptionalLong;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import org.lwjgl.glfw.*;
import org.lwjgl.system.Callback;
import org.lwjgl.system.MemoryStack;

import static org.lwjgl.glfw.GLFW.*;

/** Collects GLFW window and standard gamepad input on the owner thread. */
public final class GlfwInputSource implements AutoCloseable {
    public static final int DEFAULT_CAPACITY = 4096;
    private static final AtomicLong NEXT_SOURCE = new AtomicLong();
    private final long window;
    private final Thread ownerThread;
    private final BoundedInputCollector collector;
    private final long sourceNumber;
    private final InputDeviceId keyboardId;
    private final InputDeviceId pointerId;
    private long nextGamepadNumber;
    private final Set<KeyboardKey> heldKeys = new HashSet<>();
    private final Set<PointerButton> heldButtons = new HashSet<>();
    private final Map<KeyboardKey, LogicalKey> logicalKeys = new HashMap<>();
    private final Map<Integer, Gamepad> gamepads = new HashMap<>();
    private final GLFWKeyCallback keyCallback;
    private final GLFWCharCallback charCallback;
    private final GLFWMouseButtonCallback mouseButtonCallback;
    private final GLFWCursorPosCallback cursorCallback;
    private final GLFWScrollCallback scrollCallback;
    private final GLFWWindowFocusCallback focusCallback;
    private final GLFWKeyCallback previousKey;
    private final GLFWCharCallback previousChar;
    private final GLFWMouseButtonCallback previousMouseButton;
    private final GLFWCursorPosCallback previousCursor;
    private final GLFWScrollCallback previousScroll;
    private final GLFWWindowFocusCallback previousFocus;
    private boolean closed;

    public GlfwInputSource(long window) { this(window, DEFAULT_CAPACITY); }
    public GlfwInputSource(long window, int capacity) {
        if (window == 0L) throw new IllegalArgumentException("window must not be zero");
        this.window = window;
        sourceNumber = NEXT_SOURCE.getAndIncrement();
        keyboardId = InputDeviceId.of("glfw:keyboard_" + sourceNumber);
        pointerId = InputDeviceId.of("glfw:pointer_" + sourceNumber);
        ownerThread = Thread.currentThread();
        collector = new BoundedInputCollector(capacity);
        collector.connect(new InputDevice(keyboardId, InputDeviceClass.KEYBOARD, "GLFW keyboard"), OptionalLong.empty());
        collector.connect(new InputDevice(pointerId, InputDeviceClass.POINTER, "GLFW pointer"), OptionalLong.empty());
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var x = stack.mallocDouble(1); var y = stack.mallocDouble(1);
            glfwGetCursorPos(window, x, y);
            collector.pointer(pointerId, new InputVector2(x.get(0), y.get(0)), OptionalLong.empty());
        }

        keyCallback = GLFWKeyCallback.create(this::onKey);
        charCallback = GLFWCharCallback.create((ignored, codePoint) -> collector.text(keyboardId, codePoint, now()));
        mouseButtonCallback = GLFWMouseButtonCallback.create(this::onMouseButton);
        cursorCallback = GLFWCursorPosCallback.create((ignored, x, y) -> collector.pointer(pointerId, new InputVector2(x, y), now()));
        scrollCallback = GLFWScrollCallback.create((ignored, x, y) -> collector.scroll(pointerId, new InputVector2(x, y), now()));
        focusCallback = GLFWWindowFocusCallback.create((ignored, focused) -> { if (!focused) releaseHeld(); });
        previousKey = glfwSetKeyCallback(window, keyCallback);
        previousChar = glfwSetCharCallback(window, charCallback);
        previousMouseButton = glfwSetMouseButtonCallback(window, mouseButtonCallback);
        previousCursor = glfwSetCursorPosCallback(window, cursorCallback);
        previousScroll = glfwSetScrollCallback(window, scrollCallback);
        previousFocus = glfwSetWindowFocusCallback(window, focusCallback);
    }

    public InputPollResult poll() { requireOwner(); pollGamepads(); return collector.poll(); }
    public RawInputSnapshot snapshot() { return collector.snapshot(); }
    public InputDeviceId keyboardId() { return keyboardId; }
    public InputDeviceId pointerId() { return pointerId; }

    private void onKey(long ignored, int code, int scanCode, int action, int modifiers) {
        KeyboardKey key = key(code);
        if (key == KeyboardKey.UNKNOWN) return;
        if (action == GLFW_PRESS) {
            LogicalKey logical = logicalName(code, scanCode);
            if (logical != null) logicalKeys.put(key, logical);
            heldKeys.add(key);
            collector.button(keyboardId, key, ButtonTransitionKind.PRESS, logicalKeys.get(key), now());
        } else if (action == GLFW_REPEAT) {
            collector.button(keyboardId, key, ButtonTransitionKind.REPEAT, logicalKeys.get(key), now());
        } else if (action == GLFW_RELEASE) {
            heldKeys.remove(key);
            collector.button(keyboardId, key, ButtonTransitionKind.RELEASE, logicalKeys.remove(key), now());
        }
    }

    private void onMouseButton(long ignored, int code, int action, int modifiers) {
        PointerButton button = pointerButton(code);
        if (button == null) return;
        if (action == GLFW_PRESS) { heldButtons.add(button); collector.button(pointerId, button, ButtonTransitionKind.PRESS, null, now()); }
        else if (action == GLFW_RELEASE) { heldButtons.remove(button); collector.button(pointerId, button, ButtonTransitionKind.RELEASE, null, now()); }
    }

    private void releaseHeld() {
        OptionalLong time = now();
        for (KeyboardKey key : Set.copyOf(heldKeys)) collector.button(keyboardId, key, ButtonTransitionKind.RELEASE, logicalKeys.remove(key), time);
        for (PointerButton button : Set.copyOf(heldButtons)) collector.button(pointerId, button, ButtonTransitionKind.RELEASE, null, time);
        heldKeys.clear(); heldButtons.clear();
    }

    private void pollGamepads() {
        for (int joystick = GLFW_JOYSTICK_1; joystick <= GLFW_JOYSTICK_LAST; joystick++) {
            boolean present = glfwJoystickIsGamepad(joystick);
            Gamepad known = gamepads.get(joystick);
            if (!present) {
                if (known != null) { collector.disconnect(known.id, now()); gamepads.remove(joystick); }
                continue;
            }
            if (known == null) {
                InputDeviceId id = InputDeviceId.of("glfw:gamepad_" + sourceNumber + "_" + nextGamepadNumber++);
                String name = glfwGetGamepadName(joystick);
                known = new Gamepad(id);
                gamepads.put(joystick, known);
                collector.connect(new InputDevice(id, InputDeviceClass.GAMEPAD, name == null ? "GLFW gamepad" : name), now());
            }
            try (GLFWGamepadState state = GLFWGamepadState.calloc()) {
                if (!glfwGetGamepadState(joystick, state)) continue;
                for (int index = 0; index <= GLFW_GAMEPAD_BUTTON_LAST; index++) {
                    boolean pressed = state.buttons(index) == GLFW_PRESS;
                    if (known.buttons[index] != pressed) {
                        known.buttons[index] = pressed;
                        collector.button(known.id, GamepadButton.values()[index],
                                pressed ? ButtonTransitionKind.PRESS : ButtonTransitionKind.RELEASE, null, now());
                    }
                }
                for (int index = 0; index <= GLFW_GAMEPAD_AXIS_LAST; index++) {
                    float value = state.axes(index);
                    if (Float.compare(known.axes[index], value) != 0) {
                        known.axes[index] = value;
                        collector.axis(known.id, GamepadAxis.values()[index], value, now());
                    }
                }
            }
        }
    }

    @Override public void close() {
        if (closed) return;
        requireOwner();
        closed = true;
        free(glfwSetKeyCallback(window, previousKey));
        free(glfwSetCharCallback(window, previousChar));
        free(glfwSetMouseButtonCallback(window, previousMouseButton));
        free(glfwSetCursorPosCallback(window, previousCursor));
        free(glfwSetScrollCallback(window, previousScroll));
        free(glfwSetWindowFocusCallback(window, previousFocus));
        collector.close();
    }

    private void requireOwner() {
        if (Thread.currentThread() != ownerThread) throw new IllegalStateException("GLFW input must run on its owner thread");
        if (closed) throw new IllegalStateException("GLFW input source is closed");
    }
    private static OptionalLong now() { return OptionalLong.of(System.nanoTime()); }
    private static void free(Callback callback) { if (callback != null) callback.free(); }
    private static LogicalKey logicalName(int key, int scanCode) {
        String value = glfwGetKeyName(key, scanCode);
        return value == null || value.isBlank() ? null : new LogicalKey(value);
    }

    static PointerButton pointerButton(int button) {
        return switch (button) {
            case GLFW_MOUSE_BUTTON_LEFT -> PointerButton.PRIMARY;
            case GLFW_MOUSE_BUTTON_RIGHT -> PointerButton.SECONDARY;
            case GLFW_MOUSE_BUTTON_MIDDLE -> PointerButton.MIDDLE;
            case GLFW_MOUSE_BUTTON_4 -> PointerButton.BUTTON_4; case GLFW_MOUSE_BUTTON_5 -> PointerButton.BUTTON_5;
            case GLFW_MOUSE_BUTTON_6 -> PointerButton.BUTTON_6; case GLFW_MOUSE_BUTTON_7 -> PointerButton.BUTTON_7;
            case GLFW_MOUSE_BUTTON_8 -> PointerButton.BUTTON_8; default -> null;
        };
    }

    static KeyboardKey key(int code) {
        if (code >= GLFW_KEY_A && code <= GLFW_KEY_Z) return KeyboardKey.values()[KeyboardKey.A.ordinal() + code - GLFW_KEY_A];
        if (code >= GLFW_KEY_0 && code <= GLFW_KEY_9) return KeyboardKey.values()[KeyboardKey.DIGIT_0.ordinal() + code - GLFW_KEY_0];
        if (code >= GLFW_KEY_F1 && code <= GLFW_KEY_F12) return KeyboardKey.values()[KeyboardKey.F1.ordinal() + code - GLFW_KEY_F1];
        return switch (code) {
            case GLFW_KEY_SPACE -> KeyboardKey.SPACE; case GLFW_KEY_ESCAPE -> KeyboardKey.ESCAPE;
            case GLFW_KEY_ENTER -> KeyboardKey.ENTER; case GLFW_KEY_KP_ENTER -> KeyboardKey.KP_ENTER;
            case GLFW_KEY_TAB -> KeyboardKey.TAB;
            case GLFW_KEY_BACKSPACE -> KeyboardKey.BACKSPACE; case GLFW_KEY_INSERT -> KeyboardKey.INSERT;
            case GLFW_KEY_DELETE -> KeyboardKey.DELETE; case GLFW_KEY_RIGHT -> KeyboardKey.RIGHT;
            case GLFW_KEY_LEFT -> KeyboardKey.LEFT; case GLFW_KEY_DOWN -> KeyboardKey.DOWN; case GLFW_KEY_UP -> KeyboardKey.UP;
            case GLFW_KEY_PAGE_UP -> KeyboardKey.PAGE_UP; case GLFW_KEY_PAGE_DOWN -> KeyboardKey.PAGE_DOWN;
            case GLFW_KEY_HOME -> KeyboardKey.HOME; case GLFW_KEY_END -> KeyboardKey.END;
            case GLFW_KEY_LEFT_SHIFT -> KeyboardKey.LEFT_SHIFT; case GLFW_KEY_LEFT_CONTROL -> KeyboardKey.LEFT_CONTROL;
            case GLFW_KEY_LEFT_ALT -> KeyboardKey.LEFT_ALT; case GLFW_KEY_LEFT_SUPER -> KeyboardKey.LEFT_SUPER;
            case GLFW_KEY_RIGHT_SHIFT -> KeyboardKey.RIGHT_SHIFT; case GLFW_KEY_RIGHT_CONTROL -> KeyboardKey.RIGHT_CONTROL;
            case GLFW_KEY_RIGHT_ALT -> KeyboardKey.RIGHT_ALT; case GLFW_KEY_RIGHT_SUPER -> KeyboardKey.RIGHT_SUPER;
            case GLFW_KEY_COMMA -> KeyboardKey.COMMA; case GLFW_KEY_MINUS -> KeyboardKey.MINUS;
            case GLFW_KEY_PERIOD -> KeyboardKey.PERIOD; case GLFW_KEY_SLASH -> KeyboardKey.SLASH;
            case GLFW_KEY_SEMICOLON -> KeyboardKey.SEMICOLON; case GLFW_KEY_EQUAL -> KeyboardKey.EQUAL;
            case GLFW_KEY_LEFT_BRACKET -> KeyboardKey.LEFT_BRACKET; case GLFW_KEY_BACKSLASH -> KeyboardKey.BACKSLASH;
            case GLFW_KEY_RIGHT_BRACKET -> KeyboardKey.RIGHT_BRACKET; case GLFW_KEY_GRAVE_ACCENT -> KeyboardKey.GRAVE_ACCENT;
            default -> KeyboardKey.UNKNOWN;
        };
    }

    private static final class Gamepad {
        private final InputDeviceId id;
        private final boolean[] buttons = new boolean[GLFW_GAMEPAD_BUTTON_LAST + 1];
        private final float[] axes = new float[GLFW_GAMEPAD_AXIS_LAST + 1];
        private Gamepad(InputDeviceId id) { this.id = id; Arrays.fill(axes, Float.NaN); }
    }
}

package io.github.juloass.navigation.grid;

import java.util.ArrayDeque;
import java.util.Collection;

public final class WaypointFollower {
    public record Direction(float x,float z,boolean moving,boolean finished){}
    private final ArrayDeque<GridPathfinder.Step> steps=new ArrayDeque<>();
    public void setPath(Collection<GridPathfinder.Step> next){steps.clear();steps.addAll(next);}
    public void clear(){steps.clear();}
    public boolean finished(){return steps.isEmpty();}
    public Direction direction(float x,float z,float radius){
        while(!steps.isEmpty()){GridPathfinder.Step s=steps.peekFirst();float dx=s.x()-x,dz=s.z()-z,length=(float)Math.sqrt(dx*dx+dz*dz);
            if(length<=radius){steps.removeFirst();continue;}return new Direction(dx/length,dz/length,true,false);}
        return new Direction(0,0,false,true);
    }
}

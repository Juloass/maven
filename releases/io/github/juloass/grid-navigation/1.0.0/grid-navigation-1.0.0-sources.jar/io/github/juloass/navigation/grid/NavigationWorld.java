package io.github.juloass.navigation.grid;

@FunctionalInterface
public interface NavigationWorld {
    Float walkableHeight(int cellX, int cellZ, float fromY);

    default boolean segmentClear(float fromX,float fromY,float fromZ,float toX,float toY,float toZ,float maxStepHeight){
        return segmentClear(fromX, fromY, fromZ, toX, toY, toZ, maxStepHeight, maxStepHeight);
    }

    default boolean segmentClear(float fromX,float fromY,float fromZ,float toX,float toY,float toZ,
                                 float maxClimbHeight,float maxDropHeight){
        float dx=toX-fromX,dz=toZ-fromZ;
        float distance=(float)Math.sqrt(dx*dx+dz*dz);
        int samples=Math.max(1,(int)Math.ceil(distance*4.0f));
        float previousY=fromY;
        for(int i=1;i<=samples;i++){
            float t=i/(float)samples;
            int x=(int)Math.floor(fromX+dx*t),z=(int)Math.floor(fromZ+dz*t);
            Float y=walkableHeight(x,z,previousY);
            if(y==null||!traversableHeightChange(previousY,y,maxClimbHeight,maxDropHeight))return false;
            previousY=y;
        }
        return traversableHeightChange(previousY,toY,maxClimbHeight,maxDropHeight);
    }

    private static boolean traversableHeightChange(float fromY,float toY,float maxClimbHeight,float maxDropHeight){
        float change=toY-fromY;
        return change<=maxClimbHeight&&change>=-maxDropHeight;
    }
}

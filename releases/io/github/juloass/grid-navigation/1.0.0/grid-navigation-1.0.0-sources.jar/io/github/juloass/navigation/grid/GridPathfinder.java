package io.github.juloass.navigation.grid;

import java.util.*;
import java.util.function.BooleanSupplier;

public final class GridPathfinder {
    public enum Status {
        COMPLETE, PARTIAL_EXPANSION_LIMIT, CANCELLED,
        FAILED_INVALID_START, FAILED_BLOCKED_DESTINATION, FAILED_NO_ROUTE
    }
    public record Step(float x, float y, float z) {}
    public record Result(List<Step> steps, Status status, int expansions) { public Result { steps=List.copyOf(steps); } }
    private static final int[] OFFSETS={1,0,-1,0,0,1,0,-1,1,1,1,-1,-1,1,-1,-1};
    private GridPathfinder() {}
    public static Result find(NavigationWorld world,int sx,int sz,float sy,int gx,int gz,float tx,float tz,
                              float maxStep,int maxDistance,int maxExpansions) {
        return find(world, sx, sz, sy, gx, gz, tx, tz,
                maxStep, maxStep, maxDistance, maxExpansions, () -> false);
    }

    public static Result find(NavigationWorld world,int sx,int sz,float sy,int gx,int gz,float tx,float tz,
                              float maxStep,int maxDistance,int maxExpansions,BooleanSupplier cancelled) {
        return find(world, sx, sz, sy, gx, gz, tx, tz,
                maxStep, maxStep, maxDistance, maxExpansions, cancelled);
    }

    public static Result find(NavigationWorld world,int sx,int sz,float sy,int gx,int gz,float tx,float tz,
                              float maxClimb,float maxDrop,int maxDistance,int maxExpansions) {
        return find(world, sx, sz, sy, gx, gz, tx, tz,
                maxClimb, maxDrop, maxDistance, maxExpansions, () -> false);
    }

    public static Result find(NavigationWorld world,int sx,int sz,float sy,int gx,int gz,float tx,float tz,
                              float maxClimb,float maxDrop,int maxDistance,int maxExpansions,
                              BooleanSupplier cancelled) {
        Objects.requireNonNull(cancelled, "cancelled");
        if(cancelled.getAsBoolean())return new Result(List.of(),Status.CANCELLED,0);
        Float resolvedStartY=world.walkableHeight(sx,sz,sy);
        if(resolvedStartY==null)return new Result(List.of(),Status.FAILED_INVALID_START,0);
        PriorityQueue<Node> open=new PriorityQueue<>(Comparator.comparingDouble(Node::score));
        Map<Cell,Float> costs=new HashMap<>();
        Node start=new Node(sx,sz,resolvedStartY,0,heuristic(sx,sz,gx,gz),null),best=start,found=null;
        open.add(start);costs.put(cell(sx,sz,resolvedStartY),0f);int expansions=0;
        boolean goalHeightSampled=false,goalHeightFound=false;
        while(!open.isEmpty()&&expansions++<maxExpansions){
            if(cancelled.getAsBoolean())return new Result(List.of(),Status.CANCELLED,expansions);
            Node node=open.poll();
            if(heuristic(node.x,node.z,gx,gz)<heuristic(best.x,best.z,gx,gz))best=node;
            if(node.x==gx&&node.z==gz){found=node;break;}
            for(int i=0;i<OFFSETS.length;i+=2){
                if(cancelled.getAsBoolean())return new Result(List.of(),Status.CANCELLED,expansions);
                int nx=node.x+OFFSETS[i],nz=node.z+OFFSETS[i+1];
                if(Math.abs(nx-sx)+Math.abs(nz-sz)>maxDistance)continue;
                Float ny=world.walkableHeight(nx,nz,node.y);
                if(nx==gx&&nz==gz){
                    goalHeightSampled=true;
                    goalHeightFound|=ny!=null;
                }
                if(ny==null||!traversableHeightChange(node.y,ny,maxClimb,maxDrop))continue;
                boolean diagonal=OFFSETS[i]!=0&&OFFSETS[i+1]!=0;
                if(diagonal){
                    Float sideX=world.walkableHeight(node.x+OFFSETS[i],node.z,node.y);
                    Float sideZ=world.walkableHeight(node.x,node.z+OFFSETS[i+1],node.y);
                    if(sideX==null||sideZ==null
                            ||!traversableHeightChange(node.y,sideX,maxClimb,maxDrop)
                            ||!traversableHeightChange(node.y,sideZ,maxClimb,maxDrop))continue;
                }
                Node parent=node;
                float cost=node.cost+(diagonal?1.4142135f:1f)+Math.abs(ny-node.y)*.25f;
                if(node.parent!=null&&world.segmentClear(node.parent.x+.5f,node.parent.y,node.parent.z+.5f,
                        nx+.5f,ny,nz+.5f,maxClimb,maxDrop)){
                    parent=node.parent;float dx=nx+.5f-(parent.x+.5f),dz=nz+.5f-(parent.z+.5f);
                    cost=parent.cost+(float)Math.sqrt(dx*dx+dz*dz)+Math.abs(ny-parent.y)*.25f;
                }
                Cell nextCell=cell(nx,nz,ny);
                if(cost>=costs.getOrDefault(nextCell,Float.POSITIVE_INFINITY))continue;
                costs.put(nextCell,cost);open.add(new Node(nx,nz,ny,cost,cost+heuristic(nx,nz,gx,gz),parent));
            }
        }
        Node end=found==null?best:found;
        if(end==start)return new Result(List.of(),
                goalHeightSampled&&!goalHeightFound?Status.FAILED_BLOCKED_DESTINATION:Status.FAILED_NO_ROUTE,
                expansions);
        ArrayDeque<Step> reverse=new ArrayDeque<>();for(Node n=end;n.parent!=null;n=n.parent)reverse.addFirst(new Step(n.x+.5f,n.y,n.z+.5f));
        ArrayList<Step> steps=new ArrayList<>(reverse);
        if(found!=null&&!steps.isEmpty()){Step last=steps.getLast();steps.set(steps.size()-1,new Step(tx,last.y,tz));}
        return new Result(steps,found==null?Status.PARTIAL_EXPANSION_LIMIT:Status.COMPLETE,expansions);
    }
    private static boolean traversableHeightChange(float fromY,float toY,float maxClimb,float maxDrop){
        float change=toY-fromY;
        return change<=maxClimb&&change>=-maxDrop;
    }
    private static Cell cell(int x,int z,float y){return new Cell(x,z,Math.round(y*256.0f));}
    private static float heuristic(int x,int z,int gx,int gz){float dx=gx-x,dz=gz-z;return(float)Math.sqrt(dx*dx+dz*dz);}
    private record Cell(int x,int z,int heightKey){}
    private record Node(int x,int z,float y,float cost,float score,Node parent){}
}

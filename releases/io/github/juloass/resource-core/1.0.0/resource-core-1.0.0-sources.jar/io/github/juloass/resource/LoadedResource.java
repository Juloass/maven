package io.github.juloass.resource;

import java.util.List;
import java.util.Objects;

/** One detached typed value with its contributing origins. */
public record LoadedResource<T>(
        ResourceKey<T> key,
        T value,
        long generation,
        List<ResourceOrigin> origins,
        ResourceMetadata metadata
) {
    public LoadedResource {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(value, "value");
        Objects.requireNonNull(origins, "origins");
        Objects.requireNonNull(metadata, "metadata");
        origins = List.copyOf(origins);
        if (generation < 0 || origins.isEmpty()) {
            throw new IllegalArgumentException("Loaded resource needs a generation and origin");
        }
    }
}

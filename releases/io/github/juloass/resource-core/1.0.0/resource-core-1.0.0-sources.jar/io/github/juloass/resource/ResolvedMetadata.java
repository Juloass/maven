package io.github.juloass.resource;

import java.util.List;
import java.util.Objects;

/** One resolved typed metadata value with its complete provenance. */
public record ResolvedMetadata<T>(T value, List<ResourceOrigin> origins) {
    public ResolvedMetadata {
        Objects.requireNonNull(value, "value");
        Objects.requireNonNull(origins, "origins");
        origins = List.copyOf(origins);
        if (origins.isEmpty()) throw new IllegalArgumentException("Metadata needs an origin");
    }
}

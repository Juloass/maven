package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Versioned input for one metadata section decoder. */
public record MetadataSectionInput(
        Identifier sectionId,
        int version,
        MetadataValue.ObjectValue data,
        String source
) {
    public MetadataSectionInput {
        Objects.requireNonNull(sectionId, "sectionId");
        Objects.requireNonNull(data, "data");
        Objects.requireNonNull(source, "source");
        if (version <= 0) throw new IllegalArgumentException("Metadata version must be positive");
    }
}

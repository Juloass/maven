package io.github.juloass.resource;

import java.util.List;
import java.util.Objects;

/** Base exception for structured resource failures. */
public class ResourceException extends RuntimeException {
    private final List<ResourceProblem> problems;

    public ResourceException(ResourceProblem problem) {
        this(List.of(Objects.requireNonNull(problem, "problem")));
    }

    public ResourceException(List<ResourceProblem> problems) {
        super(message(problems), firstCause(problems));
        if (problems == null || problems.isEmpty()) {
            throw new IllegalArgumentException("At least one resource problem is required");
        }
        this.problems = List.copyOf(problems);
    }

    public List<ResourceProblem> problems() {
        return problems;
    }

    private static String message(List<ResourceProblem> problems) {
        if (problems == null || problems.isEmpty()) return "Resource operation failed";
        return problems.getFirst().message();
    }

    private static Throwable firstCause(List<ResourceProblem> problems) {
        if (problems == null || problems.isEmpty()) return null;
        return problems.getFirst().cause().orElse(null);
    }
}

package io.github.juloass.resource;

import java.util.List;
import java.util.Optional;

/** Pinned context used by typed resource loaders. */
public interface ResourceLoadContext {
    long generation();
    <T> LoadedResource<T> load(ResourceKey<T> key);
    Optional<Resource> findRaw(ResourcePath path);
    List<Resource> rawStack(ResourcePath path);
}

package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Identifies one typed logical resource. */
public record ResourceKey<T>(
        ResourceType<T> type,
        Identifier id
) {
    public ResourceKey {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(id, "id");
    }

    public ResourcePath path() {
        return type.pathPattern().map(type.domain(), id);
    }
}
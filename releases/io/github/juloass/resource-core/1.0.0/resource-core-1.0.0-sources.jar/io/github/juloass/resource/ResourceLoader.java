package io.github.juloass.resource;

/** Decodes one selected resource. */
@FunctionalInterface
public interface ResourceLoader<T> {
    T load(ResourceLoadContext context, Resource resource)
            throws Exception;
}
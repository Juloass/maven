package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/** Identifies one exact logical file in one resource domain. */
public record ResourcePath(
        ResourceDomain domain,
        Identifier identifier,
        String extension
) implements Comparable<ResourcePath> {
    private static final Pattern EXTENSION =
            Pattern.compile("\\.[a-z0-9][a-z0-9_.-]*");

    public ResourcePath {
        Objects.requireNonNull(domain, "domain");
        Objects.requireNonNull(identifier, "identifier");
        Objects.requireNonNull(extension, "extension");
        if (!EXTENSION.matcher(extension).matches()) {
            throw new IllegalArgumentException(
                    "Invalid resource extension: " + extension);
        }
    }

    public static ResourcePath of(
            ResourceDomain domain,
            Identifier identifier,
            String extension
    ) {
        return new ResourcePath(domain, identifier, extension);
    }

    public static ResourcePath of(
            ResourceDomain domain,
            String namespace,
            String path
    ) {
        Objects.requireNonNull(path, "path");
        int separator = path.lastIndexOf('/');
        int extensionStart = path.indexOf('.', separator + 1);
        if (extensionStart <= separator + 1) {
            throw new IllegalArgumentException(
                    "Resource path requires a file extension: " + path);
        }
        return of(
                domain,
                Identifier.of(namespace, path.substring(0, extensionStart)),
                path.substring(extensionStart));
    }

    public static ResourcePath parse(
            ResourceDomain domain,
            String value
    ) {
        Objects.requireNonNull(value, "value");
        int separator = value.indexOf(':');
        if (separator <= 0
                || separator == value.length() - 1
                || value.indexOf(':', separator + 1) >= 0) {
            throw new IllegalArgumentException(
                    "Invalid resource path: " + value);
        }
        return of(
                domain,
                value.substring(0, separator),
                value.substring(separator + 1));
    }

    public static Optional<ResourcePath> tryParse(
            ResourceDomain domain,
            String value
    ) {
        if (domain == null || value == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(parse(domain, value));
        } catch (IllegalArgumentException exception) {
            return Optional.empty();
        }
    }

    public String namespace() {
        return identifier.namespace();
    }

    public String path() {
        return identifier.path() + extension;
    }

    public String value() {
        return domain.name() + ' ' + namespace() + ':' + path();
    }

    public ResourcePath withPath(String path) {
        return of(domain, namespace(), path);
    }

    @Override
    public int compareTo(ResourcePath other) {
        Objects.requireNonNull(other, "other");
        int domainOrder = domain.compareTo(other.domain);
        if (domainOrder != 0) {
            return domainOrder;
        }
        int identifierOrder = identifier.compareTo(other.identifier);
        return identifierOrder != 0
                ? identifierOrder
                : extension.compareTo(other.extension);
    }

    @Override
    public String toString() {
        return value();
    }
}
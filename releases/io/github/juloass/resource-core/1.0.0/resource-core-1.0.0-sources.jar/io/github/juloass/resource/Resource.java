package io.github.juloass.resource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.OptionalLong;

/** Represents one resolved resource in an immutable generation. */
public interface Resource {
    ResourcePath path();

    ResourceOrigin origin();

    ResourceMetadata metadata();

    OptionalLong size();

    /**
     * Opens a fresh stream for this resource.
     *
     * @return an independent stream
     * @throws IOException when the source cannot open the stream
     */
    InputStream openStream() throws IOException;

    default byte[] readAllBytes(long maximumBytes) throws IOException {
        if (maximumBytes < 0) {
            throw new IllegalArgumentException(
                    "maximumBytes must be non-negative");
        }
        OptionalLong knownSize = size();
        if (knownSize.isPresent()
                && knownSize.getAsLong() > maximumBytes) {
            throw new IOException(
                    "Resource exceeds " + maximumBytes
                            + " bytes: " + path());
        }
        try (InputStream input = openStream();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            long total = 0;
            for (int count; (count = input.read(buffer)) >= 0; ) {
                total += count;
                if (total > maximumBytes) {
                    throw new IOException(
                            "Resource exceeds " + maximumBytes
                                    + " bytes: " + path());
                }
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        }
    }

    default ByteBuffer readByteBuffer(long maximumBytes)
            throws IOException {
        return ByteBuffer.wrap(readAllBytes(maximumBytes))
                .asReadOnlyBuffer();
    }

    default String readUtf8(long maximumBytes) throws IOException {
        byte[] bytes = readAllBytes(maximumBytes);
        String value = new String(bytes, StandardCharsets.UTF_8);
        return value.startsWith("﻿")
                ? value.substring(1)
                : value;
    }
}
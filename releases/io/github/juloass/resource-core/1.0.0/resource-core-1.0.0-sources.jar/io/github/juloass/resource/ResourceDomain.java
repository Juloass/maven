package io.github.juloass.resource;

/** A structural root inside a resource pack. */
public enum ResourceDomain {
    ASSETS("assets"),
    DATA("data");

    private final String directory;

    ResourceDomain(String directory) {
        this.directory = directory;
    }

    /** Returns the physical root directory. */
    public String directory() {
        return directory;
    }
}

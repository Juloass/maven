package io.github.juloass.resource;

import java.util.Objects;
import java.util.Optional;

/** One structured resource failure. */
public record ResourceProblem(
        Code code,
        String source,
        String message,
        Optional<ResourcePath> path,
        Optional<Throwable> cause
) {
    public enum Code {
        INVALID_PACK,
        UNSUPPORTED_JSON_SYNTAX,
        DUPLICATE_PACK,
        INVALID_NAMESPACE,
        INVALID_PATH,
        DUPLICATE_ENTRY,
        CASE_COLLISION,
        PATH_TRAVERSAL,
        READ_FAILURE,
        SIZE_LIMIT,
        MISSING_RESOURCE,
        INVALID_METADATA,
        UNKNOWN_METADATA_SECTION,
        UNSUPPORTED_METADATA_VERSION,
        MISSING_METADATA,
        TYPE_MISMATCH,
        LOAD_FAILURE,
        DEPENDENCY_CYCLE,
        RELOAD_FAILURE,
        CLOSED_MANAGER
    }

    public ResourceProblem {
        Objects.requireNonNull(code, "code");
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(message, "message");
        path = path == null ? Optional.empty() : path;
        cause = cause == null ? Optional.empty() : cause;
    }

    public static ResourceProblem of(Code code, String source, String message) {
        return new ResourceProblem(code, source, message, Optional.empty(), Optional.empty());
    }
}

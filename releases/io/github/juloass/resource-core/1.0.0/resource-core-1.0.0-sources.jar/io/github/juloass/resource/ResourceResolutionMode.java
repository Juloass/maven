package io.github.juloass.resource;

/** Selection rule for one typed resource. */
public enum ResourceResolutionMode {
    REPLACE,
    LAYERED
}

package io.github.juloass.resource;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Library-owned immutable JSON value used by metadata decoders. */
public sealed interface MetadataValue permits MetadataValue.ObjectValue,
        MetadataValue.ArrayValue, MetadataValue.StringValue,
        MetadataValue.NumberValue, MetadataValue.BooleanValue,
        MetadataValue.NullValue {

    record ObjectValue(Map<String, MetadataValue> values) implements MetadataValue {
        public ObjectValue {
            Objects.requireNonNull(values, "values");
            values = Map.copyOf(values);
        }

        public MetadataValue require(String name) {
            MetadataValue value = values.get(name);
            if (value == null) throw new IllegalArgumentException("Missing metadata field " + name);
            return value;
        }
    }

    record ArrayValue(List<MetadataValue> values) implements MetadataValue {
        public ArrayValue {
            Objects.requireNonNull(values, "values");
            values = List.copyOf(values);
        }
    }

    record StringValue(String value) implements MetadataValue {
        public StringValue { Objects.requireNonNull(value, "value"); }
    }

    record NumberValue(BigDecimal value) implements MetadataValue {
        public NumberValue { Objects.requireNonNull(value, "value"); }
    }

    record BooleanValue(boolean value) implements MetadataValue { }

    enum NullValue implements MetadataValue { INSTANCE }
}

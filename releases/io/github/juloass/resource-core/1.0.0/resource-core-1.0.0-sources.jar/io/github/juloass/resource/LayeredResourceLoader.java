package io.github.juloass.resource;

import java.util.List;

/** Decodes resource contributions in low-to-high order. */
@FunctionalInterface
public interface LayeredResourceLoader<T> {
    T load(ResourceLoadContext context, List<Resource> resources)
            throws Exception;
}
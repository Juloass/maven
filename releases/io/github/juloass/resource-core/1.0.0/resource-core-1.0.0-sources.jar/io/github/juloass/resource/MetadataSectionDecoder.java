package io.github.juloass.resource;

/** Decodes one metadata section without exposing a JSON library. */
@FunctionalInterface
public interface MetadataSectionDecoder<T> {
    T decode(MetadataSectionInput input) throws Exception;
}

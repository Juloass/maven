package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** Immutable mapping and decoder for one resource value type. */
public final class ResourceType<T> {
    private final Identifier id;
    private final Class<T> valueType;
    private final ResourceDomain domain;
    private final ResourcePathPattern pathPattern;
    private final ResourceResolutionMode resolutionMode;
    private final ResourceLoader<T> loader;
    private final LayeredResourceLoader<T> layeredLoader;
    private final Set<MetadataSectionType<?>> optionalMetadata;
    private final Set<MetadataSectionType<?>> requiredMetadata;

    private ResourceType(Builder<T> builder) {
        id = builder.id;
        valueType = builder.valueType;
        domain = Objects.requireNonNull(builder.domain, "domain");
        pathPattern = Objects.requireNonNull(builder.pathPattern, "pathPattern");
        resolutionMode = Objects.requireNonNull(builder.resolutionMode, "resolutionMode");
        loader = builder.loader;
        layeredLoader = builder.layeredLoader;
        optionalMetadata = Set.copyOf(builder.optionalMetadata);
        requiredMetadata = Set.copyOf(builder.requiredMetadata);
        LinkedHashSet<MetadataSectionType<?>> overlap = new LinkedHashSet<>(optionalMetadata);
        overlap.retainAll(requiredMetadata);
        if (!overlap.isEmpty()) throw new IllegalArgumentException("Metadata cannot be optional and required");
    }

    public static <T> Builder<T> builder(Identifier id, Class<T> valueType) {
        return new Builder<>(id, valueType);
    }

    public Identifier id() { return id; }
    public Class<T> valueType() { return valueType; }
    public ResourceDomain domain() { return domain; }
    public ResourcePathPattern pathPattern() { return pathPattern; }
    public ResourceResolutionMode resolutionMode() { return resolutionMode; }
    public Optional<ResourceLoader<T>> loader() { return Optional.ofNullable(loader); }
    public Optional<LayeredResourceLoader<T>> layeredLoader() { return Optional.ofNullable(layeredLoader); }
    public Set<MetadataSectionType<?>> optionalMetadata() { return optionalMetadata; }
    public Set<MetadataSectionType<?>> requiredMetadata() { return requiredMetadata; }
    public ResourceKey<T> key(Identifier id) { return new ResourceKey<>(this, id); }

    public static final class Builder<T> {
        private final Identifier id;
        private final Class<T> valueType;
        private ResourceDomain domain;
        private ResourcePathPattern pathPattern;
        private ResourceResolutionMode resolutionMode;
        private ResourceLoader<T> loader;
        private LayeredResourceLoader<T> layeredLoader;
        private final Set<MetadataSectionType<?>> optionalMetadata = new LinkedHashSet<>();
        private final Set<MetadataSectionType<?>> requiredMetadata = new LinkedHashSet<>();

        private Builder(Identifier id, Class<T> valueType) {
            this.id = Objects.requireNonNull(id, "id");
            this.valueType = Objects.requireNonNull(valueType, "valueType");
        }

        public Builder<T> domain(ResourceDomain domain) {
            this.domain = Objects.requireNonNull(domain, "domain");
            return this;
        }

        public Builder<T> path(String directory, String extension) {
            pathPattern = ResourcePathPattern.of(directory, extension);
            return this;
        }

        public Builder<T> replaceWith(ResourceLoader<T> loader) {
            resolutionMode = ResourceResolutionMode.REPLACE;
            this.loader = Objects.requireNonNull(loader, "loader");
            layeredLoader = null;
            return this;
        }

        public Builder<T> layerWith(LayeredResourceLoader<T> loader) {
            resolutionMode = ResourceResolutionMode.LAYERED;
            layeredLoader = Objects.requireNonNull(loader, "loader");
            this.loader = null;
            return this;
        }

        public Builder<T> optionalMetadata(MetadataSectionType<?> type) {
            optionalMetadata.add(Objects.requireNonNull(type, "type"));
            return this;
        }

        public Builder<T> requiredMetadata(MetadataSectionType<?> type) {
            requiredMetadata.add(Objects.requireNonNull(type, "type"));
            return this;
        }

        public ResourceType<T> build() {
            if (resolutionMode == null) throw new IllegalStateException("A resource loader is required");
            return new ResourceType<>(this);
        }
    }
}

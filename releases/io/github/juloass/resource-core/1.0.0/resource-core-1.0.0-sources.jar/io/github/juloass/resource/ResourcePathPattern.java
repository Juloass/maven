package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/** Maps an extensionless identifier to an exact resource path. */
public record ResourcePathPattern(String directory, String extension) {
    private static final Pattern DIRECTORY =
            Pattern.compile("[a-z0-9_-]+(?:/[a-z0-9_-]+)*");
    private static final Pattern EXTENSION =
            Pattern.compile("\\.[a-z0-9][a-z0-9_.-]*");

    public ResourcePathPattern {
        Objects.requireNonNull(directory, "directory");
        Objects.requireNonNull(extension, "extension");
        if (!directory.isEmpty()
                && !DIRECTORY.matcher(directory).matches()) {
            throw new IllegalArgumentException(
                    "Invalid resource directory: " + directory);
        }
        if (!EXTENSION.matcher(extension).matches()) {
            throw new IllegalArgumentException(
                    "Invalid resource extension: " + extension);
        }
    }

    public static ResourcePathPattern of(
            String directory,
            String extension
    ) {
        return new ResourcePathPattern(directory, extension);
    }

    public ResourcePath map(
            ResourceDomain domain,
            Identifier id
    ) {
        Objects.requireNonNull(domain, "domain");
        Objects.requireNonNull(id, "id");
        String prefix = directory.isEmpty() ? "" : directory + '/';
        Identifier pathId = Identifier.of(
                id.namespace(), prefix + id.path());
        return ResourcePath.of(domain, pathId, extension);
    }

    public Optional<Identifier> reverse(ResourcePath path) {
        Objects.requireNonNull(path, "path");
        String prefix = directory.isEmpty() ? "" : directory + '/';
        if (!path.identifier().path().startsWith(prefix)
                || !path.extension().equals(extension)) {
            return Optional.empty();
        }
        String logical = path.identifier().path().substring(
                prefix.length());
        try {
            return Optional.of(Identifier.of(path.namespace(), logical));
        } catch (IllegalArgumentException exception) {
            return Optional.empty();
        }
    }
}
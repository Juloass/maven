package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Identifies one source level in a resource provenance chain. */
public record ResourceSourceOrigin(
        Identifier sourceId,
        int sourceOrder,
        String sourceDescription
) {
    public ResourceSourceOrigin {
        Objects.requireNonNull(sourceId, "sourceId");
        Objects.requireNonNull(sourceDescription, "sourceDescription");
        if (sourceOrder < 0) {
            throw new IllegalArgumentException(
                    "sourceOrder must be non-negative");
        }
    }
}
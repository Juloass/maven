package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Immutable typed metadata attached to one resolved resource. */
public final class ResourceMetadata {
    public static final ResourceMetadata EMPTY = new ResourceMetadata(Map.of(), Map.of());

    private final Map<MetadataSectionType<?>, ResolvedMetadata<?>> resolved;
    private final Map<Identifier, MetadataValue> preserved;

    public ResourceMetadata(
            Map<MetadataSectionType<?>, ResolvedMetadata<?>> resolved,
            Map<Identifier, MetadataValue> preserved
    ) {
        this.resolved = Map.copyOf(resolved);
        this.preserved = Map.copyOf(preserved);
    }

    @SuppressWarnings("unchecked")
    public <T> Optional<ResolvedMetadata<T>> find(MetadataSectionType<T> type) {
        return Optional.ofNullable((ResolvedMetadata<T>) resolved.get(type));
    }

    public <T> ResolvedMetadata<T> require(MetadataSectionType<T> type) {
        return find(type).orElseThrow(() -> new IllegalArgumentException(
                "Missing metadata section " + type.id()));
    }

    public Set<Identifier> sectionIds() {
        java.util.TreeSet<Identifier> ids = new java.util.TreeSet<>(preserved.keySet());
        resolved.keySet().forEach(type -> ids.add(type.id()));
        return Set.copyOf(ids);
    }

    public Map<Identifier, MetadataValue> preservedSections() {
        return preserved;
    }
}

package io.github.juloass.resource;

/** Resolution policy for one typed metadata section. */
public enum MetadataLayerPolicy {
    LOCAL_ONLY,
    INHERIT_IF_ABSENT,
    MERGE
}

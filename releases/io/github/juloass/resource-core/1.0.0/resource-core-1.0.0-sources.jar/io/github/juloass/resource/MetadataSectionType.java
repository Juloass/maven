package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** Runtime type and decoder for one versioned metadata section. */
public final class MetadataSectionType<T> {
    private final Identifier id;
    private final Class<T> valueType;
    private final Set<Integer> supportedVersions;
    private final MetadataLayerPolicy layerPolicy;
    private final MetadataSectionDecoder<T> decoder;
    private final MetadataSectionMerger<T> merger;

    private MetadataSectionType(Builder<T> builder) {
        id = builder.id;
        valueType = builder.valueType;
        supportedVersions = Set.copyOf(builder.supportedVersions);
        layerPolicy = builder.layerPolicy;
        decoder = builder.decoder;
        merger = builder.merger;
        if (supportedVersions.isEmpty() || supportedVersions.stream().anyMatch(value -> value == null || value <= 0)) {
            throw new IllegalArgumentException("Metadata versions must be positive");
        }
        if (layerPolicy == MetadataLayerPolicy.MERGE && merger == null) {
            throw new IllegalArgumentException("MERGE metadata requires a merger");
        }
    }

    public static <T> Builder<T> builder(Identifier id, Class<T> valueType) {
        return new Builder<>(id, valueType);
    }

    public Identifier id() { return id; }
    public Class<T> valueType() { return valueType; }
    public Set<Integer> supportedVersions() { return supportedVersions; }
    public MetadataLayerPolicy layerPolicy() { return layerPolicy; }
    public MetadataSectionDecoder<T> decoder() { return decoder; }
    public Optional<MetadataSectionMerger<T>> merger() { return Optional.ofNullable(merger); }

    public static final class Builder<T> {
        private final Identifier id;
        private final Class<T> valueType;
        private Set<Integer> supportedVersions = Set.of(1);
        private MetadataLayerPolicy layerPolicy = MetadataLayerPolicy.LOCAL_ONLY;
        private MetadataSectionDecoder<T> decoder;
        private MetadataSectionMerger<T> merger;

        private Builder(Identifier id, Class<T> valueType) {
            this.id = Objects.requireNonNull(id, "id");
            this.valueType = Objects.requireNonNull(valueType, "valueType");
        }

        public Builder<T> versions(Set<Integer> versions) {
            supportedVersions = Set.copyOf(Objects.requireNonNull(versions, "versions"));
            return this;
        }

        public Builder<T> decoder(MetadataSectionDecoder<T> decoder) {
            this.decoder = Objects.requireNonNull(decoder, "decoder");
            return this;
        }

        public Builder<T> inheritIfAbsent() {
            layerPolicy = MetadataLayerPolicy.INHERIT_IF_ABSENT;
            merger = null;
            return this;
        }

        public Builder<T> mergeWith(MetadataSectionMerger<T> merger) {
            layerPolicy = MetadataLayerPolicy.MERGE;
            this.merger = Objects.requireNonNull(merger, "merger");
            return this;
        }

        public MetadataSectionType<T> build() {
            Objects.requireNonNull(decoder, "decoder");
            return new MetadataSectionType<>(this);
        }
    }
}

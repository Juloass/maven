/**
 * Renderer-independent resource values, typed keys, metadata contracts, and
 * structured failures.
 */
package io.github.juloass.resource;

package io.github.juloass.resource;

import java.util.List;

/** Merges typed metadata contributions in low-to-high order. */
@FunctionalInterface
public interface MetadataSectionMerger<T> {
    T merge(List<MetadataContribution<T>> contributions) throws Exception;
}

package io.github.juloass.resource;

import java.util.Objects;

/** One typed metadata value and its origin. */
public record MetadataContribution<T>(T value, ResourceOrigin origin) {
    public MetadataContribution {
        Objects.requireNonNull(value, "value");
        Objects.requireNonNull(origin, "origin");
    }
}

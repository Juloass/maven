package io.github.juloass.resource;

import java.util.List;
import java.util.Objects;

/** The selected resource and the lower resources that it shadows. */
public record ResolvedResource(Resource selected, List<Resource> shadowed) {
    public ResolvedResource {
        Objects.requireNonNull(selected, "selected");
        Objects.requireNonNull(shadowed, "shadowed");
        shadowed = List.copyOf(shadowed);
    }
}

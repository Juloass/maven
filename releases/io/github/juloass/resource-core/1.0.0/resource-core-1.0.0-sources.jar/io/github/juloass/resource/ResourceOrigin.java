package io.github.juloass.resource;

import io.github.juloass.identifier.Identifier;

import java.util.List;
import java.util.Objects;

/** Contains the complete provenance of one resolved resource. */
public record ResourceOrigin(
        Identifier packId,
        String packDescription,
        int packFormat,
        int packOrder,
        List<ResourceSourceOrigin> sources,
        ResourcePath path,
        long generation
) {
    public ResourceOrigin {
        Objects.requireNonNull(packId, "packId");
        Objects.requireNonNull(packDescription, "packDescription");
        Objects.requireNonNull(sources, "sources");
        Objects.requireNonNull(path, "path");
        sources = List.copyOf(sources);
        if (packFormat < 0 || packOrder < 0 || generation < 0) {
            throw new IllegalArgumentException(
                    "Resource origin numbers must be non-negative");
        }
        if (sources.isEmpty()) {
            throw new IllegalArgumentException(
                    "Resource origin requires a source");
        }
    }

    public Identifier sourceId() {
        return sources.getLast().sourceId();
    }

    public int sourceOrder() {
        return sources.getLast().sourceOrder();
    }

    public String physicalSource() {
        return sources.getLast().sourceDescription();
    }

    public ResourceDomain domain() {
        return path.domain();
    }
}
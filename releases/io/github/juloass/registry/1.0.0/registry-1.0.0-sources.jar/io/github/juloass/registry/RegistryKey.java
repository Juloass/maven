package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Identifies one registry and declares its runtime value type. */
public record RegistryKey<T>(Identifier id, Class<T> valueType)
        implements Comparable<RegistryKey<?>> {
    public RegistryKey {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(valueType, "valueType");
    }

    /** Creates a key from an identifier. */
    public static <T> RegistryKey<T> of(Identifier id, Class<T> valueType) {
        return new RegistryKey<>(id, valueType);
    }

    /** Parses an identifier and creates a key. */
    public static <T> RegistryKey<T> of(String id, Class<T> valueType) {
        return new RegistryKey<>(Identifier.parse(id), valueType);
    }

    @Override
    public int compareTo(RegistryKey<?> other) {
        Objects.requireNonNull(other, "other");
        int idResult = id.compareTo(other.id);
        return idResult != 0 ? idResult : valueType.getName().compareTo(other.valueType.getName());
    }
}

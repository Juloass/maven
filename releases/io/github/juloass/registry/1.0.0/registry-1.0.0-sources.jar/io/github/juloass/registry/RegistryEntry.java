package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** One immutable registry entry. */
public record RegistryEntry<T>(Identifier id, T value) {
    public RegistryEntry {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(value, "value");
    }
}

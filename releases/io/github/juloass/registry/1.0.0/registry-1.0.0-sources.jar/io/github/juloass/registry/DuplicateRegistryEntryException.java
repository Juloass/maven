package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports an entry identifier that is already registered. */
public final class DuplicateRegistryEntryException extends IllegalArgumentException {
    private final RegistryKey<?> registryKey;
    private final Identifier entryId;
    private final Object existingValue;
    private final Object rejectedValue;

    DuplicateRegistryEntryException(
            RegistryKey<?> registryKey,
            Identifier entryId,
            Object existingValue,
            Object rejectedValue
    ) {
        super("Duplicate entry " + entryId + " in registry " + registryKey.id());
        this.registryKey = Objects.requireNonNull(registryKey, "registryKey");
        this.entryId = Objects.requireNonNull(entryId, "entryId");
        this.existingValue = Objects.requireNonNull(existingValue, "existingValue");
        this.rejectedValue = Objects.requireNonNull(rejectedValue, "rejectedValue");
    }

    public RegistryKey<?> registryKey() { return registryKey; }
    public Identifier entryId() { return entryId; }
    public Object existingValue() { return existingValue; }
    public Object rejectedValue() { return rejectedValue; }
}

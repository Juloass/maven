package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports a required entry that is not registered. */
public final class MissingRegistryEntryException extends IllegalArgumentException {
    private final RegistryKey<?> registryKey;
    private final Identifier entryId;

    MissingRegistryEntryException(RegistryKey<?> registryKey, Identifier entryId) {
        super("Missing entry " + entryId + " in registry " + registryKey.id());
        this.registryKey = Objects.requireNonNull(registryKey, "registryKey");
        this.entryId = Objects.requireNonNull(entryId, "entryId");
    }

    public RegistryKey<?> registryKey() { return registryKey; }
    public Identifier entryId() { return entryId; }
}

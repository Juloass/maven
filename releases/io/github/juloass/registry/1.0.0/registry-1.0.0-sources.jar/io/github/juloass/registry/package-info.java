/** Immutable identifier-keyed registries and their single-threaded builders. */
package io.github.juloass.registry;

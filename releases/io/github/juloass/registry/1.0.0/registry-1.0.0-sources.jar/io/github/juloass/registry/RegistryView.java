package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Read-only access to a registry state.
 *
 * @param <T> registry value type
 */
public interface RegistryView<T> {
    /** Returns the registry key. */
    RegistryKey<T> key();

    /** Returns the value for an identifier, if present. */
    Optional<T> find(Identifier id);

    /** Returns the value for an identifier or throws a missing-entry exception. */
    T require(Identifier id);

    /** Reports whether the identifier is present. */
    boolean contains(Identifier id);

    /** Reports whether the registry is empty. */
    default boolean isEmpty() {
        return size() == 0;
    }

    /** Returns the entry count. */
    int size();

    /** Returns immutable entries in registry order. */
    List<RegistryEntry<T>> entries();

    /** Returns immutable identifiers in registry order. */
    Set<Identifier> ids();

    /** Returns immutable values in registry order. */
    Collection<T> values();

    /** Returns an immutable map in registry order. */
    Map<Identifier, T> asMap();
}
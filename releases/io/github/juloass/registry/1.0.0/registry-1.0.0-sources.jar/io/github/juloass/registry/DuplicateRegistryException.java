package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports two registries with the same identifier. */
public final class DuplicateRegistryException extends IllegalArgumentException {
    private final Identifier registryId;
    private final RegistryKey<?> existingKey;
    private final RegistryKey<?> rejectedKey;

    DuplicateRegistryException(RegistryKey<?> existingKey, RegistryKey<?> rejectedKey) {
        super("Duplicate registry identifier " + rejectedKey.id());
        this.registryId = rejectedKey.id();
        this.existingKey = Objects.requireNonNull(existingKey, "existingKey");
        this.rejectedKey = Objects.requireNonNull(rejectedKey, "rejectedKey");
    }

    public Identifier registryId() { return registryId; }
    public RegistryKey<?> existingKey() { return existingKey; }
    public RegistryKey<?> rejectedKey() { return rejectedKey; }
}

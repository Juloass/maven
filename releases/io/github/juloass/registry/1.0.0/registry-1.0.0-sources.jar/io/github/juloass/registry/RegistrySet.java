package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

/** An immutable typed collection of registries. */
public final class RegistrySet {
    private final Map<Identifier, Registry<?>> registries;
    private final Set<RegistryKey<?>> keys;

    private RegistrySet(Map<Identifier, Registry<?>> source) {
        LinkedHashMap<Identifier, Registry<?>> ordered = new LinkedHashMap<>();
        new TreeMap<>(source).forEach(ordered::put);
        this.registries = Collections.unmodifiableMap(ordered);
        LinkedHashSet<RegistryKey<?>> orderedKeys = new LinkedHashSet<>();
        ordered.values().stream().map(Registry::key).forEach(orderedKeys::add);
        this.keys = Collections.unmodifiableSet(orderedKeys);
    }

    public static Builder builder() { return new Builder(); }

    public <T> Optional<Registry<T>> find(RegistryKey<T> key) {
        Objects.requireNonNull(key, "key");
        Registry<?> registry = registries.get(key.id());
        if (registry == null) return Optional.empty();
        requireCompatible(key, registry.key());
        @SuppressWarnings("unchecked") Registry<T> typed = (Registry<T>) registry;
        return Optional.of(typed);
    }

    public <T> Registry<T> require(RegistryKey<T> key) {
        return find(key).orElseThrow(() -> new MissingRegistryException(key));
    }

    public boolean contains(RegistryKey<?> key) {
        Objects.requireNonNull(key, "key");
        Registry<?> registry = registries.get(key.id());
        if (registry == null) return false;
        requireCompatible(key, registry.key());
        return true;
    }

    public Set<RegistryKey<?>> keys() { return keys; }

    private static void requireCompatible(RegistryKey<?> requested, RegistryKey<?> actual) {
        if (!requested.valueType().equals(actual.valueType())) {
            throw new RegistryTypeMismatchException(
                    requested.id(), requested.valueType(), actual.valueType());
        }
    }

    /** Builds one immutable registry set. */
    public static final class Builder {
        private final LinkedHashMap<Identifier, Registry<?>> registries = new LinkedHashMap<>();
        private RegistrySet built;

        public Builder add(Registry<?> registry) {
            Objects.requireNonNull(registry, "registry");
            if (built != null) throw new IllegalStateException("Registry set is already built");
            Registry<?> previous = registries.putIfAbsent(registry.key().id(), registry);
            if (previous != null) {
                throw new DuplicateRegistryException(previous.key(), registry.key());
            }
            return this;
        }

        public RegistrySet build() {
            if (built == null) built = new RegistrySet(registries);
            return built;
        }
    }
}

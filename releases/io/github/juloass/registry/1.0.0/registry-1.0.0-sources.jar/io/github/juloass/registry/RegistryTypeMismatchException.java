package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** Reports a value or lookup type that conflicts with a registry key. */
public final class RegistryTypeMismatchException extends IllegalArgumentException {
    private final Identifier registryId;
    private final Class<?> expectedType;
    private final Class<?> actualType;

    RegistryTypeMismatchException(Identifier registryId, Class<?> expectedType, Class<?> actualType) {
        super("Registry " + registryId + " requires " + expectedType.getName()
                + " but received " + actualType.getName());
        this.registryId = Objects.requireNonNull(registryId, "registryId");
        this.expectedType = Objects.requireNonNull(expectedType, "expectedType");
        this.actualType = Objects.requireNonNull(actualType, "actualType");
    }

    public Identifier registryId() { return registryId; }
    public Class<?> expectedType() { return expectedType; }
    public Class<?> actualType() { return actualType; }
}

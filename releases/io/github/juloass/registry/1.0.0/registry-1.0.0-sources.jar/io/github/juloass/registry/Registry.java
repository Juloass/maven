package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** An immutable identifier-keyed registry. */
public final class Registry<T> implements RegistryView<T> {
    private final RegistryKey<T> key;
    private final Map<Identifier, T> valuesById;
    private final List<RegistryEntry<T>> entries;

    Registry(RegistryKey<T> key, Map<Identifier, T> orderedValues) {
        this.key = Objects.requireNonNull(key, "key");
        LinkedHashMap<Identifier, T> copy = new LinkedHashMap<>(orderedValues);
        this.valuesById = Collections.unmodifiableMap(copy);
        ArrayList<RegistryEntry<T>> entryCopy = new ArrayList<>(copy.size());
        copy.forEach((id, value) -> entryCopy.add(new RegistryEntry<>(id, value)));
        this.entries = List.copyOf(entryCopy);
    }

    @Override public RegistryKey<T> key() { return key; }

    @Override
    public Optional<T> find(Identifier id) {
        return Optional.ofNullable(valuesById.get(Objects.requireNonNull(id, "id")));
    }

    @Override
    public T require(Identifier id) {
        return find(id).orElseThrow(() -> new MissingRegistryEntryException(key, id));
    }

    @Override public boolean contains(Identifier id) {
        return valuesById.containsKey(Objects.requireNonNull(id, "id"));
    }

    @Override public int size() { return valuesById.size(); }
    @Override public List<RegistryEntry<T>> entries() { return entries; }
    @Override public Set<Identifier> ids() { return valuesById.keySet(); }
    @Override public Collection<T> values() { return valuesById.values(); }
    @Override public Map<Identifier, T> asMap() { return valuesById; }
}

package io.github.juloass.registry;

import io.github.juloass.identifier.Identifier;

import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** A single-threaded builder for one immutable registry. */
public final class RegistryBuilder<T> implements RegistryView<T> {
    private final RegistryKey<T> key;
    private final Comparator<Identifier> order;
    private final LinkedHashMap<Identifier, T> values = new LinkedHashMap<>();
    private Registry<T> built;

    private RegistryBuilder(RegistryKey<T> key, Comparator<Identifier> order) {
        this.key = Objects.requireNonNull(key, "key");
        this.order = Objects.requireNonNull(order, "order");
    }

    public static <T> RegistryBuilder<T> create(RegistryKey<T> key) {
        return new RegistryBuilder<>(key, Comparator.naturalOrder());
    }

    public static <T> RegistryBuilder<T> create(
            RegistryKey<T> key,
            Comparator<Identifier> order
    ) {
        return new RegistryBuilder<>(key, order);
    }

    public RegistryBuilder<T> register(Identifier id, T value) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(value, "value");
        if (built != null) {
            throw new IllegalStateException("Registry is already built: " + key.id());
        }
        if (!key.valueType().isInstance(value)) {
            throw new RegistryTypeMismatchException(key.id(), key.valueType(), value.getClass());
        }
        T previous = values.putIfAbsent(id, value);
        if (previous != null) {
            throw new DuplicateRegistryEntryException(key, id, previous, value);
        }
        return this;
    }

    public Registry<T> build() {
        if (built == null) {
            built = new Registry<>(key, orderedValues());
        }
        return built;
    }

    @Override public RegistryKey<T> key() { return key; }

    @Override
    public Optional<T> find(Identifier id) {
        return Optional.ofNullable(values.get(Objects.requireNonNull(id, "id")));
    }

    @Override
    public T require(Identifier id) {
        return find(id).orElseThrow(() -> new MissingRegistryEntryException(key, id));
    }

    @Override public boolean contains(Identifier id) {
        return values.containsKey(Objects.requireNonNull(id, "id"));
    }

    @Override public int size() { return values.size(); }
    @Override public List<RegistryEntry<T>> entries() { return snapshot().entries(); }
    @Override public Set<Identifier> ids() { return snapshot().ids(); }
    @Override public Collection<T> values() { return snapshot().values(); }
    @Override public Map<Identifier, T> asMap() { return snapshot().asMap(); }

    private Registry<T> snapshot() {
        return new Registry<>(key, orderedValues());
    }

    private Map<Identifier, T> orderedValues() {
        LinkedHashMap<Identifier, T> ordered = new LinkedHashMap<>();
        values.entrySet().stream()
                .sorted(Map.Entry.comparingByKey(order))
                .forEach(entry -> ordered.put(entry.getKey(), entry.getValue()));
        return ordered;
    }
}

package io.github.juloass.registry;

import java.util.Objects;

/** Reports a required registry that is not present. */
public final class MissingRegistryException extends IllegalArgumentException {
    private final RegistryKey<?> registryKey;

    MissingRegistryException(RegistryKey<?> registryKey) {
        super("Missing registry " + registryKey.id());
        this.registryKey = Objects.requireNonNull(registryKey, "registryKey");
    }

    public RegistryKey<?> registryKey() { return registryKey; }
}

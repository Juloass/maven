package io.github.juloass.localization.resource;

import io.github.juloass.localization.LocaleId;
import io.github.juloass.localization.LocalizationValidationException;
import io.github.juloass.localization.TranslationCatalog;
import io.github.juloass.localization.TranslationEntry;
import io.github.juloass.localization.TranslationProvider;
import io.github.juloass.localization.json.JsonTranslationLoader;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.pack.ResourceManager;
import io.github.juloass.resource.pack.ResourcePackCandidate;
import io.github.juloass.resource.pack.ResourceSnapshot;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;

/** Loads immutable locale catalogs from the lang directory in resource packs. */
public final class ResourceTranslationProvider implements TranslationProvider {
    private final TranslationCatalog catalog;

    public ResourceTranslationProvider(
            List<ResourcePackCandidate> packs,
            LocaleId fallbackLocale,
            Consumer<String> diagnostics
    ) {
        Consumer<String> sink = diagnostics == null ? ignored -> { } : diagnostics;
        JsonTranslationLoader.Builder loader = JsonTranslationLoader.builder(fallbackLocale);
        try (ResourceManager manager = ResourceManager.create(ResourceDomain.ASSETS, packs);
             ResourceSnapshot snapshot = manager.acquireSnapshot()) {
            snapshot.listResources("lang/", ResourceTranslationProvider::isLocaleFile)
                    .forEach((path, resource) -> loader.addInput(
                            resource.origin().packId() + "/" + path,
                            locale(path),
                            resource::openStream));
            catalog = loader.load();
        } catch (LocalizationValidationException invalid) {
            invalid.diagnostics().forEach(problem -> sink.accept(problem.format()));
            throw invalid;
        }
    }

    private static boolean isLocaleFile(ResourcePath path) {
        String value = path.path();
        return value.startsWith("lang/")
                && value.endsWith(".json")
                && value.indexOf('/', "lang/".length()) < 0;
    }

    private static LocaleId locale(ResourcePath path) {
        String filename = path.path().substring("lang/".length());
        return LocaleId.of(filename.substring(0, filename.length() - ".json".length()));
    }

    @Override
    public Set<LocaleId> availableLocales() {
        return catalog.availableLocales();
    }

    @Override
    public Optional<TranslationEntry> find(LocaleId locale, String key) {
        return catalog.find(locale, key);
    }
}

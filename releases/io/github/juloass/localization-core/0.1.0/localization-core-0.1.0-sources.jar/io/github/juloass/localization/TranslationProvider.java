package io.github.juloass.localization;

import java.util.Optional;
import java.util.Set;

/** Thread-safe immutable source of validated translation templates. */
public interface TranslationProvider {
    Set<LocaleId> availableLocales();
    Optional<TranslationEntry> find(LocaleId locale, String key);
}

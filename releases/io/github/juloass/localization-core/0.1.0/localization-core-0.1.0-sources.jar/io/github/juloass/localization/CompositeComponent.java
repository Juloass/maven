package io.github.juloass.localization;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Ordered composition of component trees. */
public record CompositeComponent(List<TextComponent> children) implements TextComponent {
    public CompositeComponent {
        children = List.copyOf(Objects.requireNonNull(children, "children"));
        if (children.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Composite children must not contain null");
        }
    }

    public static CompositeComponent of(TextComponent... components) {
        Objects.requireNonNull(components, "components");
        List<TextComponent> flattened = new ArrayList<>();
        for (TextComponent component : components) {
            Objects.requireNonNull(component, "component");
            if (component instanceof CompositeComponent composite) flattened.addAll(composite.children());
            else flattened.add(component);
        }
        return new CompositeComponent(flattened);
    }
}

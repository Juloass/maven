package io.github.juloass.localization;

import io.github.juloass.color.Color;

import java.util.Arrays;
import java.util.Objects;

/** Immutable renderer-independent text tree. */
public sealed interface TextComponent permits LiteralComponent, TranslatableComponent,
        CompositeComponent, StyledComponent {
    static LiteralComponent literal(String text) {
        return new LiteralComponent(text);
    }

    static TranslatableComponent translatable(String key, Object... arguments) {
        Objects.requireNonNull(arguments, "arguments");
        return new TranslatableComponent(key, Arrays.stream(arguments).map(TranslationArgument::of).toList());
    }

    static CompositeComponent composite(TextComponent... components) {
        return CompositeComponent.of(components);
    }

    default TextComponent append(TextComponent component) {
        return CompositeComponent.of(this, component);
    }

    default TextComponent append(String literal) {
        return append(literal(literal));
    }

    default TextComponent styled(TextStyle style) {
        return new StyledComponent(this, style);
    }

    default TextComponent color(Color color) {
        return styled(TextStyle.color(color));
    }

    default TextComponent decorate(TextDecoration decoration) {
        return styled(TextStyle.EMPTY.with(decoration));
    }

    default TextComponent undecorate(TextDecoration decoration) {
        return styled(TextStyle.EMPTY.without(decoration));
    }

    default TextComponent bold() { return decorate(TextDecoration.BOLD); }
    default TextComponent withoutBold() { return undecorate(TextDecoration.BOLD); }
    default TextComponent italic() { return decorate(TextDecoration.ITALIC); }
    default TextComponent withoutItalic() { return undecorate(TextDecoration.ITALIC); }
    default TextComponent underlined() { return decorate(TextDecoration.UNDERLINED); }
    default TextComponent withoutUnderline() { return undecorate(TextDecoration.UNDERLINED); }
    default TextComponent strikethrough() { return decorate(TextDecoration.STRIKETHROUGH); }
    default TextComponent withoutStrikethrough() { return undecorate(TextDecoration.STRIKETHROUGH); }
}

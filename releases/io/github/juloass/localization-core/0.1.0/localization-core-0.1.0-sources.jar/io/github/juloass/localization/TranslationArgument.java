package io.github.juloass.localization;

import java.util.Objects;

/** Closed, serialization-friendly set of values accepted by translation placeholders. */
public sealed interface TranslationArgument permits TranslationArgument.ComponentValue,
        TranslationArgument.StringValue, TranslationArgument.IntegerValue,
        TranslationArgument.DecimalValue, TranslationArgument.BooleanValue {
    record ComponentValue(TextComponent value) implements TranslationArgument {
        public ComponentValue { Objects.requireNonNull(value, "value"); }
    }

    record StringValue(String value) implements TranslationArgument {
        public StringValue { Objects.requireNonNull(value, "value"); }
    }

    record IntegerValue(long value) implements TranslationArgument { }

    record DecimalValue(double value) implements TranslationArgument {
        public DecimalValue {
            if (!Double.isFinite(value)) throw new IllegalArgumentException("Decimal argument must be finite");
        }
    }

    record BooleanValue(boolean value) implements TranslationArgument { }

    static TranslationArgument of(Object value) {
        if (value instanceof TranslationArgument argument) return argument;
        if (value instanceof TextComponent component) return new ComponentValue(component);
        if (value instanceof CharSequence sequence) return new StringValue(sequence.toString());
        if (value instanceof Byte || value instanceof Short || value instanceof Integer || value instanceof Long) {
            return new IntegerValue(((Number) value).longValue());
        }
        if (value instanceof Float || value instanceof Double) {
            return new DecimalValue(((Number) value).doubleValue());
        }
        if (value instanceof Boolean bool) return new BooleanValue(bool);
        throw new IllegalArgumentException("Unsupported translation argument type: "
                + (value == null ? "null" : value.getClass().getName()));
    }
}

package io.github.juloass.localization;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

/** Immutable validated translation catalog suitable for runtime sharing. */
public final class TranslationCatalog implements TranslationProvider {
    private final Map<LocaleId, Map<String, TranslationEntry>> entries;

    private TranslationCatalog(Map<LocaleId, Map<String, TranslationEntry>> entries) {
        this.entries = entries;
    }

    public static Builder builder(LocaleId referenceLocale) {
        return new Builder(referenceLocale);
    }

    public static TranslationCatalog fromBundles(
            LocaleId referenceLocale,
            Map<LocaleId, ? extends Map<String, String>> bundles
    ) {
        Objects.requireNonNull(bundles, "bundles");
        Builder builder = builder(referenceLocale);
        bundles.forEach((locale, values) -> {
            Objects.requireNonNull(values, "bundle");
            builder.addLocale(locale);
            values.forEach((key, value) -> builder.add(locale, "<memory:" + locale + ">", key, value));
        });
        return builder.build();
    }

    @Override
    public Set<LocaleId> availableLocales() {
        return entries.keySet();
    }

    @Override
    public Optional<TranslationEntry> find(LocaleId locale, String key) {
        Objects.requireNonNull(locale, "locale");
        Objects.requireNonNull(key, "key");
        return Optional.ofNullable(entries.getOrDefault(locale, Map.of()).get(key));
    }

    public Map<String, TranslationEntry> entries(LocaleId locale) {
        return entries.getOrDefault(locale, Map.of());
    }

    public static final class Builder {
        private final LocaleId referenceLocale;
        private final Map<LocaleId, Map<String, RawEntry>> raw = new TreeMap<>();
        private final List<LocalizationDiagnostic> diagnostics = new ArrayList<>();

        private Builder(LocaleId referenceLocale) {
            this.referenceLocale = Objects.requireNonNull(referenceLocale, "referenceLocale");
        }

        public Builder addLocale(LocaleId locale) {
            raw.computeIfAbsent(Objects.requireNonNull(locale, "locale"), ignored -> new LinkedHashMap<>());
            return this;
        }

        public Builder add(LocaleId locale, String source, String key, String template) {
            Objects.requireNonNull(locale, "locale");
            source = Objects.requireNonNullElse(source, "<unknown>");
            String normalizedKey = key == null ? "" : key.strip();
            if (normalizedKey.isEmpty()) {
                diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_VALUE, source, locale, key,
                        "Translation key must not be blank."));
                return this;
            }
            if (template == null) {
                diagnostics.add(error(LocalizationDiagnostic.Code.INVALID_VALUE, source, locale, normalizedKey,
                        "Translation value must not be null."));
                return this;
            }
            Map<String, RawEntry> localeEntries = raw.computeIfAbsent(locale, ignored -> new LinkedHashMap<>());
            RawEntry previous = localeEntries.putIfAbsent(normalizedKey,
                    new RawEntry(locale, source, normalizedKey, template));
            if (previous != null) {
                diagnostics.add(error(LocalizationDiagnostic.Code.DUPLICATE_KEY, source, locale, normalizedKey,
                        "Duplicate translation key; first declared by " + previous.source + "."));
            }
            return this;
        }

        public TranslationCatalog build() {
            List<LocalizationDiagnostic> problems = new ArrayList<>(diagnostics);
            if (!raw.containsKey(referenceLocale)) {
                problems.add(error(LocalizationDiagnostic.Code.MISSING_REQUIRED_LOCALE, "<catalog>", referenceLocale,
                        "<document>", "Required reference locale is missing."));
            }

            Map<LocaleId, Map<String, TranslationEntry>> compiled = new TreeMap<>();
            raw.forEach((locale, values) -> {
                Map<String, TranslationEntry> localeEntries = new LinkedHashMap<>();
                values.forEach((key, value) -> {
                    try {
                        localeEntries.put(key, new TranslationEntry(locale, value.source, key,
                                TranslationTemplate.compile(value.template)));
                    } catch (IllegalArgumentException invalid) {
                        problems.add(error(LocalizationDiagnostic.Code.INVALID_TEMPLATE, value.source, locale, key,
                                invalid.getMessage()));
                    }
                });
                compiled.put(locale, Collections.unmodifiableMap(localeEntries));
            });

            Map<String, TranslationEntry> reference = compiled.getOrDefault(referenceLocale, Map.of());
            compiled.forEach((locale, values) -> {
                if (locale.equals(referenceLocale)) return;
                values.forEach((key, entry) -> {
                    TranslationEntry base = reference.get(key);
                    if (base != null && !base.template().requiredArgumentIndexes()
                            .equals(entry.template().requiredArgumentIndexes())) {
                        problems.add(error(LocalizationDiagnostic.Code.PLACEHOLDER_MISMATCH,
                                entry.source(), locale, key,
                                "Placeholder indexes " + displayIndexes(entry.template().requiredArgumentIndexes())
                                        + " differ from reference "
                                        + displayIndexes(base.template().requiredArgumentIndexes()) + "."));
                    }
                });
            });

            if (!problems.isEmpty()) throw new LocalizationValidationException(problems);
            Map<LocaleId, Map<String, TranslationEntry>> immutable = new LinkedHashMap<>();
            compiled.forEach(immutable::put);
            return new TranslationCatalog(Collections.unmodifiableMap(immutable));
        }

        private static String displayIndexes(Set<Integer> indexes) {
            return indexes.stream().map(index -> Integer.toString(index + 1)).toList().toString();
        }

        private static LocalizationDiagnostic error(LocalizationDiagnostic.Code code, String source,
                                                     LocaleId locale, String key, String message) {
            return new LocalizationDiagnostic(LocalizationDiagnostic.Severity.ERROR, code,
                    source, locale, key, message);
        }

        private record RawEntry(LocaleId locale, String source, String key, String template) { }
    }
}

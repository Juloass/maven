package io.github.juloass.localization;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@FunctionalInterface
public interface LocalizationDiagnosticSink {
    LocalizationDiagnosticSink NONE = ignored -> { };

    void report(LocalizationDiagnostic diagnostic);

    static LocalizationDiagnosticSink deduplicating(LocalizationDiagnosticSink delegate) {
        LocalizationDiagnosticSink target = delegate == null ? NONE : delegate;
        Set<LocalizationDiagnostic> reported = ConcurrentHashMap.newKeySet();
        return diagnostic -> {
            if (reported.add(diagnostic)) target.report(diagnostic);
        };
    }
}

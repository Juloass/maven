package io.github.juloass.localization;

import java.util.Objects;

/** Structured validation or resolution problem suitable for logs, tools, and tests. */
public record LocalizationDiagnostic(
        Severity severity,
        Code code,
        String source,
        LocaleId locale,
        String key,
        String message
) {
    public enum Severity { WARNING, ERROR }

    public enum Code {
        SOURCE_ERROR,
        INVALID_JSON,
        DUPLICATE_KEY,
        INVALID_VALUE,
        INVALID_LOCALE,
        INVALID_TEMPLATE,
        PLACEHOLDER_MISMATCH,
        MISSING_REQUIRED_LOCALE,
        FALLBACK_USED,
        MISSING_KEY,
        MISSING_ARGUMENT,
        LISTENER_FAILURE
    }

    public LocalizationDiagnostic {
        Objects.requireNonNull(severity, "severity");
        Objects.requireNonNull(code, "code");
        source = Objects.requireNonNullElse(source, "<unknown>");
        key = Objects.requireNonNullElse(key, "<document>");
        Objects.requireNonNull(message, "message");
    }

    public String format() {
        String localeText = locale == null ? "" : " [" + locale + "]";
        return severity + " " + code + " " + source + localeText + " key '" + key + "': " + message;
    }
}

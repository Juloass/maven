package io.github.juloass.localization;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/** Aggregates catalog validation errors without losing their source context. */
public final class LocalizationValidationException extends RuntimeException {
    private final List<LocalizationDiagnostic> diagnostics;

    public LocalizationValidationException(List<LocalizationDiagnostic> diagnostics) {
        super(format(diagnostics));
        this.diagnostics = List.copyOf(diagnostics);
    }

    public List<LocalizationDiagnostic> diagnostics() {
        return diagnostics;
    }

    private static String format(List<LocalizationDiagnostic> diagnostics) {
        Objects.requireNonNull(diagnostics, "diagnostics");
        return "Invalid localization data:\n" + diagnostics.stream()
                .map(LocalizationDiagnostic::format)
                .collect(Collectors.joining("\n"));
    }
}

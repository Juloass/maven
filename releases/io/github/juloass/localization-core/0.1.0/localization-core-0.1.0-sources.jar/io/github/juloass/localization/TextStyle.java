package io.github.juloass.localization;

import io.github.juloass.color.Color;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Objects;

/** Immutable style patch applied to a component and inherited by its descendants. */
public record TextStyle(Color color, Map<TextDecoration, DecorationState> decorations) {
    public static final TextStyle EMPTY = new TextStyle(null, Map.of());

    public TextStyle {
        EnumMap<TextDecoration, DecorationState> copy = new EnumMap<>(TextDecoration.class);
        if (decorations != null) {
            decorations.forEach((decoration, state) -> copy.put(
                    Objects.requireNonNull(decoration, "decoration"),
                    Objects.requireNonNull(state, "state")));
        }
        decorations = Map.copyOf(copy);
    }

    public static TextStyle color(Color color) {
        return EMPTY.withColor(color);
    }

    public DecorationState state(TextDecoration decoration) {
        return decorations.getOrDefault(Objects.requireNonNull(decoration, "decoration"), DecorationState.INHERIT);
    }

    public TextStyle withColor(Color color) {
        return new TextStyle(Objects.requireNonNull(color, "color"), decorations);
    }

    public TextStyle with(TextDecoration decoration) {
        return with(decoration, DecorationState.ENABLED);
    }

    public TextStyle without(TextDecoration decoration) {
        return with(decoration, DecorationState.DISABLED);
    }

    public TextStyle inheriting(TextDecoration decoration) {
        return with(decoration, DecorationState.INHERIT);
    }

    public TextStyle with(TextDecoration decoration, DecorationState state) {
        Objects.requireNonNull(decoration, "decoration");
        Objects.requireNonNull(state, "state");
        EnumMap<TextDecoration, DecorationState> updated = new EnumMap<>(TextDecoration.class);
        updated.putAll(decorations);
        if (state == DecorationState.INHERIT) updated.remove(decoration);
        else updated.put(decoration, state);
        return new TextStyle(color, updated);
    }

    public ResolvedTextStyle applyTo(ResolvedTextStyle inherited) {
        Objects.requireNonNull(inherited, "inherited");
        EnumSet<TextDecoration> resolved = inherited.decorations().isEmpty()
                ? EnumSet.noneOf(TextDecoration.class)
                : EnumSet.copyOf(inherited.decorations());
        for (TextDecoration decoration : TextDecoration.values()) {
            switch (state(decoration)) {
                case INHERIT -> { }
                case ENABLED -> resolved.add(decoration);
                case DISABLED -> resolved.remove(decoration);
            }
        }
        return new ResolvedTextStyle(color == null ? inherited.color() : color, resolved);
    }
}

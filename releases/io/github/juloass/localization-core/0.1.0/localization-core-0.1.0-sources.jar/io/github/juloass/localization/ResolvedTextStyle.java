package io.github.juloass.localization;

import io.github.juloass.color.Color;

import java.util.Objects;
import java.util.Set;

/** Final style for one output span. A null color selects the renderer default. */
public record ResolvedTextStyle(Color color, Set<TextDecoration> decorations) {
    public static final ResolvedTextStyle DEFAULT = new ResolvedTextStyle(null, Set.of());

    public ResolvedTextStyle {
        decorations = Set.copyOf(Objects.requireNonNull(decorations, "decorations"));
    }

    public boolean has(TextDecoration decoration) {
        return decorations.contains(Objects.requireNonNull(decoration, "decoration"));
    }
}

package io.github.juloass.localization;

import java.util.List;
import java.util.Objects;

/** Locale-resolved output retaining presentation spans and non-fatal diagnostics. */
public record ResolvedText(List<TextSpan> spans, List<LocalizationDiagnostic> diagnostics) {
    public ResolvedText {
        spans = List.copyOf(Objects.requireNonNull(spans, "spans"));
        diagnostics = List.copyOf(Objects.requireNonNull(diagnostics, "diagnostics"));
    }

    public String plainText() {
        StringBuilder text = new StringBuilder();
        for (TextSpan span : spans) text.append(span.text());
        return text.toString();
    }
}

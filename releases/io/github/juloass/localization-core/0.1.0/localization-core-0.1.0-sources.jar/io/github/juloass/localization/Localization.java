package io.github.juloass.localization;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Thread-safe locale selector and component resolver over a validated provider. */
public final class Localization {
    public static final int MAX_COMPONENT_DEPTH = 64;

    private final TranslationProvider provider;
    private final List<LocaleId> fallbackLocales;
    private final LocalizationDiagnosticSink diagnosticSink;
    private final CopyOnWriteArrayList<Consumer<LocaleId>> listeners = new CopyOnWriteArrayList<>();
    private volatile LocaleId locale;

    public Localization(TranslationProvider provider, LocaleId locale, List<LocaleId> fallbackLocales,
                        LocalizationDiagnosticSink diagnosticSink) {
        this.provider = Objects.requireNonNull(provider, "provider");
        this.locale = requireAvailable(Objects.requireNonNull(locale, "locale"));
        LinkedHashSet<LocaleId> uniqueFallbacks = new LinkedHashSet<>(
                Objects.requireNonNull(fallbackLocales, "fallbackLocales"));
        if (uniqueFallbacks.contains(null)) throw new IllegalArgumentException("Fallback locales must not contain null");
        uniqueFallbacks.forEach(this::requireAvailable);
        this.fallbackLocales = List.copyOf(uniqueFallbacks);
        this.diagnosticSink = diagnosticSink == null ? LocalizationDiagnosticSink.NONE : diagnosticSink;
    }

    public Localization(TranslationProvider provider, LocaleId locale, LocaleId fallbackLocale,
                        LocalizationDiagnosticSink diagnosticSink) {
        this(provider, locale, List.of(Objects.requireNonNull(fallbackLocale, "fallbackLocale")), diagnosticSink);
    }

    public LocaleId locale() { return locale; }
    public List<LocaleId> fallbackLocales() { return fallbackLocales; }

    public List<LocaleId> availableLocales() {
        return provider.availableLocales().stream().sorted(Comparator.naturalOrder()).toList();
    }

    public void setLocale(LocaleId next) {
        LocaleId validated = requireAvailable(Objects.requireNonNull(next, "next"));
        LocaleId previous = locale;
        locale = validated;
        if (validated.equals(previous)) return;
        for (Consumer<LocaleId> listener : listeners) {
            try {
                listener.accept(validated);
            } catch (RuntimeException failure) {
                safeReport(new LocalizationDiagnostic(LocalizationDiagnostic.Severity.WARNING,
                        LocalizationDiagnostic.Code.LISTENER_FAILURE, listener.getClass().getName(), validated,
                        "<locale>", "Locale listener failed: " + failure));
            }
        }
    }

    public LocaleSubscription addLocaleChangeListener(Consumer<LocaleId> listener) {
        Consumer<LocaleId> validated = Objects.requireNonNull(listener, "listener");
        listeners.add(validated);
        return new ListenerSubscription(validated);
    }

    public void removeLocaleChangeListener(Consumer<LocaleId> listener) {
        listeners.remove(listener);
    }

    public ResolvedText resolve(TextComponent component) {
        Objects.requireNonNull(component, "component");
        LocaleId selected = locale;
        Resolution resolution = new Resolution();
        resolve(component, ResolvedTextStyle.DEFAULT, selected, resolution, 1);
        return new ResolvedText(resolution.spans, resolution.diagnostics);
    }

    public String resolvePlainText(TextComponent component) {
        return resolve(component).plainText();
    }

    private void resolve(TextComponent component, ResolvedTextStyle inheritedStyle, LocaleId selected,
                         Resolution resolution, int depth) {
        requireDepth(depth);
        switch (component) {
            case LiteralComponent literal -> resolution.append(literal.text(), inheritedStyle);
            case CompositeComponent composite -> {
                for (TextComponent child : composite.children()) {
                    resolve(child, inheritedStyle, selected, resolution, depth + 1);
                }
            }
            case StyledComponent styled -> resolve(styled.content(), styled.style().applyTo(inheritedStyle),
                    selected, resolution, depth + 1);
            case TranslatableComponent translatable -> resolveTranslation(translatable, inheritedStyle,
                    selected, resolution, depth);
        }
    }

    private void resolveTranslation(TranslatableComponent component, ResolvedTextStyle style, LocaleId selected,
                                    Resolution resolution, int depth) {
        TranslationEntry entry = provider.find(selected, component.key()).orElse(null);
        LocaleId resolvedLocale = selected;
        if (entry == null) {
            for (LocaleId fallback : fallbackLocales) {
                if (fallback.equals(selected)) continue;
                entry = provider.find(fallback, component.key()).orElse(null);
                if (entry != null) {
                    resolvedLocale = fallback;
                    diagnostic(resolution, LocalizationDiagnostic.Code.FALLBACK_USED, entry.source(), selected,
                            component.key(), "Used fallback locale " + fallback + ".");
                    break;
                }
            }
        }
        if (entry == null) {
            resolution.append(component.key(), style);
            diagnostic(resolution, LocalizationDiagnostic.Code.MISSING_KEY, "<runtime>", selected, component.key(),
                    "Translation is missing from the active locale and every configured fallback.");
            return;
        }

        for (TranslationTemplate.Token token : entry.template().tokens()) {
            if (token instanceof TranslationTemplate.Literal literal) {
                resolution.append(literal.value(), style);
            } else if (token instanceof TranslationTemplate.Argument argument) {
                if (argument.index() >= component.arguments().size()) {
                    resolution.append(argument.sourceText(), style);
                    diagnostic(resolution, LocalizationDiagnostic.Code.MISSING_ARGUMENT, entry.source(),
                            resolvedLocale, component.key(), "Placeholder " + argument.sourceText()
                                    + " requires argument " + (argument.index() + 1) + " but only "
                                    + component.arguments().size() + " were supplied.");
                } else {
                    resolveArgument(component.arguments().get(argument.index()), style, selected, resolution, depth);
                }
            }
        }
    }

    private void resolveArgument(TranslationArgument argument, ResolvedTextStyle style, LocaleId selected,
                                 Resolution resolution, int depth) {
        switch (argument) {
            case TranslationArgument.ComponentValue value -> resolve(value.value(), style, selected, resolution, depth + 1);
            case TranslationArgument.StringValue value -> resolution.append(value.value(), style);
            case TranslationArgument.IntegerValue value -> resolution.append(Long.toString(value.value()), style);
            case TranslationArgument.DecimalValue value -> resolution.append(Double.toString(value.value()), style);
            case TranslationArgument.BooleanValue value -> resolution.append(Boolean.toString(value.value()), style);
        }
    }

    private void diagnostic(Resolution resolution, LocalizationDiagnostic.Code code, String source,
                            LocaleId locale, String key, String message) {
        LocalizationDiagnostic diagnostic = new LocalizationDiagnostic(LocalizationDiagnostic.Severity.WARNING,
                code, source, locale, key, message);
        resolution.diagnostics.add(diagnostic);
        safeReport(diagnostic);
    }

    private void safeReport(LocalizationDiagnostic diagnostic) {
        try {
            diagnosticSink.report(diagnostic);
        } catch (RuntimeException ignored) {
            // Diagnostic reporting must not break localization or listener notification.
        }
    }

    private LocaleId requireAvailable(LocaleId candidate) {
        if (!provider.availableLocales().contains(candidate)) {
            throw new IllegalArgumentException("Provider does not contain locale " + candidate);
        }
        return candidate;
    }

    private static void requireDepth(int depth) {
        if (depth > MAX_COMPONENT_DEPTH) {
            throw new IllegalArgumentException("Component tree exceeds " + MAX_COMPONENT_DEPTH + " levels");
        }
    }

    private final class ListenerSubscription implements LocaleSubscription {
        private final Consumer<LocaleId> listener;
        private boolean closed;

        private ListenerSubscription(Consumer<LocaleId> listener) { this.listener = listener; }

        @Override
        public synchronized void close() {
            if (!closed) {
                listeners.remove(listener);
                closed = true;
            }
        }
    }

    private static final class Resolution {
        private final List<TextSpan> spans = new ArrayList<>();
        private final List<LocalizationDiagnostic> diagnostics = new ArrayList<>();

        private void append(String text, ResolvedTextStyle style) {
            if (text.isEmpty()) return;
            int last = spans.size() - 1;
            if (last >= 0 && spans.get(last).style().equals(style)) {
                TextSpan previous = spans.get(last);
                spans.set(last, new TextSpan(previous.text() + text, style));
            } else {
                spans.add(new TextSpan(text, style));
            }
        }
    }
}

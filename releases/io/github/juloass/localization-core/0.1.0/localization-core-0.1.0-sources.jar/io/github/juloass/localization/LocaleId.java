package io.github.juloass.localization;

import java.util.IllformedLocaleException;
import java.util.Locale;
import java.util.Objects;

/** Canonical BCP-47 locale identifier with an underscore file-name form. */
public record LocaleId(String value) implements Comparable<LocaleId> {
    public LocaleId {
        Objects.requireNonNull(value, "value");
        String candidate = value.strip();
        if (candidate.isEmpty()) {
            throw new IllegalArgumentException("Locale id must not be blank");
        }
        try {
            Locale locale = new Locale.Builder().setLanguageTag(candidate.replace('_', '-')).build();
            if (locale.getLanguage().isEmpty() || locale.toLanguageTag().equals("und")) {
                throw new IllegalArgumentException("Locale id must contain a language: " + value);
            }
            value = locale.toLanguageTag().toLowerCase(Locale.ROOT).replace('-', '_');
        } catch (IllformedLocaleException exception) {
            throw new IllegalArgumentException("Invalid BCP-47 locale id '" + value + "'", exception);
        }
    }

    public static LocaleId of(String value) {
        return new LocaleId(value);
    }

    public static LocaleId parse(String value) {
        return of(value);
    }

    public static LocaleId from(Locale locale) {
        Objects.requireNonNull(locale, "locale");
        return of(locale.toLanguageTag());
    }

    public Locale toJavaLocale() {
        return Locale.forLanguageTag(toLanguageTag());
    }

    public String toLanguageTag() {
        return value.replace('_', '-');
    }

    @Override
    public int compareTo(LocaleId other) {
        return value.compareTo(other.value);
    }

    @Override
    public String toString() {
        return value;
    }
}

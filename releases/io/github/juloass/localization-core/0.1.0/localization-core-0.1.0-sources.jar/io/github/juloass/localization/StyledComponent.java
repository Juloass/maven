package io.github.juloass.localization;

import java.util.Objects;

/** Applies a style patch to a nested component tree. */
public record StyledComponent(TextComponent content, TextStyle style) implements TextComponent {
    public StyledComponent {
        Objects.requireNonNull(content, "content");
        Objects.requireNonNull(style, "style");
    }
}

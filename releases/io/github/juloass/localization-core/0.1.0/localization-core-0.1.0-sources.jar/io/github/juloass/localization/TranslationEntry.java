package io.github.juloass.localization;

import java.util.Objects;

/** One source-aware, precompiled catalog entry. */
public record TranslationEntry(LocaleId locale, String source, String key, TranslationTemplate template) {
    public TranslationEntry {
        Objects.requireNonNull(locale, "locale");
        source = Objects.requireNonNullElse(source, "<unknown>");
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(template, "template");
    }
}

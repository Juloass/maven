package io.github.juloass.localization;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/** Immutable precompiled form of the supported percent-placeholder syntax. */
public final class TranslationTemplate {
    private final String sourceText;
    private final List<Token> tokens;
    private final Set<Integer> requiredArgumentIndexes;

    private TranslationTemplate(String sourceText, List<Token> tokens, Set<Integer> requiredArgumentIndexes) {
        this.sourceText = sourceText;
        this.tokens = List.copyOf(tokens);
        this.requiredArgumentIndexes = Collections.unmodifiableSet(new LinkedHashSet<>(requiredArgumentIndexes));
    }

    public static TranslationTemplate compile(String template) {
        Objects.requireNonNull(template, "template");
        List<Token> tokens = new ArrayList<>();
        Set<Integer> required = new LinkedHashSet<>();
        StringBuilder literal = new StringBuilder();
        int sequentialArgument = 0;

        for (int cursor = 0; cursor < template.length();) {
            char current = template.charAt(cursor);
            if (current != '%') {
                literal.append(current);
                cursor++;
                continue;
            }

            int start = cursor++;
            if (cursor < template.length() && template.charAt(cursor) == '%') {
                literal.append('%');
                cursor++;
                continue;
            }

            flushLiteral(tokens, literal);
            int digitsStart = cursor;
            while (cursor < template.length() && Character.isDigit(template.charAt(cursor))) cursor++;

            int argumentIndex;
            if (cursor > digitsStart) {
                if (cursor >= template.length() || template.charAt(cursor) != '$') {
                    throw invalid(template, start, "positional placeholders must use %<index>$s");
                }
                String indexText = template.substring(digitsStart, cursor++);
                try {
                    argumentIndex = Integer.parseInt(indexText) - 1;
                } catch (NumberFormatException exception) {
                    throw invalid(template, start, "placeholder index is outside the integer range");
                }
                if (argumentIndex < 0) throw invalid(template, start, "placeholder indices start at 1");
            } else {
                argumentIndex = sequentialArgument++;
            }

            if (cursor >= template.length() || template.charAt(cursor) != 's') {
                throw invalid(template, start, "only %s and %<index>$s are supported; escape '%' as %%");
            }
            cursor++;
            required.add(argumentIndex);
            tokens.add(new Argument(argumentIndex, template.substring(start, cursor)));
        }
        flushLiteral(tokens, literal);
        return new TranslationTemplate(template, tokens, required);
    }

    public String sourceText() { return sourceText; }
    public Set<Integer> requiredArgumentIndexes() { return requiredArgumentIndexes; }
    List<Token> tokens() { return tokens; }

    private static void flushLiteral(List<Token> tokens, StringBuilder literal) {
        if (!literal.isEmpty()) {
            tokens.add(new Literal(literal.toString()));
            literal.setLength(0);
        }
    }

    private static IllegalArgumentException invalid(String template, int offset, String reason) {
        return new IllegalArgumentException(reason + " at character " + (offset + 1)
                + " in '" + template.replace("'", "\\'") + "'");
    }

    sealed interface Token permits Literal, Argument { }
    record Literal(String value) implements Token { }
    record Argument(int index, String sourceText) implements Token { }
}

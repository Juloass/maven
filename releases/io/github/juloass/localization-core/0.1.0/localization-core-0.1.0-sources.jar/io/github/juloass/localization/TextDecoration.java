package io.github.juloass.localization;

/** Renderer-independent text decorations supported by the core model. */
public enum TextDecoration {
    BOLD,
    ITALIC,
    UNDERLINED,
    STRIKETHROUGH
}

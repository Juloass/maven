package io.github.juloass.localization;

import java.util.Objects;

/** One resolved text run sharing a concrete inherited style. */
public record TextSpan(String text, ResolvedTextStyle style) {
    public TextSpan {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(style, "style");
    }
}

package io.github.juloass.localization;

/** How a decoration patch interacts with the inherited style. */
public enum DecorationState {
    INHERIT,
    ENABLED,
    DISABLED
}

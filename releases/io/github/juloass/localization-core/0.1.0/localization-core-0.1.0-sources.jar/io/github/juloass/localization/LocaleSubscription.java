package io.github.juloass.localization;

/** Subscription that removes one locale-change listener. */
@FunctionalInterface
public interface LocaleSubscription extends AutoCloseable {
    @Override
    void close();
}

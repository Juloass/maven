package io.github.juloass.localization;

import java.util.List;
import java.util.Objects;

/** Translation key plus typed placeholder arguments. */
public record TranslatableComponent(String key, List<TranslationArgument> arguments) implements TextComponent {
    public TranslatableComponent {
        Objects.requireNonNull(key, "key");
        key = key.strip();
        if (key.isEmpty()) throw new IllegalArgumentException("Translation key must not be blank");
        arguments = List.copyOf(Objects.requireNonNull(arguments, "arguments"));
        if (arguments.stream().anyMatch(Objects::isNull)) {
            throw new IllegalArgumentException("Translation arguments must not contain null");
        }
    }
}

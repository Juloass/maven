package io.github.juloass.localization;

import java.util.Objects;

/** Text displayed exactly as supplied. */
public record LiteralComponent(String text) implements TextComponent {
    public LiteralComponent {
        Objects.requireNonNull(text, "text");
    }
}

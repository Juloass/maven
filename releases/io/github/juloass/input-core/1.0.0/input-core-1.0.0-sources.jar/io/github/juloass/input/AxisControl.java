package io.github.juloass.input;

/** A control with a scalar value. */
public non-sealed interface AxisControl extends InputControl { }


package io.github.juloass.input;

import java.util.List;
import java.util.Objects;

/** Maps buttons on one device to a digital action. */
public record ChordBinding(DeviceSelector devices, List<ButtonControl> controls) implements DigitalBinding {
    public ChordBinding {
        Objects.requireNonNull(devices, "devices");
        controls = List.copyOf(Objects.requireNonNull(controls, "controls"));
        if (controls.isEmpty()) throw new IllegalArgumentException("controls must not be empty");
        if (controls.stream().distinct().count() != controls.size()) throw new IllegalArgumentException("controls must be distinct");
    }
}


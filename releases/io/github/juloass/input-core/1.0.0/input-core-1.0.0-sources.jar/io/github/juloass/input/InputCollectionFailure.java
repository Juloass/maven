package io.github.juloass.input;

import java.util.Objects;

/** Describes why a complete input batch is unavailable. */
public record InputCollectionFailure(Code code, String message, long sequence) {
    public enum Code { OVERFLOW, CLOSED, WRONG_THREAD }
    public InputCollectionFailure {
        Objects.requireNonNull(code, "code");
        Objects.requireNonNull(message, "message");
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
    }
}


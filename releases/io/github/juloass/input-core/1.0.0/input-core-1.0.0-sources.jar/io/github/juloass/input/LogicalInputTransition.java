package io.github.juloass.input;

import java.util.OptionalLong;

/** One ordered logical action transition. */
public sealed interface LogicalInputTransition permits DigitalActionTransition, ScalarActionTransition, VectorActionTransition {
    long sequence();
    OptionalLong sourceSequence();
    OptionalLong timestampNanos();
    InputAction action();
}

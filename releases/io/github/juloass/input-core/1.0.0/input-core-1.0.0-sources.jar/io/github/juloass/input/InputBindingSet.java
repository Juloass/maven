package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** An immutable set of context action bindings. */
public final class InputBindingSet {
    public record Entry(Identifier contextId, InputAction action, InputBinding binding, int order) {
        public Entry {
            Objects.requireNonNull(contextId, "contextId");
            Objects.requireNonNull(action, "action");
            Objects.requireNonNull(binding, "binding");
            if (order < 0) throw new IllegalArgumentException("order must not be negative");
            boolean valid = action instanceof DigitalAction && binding instanceof DigitalBinding
                    || action instanceof ScalarAction && binding instanceof ScalarBinding
                    || action instanceof VectorAction && binding instanceof VectorBinding;
            if (!valid) throw new IllegalArgumentException("action and binding types must match");
        }
    }

    private final List<Entry> entries;
    private InputBindingSet(List<Entry> entries) { this.entries = List.copyOf(entries); }
    public static Builder builder() { return new Builder(); }
    public List<Entry> entries() { return entries; }
    public List<Entry> entries(Identifier contextId) {
        return entries.stream().filter(entry -> entry.contextId().equals(contextId)).toList();
    }

    public static final class Builder {
        private final List<Entry> entries = new ArrayList<>();
        public Builder bind(Identifier contextId, InputAction action, InputBinding binding) {
            entries.add(new Entry(contextId, action, binding, entries.size()));
            return this;
        }
        public InputBindingSet build() { return new InputBindingSet(entries); }
    }
}


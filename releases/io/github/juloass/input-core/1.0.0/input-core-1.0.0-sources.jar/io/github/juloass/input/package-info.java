/** Platform-independent input state, ordered transitions, bindings, contexts, and evaluation. */
package io.github.juloass.input;


package io.github.juloass.input;

import java.util.Objects;

/** Describes an input device for the current session. */
public record InputDevice(InputDeviceId id, InputDeviceClass deviceClass, String name) {
    public InputDevice {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(deviceClass, "deviceClass");
        Objects.requireNonNull(name, "name");
    }
}


package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One scalar axis value change. */
public record AxisTransition(long sequence, OptionalLong timestampNanos, ControlRef control,
                             double previousValue, double value) implements RawInputTransition {
    public AxisTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(control, "control");
        if (!(control.control() instanceof AxisControl)) throw new IllegalArgumentException("control must be an axis");
        if (!Double.isFinite(previousValue) || !Double.isFinite(value)) throw new IllegalArgumentException("axis values must be finite");
    }
}


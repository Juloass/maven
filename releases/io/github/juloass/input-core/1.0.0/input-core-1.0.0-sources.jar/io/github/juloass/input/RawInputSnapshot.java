package io.github.juloass.input;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Immutable current physical input state. */
public final class RawInputSnapshot {
    private static final RawInputSnapshot EMPTY = new RawInputSnapshot(Map.of(), Map.of(), Map.of(), Map.of());
    private final Map<InputDeviceId, InputDevice> devices;
    private final Map<ControlRef, Boolean> buttons;
    private final Map<ControlRef, Double> axes;
    private final Map<InputDeviceId, InputVector2> pointers;
    private final Map<ControlRef, LogicalKey> logicalKeys;

    public RawInputSnapshot(Map<InputDeviceId, InputDevice> devices, Map<ControlRef, Boolean> buttons,
                            Map<ControlRef, Double> axes, Map<InputDeviceId, InputVector2> pointers) {
        this(devices, buttons, axes, pointers, Map.of());
    }

    public RawInputSnapshot(Map<InputDeviceId, InputDevice> devices, Map<ControlRef, Boolean> buttons,
                            Map<ControlRef, Double> axes, Map<InputDeviceId, InputVector2> pointers,
                            Map<ControlRef, LogicalKey> logicalKeys) {
        this.devices = Map.copyOf(Objects.requireNonNull(devices, "devices"));
        this.buttons = Map.copyOf(Objects.requireNonNull(buttons, "buttons"));
        this.axes = Map.copyOf(Objects.requireNonNull(axes, "axes"));
        this.pointers = Map.copyOf(Objects.requireNonNull(pointers, "pointers"));
        this.logicalKeys = Map.copyOf(Objects.requireNonNull(logicalKeys, "logicalKeys"));
    }

    public static RawInputSnapshot empty() { return EMPTY; }
    public Map<InputDeviceId, InputDevice> devices() { return devices; }
    public Optional<InputDevice> device(InputDeviceId id) { return Optional.ofNullable(devices.get(id)); }
    public boolean pressed(ControlRef control) { return buttons.getOrDefault(control, false); }
    public double axis(ControlRef control) { return axes.getOrDefault(control, 0.0); }
    public InputVector2 pointer(InputDeviceId device) { return pointers.getOrDefault(device, InputVector2.ZERO); }
    public Map<ControlRef, Boolean> buttons() { return buttons; }
    public Map<ControlRef, Double> axes() { return axes; }
    public Map<InputDeviceId, InputVector2> pointers() { return pointers; }
    public Map<ControlRef, LogicalKey> logicalKeys() { return logicalKeys; }
}

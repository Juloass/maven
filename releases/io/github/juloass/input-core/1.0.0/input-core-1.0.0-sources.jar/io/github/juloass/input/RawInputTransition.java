package io.github.juloass.input;

import java.util.OptionalLong;

/** One ordered physical input transition. */
public sealed interface RawInputTransition permits ButtonTransition, PointerMoveTransition, ScrollTransition,
        TextInputTransition, AxisTransition, DeviceTransition {
    long sequence();
    OptionalLong timestampNanos();
}


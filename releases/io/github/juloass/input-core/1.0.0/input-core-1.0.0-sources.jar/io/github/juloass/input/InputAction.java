package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;

/** A typed logical input action. */
public sealed interface InputAction permits DigitalAction, ScalarAction, VectorAction {
    Identifier id();
}


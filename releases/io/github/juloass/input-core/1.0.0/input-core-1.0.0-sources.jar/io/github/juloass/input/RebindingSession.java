package io.github.juloass.input;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** Captures one runtime binding from ordered raw transitions. */
public final class RebindingSession {
    private final DeviceSelector devices;
    private final Set<ControlRef> ignoredUntilRelease = new HashSet<>();
    private final double axisThreshold;
    private final KeyboardIdentity keyboardIdentity;
    private boolean complete;

    public RebindingSession(RawInputSnapshot initialState, DeviceSelector devices, double axisThreshold) {
        this(initialState, devices, axisThreshold, KeyboardIdentity.PHYSICAL);
    }

    public RebindingSession(RawInputSnapshot initialState, DeviceSelector devices, double axisThreshold,
                            KeyboardIdentity keyboardIdentity) {
        Objects.requireNonNull(initialState, "initialState");
        this.devices = Objects.requireNonNull(devices, "devices");
        if (!Double.isFinite(axisThreshold) || axisThreshold <= 0.0 || axisThreshold > 1.0) {
            throw new IllegalArgumentException("axisThreshold must be in (0, 1]");
        }
        this.axisThreshold = axisThreshold;
        this.keyboardIdentity = Objects.requireNonNull(keyboardIdentity, "keyboardIdentity");
        initialState.buttons().forEach((control, pressed) -> { if (pressed) ignoredUntilRelease.add(control); });
    }

    public Optional<InputBinding> accept(RawInputTransition transition, RawInputSnapshot currentState) {
        Objects.requireNonNull(transition, "transition");
        Objects.requireNonNull(currentState, "currentState");
        if (complete) throw new IllegalStateException("rebinding session is complete");
        if (transition instanceof ButtonTransition button) {
            if (button.kind() == ButtonTransitionKind.RELEASE) { ignoredUntilRelease.remove(button.control()); return Optional.empty(); }
            if (button.kind() != ButtonTransitionKind.PRESS || ignoredUntilRelease.contains(button.control())) return Optional.empty();
            InputDevice device = currentState.device(button.control().device()).orElse(null);
            if (device == null || !devices.matches(device)) return Optional.empty();
            List<ButtonControl> controls = currentState.buttons().entrySet().stream()
                    .filter(entry -> entry.getValue() && entry.getKey().device().equals(device.id()))
                    .map(entry -> entry.getKey().control()).filter(ButtonControl.class::isInstance)
                    .map(ButtonControl.class::cast).filter(control -> !(control instanceof LogicalKey))
                    .map(control -> capturedIdentity(button, control, currentState)).distinct()
                    .sorted(Comparator.comparing(InputControl::stableName)).toList();
            complete = true;
            return Optional.of(controls.size() > 1 ? new ChordBinding(DeviceSelector.device(device.id()), controls)
                    : new DirectButtonBinding(DeviceSelector.device(device.id()), controls.getFirst()));
        }
        if (transition instanceof AxisTransition axis && Math.abs(axis.value()) >= axisThreshold) {
            InputDevice device = currentState.device(axis.control().device()).orElse(null);
            if (device == null || !devices.matches(device)) return Optional.empty();
            complete = true;
            return Optional.of(new DirectAxisBinding(DeviceSelector.device(device.id()),
                    (AxisControl) axis.control().control(), 0.0, axis.value() < 0.0));
        }
        return Optional.empty();
    }

    public boolean complete() { return complete; }

    private ButtonControl capturedIdentity(ButtonTransition event, ButtonControl control, RawInputSnapshot state) {
        if (keyboardIdentity == KeyboardIdentity.PHYSICAL || !(control instanceof KeyboardKey)) return control;
        if (event.control().control().equals(control) && event.logicalKey().isPresent()) return event.logicalKey().get();
        LogicalKey logical = state.logicalKeys().get(new ControlRef(event.control().device(), control));
        return logical == null ? control : logical;
    }
}

package io.github.juloass.input;

import java.util.Objects;

/** Selects one control on one device. */
public record ControlRef(InputDeviceId device, InputControl control) implements Comparable<ControlRef> {
    public ControlRef { Objects.requireNonNull(device, "device"); Objects.requireNonNull(control, "control"); }
    @Override public int compareTo(ControlRef other) {
        int deviceOrder = device.compareTo(other.device);
        return deviceOrder != 0 ? deviceOrder : control.stableName().compareTo(other.control.stableName());
    }
}


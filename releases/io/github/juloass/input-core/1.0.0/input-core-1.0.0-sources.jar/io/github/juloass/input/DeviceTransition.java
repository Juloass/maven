package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One device connection change. */
public record DeviceTransition(long sequence, OptionalLong timestampNanos, InputDevice device,
                               boolean connected) implements RawInputTransition {
    public DeviceTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(device, "device");
    }
}


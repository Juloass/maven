package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One pointer position change. */
public record PointerMoveTransition(long sequence, OptionalLong timestampNanos, InputDeviceId device,
                                    InputVector2 position, InputVector2 movement) implements RawInputTransition {
    public PointerMoveTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(device, "device");
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(movement, "movement");
    }
}


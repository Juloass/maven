package io.github.juloass.input;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;

/** A button press, release, or repeat. */
public record ButtonTransition(long sequence, OptionalLong timestampNanos, ControlRef control,
                               ButtonTransitionKind kind, Optional<LogicalKey> logicalKey)
        implements RawInputTransition {
    public ButtonTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(control, "control");
        Objects.requireNonNull(kind, "kind");
        logicalKey = Objects.requireNonNull(logicalKey, "logicalKey");
        if (!(control.control() instanceof ButtonControl)) throw new IllegalArgumentException("control must be a button");
    }
}


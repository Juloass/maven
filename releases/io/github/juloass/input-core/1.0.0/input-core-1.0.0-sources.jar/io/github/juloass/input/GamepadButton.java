package io.github.juloass.input;

/** Basic gamepad buttons. */
public enum GamepadButton implements ButtonControl {
    A, B, X, Y, LEFT_BUMPER, RIGHT_BUMPER, BACK, START, GUIDE,
    LEFT_THUMB, RIGHT_THUMB, DPAD_UP, DPAD_RIGHT, DPAD_DOWN, DPAD_LEFT;
    @Override public String stableName() { return "gamepad_button:" + name().toLowerCase(); }
}


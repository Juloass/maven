package io.github.juloass.input;

import java.util.Objects;

/** An adapter-provided layout-specific key name. */
public record LogicalKey(String value) implements ButtonControl {
    public LogicalKey {
        Objects.requireNonNull(value, "value");
        if (value.isBlank()) throw new IllegalArgumentException("value must not be blank");
    }

    @Override public String stableName() { return "logical_key:" + value; }
}

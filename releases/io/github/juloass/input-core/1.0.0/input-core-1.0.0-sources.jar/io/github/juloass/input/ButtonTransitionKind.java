package io.github.juloass.input;

/** The change reported by a button transition. */
public enum ButtonTransitionKind { PRESS, RELEASE, REPEAT }


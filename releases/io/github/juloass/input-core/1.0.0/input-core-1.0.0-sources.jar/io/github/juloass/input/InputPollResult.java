package io.github.juloass.input;

import java.util.Objects;
import java.util.Optional;

/** Contains either one complete batch or one collection failure. */
public record InputPollResult(Optional<RawInputBatch> batch, Optional<InputCollectionFailure> failure) {
    public InputPollResult {
        batch = Objects.requireNonNull(batch, "batch");
        failure = Objects.requireNonNull(failure, "failure");
        if (batch.isPresent() == failure.isPresent()) throw new IllegalArgumentException("exactly one result value is required");
    }
    public static InputPollResult success(RawInputBatch batch) {
        return new InputPollResult(Optional.of(Objects.requireNonNull(batch, "batch")), Optional.empty());
    }
    public static InputPollResult failure(InputCollectionFailure failure) {
        return new InputPollResult(Optional.empty(), Optional.of(Objects.requireNonNull(failure, "failure")));
    }
}


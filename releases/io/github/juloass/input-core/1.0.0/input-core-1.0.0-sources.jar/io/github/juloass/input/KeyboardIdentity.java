package io.github.juloass.input;

/** Selects the keyboard identity captured during rebinding. */
public enum KeyboardIdentity { PHYSICAL, LOGICAL }


package io.github.juloass.input;

/** Reports that action evaluation cannot continue across a collection gap. */
public final class InputDiscontinuityException extends IllegalStateException {
    public InputDiscontinuityException() { super("raw input batch is discontinuous"); }
}


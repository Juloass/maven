package io.github.juloass.input;

import java.util.Objects;

/** Maps two physical axes to a two-axis action. */
public record AxisVectorBinding(DeviceSelector devices, AxisControl xAxis, AxisControl yAxis,
                                double deadZone, boolean invertX, boolean invertY,
                                DiagonalNormalization normalization) implements VectorBinding {
    public AxisVectorBinding {
        Objects.requireNonNull(devices, "devices");
        Objects.requireNonNull(xAxis, "xAxis");
        Objects.requireNonNull(yAxis, "yAxis");
        Objects.requireNonNull(normalization, "normalization");
        if (xAxis.equals(yAxis)) throw new IllegalArgumentException("vector axes must differ");
        if (!Double.isFinite(deadZone) || deadZone < 0.0 || deadZone >= 1.0) throw new IllegalArgumentException("deadZone must be in [0, 1)");
    }
}


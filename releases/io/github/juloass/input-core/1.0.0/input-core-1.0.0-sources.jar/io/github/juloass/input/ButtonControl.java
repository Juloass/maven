package io.github.juloass.input;

/** A control with pressed and released states. */
public non-sealed interface ButtonControl extends InputControl { }


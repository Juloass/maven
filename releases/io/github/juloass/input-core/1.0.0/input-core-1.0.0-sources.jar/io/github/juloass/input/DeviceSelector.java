package io.github.juloass.input;

import java.util.Objects;
import java.util.Set;

/** Selects devices for one binding. */
public sealed interface DeviceSelector permits DeviceSelector.Any, DeviceSelector.ByClass, DeviceSelector.ById, DeviceSelector.ByIds {
    boolean matches(InputDevice device);

    static DeviceSelector any() { return Any.INSTANCE; }
    static DeviceSelector deviceClass(InputDeviceClass value) { return new ByClass(value); }
    static DeviceSelector device(InputDeviceId value) { return new ById(value); }
    static DeviceSelector devices(Set<InputDeviceId> values) { return new ByIds(values); }

    enum Any implements DeviceSelector {
        INSTANCE;
        @Override public boolean matches(InputDevice device) { return device != null; }
    }

    record ByClass(InputDeviceClass value) implements DeviceSelector {
        public ByClass { Objects.requireNonNull(value, "value"); }
        @Override public boolean matches(InputDevice device) { return device != null && device.deviceClass() == value; }
    }

    record ById(InputDeviceId value) implements DeviceSelector {
        public ById { Objects.requireNonNull(value, "value"); }
        @Override public boolean matches(InputDevice device) { return device != null && device.id().equals(value); }
    }

    record ByIds(Set<InputDeviceId> values) implements DeviceSelector {
        public ByIds {
            values = Set.copyOf(Objects.requireNonNull(values, "values"));
            if (values.isEmpty()) throw new IllegalArgumentException("values must not be empty");
        }
        @Override public boolean matches(InputDevice device) { return device != null && values.contains(device.id()); }
    }
}


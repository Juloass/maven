package io.github.juloass.input;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.OptionalLong;

/** Evaluates ordered raw input against immutable binding and context snapshots. */
public final class InputEvaluator {
    private RawInputSnapshot raw = RawInputSnapshot.empty();
    private LogicalInputSnapshot logical = LogicalInputSnapshot.empty();
    private final Set<ControlRef> captured = new HashSet<>();
    private long nextLogicalSequence;
    private boolean acceptsDiscontinuity;

    public synchronized LogicalInputBatch evaluate(RawInputBatch batch, InputBindingSet bindings,
                                                   InputContextStack contexts) {
        Objects.requireNonNull(batch, "batch");
        bindings = Objects.requireNonNull(bindings, "bindings");
        contexts = Objects.requireNonNull(contexts, "contexts");
        if (!batch.continuous() && !acceptsDiscontinuity) throw new InputDiscontinuityException();
        acceptsDiscontinuity = false;

        MutableRaw state = new MutableRaw(raw);
        LogicalInputSnapshot previous = logical;
        List<LogicalInputTransition> output = new ArrayList<>();
        for (RawInputTransition transition : batch.transitions()) {
            state.apply(transition);
            RawInputSnapshot step = state.snapshot();
            LogicalInputSnapshot current = evaluateSnapshot(step, bindings, contexts);
            appendChanges(previous, current, transition, step, bindings, contexts, output);
            previous = current;
            captured.removeIf(control -> !step.pressed(control));
        }
        if (batch.transitions().isEmpty()) {
            LogicalInputSnapshot current = evaluateSnapshot(batch.snapshot(), bindings, contexts);
            appendChanges(previous, current, null, batch.snapshot(), bindings, contexts, output);
            previous = current;
        }
        raw = batch.snapshot();
        logical = previous;
        return new LogicalInputBatch(logical, output);
    }

    /** Resets retained state after the caller handles a collection discontinuity. */
    public synchronized void reset(RawInputSnapshot snapshot) {
        raw = Objects.requireNonNull(snapshot, "snapshot");
        logical = LogicalInputSnapshot.empty();
        captured.clear();
        acceptsDiscontinuity = true;
    }

    public synchronized LogicalInputSnapshot snapshot() { return logical; }

    private LogicalInputSnapshot evaluateSnapshot(RawInputSnapshot snapshot, InputBindingSet bindings,
                                                  InputContextStack contexts) {
        Map<DigitalAction, Boolean> digital = new LinkedHashMap<>();
        Map<ScalarAction, Double> scalar = new LinkedHashMap<>();
        Map<VectorAction, InputVector2> vector = new LinkedHashMap<>();
        Set<InputAction> consumedActions = new HashSet<>();
        Set<ControlRef> masked = new HashSet<>(captured);

        for (InputContext context : contexts.contexts()) {
            List<InputBindingSet.Entry> entries = bindings.entries(context.id());
            for (InputAction action : context.actions().keySet().stream()
                    .sorted(Comparator.comparing(value -> value.id().toString())).toList()) {
                if (consumedActions.contains(action)) continue;
                List<InputBinding> actionBindings = entries.stream().filter(entry -> entry.action().equals(action))
                        .sorted(Comparator.comparingInt(InputBindingSet.Entry::order)).map(InputBindingSet.Entry::binding).toList();
                Value value = evaluateBindings(action, actionBindings, snapshot, masked);
                if (action instanceof DigitalAction typed) digital.putIfAbsent(typed, value.digital);
                if (action instanceof ScalarAction typed) scalar.putIfAbsent(typed, value.scalar);
                if (action instanceof VectorAction typed) vector.putIfAbsent(typed, value.vector);
                ConsumptionMode mode = context.actions().get(action);
                if (mode == ConsumptionMode.CONSUME_ACTION && !value.rest()) consumedActions.add(action);
                if (mode == ConsumptionMode.CONSUME_CONTROLS && !value.rest()) {
                    masked.addAll(value.controls);
                    captured.addAll(value.controls.stream().filter(snapshot::pressed).toList());
                }
            }
            if (context.blocksLowerContexts()) break;
        }
        return new LogicalInputSnapshot(digital, scalar, vector);
    }

    private void appendChanges(LogicalInputSnapshot previous, LogicalInputSnapshot current,
                               RawInputTransition source, RawInputSnapshot rawState,
                               InputBindingSet bindings, InputContextStack contexts,
                               List<LogicalInputTransition> output) {
        OptionalLong sourceSequence = source == null ? OptionalLong.empty() : OptionalLong.of(source.sequence());
        OptionalLong timestamp = source == null ? OptionalLong.empty() : source.timestampNanos();
        Set<DigitalAction> digital = new LinkedHashSet<>();
        digital.addAll(previous.digitalValues().keySet()); digital.addAll(current.digitalValues().keySet());
        digital.stream().sorted(Comparator.comparing(value -> value.id().toString())).forEach(action -> {
            boolean before = previous.value(action);
            boolean after = current.value(action);
            if (before != after) output.add(new DigitalActionTransition(nextLogicalSequence++, sourceSequence,
                    timestamp, action, after ? ButtonTransitionKind.PRESS : ButtonTransitionKind.RELEASE));
            else if (after && source instanceof ButtonTransition button && button.kind() == ButtonTransitionKind.REPEAT
                    && actionUses(action, button, rawState, bindings, contexts)) {
                output.add(new DigitalActionTransition(nextLogicalSequence++, sourceSequence, timestamp,
                        action, ButtonTransitionKind.REPEAT));
            }
        });
        Set<ScalarAction> scalar = new LinkedHashSet<>();
        scalar.addAll(previous.scalarValues().keySet()); scalar.addAll(current.scalarValues().keySet());
        scalar.stream().sorted(Comparator.comparing(value -> value.id().toString())).forEach(action -> {
            double before = previous.value(action), after = current.value(action);
            if (Double.compare(before, after) != 0) output.add(new ScalarActionTransition(nextLogicalSequence++,
                    sourceSequence, timestamp, action, before, after));
        });
        Set<VectorAction> vector = new LinkedHashSet<>();
        vector.addAll(previous.vectorValues().keySet()); vector.addAll(current.vectorValues().keySet());
        vector.stream().sorted(Comparator.comparing(value -> value.id().toString())).forEach(action -> {
            InputVector2 before = previous.value(action), after = current.value(action);
            if (!before.equals(after)) output.add(new VectorActionTransition(nextLogicalSequence++, sourceSequence,
                    timestamp, action, before, after));
        });
    }

    private static boolean actionUses(DigitalAction action, ButtonTransition transition, RawInputSnapshot snapshot, InputBindingSet bindings,
                                      InputContextStack contexts) {
        InputDevice sourceDevice = snapshot.device(transition.control().device()).orElse(null);
        if (sourceDevice == null) return false;
        for (InputContext context : contexts.contexts()) {
            if (!context.actions().containsKey(action)) continue;
            for (InputBindingSet.Entry entry : bindings.entries(context.id())) {
                if (!entry.action().equals(action)) continue;
                DeviceSelector selector = selector(entry.binding());
                if (!selector.matches(sourceDevice)) continue;
                if (uses(entry.binding(), transition.control().control())) return true;
                if (transition.logicalKey().isPresent() && uses(entry.binding(), transition.logicalKey().get())) return true;
            }
            if (context.blocksLowerContexts()) return false;
        }
        return false;
    }

    private static DeviceSelector selector(InputBinding binding) {
        if (binding instanceof DirectButtonBinding value) return value.devices();
        if (binding instanceof ChordBinding value) return value.devices();
        if (binding instanceof DirectAxisBinding value) return value.devices();
        if (binding instanceof ButtonAxisBinding value) return value.devices();
        if (binding instanceof AxisVectorBinding value) return value.devices();
        return ((ButtonVectorBinding) binding).devices();
    }

    private static boolean uses(InputBinding binding, InputControl control) {
        if (binding instanceof DirectButtonBinding direct) return direct.control().equals(control);
        return binding instanceof ChordBinding chord && chord.controls().contains(control);
    }

    private static Value evaluateBindings(InputAction action, List<InputBinding> bindings, RawInputSnapshot snapshot,
                                          Set<ControlRef> masked) {
        if (action instanceof DigitalAction) {
            Value best = Value.digital(false, Set.of());
            for (InputBinding binding : bindings) {
                Value value = evaluate((DigitalBinding) binding, snapshot, masked);
                if (value.digital) return value;
            }
            return best;
        }
        if (action instanceof ScalarAction) {
            Value best = Value.scalar(0.0, Set.of());
            for (InputBinding binding : bindings) {
                Value value = evaluate((ScalarBinding) binding, snapshot, masked);
                if (Math.abs(value.scalar) > Math.abs(best.scalar)) best = value;
            }
            return best;
        }
        Value best = Value.vector(InputVector2.ZERO, Set.of());
        for (InputBinding binding : bindings) {
            Value value = evaluate((VectorBinding) binding, snapshot, masked);
            if (value.vector.length() > best.vector.length()) best = value;
        }
        return best;
    }

    private static Value evaluate(DigitalBinding binding, RawInputSnapshot snapshot, Set<ControlRef> masked) {
        if (binding instanceof DirectButtonBinding direct) {
            for (InputDevice device : devices(snapshot, direct.devices())) {
                ControlRef ref = new ControlRef(device.id(), direct.control());
                if (!isMasked(ref, snapshot, masked) && snapshot.pressed(ref)) return Value.digital(true, aliases(ref, snapshot));
            }
            return Value.digital(false, Set.of());
        }
        ChordBinding chord = (ChordBinding) binding;
        for (InputDevice device : devices(snapshot, chord.devices())) {
            Set<ControlRef> refs = new LinkedHashSet<>();
            boolean active = true;
            for (ButtonControl control : chord.controls()) {
                ControlRef ref = new ControlRef(device.id(), control); refs.add(ref);
                active &= !isMasked(ref, snapshot, masked) && snapshot.pressed(ref);
                refs.addAll(aliases(ref, snapshot));
            }
            if (active) return Value.digital(true, refs);
        }
        return Value.digital(false, Set.of());
    }

    private static Value evaluate(ScalarBinding binding, RawInputSnapshot snapshot, Set<ControlRef> masked) {
        if (binding instanceof DirectAxisBinding direct) {
            Value best = Value.scalar(0.0, Set.of());
            for (InputDevice device : devices(snapshot, direct.devices())) {
                ControlRef ref = new ControlRef(device.id(), direct.control());
                double value = masked.contains(ref) ? 0.0 : snapshot.axis(ref);
                value = Math.abs(value) <= direct.deadZone() ? 0.0 : (direct.inverted() ? -value : value);
                if (Math.abs(value) > Math.abs(best.scalar)) best = Value.scalar(value, Set.of(ref));
            }
            return best;
        }
        ButtonAxisBinding buttons = (ButtonAxisBinding) binding;
        Value best = Value.scalar(0.0, Set.of());
        for (InputDevice device : devices(snapshot, buttons.devices())) {
            ControlRef negative = new ControlRef(device.id(), buttons.negative());
            ControlRef positive = new ControlRef(device.id(), buttons.positive());
            double value = (masked.contains(positive) ? 0 : snapshot.pressed(positive) ? 1 : 0)
                    - (masked.contains(negative) ? 0 : snapshot.pressed(negative) ? 1 : 0);
            if (Math.abs(value) > Math.abs(best.scalar)) best = Value.scalar(value, Set.of(negative, positive));
        }
        return best;
    }

    private static Value evaluate(VectorBinding binding, RawInputSnapshot snapshot, Set<ControlRef> masked) {
        Value best = Value.vector(InputVector2.ZERO, Set.of());
        if (binding instanceof AxisVectorBinding axes) {
            for (InputDevice device : devices(snapshot, axes.devices())) {
                ControlRef x = new ControlRef(device.id(), axes.xAxis()), y = new ControlRef(device.id(), axes.yAxis());
                double xv = masked.contains(x) ? 0.0 : snapshot.axis(x);
                double yv = masked.contains(y) ? 0.0 : snapshot.axis(y);
                if (Math.abs(xv) <= axes.deadZone()) xv = 0.0;
                if (Math.abs(yv) <= axes.deadZone()) yv = 0.0;
                InputVector2 value = normalize(new InputVector2(axes.invertX() ? -xv : xv, axes.invertY() ? -yv : yv), axes.normalization());
                if (value.length() > best.vector.length()) best = Value.vector(value, Set.of(x, y));
            }
            return best;
        }
        ButtonVectorBinding buttons = (ButtonVectorBinding) binding;
        for (InputDevice device : devices(snapshot, buttons.devices())) {
            ControlRef left = new ControlRef(device.id(), buttons.left()), right = new ControlRef(device.id(), buttons.right());
            ControlRef up = new ControlRef(device.id(), buttons.up()), down = new ControlRef(device.id(), buttons.down());
            double x = pressed(snapshot, right, masked) - pressed(snapshot, left, masked);
            double y = pressed(snapshot, down, masked) - pressed(snapshot, up, masked);
            InputVector2 value = normalize(new InputVector2(x, y), buttons.normalization());
            if (value.length() > best.vector.length()) best = Value.vector(value, Set.of(left, right, up, down));
        }
        return best;
    }

    private static double pressed(RawInputSnapshot state, ControlRef ref, Set<ControlRef> masked) {
        return !isMasked(ref, state, masked) && state.pressed(ref) ? 1.0 : 0.0;
    }
    private static boolean isMasked(ControlRef ref, RawInputSnapshot state, Set<ControlRef> masked) {
        return aliases(ref, state).stream().anyMatch(masked::contains);
    }
    private static Set<ControlRef> aliases(ControlRef ref, RawInputSnapshot state) {
        Set<ControlRef> aliases = new LinkedHashSet<>();
        aliases.add(ref);
        if (ref.control() instanceof LogicalKey logical) {
            state.logicalKeys().forEach((physical, value) -> {
                if (physical.device().equals(ref.device()) && value.equals(logical)) aliases.add(physical);
            });
        } else {
            LogicalKey logical = state.logicalKeys().get(ref);
            if (logical != null) aliases.add(new ControlRef(ref.device(), logical));
        }
        return Set.copyOf(aliases);
    }
    private static InputVector2 normalize(InputVector2 value, DiagonalNormalization mode) {
        return mode == DiagonalNormalization.UNIT_LENGTH ? value.clampedToUnitLength() : value;
    }
    private static List<InputDevice> devices(RawInputSnapshot snapshot, DeviceSelector selector) {
        return snapshot.devices().values().stream().filter(selector::matches)
                .sorted(Comparator.comparing(InputDevice::id)).toList();
    }

    private record Value(boolean digital, double scalar, InputVector2 vector, Set<ControlRef> controls) {
        static Value digital(boolean value, Set<ControlRef> controls) { return new Value(value, 0.0, InputVector2.ZERO, Set.copyOf(controls)); }
        static Value scalar(double value, Set<ControlRef> controls) { return new Value(false, value, InputVector2.ZERO, Set.copyOf(controls)); }
        static Value vector(InputVector2 value, Set<ControlRef> controls) { return new Value(false, 0.0, value, Set.copyOf(controls)); }
        boolean rest() { return !digital && scalar == 0.0 && vector.equals(InputVector2.ZERO); }
    }

    private static final class MutableRaw {
        private final Map<InputDeviceId, InputDevice> devices;
        private final Map<ControlRef, Boolean> buttons;
        private final Map<ControlRef, Double> axes;
        private final Map<InputDeviceId, InputVector2> pointers;
        private final Map<ControlRef, LogicalKey> logicalKeys;
        MutableRaw(RawInputSnapshot snapshot) {
            devices = new HashMap<>(snapshot.devices()); buttons = new HashMap<>(snapshot.buttons());
            axes = new HashMap<>(snapshot.axes()); pointers = new HashMap<>(snapshot.pointers());
            logicalKeys = new HashMap<>(snapshot.logicalKeys());
        }
        void apply(RawInputTransition transition) {
            if (transition instanceof DeviceTransition device) {
                if (device.connected()) devices.put(device.device().id(), device.device());
                else { devices.remove(device.device().id()); buttons.keySet().removeIf(key -> key.device().equals(device.device().id()));
                    axes.keySet().removeIf(key -> key.device().equals(device.device().id())); pointers.remove(device.device().id()); }
            } else if (transition instanceof ButtonTransition button) {
                if (button.kind() != ButtonTransitionKind.REPEAT) buttons.put(button.control(), button.kind() == ButtonTransitionKind.PRESS);
                button.logicalKey().ifPresent(key -> {
                    logicalKeys.put(button.control(), key);
                    if (button.kind() != ButtonTransitionKind.REPEAT) buttons.put(new ControlRef(button.control().device(), key), button.kind() == ButtonTransitionKind.PRESS);
                });
            } else if (transition instanceof AxisTransition axis) axes.put(axis.control(), axis.value());
            else if (transition instanceof PointerMoveTransition pointer) pointers.put(pointer.device(), pointer.position());
        }
        RawInputSnapshot snapshot() { return new RawInputSnapshot(devices, buttons, axes, pointers, logicalKeys); }
    }
}

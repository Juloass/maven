package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One digital action press, release, or repeat. */
public record DigitalActionTransition(long sequence, OptionalLong sourceSequence, OptionalLong timestampNanos,
                                      DigitalAction action, ButtonTransitionKind kind) implements LogicalInputTransition {
    public DigitalActionTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(sourceSequence, "sourceSequence"); Objects.requireNonNull(timestampNanos, "timestampNanos"); Objects.requireNonNull(action, "action"); Objects.requireNonNull(kind, "kind");
    }
}

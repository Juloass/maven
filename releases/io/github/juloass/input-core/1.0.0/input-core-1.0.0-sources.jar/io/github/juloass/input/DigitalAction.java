package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;

/** A Boolean logical action. */
public record DigitalAction(Identifier id) implements InputAction {
    public DigitalAction { Objects.requireNonNull(id, "id"); }
    public static DigitalAction of(String id) { return new DigitalAction(Identifier.parse(id)); }
}


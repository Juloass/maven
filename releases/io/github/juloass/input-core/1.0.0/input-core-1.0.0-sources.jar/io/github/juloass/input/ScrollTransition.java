package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One pointer scroll change. */
public record ScrollTransition(long sequence, OptionalLong timestampNanos, InputDeviceId device,
                               InputVector2 amount) implements RawInputTransition {
    public ScrollTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(device, "device");
        Objects.requireNonNull(amount, "amount");
    }
}


package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;

/** A scalar logical action. */
public record ScalarAction(Identifier id) implements InputAction {
    public ScalarAction { Objects.requireNonNull(id, "id"); }
    public static ScalarAction of(String id) { return new ScalarAction(Identifier.parse(id)); }
}


package io.github.juloass.input;

/** A runtime mapping from physical controls to one logical value. */
public sealed interface InputBinding permits DigitalBinding, ScalarBinding, VectorBinding { }


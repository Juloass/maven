package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;

/** One exact binding conflict in an active context. */
public record BindingConflict(Identifier contextId, InputAction action, InputBinding binding) {
    public BindingConflict {
        Objects.requireNonNull(contextId, "contextId"); Objects.requireNonNull(action, "action"); Objects.requireNonNull(binding, "binding");
    }
}


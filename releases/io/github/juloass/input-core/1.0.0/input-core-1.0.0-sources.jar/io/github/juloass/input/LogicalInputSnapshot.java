package io.github.juloass.input;

import java.util.Map;
import java.util.Objects;

/** Immutable current logical action state. */
public final class LogicalInputSnapshot {
    private final Map<DigitalAction, Boolean> digital;
    private final Map<ScalarAction, Double> scalar;
    private final Map<VectorAction, InputVector2> vector;
    public LogicalInputSnapshot(Map<DigitalAction, Boolean> digital, Map<ScalarAction, Double> scalar,
                                Map<VectorAction, InputVector2> vector) {
        this.digital = Map.copyOf(Objects.requireNonNull(digital, "digital"));
        this.scalar = Map.copyOf(Objects.requireNonNull(scalar, "scalar"));
        this.vector = Map.copyOf(Objects.requireNonNull(vector, "vector"));
    }
    public static LogicalInputSnapshot empty() { return new LogicalInputSnapshot(Map.of(), Map.of(), Map.of()); }
    public boolean value(DigitalAction action) { return digital.getOrDefault(action, false); }
    public double value(ScalarAction action) { return scalar.getOrDefault(action, 0.0); }
    public InputVector2 value(VectorAction action) { return vector.getOrDefault(action, InputVector2.ZERO); }
    public Map<DigitalAction, Boolean> digitalValues() { return digital; }
    public Map<ScalarAction, Double> scalarValues() { return scalar; }
    public Map<VectorAction, InputVector2> vectorValues() { return vector; }
}


package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One vector action value change. */
public record VectorActionTransition(long sequence, OptionalLong sourceSequence, OptionalLong timestampNanos,
                                     VectorAction action, InputVector2 previousValue, InputVector2 value)
        implements LogicalInputTransition {
    public VectorActionTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(sourceSequence, "sourceSequence"); Objects.requireNonNull(timestampNanos, "timestampNanos"); Objects.requireNonNull(action, "action");
        Objects.requireNonNull(previousValue, "previousValue"); Objects.requireNonNull(value, "value");
    }
}

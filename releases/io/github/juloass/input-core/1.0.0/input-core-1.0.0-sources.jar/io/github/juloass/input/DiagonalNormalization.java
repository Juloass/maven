package io.github.juloass.input;

/** Defines how a composed two-axis value handles diagonals. */
public enum DiagonalNormalization { NONE, UNIT_LENGTH }


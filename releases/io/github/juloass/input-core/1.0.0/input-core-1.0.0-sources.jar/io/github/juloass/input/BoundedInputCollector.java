package io.github.juloass.input;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;

/** A synchronized bounded collector shared by platform adapters. */
public final class BoundedInputCollector implements AutoCloseable {
    private final int capacity;
    private final Map<InputDeviceId, InputDevice> devices = new LinkedHashMap<>();
    private final Map<ControlRef, Boolean> buttons = new HashMap<>();
    private final Map<ControlRef, Double> axes = new HashMap<>();
    private final Map<InputDeviceId, InputVector2> pointers = new HashMap<>();
    private final Map<ControlRef, LogicalKey> logicalKeys = new HashMap<>();
    private final List<RawInputTransition> transitions;
    private long nextSequence;
    private boolean overflow;
    private boolean discontinuous;
    private boolean closed;

    public BoundedInputCollector(int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("capacity must be positive");
        this.capacity = capacity;
        this.transitions = new ArrayList<>(Math.min(capacity, 1024));
    }

    public synchronized void connect(InputDevice device, OptionalLong timestamp) {
        requireOpen();
        Objects.requireNonNull(device, "device");
        devices.put(device.id(), device);
        add(sequence -> new DeviceTransition(sequence, timestamp(timestamp), device, true));
    }

    public synchronized void disconnect(InputDeviceId id, OptionalLong timestamp) {
        requireOpen();
        InputDevice device = devices.remove(Objects.requireNonNull(id, "id"));
        if (device == null) return;
        buttons.keySet().removeIf(control -> control.device().equals(id));
        axes.keySet().removeIf(control -> control.device().equals(id));
        pointers.remove(id);
        logicalKeys.keySet().removeIf(control -> control.device().equals(id));
        add(sequence -> new DeviceTransition(sequence, timestamp(timestamp), device, false));
    }

    public synchronized void button(InputDeviceId device, ButtonControl control, ButtonTransitionKind kind,
                                    LogicalKey logicalKey, OptionalLong timestamp) {
        requireDevice(device);
        Objects.requireNonNull(control, "control");
        Objects.requireNonNull(kind, "kind");
        ControlRef physical = new ControlRef(device, control);
        if (kind == ButtonTransitionKind.PRESS) buttons.put(physical, true);
        if (kind == ButtonTransitionKind.RELEASE) buttons.put(physical, false);
        if (logicalKey != null) {
            logicalKeys.put(physical, logicalKey);
            ControlRef logical = new ControlRef(device, logicalKey);
            if (kind == ButtonTransitionKind.PRESS) buttons.put(logical, true);
            if (kind == ButtonTransitionKind.RELEASE) buttons.put(logical, false);
        }
        add(sequence -> new ButtonTransition(sequence, timestamp(timestamp), physical, kind, Optional.ofNullable(logicalKey)));
    }

    public synchronized void axis(InputDeviceId device, AxisControl control, double value, OptionalLong timestamp) {
        requireDevice(device);
        if (!Double.isFinite(value)) throw new IllegalArgumentException("value must be finite");
        ControlRef reference = new ControlRef(device, Objects.requireNonNull(control, "control"));
        double previous = axes.getOrDefault(reference, 0.0);
        if (Double.compare(previous, value) == 0) return;
        axes.put(reference, value);
        add(sequence -> new AxisTransition(sequence, timestamp(timestamp), reference, previous, value));
    }

    public synchronized void pointer(InputDeviceId device, InputVector2 position, OptionalLong timestamp) {
        requireDevice(device);
        Objects.requireNonNull(position, "position");
        InputVector2 previous = pointers.putIfAbsent(device, position);
        if (previous == null || previous.equals(position)) return;
        pointers.put(device, position);
        InputVector2 movement = new InputVector2(position.x() - previous.x(), position.y() - previous.y());
        add(sequence -> new PointerMoveTransition(sequence, timestamp(timestamp), device, position, movement));
    }

    public synchronized void scroll(InputDeviceId device, InputVector2 amount, OptionalLong timestamp) {
        requireDevice(device);
        Objects.requireNonNull(amount, "amount");
        add(sequence -> new ScrollTransition(sequence, timestamp(timestamp), device, amount));
    }

    public synchronized void text(InputDeviceId device, int codePoint, OptionalLong timestamp) {
        requireDevice(device);
        add(sequence -> new TextInputTransition(sequence, timestamp(timestamp), device, codePoint));
    }

    public synchronized InputPollResult poll() {
        if (closed) return InputPollResult.failure(new InputCollectionFailure(InputCollectionFailure.Code.CLOSED,
                "input collector is closed", nextSequence));
        if (overflow) {
            transitions.clear();
            overflow = false;
            discontinuous = true;
            return InputPollResult.failure(new InputCollectionFailure(InputCollectionFailure.Code.OVERFLOW,
                    "input transition capacity was exceeded", nextSequence));
        }
        RawInputBatch batch = new RawInputBatch(snapshot(), List.copyOf(transitions), !discontinuous);
        transitions.clear();
        discontinuous = false;
        return InputPollResult.success(batch);
    }

    public synchronized RawInputSnapshot snapshot() {
        return new RawInputSnapshot(devices, buttons, axes, pointers, logicalKeys);
    }

    @Override public synchronized void close() { closed = true; transitions.clear(); }

    private void add(TransitionFactory factory) {
        long sequence = nextSequence++;
        if (overflow) return;
        if (transitions.size() == capacity) { overflow = true; transitions.clear(); return; }
        transitions.add(factory.create(sequence));
    }

    private void requireDevice(InputDeviceId id) {
        requireOpen();
        Objects.requireNonNull(id, "device");
        if (!devices.containsKey(id)) throw new IllegalArgumentException("device is not connected: " + id);
    }

    private void requireOpen() { if (closed) throw new IllegalStateException("input collector is closed"); }
    private static OptionalLong timestamp(OptionalLong value) { return Objects.requireNonNull(value, "timestamp"); }
    private interface TransitionFactory { RawInputTransition create(long sequence); }
}

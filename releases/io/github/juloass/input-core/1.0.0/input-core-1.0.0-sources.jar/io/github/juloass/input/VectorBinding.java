package io.github.juloass.input;

/** A binding for a vector action. */
public sealed interface VectorBinding extends InputBinding permits ButtonVectorBinding, AxisVectorBinding { }


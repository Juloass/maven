package io.github.juloass.input;

import java.util.Objects;

/** Maps negative and positive buttons to a scalar action. */
public record ButtonAxisBinding(DeviceSelector devices, ButtonControl negative, ButtonControl positive)
        implements ScalarBinding {
    public ButtonAxisBinding {
        Objects.requireNonNull(devices, "devices");
        Objects.requireNonNull(negative, "negative");
        Objects.requireNonNull(positive, "positive");
        if (negative.equals(positive)) throw new IllegalArgumentException("axis buttons must differ");
    }
}


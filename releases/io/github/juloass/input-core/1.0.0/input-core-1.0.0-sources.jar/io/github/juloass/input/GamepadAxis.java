package io.github.juloass.input;

/** Basic gamepad axes. */
public enum GamepadAxis implements AxisControl {
    LEFT_X, LEFT_Y, RIGHT_X, RIGHT_Y, LEFT_TRIGGER, RIGHT_TRIGGER;
    @Override public String stableName() { return "gamepad_axis:" + name().toLowerCase(); }
}


package io.github.juloass.input;

/** A stable physical control name. */
public sealed interface InputControl permits ButtonControl, AxisControl { String stableName(); }


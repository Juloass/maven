package io.github.juloass.input;

/** Pointer buttons with stable semantic positions. */
public enum PointerButton implements ButtonControl {
    PRIMARY, SECONDARY, MIDDLE, BUTTON_4, BUTTON_5, BUTTON_6, BUTTON_7, BUTTON_8;
    @Override public String stableName() { return "pointer:" + name().toLowerCase(); }
}


package io.github.juloass.input;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/** An immutable high-to-low input context order. */
public final class InputContextStack {
    private final List<InputContext> contexts;
    public InputContextStack(List<InputContext> contexts) {
        Objects.requireNonNull(contexts, "contexts");
        List<Indexed> indexed = new ArrayList<>();
        Set<Object> ids = new HashSet<>();
        for (int index = 0; index < contexts.size(); index++) {
            InputContext context = Objects.requireNonNull(contexts.get(index), "context");
            if (!ids.add(context.id())) throw new IllegalArgumentException("duplicate context: " + context.id());
            indexed.add(new Indexed(index, context));
        }
        indexed.sort(Comparator.comparingInt((Indexed value) -> value.context.priority()).reversed()
                .thenComparingInt(Indexed::index));
        this.contexts = indexed.stream().map(Indexed::context).toList();
    }
    public static InputContextStack of(InputContext... contexts) { return new InputContextStack(List.of(contexts)); }
    public List<InputContext> contexts() { return contexts; }
    private record Indexed(int index, InputContext context) { }
}


package io.github.juloass.input;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Finds exact runtime binding conflicts in active contexts. */
public final class BindingConflicts {
    private BindingConflicts() { }
    public static List<BindingConflict> find(InputBinding candidate, InputAction target,
                                             InputBindingSet bindings, InputContextStack contexts) {
        Objects.requireNonNull(candidate, "candidate"); Objects.requireNonNull(target, "target");
        Objects.requireNonNull(bindings, "bindings"); Objects.requireNonNull(contexts, "contexts");
        List<BindingConflict> conflicts = new ArrayList<>();
        for (InputContext context : contexts.contexts()) {
            for (InputBindingSet.Entry entry : bindings.entries(context.id())) {
                if (!entry.action().equals(target) && entry.binding().equals(candidate)) {
                    conflicts.add(new BindingConflict(context.id(), entry.action(), entry.binding()));
                }
            }
        }
        return List.copyOf(conflicts);
    }
}


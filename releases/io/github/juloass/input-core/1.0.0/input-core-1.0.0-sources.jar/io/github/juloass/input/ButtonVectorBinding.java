package io.github.juloass.input;

import java.util.Objects;

/** Maps four buttons to a two-axis action. */
public record ButtonVectorBinding(DeviceSelector devices, ButtonControl left, ButtonControl right,
                                  ButtonControl up, ButtonControl down, DiagonalNormalization normalization)
        implements VectorBinding {
    public ButtonVectorBinding {
        Objects.requireNonNull(devices, "devices");
        Objects.requireNonNull(left, "left");
        Objects.requireNonNull(right, "right");
        Objects.requireNonNull(up, "up");
        Objects.requireNonNull(down, "down");
        Objects.requireNonNull(normalization, "normalization");
        if (java.util.Set.of(left, right, up, down).size() != 4) throw new IllegalArgumentException("vector buttons must differ");
    }
}


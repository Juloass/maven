package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** One active logical input context. */
public final class InputContext {
    private final Identifier id;
    private final int priority;
    private final Map<InputAction, ConsumptionMode> actions;
    private final boolean blocksLowerContexts;

    private InputContext(Identifier id, int priority, Map<InputAction, ConsumptionMode> actions, boolean blocksLowerContexts) {
        this.id = Objects.requireNonNull(id, "id");
        this.priority = priority;
        this.actions = Map.copyOf(actions);
        this.blocksLowerContexts = blocksLowerContexts;
    }

    public static Builder builder(Identifier id, int priority) { return new Builder(id, priority); }
    public Identifier id() { return id; }
    public int priority() { return priority; }
    public Map<InputAction, ConsumptionMode> actions() { return actions; }
    public boolean blocksLowerContexts() { return blocksLowerContexts; }

    public static final class Builder {
        private final Identifier id;
        private final int priority;
        private final Map<InputAction, ConsumptionMode> actions = new LinkedHashMap<>();
        private boolean blocksLower;
        private Builder(Identifier id, int priority) { this.id = Objects.requireNonNull(id, "id"); this.priority = priority; }
        public Builder action(InputAction action, ConsumptionMode mode) {
            actions.put(Objects.requireNonNull(action, "action"), Objects.requireNonNull(mode, "mode"));
            return this;
        }
        public Builder blocksLowerContexts(boolean value) { blocksLower = value; return this; }
        public InputContext build() { return new InputContext(id, priority, actions, blocksLower); }
    }
}


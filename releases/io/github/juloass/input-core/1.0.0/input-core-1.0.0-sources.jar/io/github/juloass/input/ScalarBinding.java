package io.github.juloass.input;

/** A binding for a scalar action. */
public sealed interface ScalarBinding extends InputBinding permits DirectAxisBinding, ButtonAxisBinding { }


package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One scalar action value change. */
public record ScalarActionTransition(long sequence, OptionalLong sourceSequence, OptionalLong timestampNanos,
                                     ScalarAction action, double previousValue, double value) implements LogicalInputTransition {
    public ScalarActionTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(sourceSequence, "sourceSequence"); Objects.requireNonNull(timestampNanos, "timestampNanos"); Objects.requireNonNull(action, "action");
        if (!Double.isFinite(previousValue) || !Double.isFinite(value)) throw new IllegalArgumentException("values must be finite");
    }
}

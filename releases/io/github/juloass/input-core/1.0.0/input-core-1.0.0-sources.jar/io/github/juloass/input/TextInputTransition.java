package io.github.juloass.input;

import java.util.Objects;
import java.util.OptionalLong;

/** One committed Unicode code point. */
public record TextInputTransition(long sequence, OptionalLong timestampNanos, InputDeviceId device,
                                  int codePoint) implements RawInputTransition {
    public TextInputTransition {
        if (sequence < 0) throw new IllegalArgumentException("sequence must not be negative");
        Objects.requireNonNull(timestampNanos, "timestampNanos");
        Objects.requireNonNull(device, "device");
        if (!Character.isValidCodePoint(codePoint)) throw new IllegalArgumentException("invalid Unicode code point");
    }
}


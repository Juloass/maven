package io.github.juloass.input;

/** Stable physical keyboard keys used by both adapters. */
public enum KeyboardKey implements ButtonControl {
    UNKNOWN, SPACE, APOSTROPHE, COMMA, MINUS, PERIOD, SLASH,
    DIGIT_0, DIGIT_1, DIGIT_2, DIGIT_3, DIGIT_4, DIGIT_5, DIGIT_6, DIGIT_7, DIGIT_8, DIGIT_9,
    SEMICOLON, EQUAL,
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
    LEFT_BRACKET, BACKSLASH, RIGHT_BRACKET, GRAVE_ACCENT,
    ESCAPE, ENTER, KP_ENTER, TAB, BACKSPACE, INSERT, DELETE, RIGHT, LEFT, DOWN, UP,
    PAGE_UP, PAGE_DOWN, HOME, END, CAPS_LOCK, SCROLL_LOCK, NUM_LOCK, PRINT_SCREEN, PAUSE,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    LEFT_SHIFT, LEFT_CONTROL, LEFT_ALT, LEFT_SUPER,
    RIGHT_SHIFT, RIGHT_CONTROL, RIGHT_ALT, RIGHT_SUPER, MENU;

    @Override public String stableName() { return "keyboard:" + name().toLowerCase(); }
}

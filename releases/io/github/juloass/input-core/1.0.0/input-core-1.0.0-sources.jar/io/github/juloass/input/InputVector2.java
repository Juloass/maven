package io.github.juloass.input;

/** An immutable two-axis input value. */
public record InputVector2(double x, double y) {
    public static final InputVector2 ZERO = new InputVector2(0.0, 0.0);
    public InputVector2 {
        if (!Double.isFinite(x) || !Double.isFinite(y)) throw new IllegalArgumentException("vector values must be finite");
    }
    public double length() { return Math.hypot(x, y); }
    /** Returns this vector when its length is at most one, or a unit-length vector otherwise. */
    public InputVector2 clampedToUnitLength() {
        double length = length();
        return length == 0.0 || length <= 1.0 ? this : new InputVector2(x / length, y / length);
    }
}

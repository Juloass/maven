package io.github.juloass.input;

import java.util.Objects;

/** Maps one physical axis to a scalar action. */
public record DirectAxisBinding(DeviceSelector devices, AxisControl control, double deadZone, boolean inverted)
        implements ScalarBinding {
    public DirectAxisBinding {
        Objects.requireNonNull(devices, "devices");
        Objects.requireNonNull(control, "control");
        if (!Double.isFinite(deadZone) || deadZone < 0.0 || deadZone >= 1.0) throw new IllegalArgumentException("deadZone must be in [0, 1)");
    }
}


package io.github.juloass.input;

import java.util.List;
import java.util.Objects;

/** One complete ordered transition sequence and its final state. */
public record RawInputBatch(RawInputSnapshot snapshot, List<RawInputTransition> transitions, boolean continuous) {
    public RawInputBatch {
        Objects.requireNonNull(snapshot, "snapshot");
        transitions = List.copyOf(Objects.requireNonNull(transitions, "transitions"));
        long previous = -1;
        for (RawInputTransition transition : transitions) {
            if (transition.sequence() <= previous) throw new IllegalArgumentException("transition sequence must increase");
            previous = transition.sequence();
        }
    }

    public RawInputBatch(RawInputSnapshot snapshot, List<RawInputTransition> transitions) {
        this(snapshot, transitions, true);
    }
}

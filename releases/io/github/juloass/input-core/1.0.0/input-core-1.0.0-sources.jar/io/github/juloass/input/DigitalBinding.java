package io.github.juloass.input;

/** A binding for a digital action. */
public sealed interface DigitalBinding extends InputBinding permits DirectButtonBinding, ChordBinding { }


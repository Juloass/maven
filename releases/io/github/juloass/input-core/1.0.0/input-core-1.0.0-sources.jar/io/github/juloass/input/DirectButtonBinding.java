package io.github.juloass.input;

import java.util.Objects;

/** Maps one button to a digital action. */
public record DirectButtonBinding(DeviceSelector devices, ButtonControl control) implements DigitalBinding {
    public DirectButtonBinding {
        Objects.requireNonNull(devices, "devices");
        Objects.requireNonNull(control, "control");
    }
}


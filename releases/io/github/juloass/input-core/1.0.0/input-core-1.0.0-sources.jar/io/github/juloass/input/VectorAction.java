package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;

/** A two-axis logical action. */
public record VectorAction(Identifier id) implements InputAction {
    public VectorAction { Objects.requireNonNull(id, "id"); }
    public static VectorAction of(String id) { return new VectorAction(Identifier.parse(id)); }
}


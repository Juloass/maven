package io.github.juloass.input;

import java.util.List;
import java.util.Objects;

/** One logical state and its complete ordered transitions. */
public record LogicalInputBatch(LogicalInputSnapshot snapshot, List<LogicalInputTransition> transitions) {
    public LogicalInputBatch {
        Objects.requireNonNull(snapshot, "snapshot");
        transitions = List.copyOf(Objects.requireNonNull(transitions, "transitions"));
    }
}


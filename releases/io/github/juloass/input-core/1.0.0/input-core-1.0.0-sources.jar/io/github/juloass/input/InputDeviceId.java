package io.github.juloass.input;

import io.github.juloass.identifier.Identifier;
import java.util.Objects;

/** Identifies one device during one application session. */
public record InputDeviceId(Identifier value) implements Comparable<InputDeviceId> {
    public InputDeviceId { Objects.requireNonNull(value, "value"); }
    public static InputDeviceId of(String value) { return new InputDeviceId(Identifier.parse(value)); }
    @Override public int compareTo(InputDeviceId other) { return value.compareTo(other.value); }
    @Override public String toString() { return value.toString(); }
}


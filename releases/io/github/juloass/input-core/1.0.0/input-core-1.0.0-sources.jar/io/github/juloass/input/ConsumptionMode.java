package io.github.juloass.input;

/** Defines how an active context restricts lower contexts. */
public enum ConsumptionMode { OBSERVE, CONSUME_ACTION, CONSUME_CONTROLS }


package io.github.juloass.input;

/** A physical input device category. */
public enum InputDeviceClass { KEYBOARD, POINTER, GAMEPAD }


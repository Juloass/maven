package io.github.juloass.color;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

final class NamedColors {
    private static final Map<String, Color> BY_NAME = createByName();
    private static final Map<Color, String> BY_COLOR = createByColor(BY_NAME);

    private NamedColors() {
    }

    static Color get(String name) {
        return BY_NAME.get(name.toLowerCase(Locale.ROOT));
    }

    static Optional<String> nameOf(Color color) {
        return Optional.ofNullable(BY_COLOR.get(color));
    }

    private static Map<String, Color> createByName() {
        return Map.ofEntries(
                named("aliceblue", 0xF0F8FF),
                named("antiquewhite", 0xFAEBD7),
                named("aqua", 0x00FFFF),
                named("aquamarine", 0x7FFFD4),
                named("azure", 0xF0FFFF),
                named("beige", 0xF5F5DC),
                named("bisque", 0xFFE4C4),
                named("black", 0x000000),
                named("blanchedalmond", 0xFFEBCD),
                named("blue", 0x0000FF),
                named("blueviolet", 0x8A2BE2),
                named("brown", 0xA52A2A),
                named("burlywood", 0xDEB887),
                named("cadetblue", 0x5F9EA0),
                named("chartreuse", 0x7FFF00),
                named("chocolate", 0xD2691E),
                named("coral", 0xFF7F50),
                named("cornflowerblue", 0x6495ED),
                named("cornsilk", 0xFFF8DC),
                named("crimson", 0xDC143C),
                named("cyan", 0x00FFFF),
                named("darkblue", 0x00008B),
                named("darkcyan", 0x008B8B),
                named("darkgoldenrod", 0xB8860B),
                named("darkgray", 0xA9A9A9),
                named("darkgreen", 0x006400),
                named("darkgrey", 0xA9A9A9),
                named("darkkhaki", 0xBDB76B),
                named("darkmagenta", 0x8B008B),
                named("darkolivegreen", 0x556B2F),
                named("darkorange", 0xFF8C00),
                named("darkorchid", 0x9932CC),
                named("darkred", 0x8B0000),
                named("darksalmon", 0xE9967A),
                named("darkseagreen", 0x8FBC8F),
                named("darkslateblue", 0x483D8B),
                named("darkslategray", 0x2F4F4F),
                named("darkslategrey", 0x2F4F4F),
                named("darkturquoise", 0x00CED1),
                named("darkviolet", 0x9400D3),
                named("deeppink", 0xFF1493),
                named("deepskyblue", 0x00BFFF),
                named("dimgray", 0x696969),
                named("dimgrey", 0x696969),
                named("dodgerblue", 0x1E90FF),
                named("firebrick", 0xB22222),
                named("floralwhite", 0xFFFAF0),
                named("forestgreen", 0x228B22),
                named("fuchsia", 0xFF00FF),
                named("gainsboro", 0xDCDCDC),
                named("ghostwhite", 0xF8F8FF),
                named("gold", 0xFFD700),
                named("goldenrod", 0xDAA520),
                named("gray", 0x808080),
                named("green", 0x008000),
                named("greenyellow", 0xADFF2F),
                named("grey", 0x808080),
                named("honeydew", 0xF0FFF0),
                named("hotpink", 0xFF69B4),
                named("indianred", 0xCD5C5C),
                named("indigo", 0x4B0082),
                named("ivory", 0xFFFFFF0),
                named("khaki", 0xF0E68C),
                named("lavender", 0xE6E6FA),
                named("lavenderblush", 0xFFF0F5),
                named("lawngreen", 0x7CFC00),
                named("lemonchiffon", 0xFFFACD),
                named("lightblue", 0xADD8E6),
                named("lightcoral", 0xF08080),
                named("lightcyan", 0xE0FFFF),
                named("lightgoldenrodyellow", 0xFAFAD2),
                named("lightgray", 0xD3D3D3),
                named("lightgreen", 0x90EE90),
                named("lightgrey", 0xD3D3D3),
                named("lightpink", 0xFFB6C1),
                named("lightsalmon", 0xFFA07A),
                named("lightseagreen", 0x20B2AA),
                named("lightskyblue", 0x87CEFA),
                named("lightslategray", 0x778899),
                named("lightslategrey", 0x778899),
                named("lightsteelblue", 0xB0C4DE),
                named("lightyellow", 0xFFFFE0),
                named("lime", 0x00FF00),
                named("limegreen", 0x32CD32),
                named("linen", 0xFAF0E6),
                named("magenta", 0xFF00FF),
                named("maroon", 0x800000),
                named("mediumaquamarine", 0x66CDAA),
                named("mediumblue", 0x0000CD),
                named("mediumorchid", 0xBA55D3),
                named("mediumpurple", 0x9370DB),
                named("mediumseagreen", 0x3CB371),
                named("mediumslateblue", 0x7B68EE),
                named("mediumspringgreen", 0x00FA9A),
                named("mediumturquoise", 0x48D1CC),
                named("mediumvioletred", 0xC71585),
                named("midnightblue", 0x191970),
                named("mintcream", 0xF5FFFA),
                named("mistyrose", 0xFFE4E1),
                named("moccasin", 0xFFE4B5),
                named("navajowhite", 0xFFDEAD),
                named("navy", 0x000080),
                named("oldlace", 0xFDF5E6),
                named("olive", 0x808000),
                named("olivedrab", 0x6B8E23),
                named("orange", 0xFFA500),
                named("orangered", 0xFF4500),
                named("orchid", 0xDA70D6),
                named("palegoldenrod", 0xEEE8AA),
                named("palegreen", 0x98FB98),
                named("paleturquoise", 0xAFEEEE),
                named("palevioletred", 0xDB7093),
                named("papayawhip", 0xFFEFD5),
                named("peachpuff", 0xFFDAB9),
                named("peru", 0xCD853F),
                named("pink", 0xFFC0CB),
                named("plum", 0xDDA0DD),
                named("powderblue", 0xB0E0E6),
                named("purple", 0x800080),
                named("rebeccapurple", 0x663399),
                named("red", 0xFF0000),
                named("rosybrown", 0xBC8F8F),
                named("royalblue", 0x4169E1),
                named("saddlebrown", 0x8B4513),
                named("salmon", 0xFA8072),
                named("sandybrown", 0xF4A460),
                named("seagreen", 0x2E8B57),
                named("seashell", 0xFFF5EE),
                named("sienna", 0xA0522D),
                named("silver", 0xC0C0C0),
                named("skyblue", 0x87CEEB),
                named("slateblue", 0x6A5ACD),
                named("slategray", 0x708090),
                named("slategrey", 0x708090),
                named("snow", 0xFFFAFA),
                named("springgreen", 0x00FF7F),
                named("steelblue", 0x4682B4),
                named("tan", 0xD2B48C),
                named("teal", 0x008080),
                named("thistle", 0xD8BFD8),
                named("tomato", 0xFF6347),
                named("transparent", 0x000000, 0),
                named("turquoise", 0x40E0D0),
                named("violet", 0xEE82EE),
                named("wheat", 0xF5DEB3),
                named("white", 0xFFFFFF),
                named("whitesmoke", 0xF5F5F5),
                named("yellow", 0xFFFF00),
                named("yellowgreen", 0x9ACD32)
        );
    }

    private static Map<Color, String> createByColor(Map<String, Color> byName) {
        LinkedHashMap<Color, String> colors = new LinkedHashMap<>();
        byName.forEach((name, color) -> colors.putIfAbsent(color, name));
        return Map.copyOf(colors);
    }

    private static Map.Entry<String, Color> named(String name, int rgb) {
        return named(name, rgb, 255);
    }

    private static Map.Entry<String, Color> named(String name, int rgb, int alpha) {
        return Map.entry(
                name,
                Color.srgb8(
                        rgb >>> 16 & 0xFF,
                        rgb >>> 8 & 0xFF,
                        rgb & 0xFF,
                        alpha
                )
        );
    }
}

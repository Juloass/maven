/**
 * Canonical colors, color-space conversion, and explicit color operations.
 */
package io.github.juloass.color;
package io.github.juloass.color;

import io.github.juloass.math.Angle;
import io.github.juloass.math.NumericComparison;
import io.github.juloass.math.Scalars;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;

/**
 * Immutable CIE XYZ D65 color with straight alpha.
 *
 * <p>XYZ coordinates use double precision and remain unbounded. Alpha is in
 * the closed range from zero through one.</p>
 */
public record Color(double x, double y, double z, double alpha) {
    private static final double EPS = 1e-12;
    private static final double ACHROMATIC_EPS = 1e-7;
    private static final double D50_X = 0.96422;
    private static final double D50_Z = 0.82521;
    private static final double LAB_E = 216.0 / 24389.0;
    private static final double LAB_K = 24389.0 / 27.0;

    public Color {
        x = canonical(finite("x", x));
        y = canonical(finite("y", y));
        z = canonical(finite("z", z));
        alpha = canonical(unit("alpha", alpha));
    }

    public enum RgbSpace { SRGB, LINEAR_SRGB, DISPLAY_P3, REC_2020 }
    public enum GamutMapping { REJECT, CLIP, PERCEPTUAL }
    public enum Quantization { NEAREST, FLOOR, CEILING }
    public enum InterpolationSpace {
        SRGB, LINEAR_SRGB, DISPLAY_P3, REC_2020, XYZ_D65, XYZ_D50,
        CIELAB, CIELCH, OKLAB, OKLCH, HSL, HSV, HWB
    }
    public enum HueInterpolation { SHORTER, LONGER, INCREASING, DECREASING }
    public enum DifferenceMethod { CIE76, CIEDE2000, OKLAB }

    public enum HexFormat {
        RGB_3(4, false), RGBA_4(4, true), RGB_6(8, false), RGBA_8(8, true);
        private final int bits;
        private final boolean alpha;
        HexFormat(int bits, boolean alpha) { this.bits = bits; this.alpha = alpha; }
    }

    public enum PackedFormat {
        RGB(24, 0, 1, 2, -1), BGR(24, 2, 1, 0, -1),
        RGBA(32, 0, 1, 2, 3), ARGB(32, 1, 2, 3, 0),
        BGRA(32, 2, 1, 0, 3), ABGR(32, 3, 2, 1, 0);
        private final int bits;
        private final int red;
        private final int green;
        private final int blue;
        private final int alpha;
        PackedFormat(int bits, int red, int green, int blue, int alpha) {
            this.bits = bits; this.red = red; this.green = green; this.blue = blue; this.alpha = alpha;
        }
    }

    public record Rgb(double red, double green, double blue, double alpha) {
        public Rgb {
            red = finite("red", red); green = finite("green", green);
            blue = finite("blue", blue); alpha = unit("alpha", alpha);
        }
    }

    public record Rgb8(int red, int green, int blue, int alpha) {
        public Rgb8 {
            red = byteValue("red", red); green = byteValue("green", green);
            blue = byteValue("blue", blue); alpha = byteValue("alpha", alpha);
        }
    }

    public record Xyz(double x, double y, double z, double alpha) {
        public Xyz {
            x = finite("x", x); y = finite("y", y); z = finite("z", z);
            alpha = unit("alpha", alpha);
        }
    }

    public record Cielab(double lightness, double a, double b, double alpha) {
        public Cielab {
            lightness = finite("lightness", lightness); a = finite("a", a);
            b = finite("b", b); alpha = unit("alpha", alpha);
        }
    }

    public record Cielch(double lightness, double chroma, OptionalDouble hueDegrees, double alpha) {
        public Cielch {
            lightness = finite("lightness", lightness); chroma = nonNegative("chroma", chroma);
            hueDegrees = hue(hueDegrees, chroma); alpha = unit("alpha", alpha);
        }
    }

    public record Oklab(double lightness, double a, double b, double alpha) {
        public Oklab {
            lightness = finite("lightness", lightness); a = finite("a", a);
            b = finite("b", b); alpha = unit("alpha", alpha);
        }
    }

    public record Oklch(double lightness, double chroma, OptionalDouble hueDegrees, double alpha) {
        public Oklch {
            lightness = finite("lightness", lightness); chroma = nonNegative("chroma", chroma);
            hueDegrees = hue(hueDegrees, chroma); alpha = unit("alpha", alpha);
        }
    }

    public record Hsl(OptionalDouble hueDegrees, double saturation, double lightness, double alpha) {
        public Hsl {
            saturation = finite("saturation", saturation); lightness = finite("lightness", lightness);
            hueDegrees = hue(hueDegrees, Math.abs(saturation)); alpha = unit("alpha", alpha);
        }
    }

    public record Hsv(OptionalDouble hueDegrees, double saturation, double value, double alpha) {
        public Hsv {
            saturation = finite("saturation", saturation); value = finite("value", value);
            hueDegrees = hue(hueDegrees, Math.abs(saturation)); alpha = unit("alpha", alpha);
        }
    }

    public record Hwb(OptionalDouble hueDegrees, double whiteness, double blackness, double alpha) {
        public Hwb {
            whiteness = finite("whiteness", whiteness); blackness = finite("blackness", blackness);
            hueDegrees = hue(hueDegrees, Math.max(0.0, 1.0 - whiteness - blackness));
            alpha = unit("alpha", alpha);
        }
    }

    public record PremultipliedXyz(double x, double y, double z, double alpha) {
        public PremultipliedXyz {
            x = finite("x", x); y = finite("y", y); z = finite("z", z);
            alpha = unit("alpha", alpha);
        }
        public Color toStraight() {
            if (alpha == 0.0) throw new IllegalStateException("Zero alpha lost the straight color channels");
            return new Color(x / alpha, y / alpha, z / alpha, alpha);
        }
        public Color toStraight(Color zeroAlphaColor) {
            Objects.requireNonNull(zeroAlphaColor, "zeroAlphaColor");
            return alpha == 0.0 ? new Color(zeroAlphaColor.x, zeroAlphaColor.y, zeroAlphaColor.z, 0.0)
                    : toStraight();
        }
    }

    public record Stop(double position, Color color) {
        public Stop {
            position = finite("position", position);
            color = Objects.requireNonNull(color, "color");
        }
    }

    public static final class Gradient {
        private final List<Stop> stops;
        private final InterpolationSpace space;
        private final HueInterpolation hueDirection;

        public Gradient(List<Stop> stops, InterpolationSpace space, HueInterpolation hueDirection) {
            if (Objects.requireNonNull(stops, "stops").size() < 2)
                throw new IllegalArgumentException("A gradient requires at least two stops");
            this.stops = List.copyOf(stops);
            for (int i = 1; i < this.stops.size(); i++)
                if (this.stops.get(i).position <= this.stops.get(i - 1).position)
                    throw new IllegalArgumentException("Gradient stop positions must increase");
            this.space = Objects.requireNonNull(space, "space");
            this.hueDirection = Objects.requireNonNull(hueDirection, "hueDirection");
        }
        public List<Stop> stops() { return stops; }
        public InterpolationSpace space() { return space; }
        public HueInterpolation hueDirection() { return hueDirection; }
        public Color sample(double position) {
            finite("position", position);
            if (position < stops.getFirst().position || position > stops.getLast().position)
                throw new IllegalArgumentException("Position is outside the gradient: " + position);
            if (position == stops.getFirst().position) return stops.getFirst().color;
            for (int i = 1; i < stops.size(); i++) {
                Stop right = stops.get(i);
                if (position <= right.position) {
                    Stop left = stops.get(i - 1);
                    double t = (position - left.position) / (right.position - left.position);
                    return left.color.interpolate(right.color, t, space, hueDirection);
                }
            }
            return stops.getLast().color;
        }
        public List<Color> samples(int count) {
            if (count < 2) throw new IllegalArgumentException("Sample count must be at least two");
            List<Color> result = new ArrayList<>(count);
            double first = stops.getFirst().position, last = stops.getLast().position;
            for (int i = 0; i < count; i++) result.add(sample(first + (last - first) * i / (count - 1.0)));
            return List.copyOf(result);
        }
    }

    public static Color xyzD65(double x, double y, double z) { return new Color(x, y, z, 1.0); }
    public static Color xyzD65(double x, double y, double z, double alpha) { return new Color(x, y, z, alpha); }

    public static Color xyzD50(double x, double y, double z) { return xyzD50(x, y, z, 1.0); }
    public static Color xyzD50(double x, double y, double z, double alpha) {
        double[] d65 = mul(D50_TO_D65, x, y, z);
        return new Color(d65[0], d65[1], d65[2], alpha);
    }

    public static Color srgb(double red, double green, double blue) { return srgb(red, green, blue, 1.0); }
    public static Color srgb(double red, double green, double blue, double alpha) {
        return fromRgb(RgbSpace.SRGB, red, green, blue, alpha);
    }
    public static Color srgb8(int red, int green, int blue) { return srgb8(red, green, blue, 255); }
    public static Color srgb8(int red, int green, int blue, int alpha) {
        Rgb8 c = new Rgb8(red, green, blue, alpha);
        return srgb(c.red / 255.0, c.green / 255.0, c.blue / 255.0, c.alpha / 255.0);
    }

    public static Color fromRgb(RgbSpace space, double red, double green, double blue) {
        return fromRgb(space, red, green, blue, 1.0);
    }

    public static Color fromRgb(RgbSpace space, Rgb c) {
        Objects.requireNonNull(c, "channels");
        return fromRgb(space, c.red, c.green, c.blue, c.alpha);
    }

    public static Color fromRgb(RgbSpace space, double red, double green, double blue, double alpha) {
        Rgb c = new Rgb(red, green, blue, alpha);
        double r, g, b;
        double[][] matrix;
        switch (Objects.requireNonNull(space, "space")) {
            case SRGB -> { r = decodeSrgb(c.red); g = decodeSrgb(c.green); b = decodeSrgb(c.blue); matrix = SRGB_TO_XYZ; }
            case LINEAR_SRGB -> { r = c.red; g = c.green; b = c.blue; matrix = SRGB_TO_XYZ; }
            case DISPLAY_P3 -> { r = decodeSrgb(c.red); g = decodeSrgb(c.green); b = decodeSrgb(c.blue); matrix = P3_TO_XYZ; }
            case REC_2020 -> { r = decode2020(c.red); g = decode2020(c.green); b = decode2020(c.blue); matrix = REC2020_TO_XYZ; }
            default -> throw new AssertionError(space);
        }
        double[] xyz = mul(matrix, r, g, b);
        return new Color(xyz[0], xyz[1], xyz[2], c.alpha);
    }

    public static Color cielab(double lightness, double a, double b) { return cielab(lightness, a, b, 1.0); }
    public static Color cielab(double lightness, double a, double b, double alpha) {
        double fy = (lightness + 16.0) / 116.0;
        return xyzD50(D50_X * labInv(fy + a / 500.0), labInv(fy),
                D50_Z * labInv(fy - b / 200.0), alpha);
    }

    public static Color cielch(double lightness, double chroma, OptionalDouble hue) {
        return cielch(lightness, chroma, hue, 1.0);
    }
    public static Color cielch(double lightness, double chroma, OptionalDouble hue, double alpha) {
        Cielch c = new Cielch(lightness, chroma, hue, alpha);
        double radians = Math.toRadians(c.hueDegrees.orElse(0.0));
        return cielab(c.lightness, c.chroma * Math.cos(radians), c.chroma * Math.sin(radians), c.alpha);
    }

    public static Color oklab(double lightness, double a, double b) { return oklab(lightness, a, b, 1.0); }
    public static Color oklab(double lightness, double a, double b, double alpha) {
        Oklab c = new Oklab(lightness, a, b, alpha);
        double lp = c.lightness + .3963377774 * c.a + .2158037573 * c.b;
        double mp = c.lightness - .1055613458 * c.a - .0638541728 * c.b;
        double sp = c.lightness - .0894841775 * c.a - 1.2914855480 * c.b;
        double l = lp * lp * lp, m = mp * mp * mp, s = sp * sp * sp;
        return fromRgb(RgbSpace.LINEAR_SRGB,
                4.0767416621*l - 3.3077115913*m + .2309699292*s,
                -1.2684380046*l + 2.6097574011*m - .3413193965*s,
                -.0041960863*l - .7034186147*m + 1.7076147010*s, c.alpha);
    }

    public static Color oklch(double lightness, double chroma, OptionalDouble hue) {
        return oklch(lightness, chroma, hue, 1.0);
    }
    public static Color oklch(double lightness, double chroma, OptionalDouble hue, double alpha) {
        Oklch c = new Oklch(lightness, chroma, hue, alpha);
        double radians = Math.toRadians(c.hueDegrees.orElse(0.0));
        return oklab(c.lightness, c.chroma * Math.cos(radians), c.chroma * Math.sin(radians), c.alpha);
    }

    public static Color hsl(OptionalDouble hue, double saturation, double lightness) {
        return hsl(hue, saturation, lightness, 1.0);
    }
    public static Color hsl(OptionalDouble hue, double saturation, double lightness, double alpha) {
        Hsl c = new Hsl(hue, saturation, lightness, alpha);
        if (Math.abs(c.saturation) <= EPS) return srgb(c.lightness, c.lightness, c.lightness, c.alpha);
        double h = c.hueDegrees.orElseThrow() / 360.0;
        double q = c.lightness < .5 ? c.lightness * (1 + c.saturation)
                : c.lightness + c.saturation - c.lightness * c.saturation;
        double p = 2 * c.lightness - q;
        return srgb(hueRgb(p, q, h + 1.0/3), hueRgb(p, q, h), hueRgb(p, q, h - 1.0/3), c.alpha);
    }

    public static Color hsv(OptionalDouble hue, double saturation, double value) {
        return hsv(hue, saturation, value, 1.0);
    }
    public static Color hsv(OptionalDouble hue, double saturation, double value, double alpha) {
        Hsv c = new Hsv(hue, saturation, value, alpha);
        if (Math.abs(c.saturation) <= EPS) return srgb(c.value, c.value, c.value, c.alpha);
        double h = c.hueDegrees.orElseThrow() / 60.0;
        int sector = Math.floorMod((int)Math.floor(h), 6);
        double f = h - Math.floor(h), p = c.value * (1-c.saturation);
        double q = c.value * (1-f*c.saturation), t = c.value * (1-(1-f)*c.saturation);
        return switch (sector) {
            case 0 -> srgb(c.value,t,p,c.alpha); case 1 -> srgb(q,c.value,p,c.alpha);
            case 2 -> srgb(p,c.value,t,c.alpha); case 3 -> srgb(p,q,c.value,c.alpha);
            case 4 -> srgb(t,p,c.value,c.alpha); case 5 -> srgb(c.value,p,q,c.alpha);
            default -> throw new AssertionError(sector);
        };
    }

    public static Color hwb(OptionalDouble hue, double whiteness, double blackness) {
        return hwb(hue, whiteness, blackness, 1.0);
    }
    public static Color hwb(OptionalDouble hue, double whiteness, double blackness, double alpha) {
        Hwb c = new Hwb(hue, whiteness, blackness, alpha);
        double sum = c.whiteness + c.blackness;
        if (sum >= 1.0) {
            double gray = c.whiteness / sum;
            return srgb(gray, gray, gray, c.alpha);
        }
        Rgb pure = hsv(c.hueDegrees, 1, 1, c.alpha).toSrgb();
        double factor = 1-sum;
        return srgb(pure.red*factor+c.whiteness, pure.green*factor+c.whiteness,
                pure.blue*factor+c.whiteness, c.alpha);
    }

    /** Parses #RGB, #RGBA, #RRGGBB, #RRGGBBAA, 0x forms, and CSS names. */
    public static Color parse(String value) {
        Objects.requireNonNull(value, "value");
        if (value.startsWith("#")) return parseHash(value);
        if (value.startsWith("0x") || value.startsWith("0X")) {
            String digits = value.substring(2);
            if (digits.length() != 6 && digits.length() != 8) throw invalid(value);
            return parseLongHex(digits);
        }
        Color named = NamedColors.get(value);
        if (named == null) throw invalid(value);
        return named;
    }

    public static Optional<Color> tryParse(String value) {
        if (value == null) return Optional.empty();
        try { return Optional.of(parse(value)); }
        catch (IllegalArgumentException exception) { return Optional.empty(); }
    }

    public Xyz toXyzD65() { return new Xyz(x, y, z, alpha); }
    public Xyz toXyzD50() {
        double[] v = mul(D65_TO_D50, x, y, z);
        return new Xyz(v[0], v[1], v[2], alpha);
    }

    public Rgb toRgb(RgbSpace space) {
        double[] v;
        return switch (Objects.requireNonNull(space, "space")) {
            case SRGB -> { v=mul(XYZ_TO_SRGB,x,y,z); yield new Rgb(encodeSrgb(v[0]),encodeSrgb(v[1]),encodeSrgb(v[2]),alpha); }
            case LINEAR_SRGB -> { v=mul(XYZ_TO_SRGB,x,y,z); yield new Rgb(v[0],v[1],v[2],alpha); }
            case DISPLAY_P3 -> { v=mul(XYZ_TO_P3,x,y,z); yield new Rgb(encodeSrgb(v[0]),encodeSrgb(v[1]),encodeSrgb(v[2]),alpha); }
            case REC_2020 -> { v=mul(XYZ_TO_REC2020,x,y,z); yield new Rgb(encode2020(v[0]),encode2020(v[1]),encode2020(v[2]),alpha); }
        };
    }

    public Rgb toSrgb() { return toRgb(RgbSpace.SRGB); }

    public Cielab toCielab() {
        Xyz v=toXyzD50();
        double fx=lab(v.x/D50_X), fy=lab(v.y), fz=lab(v.z/D50_Z);
        return new Cielab(116*fy-16, 500*(fx-fy), 200*(fy-fz), alpha);
    }
    public Cielch toCielch() {
        Cielab v=toCielab(); double c=Math.hypot(v.a,v.b);
        return new Cielch(v.lightness,c,angle(v.a,v.b,c),alpha);
    }
    public Oklab toOklab() {
        Rgb v=toRgb(RgbSpace.LINEAR_SRGB);
        double l=Math.cbrt(.4122214708*v.red+.5363325363*v.green+.0514459929*v.blue);
        double m=Math.cbrt(.2119034982*v.red+.6806995451*v.green+.1073969566*v.blue);
        double s=Math.cbrt(.0883024619*v.red+.2817188376*v.green+.6299787005*v.blue);
        return new Oklab(.2104542553*l+.7936177850*m-.0040720468*s,
                1.9779984951*l-2.4285922050*m+.4505937099*s,
                .0259040371*l+.7827717662*m-.8086757660*s,alpha);
    }
    public Oklch toOklch() {
        Oklab v=toOklab(); double c=Math.hypot(v.a,v.b);
        return new Oklch(v.lightness,c,angle(v.a,v.b,c),alpha);
    }
    public Hsl toHsl() {
        Rgb v=toSrgb(); double max=Math.max(v.red,Math.max(v.green,v.blue));
        double min=Math.min(v.red,Math.min(v.green,v.blue)), c=max-min, l=(max+min)/2;
        if (Math.abs(c)<=EPS) return new Hsl(OptionalDouble.empty(),0,l,alpha);
        return new Hsl(rgbHue(v,max,c),c/(1-Math.abs(2*l-1)),l,alpha);
    }
    public Hsv toHsv() {
        Rgb v=toSrgb(); double max=Math.max(v.red,Math.max(v.green,v.blue));
        double min=Math.min(v.red,Math.min(v.green,v.blue)), c=max-min;
        if (Math.abs(c)<=EPS) return new Hsv(OptionalDouble.empty(),0,max,alpha);
        return new Hsv(rgbHue(v,max,c),c/max,max,alpha);
    }
    public Hwb toHwb() {
        Rgb v=toSrgb(); double min=Math.min(v.red,Math.min(v.green,v.blue));
        double max=Math.max(v.red,Math.max(v.green,v.blue));
        return new Hwb(toHsv().hueDegrees,min,1-max,alpha);
    }

    public boolean isInGamut(RgbSpace space) {
        Rgb v=toRgb(space); return inUnit(v.red)&&inUnit(v.green)&&inUnit(v.blue);
    }
    public Color mapToGamut(RgbSpace space, GamutMapping mapping) {
        Objects.requireNonNull(space,"space"); Objects.requireNonNull(mapping,"mapping");
        if (isInGamut(space)) return this;
        return switch(mapping) {
            case REJECT -> throw new IllegalArgumentException("Color is outside the "+space+" gamut");
            case CLIP -> clipped(space); case PERCEPTUAL -> perceptual(space);
        };
    }
    public Rgb8 quantizeSrgb(GamutMapping mapping, Quantization rule) {
        Rgb v=mapToGamut(RgbSpace.SRGB,mapping).toSrgb();
        return new Rgb8(quant(v.red,255,rule),quant(v.green,255,rule),
                quant(v.blue,255,rule),quant(alpha,255,rule));
    }
    public String formatHex(HexFormat format,GamutMapping mapping,Quantization rule) {
        Objects.requireNonNull(format,"format");
        Rgb v=mapToGamut(RgbSpace.SRGB,mapping).toSrgb(); int max=(1<<format.bits)-1;
        int r=quant(v.red,max,rule),g=quant(v.green,max,rule),b=quant(v.blue,max,rule),a=quant(alpha,max,rule);
        if(format.bits==4) return format.alpha?String.format(Locale.ROOT,"#%1X%1X%1X%1X",r,g,b,a)
                :String.format(Locale.ROOT,"#%1X%1X%1X",r,g,b);
        return format.alpha?String.format(Locale.ROOT,"#%02X%02X%02X%02X",r,g,b,a)
                :String.format(Locale.ROOT,"#%02X%02X%02X",r,g,b);
    }
    public String format0x(boolean includeAlpha, GamutMapping mapping, Quantization rule) {
        return String.format(Locale.ROOT, includeAlpha ? "0x%08X" : "0x%06X",
                pack(includeAlpha ? PackedFormat.RGBA : PackedFormat.RGB, mapping, rule));
    }

    public long pack(PackedFormat format,GamutMapping mapping,Quantization rule) {
        Objects.requireNonNull(format,"format"); Rgb8 c=quantizeSrgb(mapping,rule);
        int[] bytes=new int[format.bits/8]; bytes[format.red]=c.red; bytes[format.green]=c.green;
        bytes[format.blue]=c.blue; if(format.alpha>=0)bytes[format.alpha]=c.alpha;
        long result=0; for(int value:bytes)result=result<<8|value; return result;
    }
    public static Color fromPacked(long value,PackedFormat format) {
        Objects.requireNonNull(format,"format"); long max=format.bits==32?0xffffffffL:0xffffffL;
        if(value<0||value>max)throw new IllegalArgumentException("Packed value does not fit "+format.bits+" bits");
        int[] b=new int[format.bits/8]; for(int i=b.length-1;i>=0;i--){b[i]=(int)(value&255);value>>>=8;}
        return srgb8(b[format.red],b[format.green],b[format.blue],format.alpha<0?255:b[format.alpha]);
    }
    public Optional<String> namedColor(){return NamedColors.nameOf(this);}

    public PremultipliedXyz premultiplied(){return new PremultipliedXyz(x*alpha,y*alpha,z*alpha,alpha);}
    public Color withAlpha(double value){return new Color(x,y,z,value);}
    public Color multiplyAlpha(double factor){return withAlpha(unit("result alpha",alpha*finite("factor",factor)));}
    public Color withoutAlpha(){return new Color(x,y,z,1);}
    public Color compositeOver(Color background) {
        Objects.requireNonNull(background,"background");
        double a=alpha+background.alpha*(1-alpha);
        if(a==0)return new Color(0,0,0,0);
        return new Color((x*alpha+background.x*background.alpha*(1-alpha))/a,
                (y*alpha+background.y*background.alpha*(1-alpha))/a,
                (z*alpha+background.z*background.alpha*(1-alpha))/a,a);
    }

    public Color mix(Color other,double weight,InterpolationSpace space) {
        return interpolate(other,weight,space,HueInterpolation.SHORTER);
    }
    public Color interpolate(Color other,double t,InterpolationSpace space,HueInterpolation direction) {
        Objects.requireNonNull(other,"other"); Objects.requireNonNull(space,"space");
        Objects.requireNonNull(direction,"direction"); t=unit("amount",t); double a=Scalars.lerp(alpha,other.alpha,t);
        return switch(space) {
            case SRGB -> interpRgb(other,t,RgbSpace.SRGB,a);
            case LINEAR_SRGB -> interpRgb(other,t,RgbSpace.LINEAR_SRGB,a);
            case DISPLAY_P3 -> interpRgb(other,t,RgbSpace.DISPLAY_P3,a);
            case REC_2020 -> interpRgb(other,t,RgbSpace.REC_2020,a);
            case XYZ_D65 -> new Color(Scalars.lerp(x,other.x,t),Scalars.lerp(y,other.y,t),Scalars.lerp(z,other.z,t),a);
            case XYZ_D50 -> interpXyz50(other,t,a);
            case CIELAB -> interpLab(other,t,a);
            case CIELCH -> interpLch(other,t,direction,a);
            case OKLAB -> interpOk(other,t,a);
            case OKLCH -> interpOklch(other,t,direction,a);
            case HSL -> interpHsl(other,t,direction,a);
            case HSV -> interpHsv(other,t,direction,a);
            case HWB -> interpHwb(other,t,direction,a);
        };
    }

    public double luminance(){return y;}
    public double contrastRatio(Color other) {
        requireContrast(this);requireContrast(Objects.requireNonNull(other,"other"));
        return (Math.max(y,other.y)+.05)/(Math.min(y,other.y)+.05);
    }
    public double difference(Color other,DifferenceMethod method) {
        Objects.requireNonNull(other,"other");
        return switch(Objects.requireNonNull(method,"method")){
            case CIE76 -> delta76(toCielab(),other.toCielab());
            case CIEDE2000 -> delta2000(toCielab(),other.toCielab());
            case OKLAB -> deltaOk(toOklab(),other.toOklab());
        };
    }
    public boolean approximatelyEquals(Color other,double tolerance) {
        Objects.requireNonNull(other,"other");nonNegative("tolerance",tolerance);
        NumericComparison comparison=NumericComparison.absolute(tolerance);
        return comparison.test(x,other.x)&&comparison.test(y,other.y)
                &&comparison.test(z,other.z)&&comparison.test(alpha,other.alpha);
    }
    public boolean perceptuallyEquals(Color other,DifferenceMethod method,double colorTolerance,double alphaTolerance){
        nonNegative("colorTolerance",colorTolerance);nonNegative("alphaTolerance",alphaTolerance);
        return difference(other,method)<=colorTolerance
                &&NumericComparison.absolute(alphaTolerance).test(alpha,other.alpha);
    }
    public Color adjustLightness(double amount){
        Oklch c=toOklch();return oklch(c.lightness+finite("amount",amount),c.chroma,c.hueDegrees,alpha);
    }
    public Color adjustChroma(double amount){
        Oklch c=toOklch();return oklch(c.lightness,nonNegative("result chroma",c.chroma+finite("amount",amount)),c.hueDegrees,alpha);
    }
    public Color adjustSaturation(double amount){
        Hsl c=toHsl();return hsl(c.hueDegrees,c.saturation+finite("amount",amount),c.lightness,alpha);
    }
    public Color rotateHue(double degrees){
        Oklch c=toOklch(); if(c.hueDegrees.isEmpty())return this;
        return oklch(c.lightness,c.chroma,OptionalDouble.of(c.hueDegrees.getAsDouble()+finite("degrees",degrees)),alpha);
    }
    public List<Color> paletteByHue(int count,double stepDegrees){
        if(count<1)throw new IllegalArgumentException("Palette count must be positive");
        Oklch c=toOklch();if(c.hueDegrees.isEmpty())throw new IllegalStateException("An achromatic color has no hue");
        List<Color> result=new ArrayList<>(count);
        for(int i=0;i<count;i++)result.add(oklch(c.lightness,c.chroma,
                OptionalDouble.of(c.hueDegrees.getAsDouble()+finite("stepDegrees",stepDegrees)*i),alpha));
        return List.copyOf(result);
    }
    public static Color nearest(Color target,Collection<Color> candidates,DifferenceMethod method){
        Objects.requireNonNull(target,"target");Objects.requireNonNull(candidates,"candidates");
        return candidates.stream().filter(Objects::nonNull)
                .min(Comparator.comparingDouble(c->target.difference(c,method)))
                .orElseThrow(()->new IllegalArgumentException("Candidates must contain a color"));
    }

    private Color clipped(RgbSpace space){
        Rgb v=toRgb(space);return fromRgb(space,Scalars.clamp(v.red,0,1),Scalars.clamp(v.green,0,1),Scalars.clamp(v.blue,0,1),alpha);
    }
    private Color perceptual(RgbSpace space){
        Oklch c=toOklch();if(c.chroma<=EPS||c.hueDegrees.isEmpty())return clipped(space);
        double low=0,high=c.chroma;Color best=oklch(c.lightness,0,OptionalDouble.empty(),alpha);
        if(!best.isInGamut(space))return best.clipped(space);
        for(int i=0;i<32;i++){double mid=(low+high)/2;Color candidate=oklch(c.lightness,mid,c.hueDegrees,alpha);
            if(candidate.isInGamut(space)){low=mid;best=candidate;}else high=mid;}
        return best;
    }
    private Color interpRgb(Color o,double t,RgbSpace s,double a){
        Rgb p=toRgb(s),q=o.toRgb(s);return fromRgb(s,Scalars.lerp(p.red,q.red,t),Scalars.lerp(p.green,q.green,t),Scalars.lerp(p.blue,q.blue,t),a);
    }
    private Color interpXyz50(Color o,double t,double a){
        Xyz p=toXyzD50(),q=o.toXyzD50();return xyzD50(Scalars.lerp(p.x,q.x,t),Scalars.lerp(p.y,q.y,t),Scalars.lerp(p.z,q.z,t),a);
    }
    private Color interpLab(Color o,double t,double alpha){
        Cielab p=toCielab(),q=o.toCielab();return cielab(Scalars.lerp(p.lightness,q.lightness,t),Scalars.lerp(p.a,q.a,t),Scalars.lerp(p.b,q.b,t),alpha);
    }
    private Color interpLch(Color o,double t,HueInterpolation d,double alpha){
        Cielch p=toCielch(),q=o.toCielch();double c=Scalars.lerp(p.chroma,q.chroma,t);
        return cielch(Scalars.lerp(p.lightness,q.lightness,t),c,interpHue(p.hueDegrees,q.hueDegrees,p.chroma,q.chroma,t,d,c),alpha);
    }
    private Color interpOk(Color o,double t,double alpha){
        Oklab p=toOklab(),q=o.toOklab();return oklab(Scalars.lerp(p.lightness,q.lightness,t),Scalars.lerp(p.a,q.a,t),Scalars.lerp(p.b,q.b,t),alpha);
    }
    private Color interpOklch(Color o,double t,HueInterpolation d,double alpha){
        Oklch p=toOklch(),q=o.toOklch();double c=Scalars.lerp(p.chroma,q.chroma,t);
        return oklch(Scalars.lerp(p.lightness,q.lightness,t),c,interpHue(p.hueDegrees,q.hueDegrees,p.chroma,q.chroma,t,d,c),alpha);
    }
    private Color interpHsl(Color o,double t,HueInterpolation d,double alpha){
        Hsl p=toHsl(),q=o.toHsl();double s=Scalars.lerp(p.saturation,q.saturation,t);
        return hsl(interpHue(p.hueDegrees,q.hueDegrees,Math.abs(p.saturation),Math.abs(q.saturation),t,d,Math.abs(s)),
                s,Scalars.lerp(p.lightness,q.lightness,t),alpha);
    }
    private Color interpHsv(Color o,double t,HueInterpolation d,double alpha){
        Hsv p=toHsv(),q=o.toHsv();double s=Scalars.lerp(p.saturation,q.saturation,t);
        return hsv(interpHue(p.hueDegrees,q.hueDegrees,Math.abs(p.saturation),Math.abs(q.saturation),t,d,Math.abs(s)),
                s,Scalars.lerp(p.value,q.value,t),alpha);
    }
    private Color interpHwb(Color o,double t,HueInterpolation d,double alpha){
        Hwb p=toHwb(),q=o.toHwb();double w=Scalars.lerp(p.whiteness,q.whiteness,t),b=Scalars.lerp(p.blackness,q.blackness,t);
        return hwb(interpHue(p.hueDegrees,q.hueDegrees,Math.max(0,1-p.whiteness-p.blackness),
                Math.max(0,1-q.whiteness-q.blackness),t,d,Math.max(0,1-w-b)),w,b,alpha);
    }

    private static OptionalDouble interpHue(OptionalDouble p,OptionalDouble q,double pc,double qc,
                                              double t,HueInterpolation d,double resultChroma){
        if(resultChroma<=EPS)return OptionalDouble.empty();
        if(p.isEmpty()&&q.isEmpty())return OptionalDouble.empty();
        double a=p.isPresent()?p.getAsDouble():q.getAsDouble(),b=q.isPresent()?q.getAsDouble():a;
        if(pc<=EPS)a=b;if(qc<=EPS)b=a;
        Angle start=Angle.degrees(a),end=Angle.degrees(b);
        Angle result=switch(d){
            case INCREASING->start.interpolateIncreasing(end,t);
            case DECREASING->start.interpolateDecreasing(end,t);
            case SHORTER->start.interpolateShortest(end,t);
            case LONGER->{
                double increasing=start.increasingDistanceTo(end).inRadians();
                double decreasing=start.decreasingDistanceTo(end).inRadians();
                double delta=Math.abs(increasing)>Math.abs(decreasing)?increasing:decreasing;
                yield Angle.radians(start.inRadians()+delta*t);
            }
        };
        return OptionalDouble.of(result.normalizedPositive().inDegrees());
    }

    private static OptionalDouble hue(OptionalDouble value,double chroma){
        Objects.requireNonNull(value,"hue");
        if(chroma<=ACHROMATIC_EPS)return OptionalDouble.empty();
        if(value.isEmpty())throw new IllegalArgumentException("Hue is required for a chromatic color");
        return OptionalDouble.of(degrees(finite("hue",value.getAsDouble())));
    }
    private static OptionalDouble angle(double a,double b,double c){
        return c<=ACHROMATIC_EPS?OptionalDouble.empty():OptionalDouble.of(Scalars.atan2(b,a).normalizedPositive().inDegrees());
    }
    private static OptionalDouble rgbHue(Rgb v,double max,double c){
        double h=max==v.red?(v.green-v.blue)/c:max==v.green?(v.blue-v.red)/c+2:(v.red-v.green)/c+4;
        return OptionalDouble.of(degrees(h*60));
    }

    private static Color parseHash(String value){
        String d=value.substring(1);
        return switch(d.length()){
            case 3->srgb8(nibble(d.charAt(0)),nibble(d.charAt(1)),nibble(d.charAt(2)));
            case 4->srgb8(nibble(d.charAt(0)),nibble(d.charAt(1)),nibble(d.charAt(2)),nibble(d.charAt(3)));
            case 6,8->parseLongHex(d);default->throw invalid(value);
        };
    }
    private static Color parseLongHex(String d){
        if(!d.matches("[0-9a-fA-F]+"))throw invalid(d);
        return srgb8(Integer.parseInt(d.substring(0,2),16),Integer.parseInt(d.substring(2,4),16),
                Integer.parseInt(d.substring(4,6),16),d.length()==8?Integer.parseInt(d.substring(6,8),16):255);
    }
    private static int nibble(char c){int n=Character.digit(c,16);if(n<0)throw invalid(String.valueOf(c));return n*17;}
    private static IllegalArgumentException invalid(String value){return new IllegalArgumentException("Invalid color representation: "+value);}

    private static int quant(double value,int max,Quantization rule){
        double v=Scalars.clamp(value,0,1)*max;return switch(Objects.requireNonNull(rule,"quantization")){
            case NEAREST->(int)Math.round(v);case FLOOR->(int)Math.floor(v);case CEILING->(int)Math.ceil(v);
        };
    }
    private static double delta76(Cielab p,Cielab q){return Math.sqrt(sq(p.lightness-q.lightness)+sq(p.a-q.a)+sq(p.b-q.b));}
    private static double deltaOk(Oklab p,Oklab q){return Math.sqrt(sq(p.lightness-q.lightness)+sq(p.a-q.a)+sq(p.b-q.b));}

    private static double delta2000(Cielab p,Cielab q){
        double l1=p.lightness,a1=p.a,b1=p.b,l2=q.lightness,a2=q.a,b2=q.b;
        double c1=Math.hypot(a1,b1),c2=Math.hypot(a2,b2),mc=(c1+c2)/2;
        double g=.5*(1-Math.sqrt(Math.pow(mc,7)/(Math.pow(mc,7)+Math.pow(25,7))));
        double ap1=(1+g)*a1,ap2=(1+g)*a2,cp1=Math.hypot(ap1,b1),cp2=Math.hypot(ap2,b2);
        double hp1=cp1<=EPS?0:degrees(Math.toDegrees(Math.atan2(b1,ap1)));
        double hp2=cp2<=EPS?0:degrees(Math.toDegrees(Math.atan2(b2,ap2)));
        double dl=l2-l1,dc=cp2-cp1,dh;
        if(cp1*cp2==0)dh=0;else if(Math.abs(hp2-hp1)<=180)dh=hp2-hp1;
        else if(hp2<=hp1)dh=hp2-hp1+360;else dh=hp2-hp1-360;
        double dH=2*Math.sqrt(cp1*cp2)*Math.sin(Math.toRadians(dh/2));
        double ml=(l1+l2)/2,mcp=(cp1+cp2)/2,mh;
        if(cp1*cp2==0)mh=hp1+hp2;else if(Math.abs(hp1-hp2)<=180)mh=(hp1+hp2)/2;
        else if(hp1+hp2<360)mh=(hp1+hp2+360)/2;else mh=(hp1+hp2-360)/2;
        double t=1-.17*Math.cos(Math.toRadians(mh-30))+.24*Math.cos(Math.toRadians(2*mh))
                +.32*Math.cos(Math.toRadians(3*mh+6))-.20*Math.cos(Math.toRadians(4*mh-63));
        double theta=30*Math.exp(-sq((mh-275)/25));
        double rc=2*Math.sqrt(Math.pow(mcp,7)/(Math.pow(mcp,7)+Math.pow(25,7)));
        double sl=1+.015*sq(ml-50)/Math.sqrt(20+sq(ml-50)),sc=1+.045*mcp,sh=1+.015*mcp*t;
        double rt=-Math.sin(Math.toRadians(2*theta))*rc,lt=dl/sl,ct=dc/sc,ht=dH/sh;
        return Math.sqrt(sq(lt)+sq(ct)+sq(ht)+rt*ct*ht);
    }

    private static void requireContrast(Color c){
        if(c.alpha!=1)throw new IllegalArgumentException("Contrast requires opaque colors");
        if(!c.isInGamut(RgbSpace.SRGB))throw new IllegalArgumentException("Contrast requires in-gamut sRGB colors");
    }
    private static double lab(double v){return v>LAB_E?Math.cbrt(v):(LAB_K*v+16)/116;}
    private static double labInv(double v){double c=v*v*v;return c>LAB_E?c:(116*v-16)/LAB_K;}
    private static double decodeSrgb(double v){double a=Math.abs(v);return Math.copySign(a<=.04045?a/12.92:Math.pow((a+.055)/1.055,2.4),v);}
    private static double encodeSrgb(double v){double a=Math.abs(v);return Math.copySign(a<=.0031308?12.92*a:1.055*Math.pow(a,1/2.4)-.055,v);}
    private static double decode2020(double v){double beta=.018053968510807,a=1.09929682680944,x=Math.abs(v);return Math.copySign(x<4.5*beta?x/4.5:Math.pow((x+a-1)/a,1/.45),v);}
    private static double encode2020(double v){double beta=.018053968510807,a=1.09929682680944,x=Math.abs(v);return Math.copySign(x<beta?4.5*x:a*Math.pow(x,.45)-(a-1),v);}
    private static double hueRgb(double p,double q,double h){h-=Math.floor(h);if(h<1.0/6)return p+(q-p)*6*h;if(h<.5)return q;if(h<2.0/3)return p+(q-p)*(2.0/3-h)*6;return p;}
    private static double[] mul(double[][]m,double a,double b,double c){return new double[]{m[0][0]*a+m[0][1]*b+m[0][2]*c,m[1][0]*a+m[1][1]*b+m[1][2]*c,m[2][0]*a+m[2][1]*b+m[2][2]*c};}
    private static double finite(String n,double v){if(!Double.isFinite(v))throw new IllegalArgumentException(n+" must be finite");return v;}
    private static double unit(String n,double v){finite(n,v);if(v<0||v>1)throw new IllegalArgumentException(n+" must be between zero and one");return v;}
    private static double nonNegative(String n,double v){finite(n,v);if(v<0)throw new IllegalArgumentException(n+" must not be negative");return v;}
    private static int byteValue(String n,int v){if(v<0||v>255)throw new IllegalArgumentException(n+" must be between zero and 255");return v;}
    private static boolean inUnit(double v){return v>=-EPS&&v<=1+EPS;}
    private static double degrees(double v){return canonical(Angle.degrees(v).normalizedPositive().inDegrees());}
    private static double sq(double v){return v*v;}
    private static double canonical(double v){return v==0?0:v;}

    private static final double[][] SRGB_TO_XYZ={
            {.4123907992659595,.35758433938387796,.1804807884018343},
            {.21263900587151036,.7151686787677559,.07219231536073371},
            {.01933081871559185,.11919477979462599,.9505321522496607}};
    private static final double[][] XYZ_TO_SRGB={
            {3.2409699419045226,-1.537383177570094,-.4986107602930034},
            {-.9692436362808796,1.8759675015077202,.04155505740717559},
            {.05563007969699366,-.20397695888897652,1.0569715142428786}};
    private static final double[][] P3_TO_XYZ={
            {.4865709486482162,.26566769316909306,.1982172852343625},
            {.2289745640697488,.6917385218365064,.079286914093745},
            {0,.04511338185890264,1.043944368900976}};
    private static final double[][] XYZ_TO_P3={
            {2.493496911941425,-.9313836179191239,-.40271078445071684},
            {-.8294889695615747,1.7626640603183463,.023624685841943577},
            {.03584583024378447,-.07617238926804182,.9568845240076872}};
    private static final double[][] REC2020_TO_XYZ={
            {.6369580483012914,.14461690358620832,.1688809751641721},
            {.2627002120112671,.6779980715188708,.05930171646986196},
            {0,.028072693049087428,1.060985057710791}};
    private static final double[][] XYZ_TO_REC2020={
            {1.7166511879712674,-.35567078377639233,-.25336628137365974},
            {-.6666843518324892,1.6164812366349395,.01576854581391113},
            {.017639857445310783,-.042770613257808524,.9421031212354738}};
    private static final double[][] D65_TO_D50={
            {1.0479297925449969,.022946870601609652,-.05019226628920524},
            {.02962780877005599,.9904344267538799,-.017073799063418826},
            {-.009243058152591178,.015055144896577895,.7518742814281371}};
    private static final double[][] D50_TO_D65={
            {.955473421488075,-.02309845494876471,.06325924320057072},
            {-.0283697093338637,1.0099953980813041,.021041441191917323},
            {.012314014864481998,-.020507649298898964,1.330365926242124}};
}

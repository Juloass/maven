package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.LoadedResource;
import io.github.juloass.resource.MetadataContribution;
import io.github.juloass.resource.MetadataLayerPolicy;
import io.github.juloass.resource.MetadataSectionInput;
import io.github.juloass.resource.MetadataSectionType;
import io.github.juloass.resource.MetadataValue;
import io.github.juloass.resource.ResolvedMetadata;
import io.github.juloass.resource.ResolvedResource;
import io.github.juloass.resource.Resource;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourceException;
import io.github.juloass.resource.ResourceKey;
import io.github.juloass.resource.ResourceLoadContext;
import io.github.juloass.resource.ResourceMetadata;
import io.github.juloass.resource.ResourceOrigin;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.ResourceProblem;
import io.github.juloass.resource.ResourceResolutionMode;
import io.github.juloass.resource.ResourceType;
import io.github.juloass.resource.json.StrictJson;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;

/** Thread-safe manager for one structural resource domain. */
public final class ResourceManager implements AutoCloseable {
    public static final long DEFAULT_METADATA_MAXIMUM_BYTES = 1024 * 1024;

    private final ResourceDomain domain;
    private final List<ResourcePackCandidate> packs;
    private final List<ResourceType<?>> types;
    private final UnknownMetadataPolicy unknownMetadataPolicy;
    private final long metadataMaximumBytes;
    private final AtomicReference<State> active;
    private final ReentrantLock reloadLock = new ReentrantLock();
    private final AtomicBoolean closed = new AtomicBoolean();

    private ResourceManager(Builder builder) {
        domain = builder.domain;
        packs = List.copyOf(builder.packs);
        types = List.copyOf(builder.types);
        unknownMetadataPolicy = builder.unknownMetadataPolicy;
        metadataMaximumBytes = builder.metadataMaximumBytes;
        validateTypes(domain, types);
        active = new AtomicReference<>(buildState(0));
    }

    public static ResourceManager create(ResourceDomain domain, List<ResourcePackCandidate> packs) {
        return builder(domain, packs).build();
    }

    public static Builder builder(ResourceDomain domain, List<ResourcePackCandidate> packs) {
        return new Builder(domain, packs);
    }

    public ResourceDomain domain() { return domain; }
    public long generation() { return requireState().generation(); }
    public ResourceSnapshot acquireSnapshot() {
        while (true) {
            State state = requireState();
            try {
                return new ResourceSnapshot(state);
            } catch (IllegalStateException exception) {
                if (closed.get()) throw new ResourceException(ResourceProblem.of(
                        ResourceProblem.Code.CLOSED_MANAGER,
                        "resource-manager",
                        "Resource manager is closed"));
            }
        }
    }

    public Set<String> namespaces() {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.namespaces(); }
    }

    public Optional<Resource> findResource(ResourcePath path) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.findResource(path); }
    }

    public Resource requireResource(ResourcePath path) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.requireResource(path); }
    }

    public List<Resource> resourceStack(ResourcePath path) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.resourceStack(path); }
    }

    public Map<ResourcePath, Resource> listResources(String prefix, Predicate<ResourcePath> filter) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.listResources(prefix, filter); }
    }

    public Map<ResourcePath, List<Resource>> listResourceStacks(String prefix, Predicate<ResourcePath> filter) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.listResourceStacks(prefix, filter); }
    }

    public <T> LoadedResource<T> load(ResourceKey<T> key) {
        try (ResourceSnapshot snapshot = acquireSnapshot()) { return snapshot.load(key); }
    }

    public ResourceReloadResult reload() {
        reloadLock.lock();
        try {
            State previous = requireState();
            State candidate;
            try {
                candidate = buildState(previous.generation() + 1);
            } catch (ResourceException exception) {
                return new ResourceReloadResult(previous.generation(), previous.generation(), false,
                        exception.problems());
            } catch (RuntimeException exception) {
                ResourceProblem problem = new ResourceProblem(ResourceProblem.Code.RELOAD_FAILURE,
                        "resource-manager", "Resource reload failed: " + exception.getMessage(),
                        Optional.empty(), Optional.of(exception));
                return new ResourceReloadResult(previous.generation(), previous.generation(), false,
                        List.of(problem));
            }
            if (closed.get()) {
                candidate.release();
                return new ResourceReloadResult(previous.generation(), previous.generation(), false,
                        List.of(ResourceProblem.of(ResourceProblem.Code.CLOSED_MANAGER,
                                "resource-manager", "Resource manager is closed")));
            }
            active.set(candidate);
            previous.release();
            return new ResourceReloadResult(previous.generation(), candidate.generation(), true, List.of());
        } finally {
            reloadLock.unlock();
        }
    }

    private State requireState() {
        if (closed.get()) throw new ResourceException(ResourceProblem.of(
                ResourceProblem.Code.CLOSED_MANAGER, "resource-manager", "Resource manager is closed"));
        return active.get();
    }

    @Override
    public void close() {
        reloadLock.lock();
        try {
            if (closed.compareAndSet(false, true)) active.get().release();
        } finally {
            reloadLock.unlock();
        }
    }

    private State buildState(long generation) {
        LinkedHashSet<Identifier> packIds = new LinkedHashSet<>();
        ArrayList<OpenedPack> opened = new ArrayList<>();
        try {
            for (int packOrder = 0; packOrder < packs.size(); packOrder++) {
                ResourcePackCandidate pack = Objects.requireNonNull(packs.get(packOrder), "pack candidate");
                if (!packIds.add(pack.id())) {
                    throw problem(ResourceProblem.Code.DUPLICATE_PACK, pack.id().value(),
                            "Duplicate enabled pack identifier " + pack.id());
                }
                PackMetadata metadata = pack.metadata();
                PackResourcesSnapshot resources = pack.resources().openSnapshot();
                opened.add(new OpenedPack(pack, metadata, packOrder, resources));
            }
            State state = new State(domain, generation, opened, types, unknownMetadataPolicy,
                    metadataMaximumBytes);
            state.build();
            return state;
        } catch (ResourceException exception) {
            closeOpened(opened);
            throw exception;
        } catch (IOException | RuntimeException exception) {
            closeOpened(opened);
            throw problem(ResourceProblem.Code.READ_FAILURE, "resource-manager",
                    "Cannot open resource packs: " + exception.getMessage(), exception);
        }
    }

    private static void validateTypes(ResourceDomain domain, List<ResourceType<?>> types) {
        LinkedHashSet<Identifier> ids = new LinkedHashSet<>();
        for (ResourceType<?> type : types) {
            Objects.requireNonNull(type, "resource type");
            if (type.domain() != domain) throw new IllegalArgumentException(
                    "Resource type " + type.id() + " uses domain " + type.domain());
            if (!ids.add(type.id())) throw new IllegalArgumentException("Duplicate resource type " + type.id());
        }
    }

    private static void closeOpened(List<OpenedPack> packs) {
        for (OpenedPack pack : packs.reversed()) {
            try { pack.resources.close(); } catch (IOException ignored) { }
        }
    }

    private static ResourceException problem(ResourceProblem.Code code, String source, String message) {
        return new ResourceException(ResourceProblem.of(code, source, message));
    }

    private static ResourceException problem(
            ResourceProblem.Code code, String source, String message, Throwable cause
    ) {
        return new ResourceException(new ResourceProblem(code, source, message,
                Optional.empty(), Optional.ofNullable(cause)));
    }

    private record OpenedPack(
            ResourcePackCandidate candidate,
            PackMetadata metadata,
            int order,
            PackResourcesSnapshot resources
    ) { }

    public static final class Builder {
        private final ResourceDomain domain;
        private final List<ResourcePackCandidate> packs;
        private final List<ResourceType<?>> types = new ArrayList<>();
        private UnknownMetadataPolicy unknownMetadataPolicy = UnknownMetadataPolicy.REJECT;
        private long metadataMaximumBytes = DEFAULT_METADATA_MAXIMUM_BYTES;

        private Builder(ResourceDomain domain, List<ResourcePackCandidate> packs) {
            this.domain = Objects.requireNonNull(domain, "domain");
            this.packs = List.copyOf(Objects.requireNonNull(packs, "packs"));
        }

        public Builder registerType(ResourceType<?> type) {
            types.add(Objects.requireNonNull(type, "type"));
            return this;
        }

        public Builder unknownMetadataPolicy(UnknownMetadataPolicy policy) {
            unknownMetadataPolicy = Objects.requireNonNull(policy, "policy");
            return this;
        }

        public Builder metadataMaximumBytes(long value) {
            if (value < 0) throw new IllegalArgumentException("metadataMaximumBytes must be non-negative");
            metadataMaximumBytes = value;
            return this;
        }

        public ResourceManager build() { return new ResourceManager(this); }
    }

    static final class State {
        private final ResourceDomain domain;
        private final long generation;
        private final List<OpenedPack> packs;
        private final List<ResourceType<?>> types;
        private final UnknownMetadataPolicy unknownPolicy;
        private final long metadataMaximumBytes;
        private final AtomicInteger references = new AtomicInteger(1);
        private final AtomicBoolean closed = new AtomicBoolean();
        private final ReentrantLock decodeLock = new ReentrantLock(true);
        private final Map<ResourceKey<?>, Object> cache = new LinkedHashMap<>();
        private final Map<ResourceKey<?>, ResourceException> failureCache = new LinkedHashMap<>();
        private final ThreadLocal<Deque<ResourceKey<?>>> dependencyPath = ThreadLocal.withInitial(ArrayDeque::new);
        private Map<ResourcePath, List<ManagedResource>> stacks = Map.of();
        private Set<String> namespaces = Set.of();

        State(ResourceDomain domain, long generation, List<OpenedPack> packs,
              List<ResourceType<?>> types, UnknownMetadataPolicy unknownPolicy,
              long metadataMaximumBytes) {
            this.domain = domain;
            this.generation = generation;
            this.packs = List.copyOf(packs);
            this.types = List.copyOf(types);
            this.unknownPolicy = unknownPolicy;
            this.metadataMaximumBytes = metadataMaximumBytes;
        }

        ResourceDomain domain() { return domain; }
        long generation() { return generation; }
        Set<String> namespaces() { return namespaces; }

        void build() {
            TreeMap<ResourcePath, List<Entry>> indexed = new TreeMap<>();
            TreeSet<String> namespaceSet = new TreeSet<>();
            for (OpenedPack pack : packs) {
                for (String namespace : pack.resources.namespaces(domain)) {
                    namespaceSet.add(namespace);
                    pack.resources.list(domain, namespace, "", resource -> indexed
                            .computeIfAbsent(resource.path(), ignored -> new ArrayList<>())
                            .add(new Entry(pack, resource)));
                }
            }
            validateMetadataPairs(indexed);
            TreeMap<ResourcePath, List<ManagedResource>> built = new TreeMap<>();
            for (Map.Entry<ResourcePath, List<Entry>> indexedEntry : indexed.entrySet()) {
                if (isMetadataPath(indexedEntry.getKey())) continue;
                ArrayList<ManagedResource> values = new ArrayList<>();
                List<Entry> entries = indexedEntry.getValue();
                for (Entry entry : entries) values.add(createResource(entry, indexed));
                resolveMetadata(indexedEntry.getKey(), values);
                built.put(indexedEntry.getKey(), List.copyOf(values));
            }
            stacks = Collections.unmodifiableMap(built);
            namespaces = Collections.unmodifiableSet(namespaceSet);
        }

        private ManagedResource createResource(Entry entry, Map<ResourcePath, List<Entry>> indexed) {
            ResourceOrigin origin = origin(entry);
            Map<Identifier, RawSection> raw = localSections(entry, indexed);
            return new ManagedResource(this, entry.resource, origin, raw);
        }

        private ResourceOrigin origin(Entry entry) {
            ResourcePackCandidate pack = entry.pack.candidate;
            return new ResourceOrigin(
                    pack.id(),
                    entry.pack.metadata.description(),
                    entry.pack.metadata.format(),
                    entry.pack.order,
                    entry.resource.sources(),
                    entry.resource.path(),
                    generation);
        }

        private Map<Identifier, RawSection> localSections(Entry content, Map<ResourcePath, List<Entry>> indexed) {
            ResourcePath sidecar = content.resource.path().withPath(content.resource.path().path() + ".meta.json");
            List<Entry> sidecars = indexed.getOrDefault(sidecar, List.of());
            for (Entry candidate : sidecars.reversed()) {
                if (candidate.pack.order == content.pack.order
                        && candidate.resource.sourceId().equals(content.resource.sourceId())
                        && candidate.resource.sourceOrder() == content.resource.sourceOrder()) {
                    return parseMetadata(candidate);
                }
            }
            return Map.of();
        }

        private Map<Identifier, RawSection> parseMetadata(Entry entry) {
            try (InputStream input = entry.resource.streamSupplier().open()) {
                MetadataValue.ObjectValue root = StrictJson.parseObject(input, metadataMaximumBytes,
                        entry.resource.physicalSource());
                if (!root.values().keySet().equals(Set.of("format", "sections"))) {
                    throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                            "Metadata requires only format and sections");
                }
                int format = integer(root.values().get("format"), "metadata format");
                if (format != 1) throw problem(ResourceProblem.Code.INVALID_METADATA,
                        entry.resource.physicalSource(), "Unsupported metadata envelope format " + format);
                if (!(root.values().get("sections") instanceof MetadataValue.ObjectValue sections)) {
                    throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                            "Metadata sections must be an object");
                }
                TreeMap<Identifier, RawSection> parsed = new TreeMap<>();
                for (Map.Entry<String, MetadataValue> section : sections.values().entrySet()) {
                    Identifier id;
                    try { id = Identifier.parse(section.getKey()); }
                    catch (IllegalArgumentException exception) {
                        throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                                "Invalid metadata section identifier " + section.getKey(), exception);
                    }
                    if (!(section.getValue() instanceof MetadataValue.ObjectValue wrapper)
                            || !wrapper.values().keySet().equals(Set.of("version", "data"))) {
                        throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                                "Metadata section " + id + " requires version and data");
                    }
                    int version = integer(wrapper.values().get("version"), "section version");
                    if (version <= 0 || !(wrapper.values().get("data") instanceof MetadataValue.ObjectValue data)) {
                        throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                                "Metadata section " + id + " has invalid version or data");
                    }
                    parsed.put(id, new RawSection(version, data, entry.resource.physicalSource()));
                }
                return Collections.unmodifiableMap(parsed);
            } catch (ResourceException exception) {
                if (exception.problems().stream().allMatch(problem ->
                        problem.code() == ResourceProblem.Code.INVALID_METADATA)) {
                    throw exception;
                }
                throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                        "Invalid metadata: " + exception.getMessage(), exception);
            } catch (IllegalArgumentException exception) {
                throw problem(ResourceProblem.Code.INVALID_METADATA, entry.resource.physicalSource(),
                        "Invalid metadata: " + exception.getMessage(), exception);
            } catch (IOException exception) {
                throw problem(ResourceProblem.Code.READ_FAILURE, entry.resource.physicalSource(),
                        "Cannot read metadata: " + exception.getMessage(), exception);
            }
        }

        private void validateMetadataPairs(Map<ResourcePath, List<Entry>> indexed) {
            for (Map.Entry<ResourcePath, List<Entry>> item : indexed.entrySet()) {
                if (!isMetadataPath(item.getKey())) continue;
                String basePath = item.getKey().path().substring(0,
                        item.getKey().path().length() - ".meta.json".length());
                ResourcePath base = item.getKey().withPath(basePath);
                List<Entry> contents = indexed.getOrDefault(base, List.of());
                for (Entry metadata : item.getValue()) {
                    boolean paired = contents.stream().anyMatch(content ->
                            content.pack.order == metadata.pack.order
                                    && content.resource.sourceId().equals(metadata.resource.sourceId())
                                    && content.resource.sourceOrder() == metadata.resource.sourceOrder());
                    if (!paired) throw problem(ResourceProblem.Code.INVALID_METADATA,
                            metadata.resource.physicalSource(), "Orphan metadata for " + base);
                }
            }
        }

        private void resolveMetadata(ResourcePath path, List<ManagedResource> resources) {
            ResourceType<?> type = matchingType(path);
            LinkedHashSet<MetadataSectionType<?>> allowed = new LinkedHashSet<>();
            if (type != null) {
                allowed.addAll(type.optionalMetadata());
                allowed.addAll(type.requiredMetadata());
            }
            Map<Identifier, MetadataSectionType<?>> registered = new LinkedHashMap<>();
            for (MetadataSectionType<?> section : allowed) registered.put(section.id(), section);

            for (ManagedResource resource : resources) {
                LinkedHashMap<MetadataSectionType<?>, ResolvedMetadata<?>> local = new LinkedHashMap<>();
                LinkedHashMap<Identifier, MetadataValue> preserved = new LinkedHashMap<>();
                for (Map.Entry<Identifier, RawSection> raw : resource.rawSections.entrySet()) {
                    MetadataSectionType<?> section = registered.get(raw.getKey());
                    if (section == null) {
                        if (unknownPolicy == UnknownMetadataPolicy.REJECT) {
                            throw problem(ResourceProblem.Code.UNKNOWN_METADATA_SECTION,
                                    raw.getValue().source, "Unknown metadata section " + raw.getKey());
                        }
                        preserved.put(raw.getKey(), raw.getValue().data);
                    } else {
                        Object value = decode(section, raw.getValue());
                        local.put(section, new ResolvedMetadata<>(value, List.of(resource.origin)));
                    }
                }
                resource.metadata = new ResourceMetadata(local, preserved);
            }

            if (type == null || resources.isEmpty()) return;
            ManagedResource selected = resources.getLast();
            LinkedHashMap<MetadataSectionType<?>, ResolvedMetadata<?>> resolved = new LinkedHashMap<>();
            for (MetadataSectionType<?> section : allowed) {
                ResolvedMetadata<?> value = resolveSection(section, resources);
                if (value != null) resolved.put(section, value);
            }
            for (MetadataSectionType<?> required : type.requiredMetadata()) {
                if (!resolved.containsKey(required)) throw problem(ResourceProblem.Code.MISSING_METADATA,
                        selected.origin.path().value(), "Missing required metadata section " + required.id());
            }
            selected.metadata = new ResourceMetadata(resolved, selected.metadata.preservedSections());
        }

        private <T> ResolvedMetadata<T> resolveSection(
                MetadataSectionType<T> section, List<ManagedResource> resources
        ) {
            if (section.layerPolicy() == MetadataLayerPolicy.LOCAL_ONLY) {
                return resources.getLast().metadata.find(section).orElse(null);
            }
            if (section.layerPolicy() == MetadataLayerPolicy.INHERIT_IF_ABSENT) {
                for (ManagedResource resource : resources.reversed()) {
                    Optional<ResolvedMetadata<T>> found = resource.metadata.find(section);
                    if (found.isPresent()) return found.orElseThrow();
                }
                return null;
            }
            ArrayList<MetadataContribution<T>> contributions = new ArrayList<>();
            for (ManagedResource resource : resources) {
                resource.metadata.find(section).ifPresent(value -> contributions.add(
                        new MetadataContribution<>(value.value(), resource.origin)));
            }
            if (contributions.isEmpty()) return null;
            try {
                T merged = section.merger().orElseThrow().merge(List.copyOf(contributions));
                if (!section.valueType().isInstance(merged)) throw new IllegalArgumentException("Metadata merger returned wrong type");
                return new ResolvedMetadata<>(merged,
                        contributions.stream().map(MetadataContribution::origin).toList());
            } catch (Exception exception) {
                throw problem(ResourceProblem.Code.LOAD_FAILURE, section.id().value(),
                        "Metadata merge failed for " + section.id() + ": " + exception.getMessage(), exception);
            }
        }

        private Object decode(MetadataSectionType<?> type, RawSection raw) {
            if (!type.supportedVersions().contains(raw.version)) {
                throw problem(ResourceProblem.Code.UNSUPPORTED_METADATA_VERSION, raw.source,
                        "Unsupported version " + raw.version + " for " + type.id());
            }
            try {
                Object value = type.decoder().decode(new MetadataSectionInput(
                        type.id(), raw.version, raw.data, raw.source));
                if (!type.valueType().isInstance(value)) throw new IllegalArgumentException("Decoder returned wrong type");
                return value;
            } catch (ResourceException exception) {
                throw exception;
            } catch (Exception exception) {
                throw problem(ResourceProblem.Code.LOAD_FAILURE, raw.source,
                        "Metadata decode failed for " + type.id() + ": " + exception.getMessage(), exception);
            }
        }

        private ResourceType<?> matchingType(ResourcePath path) {
            ResourceType<?> match = null;
            for (ResourceType<?> type : types) {
                if (type.pathPattern().reverse(path).isEmpty()) continue;
                if (match != null) throw problem(ResourceProblem.Code.TYPE_MISMATCH, path.value(),
                        "Resource path matches multiple types: " + match.id() + " and " + type.id());
                match = type;
            }
            return match;
        }

        private static int integer(MetadataValue value, String label) {
            if (!(value instanceof MetadataValue.NumberValue number)) {
                throw new IllegalArgumentException(label + " must be an integer");
            }
            try { return number.value().intValueExact(); }
            catch (ArithmeticException exception) { throw new IllegalArgumentException(label + " must be an integer", exception); }
        }

        private static boolean isMetadataPath(ResourcePath path) {
            return path.path().endsWith(".meta.json");
        }

        Optional<Resource> find(ResourcePath path) {
            List<ManagedResource> values = stacks.get(Objects.requireNonNull(path, "path"));
            return values == null ? Optional.empty() : Optional.of(values.getLast());
        }

        Resource require(ResourcePath path) {
            return find(path).orElseThrow(() -> problem(ResourceProblem.Code.MISSING_RESOURCE,
                    path.value(), "Missing resource " + path));
        }

        Optional<ResolvedResource> findResolved(ResourcePath path) {
            List<ManagedResource> values = stacks.get(Objects.requireNonNull(path, "path"));
            if (values == null) return Optional.empty();
            List<Resource> shadowed = values.size() <= 1 ? List.of()
                    : new ArrayList<Resource>(values.subList(0, values.size() - 1)).reversed();
            return Optional.of(new ResolvedResource(values.getLast(), shadowed));
        }

        List<Resource> stack(ResourcePath path) {
            List<ManagedResource> values = stacks.get(Objects.requireNonNull(path, "path"));
            if (values == null) return List.of();
            return List.copyOf(new ArrayList<Resource>(values).reversed());
        }

        Map<ResourcePath, Resource> list(String prefix, Predicate<ResourcePath> filter, boolean ignored) {
            validatePrefix(prefix);
            Objects.requireNonNull(filter, "filter");
            TreeMap<ResourcePath, Resource> result = new TreeMap<>();
            stacks.forEach((path, values) -> {
                if (path.path().startsWith(prefix) && filter.test(path)) result.put(path, values.getLast());
            });
            return Collections.unmodifiableMap(result);
        }

        Map<ResourcePath, List<Resource>> listStacks(String prefix, Predicate<ResourcePath> filter) {
            validatePrefix(prefix);
            Objects.requireNonNull(filter, "filter");
            TreeMap<ResourcePath, List<Resource>> result = new TreeMap<>();
            stacks.forEach((path, values) -> {
                if (path.path().startsWith(prefix) && filter.test(path)) {
                    result.put(path, List.copyOf(new ArrayList<Resource>(values).reversed()));
                }
            });
            return Collections.unmodifiableMap(result);
        }

        private static void validatePrefix(String prefix) {
            Objects.requireNonNull(prefix, "prefix");
            if (prefix.indexOf('\\') >= 0 || prefix.startsWith("/") || prefix.contains("..")) {
                throw new IllegalArgumentException("Invalid resource prefix " + prefix);
            }
        }

        @SuppressWarnings("unchecked")
        <T> LoadedResource<T> load(ResourceKey<T> key) {
            Objects.requireNonNull(key, "key");
            if (key.type().domain() != domain) throw new IllegalArgumentException(
                    "Resource key uses domain " + key.type().domain() + " in " + domain + " manager");
            ResourceType<?> registered = types.stream()
                    .filter(type -> type.id().equals(key.type().id()))
                    .findFirst()
                    .orElseThrow(() -> problem(
                            ResourceProblem.Code.TYPE_MISMATCH,
                            key.type().id().value(),
                            "Resource type is not registered in this snapshot: "
                                    + key.type().id()));
            if (registered != key.type()) {
                throw problem(
                        ResourceProblem.Code.TYPE_MISMATCH,
                        key.type().id().value(),
                        "Resource key does not use the registered type instance: "
                                + key.type().id());
            }
            decodeLock.lock();
            try {
                ResourceException priorFailure = failureCache.get(key);
                if (priorFailure != null) throw priorFailure;
                Object prior = cache.get(key);
                if (prior != null) return (LoadedResource<T>) prior;
                Deque<ResourceKey<?>> path = dependencyPath.get();
                if (path.contains(key)) {
                    ArrayList<String> cycle = new ArrayList<>();
                    boolean record = false;
                    for (ResourceKey<?> item : path) {
                        if (item.equals(key)) record = true;
                        if (record) cycle.add(item.type().id() + "/" + item.id());
                    }
                    cycle.add(key.type().id() + "/" + key.id());
                    ResourceException failure = problem(ResourceProblem.Code.DEPENDENCY_CYCLE,
                            key.id().value(), "Resource dependency cycle: " + String.join(" -> ", cycle));
                    failureCache.put(key, failure);
                    throw failure;
                }
                path.addLast(key);
                try {
                    LoadedResource<T> loaded = decode(key);
                    cache.put(key, loaded);
                    return loaded;
                } catch (ResourceException exception) {
                    failureCache.put(key, exception);
                    throw exception;
                } catch (RuntimeException exception) {
                    ResourceException failure = problem(ResourceProblem.Code.LOAD_FAILURE,
                            key.id().value(), "Resource load failed: " + exception.getMessage(), exception);
                    failureCache.put(key, failure);
                    throw failure;
                } finally {
                    path.removeLast();
                    if (path.isEmpty()) dependencyPath.remove();
                }
            } finally {
                decodeLock.unlock();
            }
        }

        private <T> LoadedResource<T> decode(ResourceKey<T> key) {
            List<ManagedResource> values = stacks.get(key.path());
            if (values == null || values.isEmpty()) throw problem(ResourceProblem.Code.MISSING_RESOURCE,
                    key.id().value(), "Missing resource " + key.path());
            LoadContext context = new LoadContext(this);
            try {
                T value;
                List<ResourceOrigin> origins;
                ResourceMetadata metadata = values.getLast().metadata;
                if (key.type().resolutionMode() == ResourceResolutionMode.REPLACE) {
                    ManagedResource selected = values.getLast();
                    value = key.type().loader().orElseThrow()
                            .load(context, selected);
                    origins = List.of(selected.origin);
                } else {
                    List<Resource> inputs = List.copyOf(values);
                    value = key.type().layeredLoader().orElseThrow()
                            .load(context, inputs);
                    origins = values.stream().map(resource -> resource.origin).toList();
                }
                if (!key.type().valueType().isInstance(value)) throw problem(
                        ResourceProblem.Code.TYPE_MISMATCH, key.id().value(),
                        "Loader returned " + (value == null ? "null" : value.getClass().getName())
                                + " for " + key.type().valueType().getName());
                return new LoadedResource<>(key, value, generation, origins, metadata);
            } catch (ResourceException exception) {
                throw exception;
            } catch (Exception exception) {
                throw problem(ResourceProblem.Code.LOAD_FAILURE, key.id().value(),
                        "Loader failed for " + key.id() + ": " + exception.getMessage(), exception);
            }
        }

        void retain() {
            while (true) {
                int current = references.get();
                if (current == 0) throw new IllegalStateException("Resource generation is closed");
                if (references.compareAndSet(current, current + 1)) return;
            }
        }

        void release() {
            int remaining = references.decrementAndGet();
            if (remaining < 0) throw new IllegalStateException("Resource generation lease underflow");
            if (remaining == 0 && closed.compareAndSet(false, true)) closeOpened(packs);
        }

        private record Entry(OpenedPack pack, PackResource resource) { }
        private record RawSection(int version, MetadataValue.ObjectValue data, String source) { }

        private static final class ManagedResource implements Resource {
            private final State state;
            private final PackResource source;
            private final ResourceOrigin origin;
            private final Map<Identifier, RawSection> rawSections;
            private ResourceMetadata metadata = ResourceMetadata.EMPTY;

            private ManagedResource(State state, PackResource source, ResourceOrigin origin,
                                    Map<Identifier, RawSection> rawSections) {
                this.state = state;
                this.source = source;
                this.origin = origin;
                this.rawSections = rawSections;
            }

            @Override public ResourcePath path() { return source.path(); }
            @Override public ResourceOrigin origin() { return origin; }
            @Override public ResourceMetadata metadata() { return metadata; }
            @Override public OptionalLong size() { return source.size(); }

            @Override
            public InputStream openStream() throws IOException {
                state.retain();
                try {
                    InputStream input = source.streamSupplier().open();
                    return new FilterInputStream(input) {
                        private final AtomicBoolean released = new AtomicBoolean();
                        @Override public void close() throws IOException {
                            try { super.close(); }
                            finally { if (released.compareAndSet(false, true)) state.release(); }
                        }
                    };
                } catch (IOException | RuntimeException exception) {
                    state.release();
                    throw exception;
                }
            }
        }

        private static final class LoadContext implements ResourceLoadContext {
            private final State state;
            private LoadContext(State state) { this.state = state; }
            @Override public long generation() { return state.generation; }
            @Override public <T> LoadedResource<T> load(ResourceKey<T> key) { return state.load(key); }
            @Override public Optional<Resource> findRaw(ResourcePath path) { return state.find(path); }
            @Override public List<Resource> rawStack(ResourcePath path) { return state.stack(path); }
        }
    }
}

package io.github.juloass.resource.pack;

/** Failure while an explicit provider discovers pack candidates. */
public final class ResourcePackDiscoveryException extends Exception {
    public ResourcePackDiscoveryException(String message, Throwable cause) {
        super(message, cause);
    }

    public ResourcePackDiscoveryException(String message) {
        super(message);
    }
}

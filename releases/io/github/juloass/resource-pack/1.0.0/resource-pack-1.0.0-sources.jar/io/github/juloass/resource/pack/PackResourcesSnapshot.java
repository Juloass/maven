package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;

import java.io.IOException;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

/** Provides a stable logical view of one resource source. */
public interface PackResourcesSnapshot extends AutoCloseable {
    Identifier sourceId();

    Set<String> namespaces(ResourceDomain domain);

    Optional<PackResource> find(ResourcePath path);

    void list(
            ResourceDomain domain,
            String namespace,
            String prefix,
            PackResourceConsumer consumer
    );

    default Set<ResourcePath> paths(ResourceDomain domain) {
        TreeSet<ResourcePath> paths = new TreeSet<>();
        for (String namespace : namespaces(domain)) {
            list(domain, namespace, "", resource -> paths.add(resource.path()));
        }
        return Collections.unmodifiableSet(paths);
    }

    @Override
    void close() throws IOException;
}
package io.github.juloass.resource.pack;

import java.util.List;

/** Explicit source of immutable resource pack candidates. */
@FunctionalInterface
public interface ResourcePackProvider {
    List<ResourcePackCandidate> resourcePacks() throws ResourcePackDiscoveryException;
}

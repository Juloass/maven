package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/** Combines logical sources in explicit low-to-high order. */
public final class CompositePackResources implements PackResources {
    private final Identifier sourceId;
    private final List<PackResources> sources;

    private CompositePackResources(
            Identifier sourceId,
            List<PackResources> sources
    ) {
        this.sourceId = sourceId;
        this.sources = List.copyOf(sources);
    }

    public static Builder builder(Identifier sourceId) {
        return new Builder(sourceId);
    }

    @Override
    public Identifier sourceId() {
        return sourceId;
    }

    @Override
    public PackResourcesSnapshot openSnapshot() throws IOException {
        ArrayList<PackResourcesSnapshot> opened = new ArrayList<>();
        try {
            for (PackResources source : sources) {
                opened.add(source.openSnapshot());
            }
            return new Snapshot(sourceId, opened);
        } catch (IOException | RuntimeException exception) {
            for (PackResourcesSnapshot snapshot : opened.reversed()) {
                try {
                    snapshot.close();
                } catch (IOException closeFailure) {
                    exception.addSuppressed(closeFailure);
                }
            }
            throw exception;
        }
    }

    public static final class Builder {
        private final Identifier sourceId;
        private final List<PackResources> sources = new ArrayList<>();

        private Builder(Identifier sourceId) {
            this.sourceId = Objects.requireNonNull(sourceId, "sourceId");
        }

        public Builder addLower(PackResources source) {
            sources.addFirst(Objects.requireNonNull(source, "source"));
            return this;
        }

        public Builder addHigher(PackResources source) {
            sources.add(Objects.requireNonNull(source, "source"));
            return this;
        }

        public CompositePackResources build() {
            if (sources.isEmpty()) {
                throw new IllegalStateException(
                        "A composite pack needs a source");
            }
            LinkedHashSet<Identifier> ids = new LinkedHashSet<>();
            for (PackResources source : sources) {
                if (!ids.add(source.sourceId())) {
                    throw new IllegalArgumentException(
                            "Duplicate source identifier "
                                    + source.sourceId());
                }
            }
            return new CompositePackResources(sourceId, sources);
        }
    }

    private static final class Snapshot
            implements PackResourcesSnapshot {
        private final Identifier sourceId;
        private final List<PackResourcesSnapshot> sources;

        private Snapshot(
                Identifier sourceId,
                List<PackResourcesSnapshot> sources
        ) {
            this.sourceId = sourceId;
            this.sources = List.copyOf(sources);
        }

        @Override
        public Identifier sourceId() {
            return sourceId;
        }

        @Override
        public Set<String> namespaces(ResourceDomain domain) {
            java.util.TreeSet<String> values = new java.util.TreeSet<>();
            sources.forEach(source ->
                    values.addAll(source.namespaces(domain)));
            return java.util.Collections.unmodifiableSet(values);
        }

        @Override
        public Optional<PackResource> find(ResourcePath path) {
            for (int index = sources.size() - 1;
                 index >= 0;
                 index--) {
                Optional<PackResource> found =
                        sources.get(index).find(path);
                if (found.isPresent()) {
                    return Optional.of(found.orElseThrow().inComposite(
                            sourceId, index));
                }
            }
            return Optional.empty();
        }

        @Override
        public void list(
                ResourceDomain domain,
                String namespace,
                String prefix,
                PackResourceConsumer consumer
        ) {
            Objects.requireNonNull(consumer, "consumer");
            for (int index = 0; index < sources.size(); index++) {
                PackResourcesSnapshot source = sources.get(index);
                int sourceOrder = index;
                source.list(
                        domain,
                        namespace,
                        prefix,
                        resource -> consumer.accept(
                                resource.inComposite(
                                        sourceId, sourceOrder)));
            }
        }

        @Override
        public void close() throws IOException {
            IOException failure = null;
            for (PackResourcesSnapshot source : sources.reversed()) {
                try {
                    source.close();
                } catch (IOException exception) {
                    if (failure == null) {
                        failure = exception;
                    } else {
                        failure.addSuppressed(exception);
                    }
                }
            }
            if (failure != null) {
                throw failure;
            }
        }
    }
}
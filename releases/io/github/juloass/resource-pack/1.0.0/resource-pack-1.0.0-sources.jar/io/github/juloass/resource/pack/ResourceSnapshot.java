package io.github.juloass.resource.pack;

import io.github.juloass.resource.LoadedResource;
import io.github.juloass.resource.ResolvedResource;
import io.github.juloass.resource.Resource;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourceKey;
import io.github.juloass.resource.ResourcePath;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

/** Leased immutable view of one complete resource generation. */
public final class ResourceSnapshot implements AutoCloseable {
    private final ResourceManager.State state;
    private final AtomicBoolean closed = new AtomicBoolean();

    ResourceSnapshot(ResourceManager.State state) {
        this.state = state;
        state.retain();
    }

    public ResourceDomain domain() { requireOpen(); return state.domain(); }
    public long generation() { requireOpen(); return state.generation(); }
    public Set<String> namespaces() { requireOpen(); return state.namespaces(); }
    public Optional<Resource> findResource(ResourcePath path) { requireOpen(); return state.find(path); }
    public Resource requireResource(ResourcePath path) { requireOpen(); return state.require(path); }
    public Optional<ResolvedResource> findResolved(ResourcePath path) { requireOpen(); return state.findResolved(path); }
    public List<Resource> resourceStack(ResourcePath path) { requireOpen(); return state.stack(path); }
    public Map<ResourcePath, Resource> listResources(String prefix, Predicate<ResourcePath> filter) {
        requireOpen(); return state.list(prefix, filter, false);
    }
    public Map<ResourcePath, List<Resource>> listResourceStacks(String prefix, Predicate<ResourcePath> filter) {
        requireOpen(); return state.listStacks(prefix, filter);
    }
    public <T> LoadedResource<T> load(ResourceKey<T> key) { requireOpen(); return state.load(key); }

    private void requireOpen() {
        if (closed.get()) throw new IllegalStateException("Resource snapshot is closed");
    }

    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) state.release();
    }
}

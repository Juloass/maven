package io.github.juloass.resource.pack;

/** Receives one indexed pack entry. */
@FunctionalInterface
public interface PackResourceConsumer {
    void accept(PackResource resource);
}

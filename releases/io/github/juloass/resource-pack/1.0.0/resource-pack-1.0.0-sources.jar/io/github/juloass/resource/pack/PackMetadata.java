package io.github.juloass.resource.pack;

import java.util.Objects;

/** Informational pack format data from {@code pack.json}. */
public record PackMetadata(String description, int format) {
    public PackMetadata {
        Objects.requireNonNull(description, "description");
        if (format < 0) throw new IllegalArgumentException("Pack format must be non-negative");
    }
}

package io.github.juloass.resource.pack;

/** Policy for metadata sections without a registered type. */
public enum UnknownMetadataPolicy {
    REJECT,
    PRESERVE
}

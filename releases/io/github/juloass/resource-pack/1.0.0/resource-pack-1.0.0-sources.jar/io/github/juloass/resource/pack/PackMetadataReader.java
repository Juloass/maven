package io.github.juloass.resource.pack;

import io.github.juloass.resource.MetadataValue;
import io.github.juloass.resource.ResourceException;
import io.github.juloass.resource.ResourceProblem;
import io.github.juloass.resource.json.StrictJson;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Optional;

/** Reads the exact foundation {@code pack.json} format. */
public final class PackMetadataReader {
    public static final long DEFAULT_MAXIMUM_BYTES = 64 * 1024;

    private PackMetadataReader() { }

    public static PackMetadata read(InputStream input, String source) {
        return read(input, DEFAULT_MAXIMUM_BYTES, source);
    }

    public static PackMetadata read(InputStream input, long maximumBytes, String source) {
        try {
            MetadataValue.ObjectValue root = StrictJson.parseObject(input, maximumBytes, source);
            if (!root.values().keySet().equals(java.util.Set.of("description", "format"))) {
                throw invalid(source, "pack.json requires only description and format");
            }
            MetadataValue descriptionValue = root.values().get("description");
            MetadataValue formatValue = root.values().get("format");
            if (!(descriptionValue instanceof MetadataValue.StringValue description)) {
                throw invalid(source, "pack.json description must be a string");
            }
            if (!(formatValue instanceof MetadataValue.NumberValue number)) {
                throw invalid(source, "pack.json format must be an integer");
            }
            BigDecimal format = number.value();
            try {
                return new PackMetadata(description.value(), format.intValueExact());
            } catch (ArithmeticException | IllegalArgumentException exception) {
                throw invalid(source, "pack.json format must be a non-negative integer");
            }
        } catch (ResourceException exception) {
            if (exception.problems().stream().allMatch(problem ->
                    problem.code() == ResourceProblem.Code.INVALID_PACK)) {
                throw exception;
            }
            throw new ResourceException(new ResourceProblem(
                    ResourceProblem.Code.INVALID_PACK,
                    source,
                    "Invalid pack.json: " + exception.getMessage(),
                    Optional.empty(),
                    Optional.of(exception)));
        }
    }

    private static ResourceException invalid(String source, String message) {
        return new ResourceException(ResourceProblem.of(
                ResourceProblem.Code.INVALID_PACK, source, message));
    }
}

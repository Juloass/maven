package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.ResourceSourceOrigin;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.OptionalLong;

/** Describes one exact entry inside an opened logical source. */
public record PackResource(
        ResourcePath path,
        OptionalLong size,
        List<ResourceSourceOrigin> sources,
        InputStreamSupplier streamSupplier
) {
    public PackResource {
        Objects.requireNonNull(path, "path");
        size = size == null ? OptionalLong.empty() : size;
        Objects.requireNonNull(sources, "sources");
        sources = List.copyOf(sources);
        Objects.requireNonNull(streamSupplier, "streamSupplier");
        if (size.isPresent() && size.getAsLong() < 0) {
            throw new IllegalArgumentException(
                    "Resource size must be non-negative");
        }
        if (sources.isEmpty()) {
            throw new IllegalArgumentException(
                    "Pack resource requires source provenance");
        }
    }

    public PackResource(
            Identifier sourceId,
            int sourceOrder,
            ResourcePath path,
            OptionalLong size,
            String sourceDescription,
            InputStreamSupplier streamSupplier
    ) {
        this(
                path,
                size,
                List.of(new ResourceSourceOrigin(
                        sourceId, sourceOrder, sourceDescription)),
                streamSupplier);
    }

    public Identifier sourceId() {
        return sources.getLast().sourceId();
    }

    public int sourceOrder() {
        return sources.getLast().sourceOrder();
    }

    public String physicalSource() {
        return sources.getLast().sourceDescription();
    }

    public PackResource inComposite(
            Identifier compositeId,
            int sourceOrder
    ) {
        ArrayList<ResourceSourceOrigin> provenance = new ArrayList<>();
        provenance.add(new ResourceSourceOrigin(
                compositeId,
                sourceOrder,
                "composite:" + compositeId.value()));
        provenance.addAll(sources);
        return new PackResource(path, size, provenance, streamSupplier);
    }
}
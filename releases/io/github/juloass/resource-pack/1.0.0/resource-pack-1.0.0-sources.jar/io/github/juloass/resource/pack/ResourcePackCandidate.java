package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;

import java.util.Objects;

/** One game-supplied pack candidate. */
public record ResourcePackCandidate(
        Identifier id,
        PackMetadata metadata,
        PackResources resources
) {
    public ResourcePackCandidate {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(metadata, "metadata");
        Objects.requireNonNull(resources, "resources");
    }
}

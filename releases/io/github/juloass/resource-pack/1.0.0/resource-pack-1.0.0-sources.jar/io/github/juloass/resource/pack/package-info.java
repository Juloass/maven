/** Pack ordering, provenance, typed loading, snapshots, and atomic reloads. */
package io.github.juloass.resource.pack;

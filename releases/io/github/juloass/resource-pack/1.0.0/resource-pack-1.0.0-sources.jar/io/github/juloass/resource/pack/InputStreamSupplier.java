package io.github.juloass.resource.pack;

import java.io.IOException;
import java.io.InputStream;

/** Opens one independent resource stream. */
@FunctionalInterface
public interface InputStreamSupplier {
    InputStream open() throws IOException;
}

package io.github.juloass.resource.pack;

import io.github.juloass.resource.ResourceProblem;

import java.util.List;

/** Result of one atomic reload attempt. */
public record ResourceReloadResult(
        long previousGeneration,
        long activeGeneration,
        boolean replaced,
        List<ResourceProblem> problems
) {
    public ResourceReloadResult {
        if (previousGeneration < 0 || activeGeneration < 0) {
            throw new IllegalArgumentException("Generations must be non-negative");
        }
        problems = List.copyOf(problems);
    }
}

package io.github.juloass.resource.pack;

import io.github.juloass.identifier.Identifier;

import java.io.IOException;

/** Opens stable logical snapshots for one resource source. */
public interface PackResources {
    Identifier sourceId();

    PackResourcesSnapshot openSnapshot() throws IOException;
}
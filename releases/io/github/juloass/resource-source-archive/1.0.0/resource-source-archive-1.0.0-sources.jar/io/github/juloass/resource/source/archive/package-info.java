/** Data-only resource packs backed by ZIP and JAR containers. */
package io.github.juloass.resource.source.archive;

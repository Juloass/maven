package io.github.juloass.resource.source.archive;

/** Configurable archive expansion limits. */
public record ArchiveLimits(
        long maximumEntryBytes,
        long maximumTotalBytes,
        double maximumCompressionRatio
) {
    public static final ArchiveLimits DEFAULT = new ArchiveLimits(
            256L * 1024 * 1024,
            2L * 1024 * 1024 * 1024,
            200.0);

    public ArchiveLimits {
        if (maximumEntryBytes < 0 || maximumTotalBytes < 0
                || !Double.isFinite(maximumCompressionRatio) || maximumCompressionRatio < 1.0) {
            throw new IllegalArgumentException("Archive limits must be finite and non-negative");
        }
    }
}

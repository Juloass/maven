package io.github.juloass.resource.source.archive;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.pack.PackMetadata;
import io.github.juloass.resource.pack.PackMetadataReader;
import io.github.juloass.resource.pack.PackResource;
import io.github.juloass.resource.pack.PackResourceConsumer;
import io.github.juloass.resource.pack.PackResources;
import io.github.juloass.resource.pack.PackResourcesSnapshot;
import io.github.juloass.resource.pack.ResourcePackCandidate;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** JAR and ZIP pack source that never loads Java classes. */
public final class ArchivePackResources implements PackResources {
    private final Identifier sourceId;
    private final Path archive;
    private final ArchiveLimits limits;

    public ArchivePackResources(Identifier sourceId, Path archive) {
        this(sourceId, archive, ArchiveLimits.DEFAULT);
    }

    public ArchivePackResources(Identifier sourceId, Path archive, ArchiveLimits limits) {
        this.sourceId = Objects.requireNonNull(sourceId, "sourceId");
        this.archive = Objects.requireNonNull(archive, "archive").toAbsolutePath().normalize();
        this.limits = Objects.requireNonNull(limits, "limits");
    }

    public static ResourcePackCandidate candidate(
            Identifier packId, Identifier sourceId, Path archive
    ) throws IOException {
        ArchivePackResources resources = new ArchivePackResources(sourceId, archive);
        PackMetadata metadata = readMetadata(archive);
        return new ResourcePackCandidate(packId, metadata, resources);
    }


    private static PackMetadata readMetadata(Path archive)
            throws IOException {
        try (ZipFile zip = new ZipFile(archive.toFile())) {
            ZipEntry descriptor = zip.getEntry("pack.json");
            if (descriptor == null || descriptor.isDirectory()) {
                throw new IOException(
                        "Archive has no pack.json: " + archive);
            }
            try (InputStream input = zip.getInputStream(descriptor)) {
                return PackMetadataReader.read(
                        input, archive + "!/pack.json");
            }
        }
    }

    @Override
    public Identifier sourceId() {
        return sourceId;
    }

    @Override
    public PackResourcesSnapshot openSnapshot() throws IOException {
        if (!Files.isRegularFile(archive)) throw new IOException("Archive does not exist: " + archive);
        ZipFile zip = new ZipFile(archive.toFile());
        try {
            EnumMap<ResourceDomain, Map<ResourcePath, ZipEntry>> indexed = new EnumMap<>(ResourceDomain.class);
            for (ResourceDomain domain : ResourceDomain.values()) indexed.put(domain, new TreeMap<>());
            TreeSet<String> exactNames = new TreeSet<>();
            LinkedHashMap<String, String> caseNames = new LinkedHashMap<>();
            long total = 0;
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;
                String name = entry.getName();
                if (!exactNames.add(name)) {
                    throw new IOException("Archive has a duplicate entry: " + name);
                }
                validateArchiveName(name);
                String folded = name.toLowerCase(Locale.ROOT);
                String priorCase = caseNames.putIfAbsent(folded, name);
                if (priorCase != null && !priorCase.equals(name)) {
                    throw new IOException("Archive has a case collision: " + priorCase + " and " + name);
                }
                ResourceDomain domain = domain(name);
                if (domain == null) continue;
                long size = entry.getSize();
                if (size < 0) throw new IOException("Archive entry has unknown expanded size: " + name);
                if (size > limits.maximumEntryBytes()) throw new IOException("Archive entry exceeds size limit: " + name);
                total = Math.addExact(total, size);
                if (total > limits.maximumTotalBytes()) throw new IOException("Archive exceeds total size limit");
                long compressed = entry.getCompressedSize();
                if (compressed == 0 && size > 0 || compressed > 0 && (double) size / compressed > limits.maximumCompressionRatio()) {
                    throw new IOException("Archive entry exceeds compression ratio limit: " + name);
                }
                String relative = name.substring(domain.directory().length() + 1);
                int separator = relative.indexOf('/');
                if (separator <= 0 || separator == relative.length() - 1) {
                    throw new IOException("Archive resource needs namespace and path: " + name);
                }
                ResourcePath path;
                try { path = ResourcePath.of(
                        domain,
                        relative.substring(0, separator),
                        relative.substring(separator + 1)); }
                catch (IllegalArgumentException exception) { throw new IOException("Invalid archive resource " + name, exception); }
                if (indexed.get(domain).putIfAbsent(path, entry) != null) {
                    throw new IOException("Duplicate archive resource " + path);
                }
            }
            if (indexed.values().stream().allMatch(Map::isEmpty)) throw new IOException("Archive contains no assets or data");
            return new Snapshot(sourceId, archive, zip, indexed);
        } catch (IOException | RuntimeException exception) {
            zip.close();
            throw exception;
        }
    }

    private static ResourceDomain domain(String name) {
        if (name.startsWith("assets/")) return ResourceDomain.ASSETS;
        if (name.startsWith("data/")) return ResourceDomain.DATA;
        return null;
    }

    private static void validateArchiveName(String name) throws IOException {
        if (name.isEmpty() || name.startsWith("/") || name.startsWith("\\") || name.indexOf('\\') >= 0) {
            throw new IOException("Invalid archive entry path: " + name);
        }
        for (String segment : name.split("/", -1)) {
            if (segment.isEmpty() || segment.equals(".") || segment.equals("..")) {
                throw new IOException("Invalid archive entry path: " + name);
            }
        }
    }

    private static final class Snapshot implements PackResourcesSnapshot {
        private final Identifier sourceId;
        private final Path archive;
        private final ZipFile zip;
        private final Map<ResourceDomain, Map<ResourcePath, ZipEntry>> indexed;
        private final AtomicBoolean closed = new AtomicBoolean();

        private Snapshot(Identifier sourceId, Path archive, ZipFile zip,
                         Map<ResourceDomain, Map<ResourcePath, ZipEntry>> indexed) {
            this.sourceId = sourceId;
            this.archive = archive;
            this.zip = zip;
            EnumMap<ResourceDomain, Map<ResourcePath, ZipEntry>> copy = new EnumMap<>(ResourceDomain.class);
            indexed.forEach((domain, values) -> copy.put(domain, Collections.unmodifiableMap(new TreeMap<>(values))));
            this.indexed = Collections.unmodifiableMap(copy);
        }

        private static PackMetadata readMetadata(Path archive)
            throws IOException {
        try (ZipFile zip = new ZipFile(archive.toFile())) {
            ZipEntry descriptor = zip.getEntry("pack.json");
            if (descriptor == null || descriptor.isDirectory()) {
                throw new IOException(
                        "Archive has no pack.json: " + archive);
            }
            try (InputStream input = zip.getInputStream(descriptor)) {
                return PackMetadataReader.read(
                        input, archive + "!/pack.json");
            }
        }
    }

    @Override
    public Identifier sourceId() {
        return sourceId;
    }

        @Override
        public Set<String> namespaces(ResourceDomain domain) {
            requireOpen();
            TreeSet<String> values = new TreeSet<>();
            indexed.getOrDefault(domain, Map.of()).keySet().forEach(path -> values.add(path.namespace()));
            return Collections.unmodifiableSet(values);
        }

        @Override
        public Optional<PackResource> find(ResourcePath path) {
            requireOpen();
            ZipEntry entry = indexed.getOrDefault(
                    path.domain(), Map.of()).get(path);
            return entry == null ? Optional.empty() : Optional.of(resource(path, entry));
        }

        @Override
        public void list(ResourceDomain domain, String namespace, String prefix, PackResourceConsumer consumer) {
            requireOpen();
            indexed.getOrDefault(domain, Map.of()).forEach((path, entry) -> {
                if (path.namespace().equals(namespace) && path.path().startsWith(prefix)) consumer.accept(resource(path, entry));
            });
        }

        private PackResource resource(ResourcePath path, ZipEntry entry) {
            return new PackResource(sourceId, 0, path, OptionalLong.of(entry.getSize()), archive + "!/" + entry.getName(),
                    () -> { requireOpen(); return zip.getInputStream(entry); });
        }

        private void requireOpen() {
            if (closed.get()) throw new IllegalStateException("Archive pack snapshot is closed");
        }

        @Override
        public void close() throws IOException {
            if (closed.compareAndSet(false, true)) zip.close();
        }
    }
}

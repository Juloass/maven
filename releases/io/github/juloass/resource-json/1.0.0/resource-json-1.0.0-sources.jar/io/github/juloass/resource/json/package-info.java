/** Strict JSON support that exposes only foundation-owned value types. */
package io.github.juloass.resource.json;

package io.github.juloass.resource.json;

import com.google.gson.Strictness;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import io.github.juloass.resource.MetadataValue;
import io.github.juloass.resource.ResourceException;
import io.github.juloass.resource.ResourceProblem;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/** Strict JSON parsing that exposes only foundation-owned value types. */
public final class StrictJson {
    private StrictJson() { }

    public static MetadataValue parse(InputStream input, long maximumBytes, String source) {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(source, "source");
        if (maximumBytes < 0 || maximumBytes >= Integer.MAX_VALUE) {
            throw new IllegalArgumentException("maximumBytes must fit a Java byte array");
        }
        try {
            byte[] bytes = readLimited(input, maximumBytes, source);
            int offset = bytes.length >= 3 && (bytes[0] & 0xff) == 0xef
                    && (bytes[1] & 0xff) == 0xbb && (bytes[2] & 0xff) == 0xbf ? 3 : 0;
            try (JsonReader reader = new JsonReader(new InputStreamReader(
                    new ByteArrayInputStream(bytes, offset, bytes.length - offset), StandardCharsets.UTF_8))) {
                reader.setStrictness(Strictness.STRICT);
                MetadataValue result = readValue(reader, source);
                if (reader.peek() != JsonToken.END_DOCUMENT) {
                    throw failure(source, "Trailing JSON content at " + reader.getPath(), null);
                }
                return result;
            }
        } catch (ResourceException exception) {
            throw exception;
        } catch (IOException | RuntimeException exception) {
            throw failure(source, "Invalid JSON: " + exception.getMessage(), exception);
        }
    }

    public static MetadataValue.ObjectValue parseObject(
            InputStream input, long maximumBytes, String source
    ) {
        MetadataValue value = parse(input, maximumBytes, source);
        if (!(value instanceof MetadataValue.ObjectValue object)) {
            throw failure(source, "JSON root must be an object", null);
        }
        return object;
    }

    private static MetadataValue readValue(JsonReader reader, String source) throws IOException {
        return switch (reader.peek()) {
            case BEGIN_OBJECT -> readObject(reader, source);
            case BEGIN_ARRAY -> readArray(reader, source);
            case STRING -> new MetadataValue.StringValue(reader.nextString());
            case NUMBER -> new MetadataValue.NumberValue(new BigDecimal(reader.nextString()));
            case BOOLEAN -> new MetadataValue.BooleanValue(reader.nextBoolean());
            case NULL -> {
                reader.nextNull();
                yield MetadataValue.NullValue.INSTANCE;
            }
            default -> throw failure(source, "Unexpected JSON token at " + reader.getPath(), null);
        };
    }

    private static MetadataValue.ObjectValue readObject(JsonReader reader, String source) throws IOException {
        LinkedHashMap<String, MetadataValue> values = new LinkedHashMap<>();
        reader.beginObject();
        while (reader.hasNext()) {
            String name = reader.nextName();
            if (values.containsKey(name)) {
                throw failure(source, "Duplicate JSON field '" + name + "' at " + reader.getPath(), null);
            }
            values.put(name, readValue(reader, source));
        }
        reader.endObject();
        return new MetadataValue.ObjectValue(values);
    }

    private static MetadataValue.ArrayValue readArray(JsonReader reader, String source) throws IOException {
        List<MetadataValue> values = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) values.add(readValue(reader, source));
        reader.endArray();
        return new MetadataValue.ArrayValue(values);
    }

    private static byte[] readLimited(InputStream input, long maximumBytes, String source) throws IOException {
        byte[] bytes = input.readNBytes((int) maximumBytes + 1);
        if (bytes.length > maximumBytes) {
            throw failure(source, "JSON exceeds " + maximumBytes + " bytes", null);
        }
        return bytes;
    }

    private static ResourceException failure(String source, String message, Throwable cause) {
        return new ResourceException(new ResourceProblem(
                ResourceProblem.Code.UNSUPPORTED_JSON_SYNTAX,
                source,
                message,
                Optional.empty(),
                Optional.ofNullable(cause)));
    }
}

package io.github.juloass.resource.source.generated;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.pack.InputStreamSupplier;
import io.github.juloass.resource.pack.PackResource;
import io.github.juloass.resource.pack.PackResourceConsumer;
import io.github.juloass.resource.pack.PackResources;
import io.github.juloass.resource.pack.PackResourcesSnapshot;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/** Immutable programmatic pack source with repeatable streams. */
public final class GeneratedPackResources implements PackResources {
    private final Identifier sourceId;
    private final Map<ResourceDomain, Map<ResourcePath, GeneratedEntry>> entries;

    private GeneratedPackResources(
            Identifier sourceId, Map<ResourceDomain, Map<ResourcePath, GeneratedEntry>> entries
    ) {
        this.sourceId = sourceId;
        EnumMap<ResourceDomain, Map<ResourcePath, GeneratedEntry>> copy = new EnumMap<>(ResourceDomain.class);
        entries.forEach((domain, values) -> copy.put(domain, Collections.unmodifiableMap(new TreeMap<>(values))));
        this.entries = Collections.unmodifiableMap(copy);
    }

    public static Builder builder(Identifier sourceId) { return new Builder(sourceId); }
    @Override public Identifier sourceId() { return sourceId; }
    @Override public PackResourcesSnapshot openSnapshot() { return new Snapshot(sourceId, entries); }

    public static final class Builder {
        private final Identifier sourceId;
        private final EnumMap<ResourceDomain, Map<ResourcePath, GeneratedEntry>> entries =
                new EnumMap<>(ResourceDomain.class);

        private Builder(Identifier sourceId) {
            this.sourceId = Objects.requireNonNull(sourceId, "sourceId");
            for (ResourceDomain domain : ResourceDomain.values()) entries.put(domain, new TreeMap<>());
        }

        public Builder add(ResourcePath path, byte[] bytes) {
            Objects.requireNonNull(bytes, "bytes");
            byte[] value = bytes.clone();
            return addEntry(path, new GeneratedEntry(OptionalLong.of(value.length),
                    () -> new ByteArrayInputStream(value)));
        }

        public Builder add(ResourcePath path, InputStreamSupplier supplier) {
            return addEntry(path, new GeneratedEntry(OptionalLong.empty(),
                    Objects.requireNonNull(supplier, "supplier")));
        }

        private Builder addEntry(
                ResourcePath path,
                GeneratedEntry entry
        ) {
            Objects.requireNonNull(path, "path");
            if (entries.get(path.domain()).putIfAbsent(path, entry) != null) {
                throw new IllegalArgumentException("Duplicate generated resource " + path);
            }
            return this;
        }

        public GeneratedPackResources build() {
            if (entries.values().stream().allMatch(Map::isEmpty)) {
                throw new IllegalStateException("Generated pack contains no resources");
            }
            return new GeneratedPackResources(sourceId, entries);
        }
    }

    private record GeneratedEntry(OptionalLong size, InputStreamSupplier supplier) { }

    private static final class Snapshot implements PackResourcesSnapshot {
        private final Identifier sourceId;
        private final Map<ResourceDomain, Map<ResourcePath, GeneratedEntry>> entries;

        private Snapshot(Identifier sourceId,
                         Map<ResourceDomain, Map<ResourcePath, GeneratedEntry>> entries) {
            this.sourceId = sourceId;
            this.entries = entries;
        }

        @Override public Identifier sourceId() { return sourceId; }

        @Override
        public Set<String> namespaces(ResourceDomain domain) {
            TreeSet<String> values = new TreeSet<>();
            entries.getOrDefault(domain, Map.of()).keySet().forEach(path -> values.add(path.namespace()));
            return Collections.unmodifiableSet(values);
        }

        @Override
        public Optional<PackResource> find(ResourcePath path) {
            GeneratedEntry entry = entries.getOrDefault(
                    path.domain(), Map.of()).get(path);
            return entry == null ? Optional.empty() : Optional.of(resource(path, entry));
        }

        @Override
        public void list(ResourceDomain domain, String namespace, String prefix, PackResourceConsumer consumer) {
            entries.getOrDefault(domain, Map.of()).forEach((path, entry) -> {
                if (path.namespace().equals(namespace) && path.path().startsWith(prefix)) consumer.accept(resource(path, entry));
            });
        }

        private PackResource resource(ResourcePath path, GeneratedEntry entry) {
            return new PackResource(sourceId, 0, path, entry.size, "generated:" + sourceId + '/' + path,
                    () -> {
                        InputStream input = entry.supplier.open();
                        if (input == null) throw new IOException("Generated stream supplier returned null: " + path);
                        return input;
                    });
        }

        @Override public void close() { }
    }
}

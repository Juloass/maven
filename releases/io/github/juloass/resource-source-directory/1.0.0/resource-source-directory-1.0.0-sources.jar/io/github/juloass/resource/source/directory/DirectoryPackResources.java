package io.github.juloass.resource.source.directory;

import io.github.juloass.identifier.Identifier;
import io.github.juloass.resource.ResourceDomain;
import io.github.juloass.resource.ResourceException;
import io.github.juloass.resource.ResourcePath;
import io.github.juloass.resource.ResourceProblem;
import io.github.juloass.resource.pack.PackMetadata;
import io.github.juloass.resource.pack.PackMetadataReader;
import io.github.juloass.resource.pack.PackResource;
import io.github.juloass.resource.pack.PackResourceConsumer;
import io.github.juloass.resource.pack.PackResources;
import io.github.juloass.resource.pack.PackResourcesSnapshot;
import io.github.juloass.resource.pack.ResourcePackCandidate;

import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/** Repeatable directory-backed pack source. */
public final class DirectoryPackResources implements PackResources {
    private final Identifier sourceId;
    private final Path root;
    private final SymbolicLinkPolicy symbolicLinkPolicy;

    public DirectoryPackResources(Identifier sourceId, Path root) {
        this(sourceId, root, SymbolicLinkPolicy.REJECT);
    }

    public DirectoryPackResources(
            Identifier sourceId, Path root, SymbolicLinkPolicy symbolicLinkPolicy
    ) {
        this.sourceId = Objects.requireNonNull(sourceId, "sourceId");
        this.root = Objects.requireNonNull(root, "root").toAbsolutePath().normalize();
        this.symbolicLinkPolicy = Objects.requireNonNull(symbolicLinkPolicy, "symbolicLinkPolicy");
    }

    public static ResourcePackCandidate candidate(Identifier packId, Identifier sourceId, Path root)
            throws IOException {
        DirectoryPackResources resources = new DirectoryPackResources(sourceId, root);
        Path descriptor = resources.root.resolve("pack.json");
        PackMetadata metadata;
        try (var input = Files.newInputStream(descriptor)) {
            metadata = PackMetadataReader.read(
                    input, descriptor.toString());
        }
        return new ResourcePackCandidate(packId, metadata, resources);
    }


    @Override public Identifier sourceId() { return sourceId; }

    @Override
    public PackResourcesSnapshot openSnapshot() throws IOException {
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("Pack root is not a directory: " + root);
        }
        Path realRoot = root.toRealPath();
        EnumMap<ResourceDomain, Map<ResourcePath, FileEntry>> indexed = new EnumMap<>(ResourceDomain.class);
        for (ResourceDomain domain : ResourceDomain.values()) {
            Path domainRoot = realRoot.resolve(domain.directory());
            TreeMap<ResourcePath, FileEntry> entries = new TreeMap<>();
            indexed.put(domain, entries);
            if (!Files.exists(domainRoot, LinkOption.NOFOLLOW_LINKS)) continue;
            if (!Files.isDirectory(domainRoot, LinkOption.NOFOLLOW_LINKS)) {
                throw new IOException("Resource domain is not a directory: " + domainRoot);
            }
            FileVisitOption[] options = symbolicLinkPolicy == SymbolicLinkPolicy.FOLLOW_WITHIN_ROOT
                    ? new FileVisitOption[]{FileVisitOption.FOLLOW_LINKS}
                    : new FileVisitOption[0];
            LinkedHashMap<String, String> caseNames = new LinkedHashMap<>();
            try (var paths = Files.walk(domainRoot, Integer.MAX_VALUE, options)) {
                for (Path path : paths.sorted().toList()) {
                    if (path.equals(domainRoot)) continue;
                    if (Files.isSymbolicLink(path) && symbolicLinkPolicy == SymbolicLinkPolicy.REJECT) {
                        throw new IOException("Symbolic link is not allowed: " + path);
                    }
                    if (!Files.isRegularFile(path)) continue;
                    Path real = path.toRealPath();
                    if (!real.startsWith(realRoot)) throw new IOException("Resource escapes pack root: " + path);
                    Path relative = domainRoot.relativize(path);
                    if (relative.getNameCount() < 2) throw new IOException("Resource needs a namespace: " + path);
                    String physicalName = relative.toString().replace('\\', '/');
                    String priorCase = caseNames.putIfAbsent(physicalName.toLowerCase(Locale.ROOT), physicalName);
                    if (priorCase != null && !priorCase.equals(physicalName)) {
                        throw new IOException("Directory has a case collision: "
                                + priorCase + " and " + physicalName);
                    }
                    String namespace = relative.getName(0).toString();
                    String logical = relative.subpath(1, relative.getNameCount()).toString().replace('\\', '/');
                    ResourcePath resourcePath;
                    try { resourcePath = ResourcePath.of(domain, namespace, logical); }
                    catch (IllegalArgumentException exception) { throw new IOException("Invalid resource path " + path, exception); }
                    BasicFileAttributes attributes = Files.readAttributes(real, BasicFileAttributes.class);
                    FileEntry entry = new FileEntry(real, attributes.size(), attributes.lastModifiedTime().toMillis(),
                            attributes.fileKey());
                    if (entries.putIfAbsent(resourcePath, entry) != null) {
                        throw new IOException("Duplicate resource path " + resourcePath);
                    }
                }
            }        }
        boolean empty = indexed.values().stream().allMatch(Map::isEmpty);
        if (empty) throw new IOException("Pack contains no assets or data: " + root);
        return new Snapshot(sourceId, indexed);
    }

    private record FileEntry(Path path, long size, long modifiedMillis, Object fileKey) { }

    private static final class Snapshot implements PackResourcesSnapshot {
        private final Identifier sourceId;
        private final Map<ResourceDomain, Map<ResourcePath, FileEntry>> indexed;

        private Snapshot(Identifier sourceId, Map<ResourceDomain, Map<ResourcePath, FileEntry>> indexed) {
            this.sourceId = sourceId;
            EnumMap<ResourceDomain, Map<ResourcePath, FileEntry>> copy = new EnumMap<>(ResourceDomain.class);
            indexed.forEach((domain, entries) -> copy.put(domain, Collections.unmodifiableMap(new TreeMap<>(entries))));
            this.indexed = Collections.unmodifiableMap(copy);
        }

        @Override public Identifier sourceId() { return sourceId; }

        @Override
        public Set<String> namespaces(ResourceDomain domain) {
            TreeSet<String> values = new TreeSet<>();
            indexed.getOrDefault(domain, Map.of()).keySet().forEach(path -> values.add(path.namespace()));
            return Collections.unmodifiableSet(values);
        }

        @Override
        public Optional<PackResource> find(ResourcePath path) {
            FileEntry entry = indexed.getOrDefault(
                    path.domain(), Map.of()).get(path);
            return entry == null ? Optional.empty() : Optional.of(resource(path, entry));
        }

        @Override
        public void list(ResourceDomain domain, String namespace, String prefix, PackResourceConsumer consumer) {
            Objects.requireNonNull(namespace, "namespace");
            Objects.requireNonNull(prefix, "prefix");
            Objects.requireNonNull(consumer, "consumer");
            indexed.getOrDefault(domain, Map.of()).forEach((path, entry) -> {
                if (path.namespace().equals(namespace) && path.path().startsWith(prefix)) consumer.accept(resource(path, entry));
            });
        }

        private PackResource resource(ResourcePath path, FileEntry entry) {
            return new PackResource(sourceId, 0, path, OptionalLong.of(entry.size), entry.path.toString(), () -> {
                BasicFileAttributes current = Files.readAttributes(entry.path, BasicFileAttributes.class);
                boolean sameKey = Objects.equals(entry.fileKey, current.fileKey());
                if (!sameKey || entry.size != current.size()
                        || entry.modifiedMillis != current.lastModifiedTime().toMillis()) {
                    throw new IOException("Resource changed after snapshot: " + entry.path);
                }
                return Files.newInputStream(entry.path);
            });
        }

        @Override public void close() { }
    }
}

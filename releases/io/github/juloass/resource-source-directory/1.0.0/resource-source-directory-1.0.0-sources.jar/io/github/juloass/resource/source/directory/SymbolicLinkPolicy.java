package io.github.juloass.resource.source.directory;

/** Directory source policy for symbolic links. */
public enum SymbolicLinkPolicy {
    REJECT,
    FOLLOW_WITHIN_ROOT
}

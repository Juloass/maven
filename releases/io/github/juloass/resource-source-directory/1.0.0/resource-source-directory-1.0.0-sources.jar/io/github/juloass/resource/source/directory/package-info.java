/** Resource packs backed by caller-supplied directories. */
package io.github.juloass.resource.source.directory;

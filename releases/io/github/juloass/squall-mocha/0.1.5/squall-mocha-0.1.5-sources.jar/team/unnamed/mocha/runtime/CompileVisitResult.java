/*
 * This file is part of mocha, licensed under the MIT license
 *
 * Copyright (c) 2021-2025 Unnamed Team
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package team.unnamed.mocha.runtime;

import javassist.CtClass;
import org.jetbrains.annotations.Nullable;

final class CompileVisitResult {
    private final CtClass lastPushedType;
    private final boolean returned;

    public CompileVisitResult(final @Nullable CtClass lastPushedType, final boolean returned) {
        this.lastPushedType = lastPushedType;
        this.returned = returned;
    }

    public CompileVisitResult(final @Nullable CtClass lastPushedType) {
        this(lastPushedType, false);
    }

    public boolean returned() {
        return returned;
    }

    public @Nullable CtClass lastPushedType() {
        return lastPushedType;
    }

    public boolean isString() {
        return lastPushedType != null && lastPushedType.getName().equals("java.lang.String");
    }

    public boolean is(final @Nullable CtClass type) {
        return lastPushedType != null && lastPushedType.equals(type);
    }
}
